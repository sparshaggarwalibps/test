package com.newgen.iforms.user;

import com.newgen.iforms.EControl;
import com.newgen.iforms.EControlOption;
import org.json.simple.JSONArray;

import com.newgen.iforms.FormDef;
import com.newgen.iforms.IControl;
import com.newgen.iforms.controls.EComboControl;
import com.newgen.iforms.custom.IFormCustomHooks;
import com.newgen.iforms.custom.IFormReference;

import com.newgen.iforms.custom.IFormServerEventHandler;
import static com.newgen.iforms.user.DolphinUtil.createODxml;
import static com.newgen.iforms.user.DolphinUtil.deleteDirectory;
import static com.newgen.iforms.user.DolphinUtil.getChannelDescFromVal;
import static com.newgen.iforms.user.DolphinUtil.getFileFromBase64;
import static com.newgen.iforms.user.DolphinUtil.getValueFromMaster;
import static com.newgen.iforms.user.DolphinUtil.isAdminEnabled;
import com.newgen.iforms.user.addDocOD.UploadToOmniDocs;
import com.newgen.iforms.user.jsFunctions.JSToJava;
import com.newgen.iforms.user.ulipvalidations.UlipValidator;
import com.newgen.iforms.user.combovalidations.ComboValidator;
import com.newgen.mvcbeans.model.WorkdeskModel;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Dolphin_CommonFunctions extends IFormCustomHooks implements IFormServerEventHandler {

    static final String ADMIN_DISABLE_ERROR_MESSAGE = "Service disbled by Administrator";
    static final String CONFIG_PATH = "CreateWorkitemService\\config.properties";             //using volId from config file	
    public static Properties propertiesFileData;
    //static Logger logger = Logger.getLogger("Dolphin_CommonFunctions");

    public void beforeFormLoad(FormDef arg0, IFormReference iFormRef) {
        // TODO Auto-generated method stub
        //iFormRef.applyGroup("form validations");
        try {
           iFormRef.applyGroup("Dolphin");

            String ActtivityName = "", userName = "", WorkItemName = "", QCquery = "";
            ActtivityName = iFormRef.getActivityName();
            userName = iFormRef.getUserName();

            WorkItemName = (String) iFormRef.getControlValue("WorkItemName");
            String insertQuery = "INSERT INTO NG_NB_USER_ACTION(WI_NAME,ACTIVITY_NAME,USERID,ACTION_DATETIME,ACTION_ID) "
                    + "VALUES('" + WorkItemName + "','" + ActtivityName + "','" + userName + "',GETDATE(),'3')";
            try {
                iFormRef.getDataFromDB(insertQuery);
            } catch (Exception e) {
                System.out.println("Error while Inserting in NG_NB_USER_ACTION " + e.toString());
            }

            //Hiding tags at QC Summary  Start
            QCquery = "SELECT ISNULL(CURR_ADD_PROOF_PROP,'') 'CURR_ADD_PROOF_PROP', ISNULL(ID_DOB_PROOF_PROP,'') 'ID_DOB_PROOF_PROP', "
                    + "ISNULL(INCOME_PROOF_PROP,'') 'INCOME_PROOF_PROP', ISNULL(NACH_REQUIRED_PROP,'') 'NACH_REQUIRED_PROP', "
                    + "ISNULL(NEFT_SUPPORT_DOC_PROP,'') 'NEFT_SUPPORT_DOC_PROP', ISNULL(PAN_CARD_COPY_PROP,'') 'PAN_CARD_COPY_PROP', "
                    + "ISNULL(PERMANENT_ADDRESS_PROOF_PROP,'') 'PERMANENT_ADDRESS_PROOF_PROP', ISNULL(PHOTOGRAPH_PROP,'') 'PHOTOGRAPH_PROP', "
                    + "ISNULL(ID_DOB_PROOF_INSUR,'') 'ID_DOB_PROOF_INSUR', ISNULL(INCOME_PROOF_INSUR,'') 'INCOME_PROOF_INSUR', "
                    + "ISNULL(PHOTOGRAPH_INSUR,'') 'PHOTOGRAPH_INSUR', ISNULL(CURR_ADD_PROOF_PAYOR,'') 'CURR_ADD_PROOF_PAYOR', "
                    + "ISNULL(ID_DOB_PROOF_PAYOR,'') 'ID_DOB_PROOF_PAYOR', ISNULL(INCOME_PROOF_PAYOR,'') 'INCOME_PROOF_PAYOR', "
                    + "ISNULL(NACH_REQUIRED_PAYOR,'') 'NACH_REQUIRED_PAYOR', ISNULL(PAN_CARD_COPY_PAYOR,'') 'PAN_CARD_COPY_PAYOR', "
                    + "ISNULL(PHOTOGRAPH_PAYOR,'') 'PHOTOGRAPH_PAYOR', ISNULL(PAN_CARD_COPY_REQ_INSUR,'') 'PAN_CARD_COPY_REQ_INSUR', ISNULL(PanCardCopyPropCompany,'') 'PanCardCopyPropCompany', "
                    + "ISNULL(PanCardCopyPayorCompany,'') 'PanCardCopyPayorCompany',isnull(OAS_DOCUMENT_PROP,'') 'OAS_DOCUMENT_PROP',isnull(MID_PROP,'') 'MID_PROP' FROM NG_NB_TAGS_LABELS(NOLOCK) "
                    + "WHERE WI_NAME='" + WorkItemName + "'";

            List qcFailedTags = iFormRef.getDataFromDB(QCquery);
            String[] Tag_IDs = {
                "Q_TAGS_REQUIREMENTS_TAG1",
                "Q_TAGS_REQUIREMENTS_TAG2",
                "Q_TAGS_REQUIREMENTS_TAG3",
                "Q_TAGS_REQUIREMENTS_TAG4",
                "Q_TAGS_REQUIREMENTS_TAG5",
                "Q_TAGS_REQUIREMENTS_TAG6",
                "Q_TAGS_REQUIREMENTS_TAG7",
                "Q_TAGS_REQUIREMENTS_TAG8",
                "Q_TAGS_REQUIREMENTS_TAG9",
                "Q_TAGS_REQUIREMENTS_TAG10",
                "Q_TAGS_REQUIREMENTS_TAG11",
                "Q_TAGS_REQUIREMENTS_TAG12",
                "Q_TAGS_REQUIREMENTS_TAG13",
                "Q_TAGS_REQUIREMENTS_TAG14",
                "Q_TAGS_REQUIREMENTS_TAG15",
                "Q_TAGS_REQUIREMENTS_TAG16",    //1083058
                "Q_TAGS_REQUIREMENTS_TAG17",
                "Q_TAGS_REQUIREMENTS_TAG18",
                "Q_TAGS_REQUIREMENTS_TAG19",
                "Q_TAGS_REQUIREMENTS_TAG20",
                "Q_TAGS_REQUIREMENTS_TAG21",
                "Q_TAGS_REQUIREMENTS_TAG22" 
            };

            String tagValue = "";
            if (!qcFailedTags.isEmpty()) {
                for (int i = 0; i < Tag_IDs.length; i++) {
                    tagValue = (String) ((List) qcFailedTags.get(0)).get(i);
                    if (tagValue.equalsIgnoreCase("PASS")) {
                        iFormRef.setStyle(Tag_IDs[i], "visible", "false");
                    }
                    if(i==20)
                {
                    if (!(tagValue.equalsIgnoreCase("Fail"))) {
                        iFormRef.setStyle(Tag_IDs[i], "visible", "false");
                    }
                }
                }
                
            }

            //Hiding tags at QC Summary  End
            if (iFormRef.getActivityName().equalsIgnoreCase("QC")) {
                iFormRef.setValue("InitialPanNo", (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PAN_NUMBER"));
            }
            String clientType = (String) iFormRef.getControlValue("Q_Personal_Proposer_Details.Client_type");
            String nomineeDOB = (String) iFormRef.getControlValue("Q_Personal_Other.DOB2");

            Date nomineeDOB_date = null;
            Date currentDate = new Date();
            new SimpleDateFormat("yyyy-mm-dd").format(currentDate);
            try {
                nomineeDOB_date = new SimpleDateFormat("yyyy-mm-dd").parse(nomineeDOB);

                if ("" != nomineeDOB) {
                    System.out.println(nomineeDOB + "\t" + nomineeDOB_date);
                    long diff = currentDate.getTime() - nomineeDOB_date.getTime();
                    int diffInYears = (int) (diff / (60 * 60 * 1000 * 24 * 30.41666666 * 12));

                    if (clientType.equalsIgnoreCase("insured") && diffInYears < 18) {
                        iFormRef.getIFormControl("t2s4").getM_objControlStyle().setM_strVisible("true");
                    } else {
                        iFormRef.getIFormControl("t2s4").getM_objControlStyle().setM_strVisible("false");
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
            }
            //validations code
            String query = "SELECT * FROM NG_NB_VALIDATION(NOLOCK) where ActivityName = '" + iFormRef.getActivityName() + "'";
            List dbData = iFormRef.getDataFromDB(query);
            if (!dbData.isEmpty()) {
                String activityName = "", visibleFields = "";
                for (int i = 0; i < dbData.size(); i++) {
                    activityName = (String) ((List) dbData.get(i)).get(0);
                    visibleFields = (String) ((List) dbData.get(i)).get(1);

                    String[] fieldArray = visibleFields.split(",");

                    for (int k = 0; k < fieldArray.length; k++) {
                        iFormRef.getIFormControl(fieldArray[k]).getM_objControlStyle().setM_strVisible("true");
                        // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                    }

                }
            }

            String planCode = (String) iFormRef.getControlValue("PLAN_NAME");
            String secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
            String Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
            List queryResult;
            String caseType = "";
            BusinessRules uwRules = new BusinessRules(iFormRef);
            if (ActtivityName.equalsIgnoreCase("MANUAL_UW")  || (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") )|| (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor"))|| ActtivityName.equalsIgnoreCase("Reinsurance")|| ActtivityName.equalsIgnoreCase("Manual_UW_Vendor") || ActtivityName.equalsIgnoreCase("Manual_UW_Supervisor") || ActtivityName.equalsIgnoreCase("UW_HOD") ) {

                //Populate reinsurer combo at UnderWriter Review Tab and set the Case Type-Protection/Non Protection
                query = "SELECT ISNULL(REINSURER,''),ISNULL(PROTECTION,'') FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE='" + planCode + "'";
                queryResult = iFormRef.getDataFromDB(query);
                if (!queryResult.isEmpty()) {
                    String reinsurer = (String) ((List) queryResult.get(0)).get(0);
                    caseType = (String) ((List) queryResult.get(0)).get(1);
                    iFormRef.setValue("CASE_TYPE", caseType);
                    String[] reinsurerArr = reinsurer.split(",");
                    for (String value : reinsurerArr) {
                        iFormRef.addItemInCombo("Q_LIST_REINSURER_LIST", value, value);
                    }
                }
                //-------

            }

            //added by Prakhar for MDM Validations for drop-downs
            String plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
            //For trad cases
            if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH") ||plan_type.equalsIgnoreCase("ANNUITY")) {
                    String subChannel = "";
                
                 query = "select DEFENCE_CHANNEL_CASE from NG_NB_DEFENCE_DETAILS(nolock) WHERE WI_NAME='"+WorkItemName+"'";
                queryResult = iFormRef.getDataFromDB(query);
                if (!queryResult.isEmpty()) {
                     subChannel = (String) ((List) queryResult.get(0)).get(0);
                }
                
                String queryYBL=""; 
                 List queryResultYBL;
                queryYBL = "select ISYBLTELESALE from NG_NB_CUSTOMER_INFORMATION(nolock) where WI_NAME='"+WorkItemName+"'";
                queryResultYBL = iFormRef.getDataFromDB(queryYBL);
                if (!queryResultYBL.isEmpty()) {
                    if(!(subChannel.equalsIgnoreCase("Y")))
                    subChannel = (String) ((List) queryResultYBL.get(0)).get(0);
                }
               // String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                //String planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                String Channel = (String) iFormRef.getControlValue("CHANNEL");
                Validate_MDM validateMDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                try {
                    validateMDM.populateProductNamesCombo();
                    validateMDM.populateCombos();
                    validateMDM.hideFields();
                    //if (ActtivityName.equalsIgnoreCase("Manual_UW")) {
                    //validateMDM.populateComboCoverageRevised();
                    //String LifeEvent = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.LIFE_EVENT");
                    //iFormRef.setValue("Q_DECISION_SECTION_UW.LIFE_STAGE_REV", LifeEvent);
                    //String discount = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
                    //iFormRef.setValue("Q_DECISION_SECTION_UW.DISCOUNT_ANY", discount);
                    //String smokerClass = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SMOKER_CLASS");
                    //iFormRef.setValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", smokerClass);
                    //}
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
            else //For ULIP cases
             if (plan_type.equalsIgnoreCase("ULIP")) {
                    UlipValidator ulipValidator = new UlipValidator("onLoad", "", iFormRef);
                    ulipValidator.populateProductNamesCombo();
                    ulipValidator.populateCombos();
                    ulipValidator.hideFields();
                    //for UW review screen
                    //if (ActtivityName.equalsIgnoreCase("Manual_UW")) {
                    ulipValidator.hideUWFields();
                    //ulipValidator.populateComboCoverageRevised();
                    //String LifeEvent = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.LIFE_EVENT");
                    //iFormRef.setValue("Q_DECISION_SECTION_UW.LIFE_STAGE_REV", LifeEvent);
                    //String discount = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
                    //iFormRef.setValue("Q_DECISION_SECTION_UW.DISCOUNT_ANY", discount);
                    //String smokerClass = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SMOKER_CLASS");
                   // iFormRef.setValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", smokerClass);
                    //}
                }
             else //For ULIP cases
                 if (plan_type.equalsIgnoreCase("COMBO")) {
                        ComboValidator comboValidator = new ComboValidator("onLoad", "", iFormRef);
                        comboValidator.populateProductNamesCombo();
                        comboValidator.populateCombos();
                        comboValidator.hideFields();
                        //for UW review screen
                        //if (ActtivityName.equalsIgnoreCase("Manual_UW")) {
                        comboValidator.hideUWFields();  //to be checked COMBO
                        String Channel = (String) iFormRef.getControlValue("CHANNEL");
                        String subChannel = "";
                        Validate_MDM validateMDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                        validateMDM.populateProductNamesCombo();
                        validateMDM.populateCombos();
                        validateMDM.hideFields();
                        //ulipValidator.populateComboCoverageRevised();
                        //String LifeEvent = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.LIFE_EVENT");
                        //iFormRef.setValue("Q_DECISION_SECTION_UW.LIFE_STAGE_REV", LifeEvent);
                        //String discount = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
                        //iFormRef.setValue("Q_DECISION_SECTION_UW.DISCOUNT_ANY", discount);
                        //String smokerClass = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SMOKER_CLASS");
                       // iFormRef.setValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", smokerClass);
                        //}
                    }

            //Added by Pranav 01102020
            /*BusinessRules rulesObj = new BusinessRules(iFormRef);
        rulesObj.copyDataToQCSummary();*/
            //End
        } catch (Exception e) {
            System.out.println("Error in beforeformLoad " + e.toString());
            e.printStackTrace();
        }
    }

    public String executeCustomService(FormDef arg0, IFormReference arg1,
            String arg2, String arg3, String arg4) {
        // TODO Auto-generated method stub
        return null;
    }

    public JSONArray executeEvent(FormDef arg0, IFormReference arg1,
            String arg2, String arg3) {
        // TODO Auto-generated method stub
        return null;
    }

    @SuppressWarnings("UnusedAssignment")
    public String executeServerEvent(IFormReference iFormRef, String controlName,
            String eventType, String stringData) {
        try
        {
        callREST_API callAPI = new callREST_API();
        // TODO Auto-generated method stub
        String resultString = "", effectiveDate;
        DecimalFormat df = new DecimalFormat("#");
        switch (eventType) {
            
             case "QCAdditionalTags":            //dr-14620 & DR-48434, DR-49133 Farman
               // iFormRef.applyGroup("Dolphin");

            String ActtivityName = "", userName = "", WorkItemName = "", QCquery = "";
            ActtivityName = iFormRef.getActivityName();
            userName = iFormRef.getUserName();

            WorkItemName = (String) iFormRef.getControlValue("WorkItemName");
            //String insertQuery = "INSERT INTO NG_NB_USER_ACTION(WI_NAME,ACTIVITY_NAME,USERID,ACTION_DATETIME,ACTION_ID) "
                
            /*try {
                iFormRef.getDataFromDB(insertQuery);
            } catch (Exception e) {
                System.out.println("Error while Inserting in NG_NB_USER_ACTION " + e.toString());
            }*/

            //Hiding tags at QC Summary  Start
            QCquery = "SELECT ISNULL(NEFTSupportDocProp,'') 'NEFTSupportDocProp', "
                    + "ISNULL(TitleGenderProp,'') 'TitleGenderProp', "
                    + "ISNULL(VideoPOSV,'') 'VideoPOSV', "
                    + "ISNULL(L2BIPhoto,'') 'L2BIPhoto', "
                    + "ISNULL(TitleGenderInsur,'') 'TitleGenderInsur', "
                    + "ISNULL(PayorPhoto,'') 'PayorPhoto', "
                    + "ISNULL(PayorPanCard,'') 'PayorPanCard', "
                    + "ISNULL(SellerDeclarationReqd,'') 'SellerDeclarationReqd', "
                    + "ISNULL(CustomerDeclarationFormProp,'') 'CustomerDeclarationFormProp', "
                    + "ISNULL(customerIDProof,'') 'customerIDProof', "
                    + "ISNULL(CustInformSheetofProduct,'') 'CustInformSheetofProduct', "
                    + "ISNULL(CriticalIllnessAndDisabiltyRider,'') 'CriticalIllnessAndDisabiltyRider', "
                    + "ISNULL(CriticalIllnessAndDisabiltySecureRider,'') 'CriticalIllnessAndDisabiltySecureRider', "
                    + "ISNULL(WaiverOfPremPlusRider,'') 'WaiverOfPremPlusRider', "
                    + "ISNULL(SmrtUltraProtectRider,'') 'SmrtUltraProtectRider', "
                    + "ISNULL(TermPlusRider,'') 'TermPlusRider', "
                    + "ISNULL(AccdntalDeathAndDismembermntRider,'') 'AccdntalDeathAndDismembermntRider', "
                    + "ISNULL(IncomeProofPropSpouse,'') 'IncomeProofPropSpouse', "
                    + "ISNULL(LiveSelfieOfProp,'') 'LiveSelfieOfProp', "
                    + "ISNULL(RakshakDocRequired,'') 'RakshakDocRequired', "
                    + "ISNULL(FTINDocument,'') 'FTINDocument', "
                    + "ISNULL(NRICase,'') 'NRICase', "
                    + "ISNULL(FormCtag,'') 'FormCtag', "
                    + "ISNULL(PhysicalJourney,'') 'PhysicalJourney', "    
                    + "ISNULL(LPOSV,'') 'LPOSV' "             //DR-49096  Abhi
                    + "FROM NG_NB_QC_ADDITIONAL_TAGS_LABELS "
                    + "WHERE WI_NAME='" + WorkItemName + "'";
                   
            List qcAdditionalTags = iFormRef.getDataFromDB(QCquery);
            String[] Tag_IDs = {
                "Q_QC_SUMMARY_TAGS_REQ_TAG1",
                "Q_QC_SUMMARY_TAGS_REQ_TAG2",
                "Q_QC_SUMMARY_TAGS_REQ_TAG3",
                "Q_QC_SUMMARY_TAGS_REQ_TAG4",
                "Q_QC_SUMMARY_TAGS_REQ_TAG5",
                "Q_QC_SUMMARY_TAGS_REQ_TAG6",
                "Q_QC_SUMMARY_TAGS_REQ_TAG7",
                "Q_QC_SUMMARY_TAGS_REQ_TAG8",
                "Q_QC_SUMMARY_TAGS_REQ_TAG9",
                "Q_QC_SUMMARY_TAGS_REQ_TAG10",
                "Q_QC_SUMMARY_TAGS_REQ_TAG11",
                "Q_QC_SUMMARY_TAGS_REQ_TAG12",
                "Q_QC_SUMMARY_TAGS_REQ_TAG13",
                "Q_QC_SUMMARY_TAGS_REQ_TAG14",
                "Q_QC_SUMMARY_TAGS_REQ_TAG15",
                "Q_QC_SUMMARY_TAGS_REQ_TAG16",
                "Q_QC_SUMMARY_TAGS_REQ_TAG17", 
                "Q_QC_SUMMARY_TAGS_REQ_TAG18",
                "Q_QC_SUMMARY_TAGS_REQ_TAG19",
                "Q_QC_SUMMARY_TAGS_REQ_TAG20",
                "Q_QC_SUMMARY_TAGS_REQ_TAG21",
                "Q_QC_SUMMARY_TAGS_REQ_TAG22",
                "Q_QC_SUMMARY_TAGS_REQ_TAG23",
                "Q_QC_SUMMARY_TAGS_REQ_TAG24",
                "Q_QC_SUMMARY_TAGS_REQ_TAG25"           //DR-49096  Abhi
                };

            String tagValue = "";
            if (!qcAdditionalTags.isEmpty()) {
                for (int i = 0; i < Tag_IDs.length; i++) {
                    tagValue = (String) ((List) qcAdditionalTags.get(0)).get(i);
                    if (tagValue.equalsIgnoreCase("PASS")) {
                        iFormRef.setStyle(Tag_IDs[i], "visible", "false");
                    }
                }
            }
             break;
        case "RouteBackTab":
                String polname = "",User="",
                 UserM = "",viewTab="hide";
                polname = (String) iFormRef.getControlValue("WorkItemName");
                User = (String)iFormRef.getUserName();
                String ViewTabQuery="EXEC NG_SP_NB_ROUTE_BACK_TAB '" + User +"'";
                List retData = (List) iFormRef.getDataFromDB(ViewTabQuery);
                if (!retData.isEmpty()) {
                    UserM = (String) ((List) retData.get(0)).get(0);
                    if((iFormRef.getActivityName().equalsIgnoreCase("Premium_Hold") || iFormRef.getActivityName().equalsIgnoreCase("WC_Hold") || iFormRef.getActivityName().equalsIgnoreCase("Postpone_Decline_Reject_Hold")) && UserM.equalsIgnoreCase(User) ){
                        viewTab="unhide";
                }
                }
                resultString =viewTab;
                break;
         case "QCTags_Validate": //dr-14620 & DR-48434, DR-49133 Farman
                String WIName="",QCTagsquery="";
                        
                WIName = (String) iFormRef.getControlValue("WorkItemName");       
                QCTagsquery = "SELECT ISNULL(NEFTSupportDocProp,'') 'NEFTSupportDocProp', ISNULL(TitleGenderProp,'') 'TitleGenderProp', "
                    + "ISNULL(VideoPOSV,'') 'VideoPOSV', "
                    + "ISNULL(L2BIPhoto,'') 'L2BIPhoto', ISNULL(TitleGenderInsur,'') 'TitleGenderInsur', "
                    + "ISNULL(PayorPhoto,'') 'PayorPhoto', ISNULL(PayorPanCard,'') 'PayorPanCard', ISNULL(SellerDeclarationReqd,'') 'SellerDeclarationReqd', ISNULL(CustomerDeclarationFormProp,'') 'CustomerDeclarationFormProp', "
                    + "ISNULL(CustInformSheetofProduct,'') 'CustInformSheetofProduct',"
                    + "ISNULL(CriticalIllnessAndDisabiltyRider,'') 'CriticalIllnessAndDisabiltyRider', ISNULL(CriticalIllnessAndDisabiltySecureRider,'') 'CriticalIllnessAndDisabiltySecureRider', "
                    + "ISNULL(WaiverOfPremPlusRider,'') 'WaiverOfPremPlusRider', ISNULL(SmrtUltraProtectRider,'') 'SmrtUltraProtectRider', "
                    + "ISNULL(TermPlusRider,'') 'TermPlusRider', "
                    + "ISNULL(AccdntalDeathAndDismembermntRider,'') 'AccdntalDeathAndDismembermntRider', "
                    + "ISNULL(IncomeProofPropSpouse,'') 'IncomeProofPropSpouse', "
                    + "ISNULL(LiveSelfieOfProp,'') 'LiveSelfieOfProp', ISNULL(RakshakDocRequired,'') 'RakshakDocRequired', ISNULL(FTINDocument,'') 'FTINDocument', "   
                    + "ISNULL(NRICase,'') 'NRICase', ISNULL(FormCtag,'') 'FormCtag', ISNULL(PhysicalJourney,'') 'PhysicalJourney', "  
                    + "ISNULL(LPOSV,'') 'LPOSV'"      //DR-49096 Abhi
                    + " FROM NG_NB_QC_ADDITIONAL_TAGS_LABELS "
                    + "WHERE WI_NAME='" + WIName + "'";
                List qcTags = iFormRef.getDataFromDB(QCTagsquery);
                String[] Tag_ID = {
                "Q_QC_SUMMARY_TAGS_REQ.TAG1",
                "Q_QC_SUMMARY_TAGS_REQ.TAG2",
                "Q_QC_SUMMARY_TAGS_REQ.TAG3",
                "Q_QC_SUMMARY_TAGS_REQ.TAG4",
                "Q_QC_SUMMARY_TAGS_REQ.TAG5",
                "Q_QC_SUMMARY_TAGS_REQ.TAG6",
                "Q_QC_SUMMARY_TAGS_REQ.TAG7",
                "Q_QC_SUMMARY_TAGS_REQ.TAG8",
                "Q_QC_SUMMARY_TAGS_REQ.TAG9",
                "Q_QC_SUMMARY_TAGS_REQ.TAG11",
                "Q_QC_SUMMARY_TAGS_REQ.TAG12",
                "Q_QC_SUMMARY_TAGS_REQ.TAG13",
                "Q_QC_SUMMARY_TAGS_REQ.TAG14",
                "Q_QC_SUMMARY_TAGS_REQ.TAG15",
                "Q_QC_SUMMARY_TAGS_REQ.TAG16",
                "Q_QC_SUMMARY_TAGS_REQ.TAG17",        
                "Q_QC_SUMMARY_TAGS_REQ.TAG18",
		"Q_QC_SUMMARY_TAGS_REQ.TAG19",
		"Q_QC_SUMMARY_TAGS_REQ.TAG20",
                "Q_QC_SUMMARY_TAGS_REQ.TAG21",
                "Q_QC_SUMMARY_TAGS_REQ.TAG22",
                "Q_QC_SUMMARY_TAGS_REQ.TAG23",
                "Q_QC_SUMMARY_TAGS_REQ.TAG24",
                "Q_QC_SUMMARY_TAGS_REQ.TAG25"       //DR-49096 	Abhi		          
                };
                 String tagValues = "";
                 String fail="N";
                 String controlValue="", client=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE"),
                        payorDiffProp=(String)iFormRef.getValue("Q_PAYOR_PAN_DETAILS.PAYOR_DIFF_PROP");
                if (!qcTags.isEmpty()) {
                    for (int i = 0; i < Tag_ID.length; i++) {
                        tagValues = (String) ((List) qcTags.get(0)).get(i);
                        controlValue=(String)iFormRef.getControlValue(Tag_ID[i]);
                        if ((!tagValues.equalsIgnoreCase("PASS")) && !(controlValue.equalsIgnoreCase("Verified") || controlValue.equalsIgnoreCase("Not Verified"))) {
                            if(client.equalsIgnoreCase("ProposerInsured") && (Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG4") || Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG5") || Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG25"))){
                                continue;
                            }
                            if(client.equalsIgnoreCase("Company") && (Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG2"))){
                                continue;
                            }
                            if((!payorDiffProp.equalsIgnoreCase("Y")) && (Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG6") || Tag_ID[i].equalsIgnoreCase("Q_QC_SUMMARY_TAGS_REQ.TAG7"))){
                                continue;
                            }
                            
                            fail="Y";
                            
                        }
                    }
                    resultString=fail;
                }
               
                break;
             //dr-24067 mansi
            case "Swiss_Re_Date":
                String swissDate="";
            	List swissReDate=(List) iFormRef.getDataFromDB("SELECT TOP 1 MPRO_INITIATION_DATE FROM NG_NB_MS_SWISS_RE(NOLOCK)");
            	if (!swissReDate.isEmpty()) {
            		swissDate = (String) ((List) swissReDate.get(0)).get(0);
            	}
            	
                resultString=swissDate;
            break;
            //DR-28244 sparsh
            case "SWP_Date":
                String swpDate="";
            	List swp_Date=(List) iFormRef.getDataFromDB("SELECT TOP 1 date FROM NG_NB_MS_SWP_DATE(NOLOCK)");
            	if (!swp_Date.isEmpty()) {
            		swpDate = (String) ((List) swp_Date.get(0)).get(0);
            	}
            	
                resultString=swpDate;
            break;
            
            case "SSP_Plans":
                String sspPlan="Y";
                String plan="";
                String casePlan=(String) iFormRef.getControlValue("PLAN_NAME");
            	List sspPlanList=(List) iFormRef.getDataFromDB("SELECT * FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE IN ('TNSTPS','TCSTPS','TNSTPL','TCSTPL','TNSTPR','TCSTPR','TNST60','TCST60','TNSTRS','TCSTRS','TNSTRL','TCSTRL','TNSTRR','TCSTRR','TNSR60','TCSR60','TSSEPL','TSSERL','TSEP60','TSER60','TNSTES','TNSTER','TNSTEL','TNSTE6','TCSTES','TCSTER','TCSTEL','TCSTE6') AND PLAN_CODE='"+casePlan+"'");
            	if (sspPlanList.isEmpty()) {
                    sspPlan="N";
                }
            	
                resultString=sspPlan;
            break;
            //DR-28244 sparsh
            case "Validate_PAYOUT_PERIOD":
            	 String plantype1 = (String) iFormRef.getControlValue("PLAN_TYPE");
             	 String planN1 = (String) iFormRef.getControlValue("PLAN_NAME");
             	 String chnl1 = (String) iFormRef.getControlValue("CHANNEL");
                 
            	 String query_PP ="", swpPlan="";
        		 if(plantype1.equalsIgnoreCase("TRAD"))
        		 {
        			 query_PP = "SELECT ISNULL(PAYOUT_PERIOD,'')"
                        + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN1 + "' AND Channel='" + chnl1 + "' ";
        		 }
        		 else if(plantype1.equalsIgnoreCase("JOINT"))
        		 {
        			 query_PP = "SELECT ISNULL(PAYOUT_PERIOD,'')"
                        + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN1 + "' AND Channel='" + chnl1 + "'"; 
        		 }
        		 else if(plantype1.equalsIgnoreCase("ULIP"))
        		 {
        			 query_PP = "SELECT ISNULL(PAYOUT_PERIOD,'')"
                        + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN1 + "' AND Channel='" + chnl1 + "' "; 
        		 }
                  else if(plantype1.equalsIgnoreCase("ANNUITY"))
        		 {
                	  query_PP = "SELECT ISNULL(PAYOUT_PERIOD,'')"
                        + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN1 + "' AND Channel='" + chnl1 + "' "; 
        		 }
                  else if(plantype1.equalsIgnoreCase("HEALTH"))
        		 {
                	  query_PP = "SELECT ISNULL(PAYOUT_PERIOD,'')"
                        + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN1 + "' AND Channel='" + chnl1 + "' "; 
        		 }
               
                List swpPlanList1=(List) iFormRef.getDataFromDB(query_PP);
                if (!swpPlanList1.isEmpty()) {
                	swpPlan = (String) ((List) swpPlanList1.get(0)).get(0);
                }
                
                resultString=swpPlan;
            break;
            
            // Start DR-33955 Nikita
            case "ISValidate_MDM":
           	 	 String plantype2 = (String) iFormRef.getControlValue("PLAN_TYPE");
            	 String planN2 = (String) iFormRef.getControlValue("PLAN_NAME");
            	 String chnl2 = (String) iFormRef.getControlValue("CHANNEL");
            	 String query_PP1 ="",Data="";
                
            	 if (controlName.equals("Q_COVERAGE_DETAILS_PROPOSITION_OF_ROP"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ROP,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ROP,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ROP,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ROP,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ROP,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_EARLY_ROP"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_EARLY_ROP_MILESTONE"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP_MILESTONE,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP_MILESTONE,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP_MILESTONE,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP_MILESTONE,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(EARLY_ROP_MILESTONE,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_GUARANTEED_ANNUITY_PERIOD"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(GUARANTEED_ANNUITY_PERIOD,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(GUARANTEED_ANNUITY_PERIOD,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(GUARANTEED_ANNUITY_PERIOD,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(GUARANTEED_ANNUITY_PERIOD,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(GUARANTEED_ANNUITY_PERIOD,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_INC_ANNUITY_PERCENTAGE"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(INC_ANNUITY_PERCENTAGE,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(INC_ANNUITY_PERCENTAGE,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(INC_ANNUITY_PERCENTAGE,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(INC_ANNUITY_PERCENTAGE,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(INC_ANNUITY_PERCENTAGE,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_PROPOSITION_OF_ANNUITY"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ANNUITY,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ANNUITY,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ANNUITY,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ANNUITY,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(PROPOSITION_OF_ANNUITY,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }
            	 else if (controlName.equals("Q_COVERAGE_DETAILS_DEFERMENT_PERIOD"))
            	 {
            		 if(plantype2.equalsIgnoreCase("TRAD"))
            		 {
            			 query_PP1 = "SELECT ISNULL(DEFERMENT_PERIOD,'')"
                         + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' ";
            		 }
            		 else if(plantype2.equalsIgnoreCase("JOINT"))
            		 {
            			 query_PP1 = "SELECT ISNULL(DEFERMENT_PERIOD,'')"
                         + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "'"; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ULIP"))
            		 {
            			 query_PP1 = "SELECT ISNULL(DEFERMENT_PERIOD,'')"
                         + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("ANNUITY"))
            		 {
            			 query_PP1 = "SELECT ISNULL(DEFERMENT_PERIOD,'')"
                         + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            		 else if(plantype2.equalsIgnoreCase("HEALTH"))
            		 {
            			 query_PP1 = "SELECT ISNULL(DEFERMENT_PERIOD,'')"
                         + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN2 + "' AND Channel='" + chnl2 + "' "; 
            		 }
            	 }

            	
            	 List PlanList2=(List) iFormRef.getDataFromDB(query_PP1);
                 if (!PlanList2.isEmpty())
                 {
               		Data = (String) ((List) PlanList2.get(0)).get(0);
                 }
               
                 resultString=Data;
                 

            break;
         // END DR-33955 Nikita

            case "validate":
                String ModalPremium = stringData;
                String Channel = "Axis";
                String ProductType = (String) iFormRef.getControlValue("Q_POLICY_DETAILS.PRODUCT_NAME");

                //resultString = "event dispatched";
                List dbData = (List) iFormRef.getDataFromDB("SELECT Minimum_Annual_Premium, Maximum_Annual_Premium FROM NG_Max_PlanMaster(NOLOCK) WHERE CHANNEL = '" + Channel + "' and Product_Type = '" + ProductType + "'");
                if (!dbData.isEmpty()) {
                    //			IControl controlRef = formReference.getIFormControl("Decision");
                    //			((EComboControl)controlRef).getM_objControlOptions().getM_arrOptions().clear();            //clear the dropdown

                    String minPremium = "", maxPremium = "";
                    for (int i = 0; i < dbData.size(); i++) {
                        minPremium = (String) ((List) dbData.get(0)).get(0);
                        maxPremium = (String) ((List) dbData.get(0)).get(1);
                    }
                    //String test = "";
                    //resultString = 	minPremium + " " + maxPremium + " " + ModalPremium + " " + Channel;				
                    double ModalPremiumDouble = Double.parseDouble(ModalPremium),
                            minPremiumDouble = Double.parseDouble(minPremium),
                            maxPremiumDouble = Double.parseDouble(maxPremium);
                    if (ModalPremiumDouble < minPremiumDouble || ModalPremiumDouble > maxPremiumDouble) {
                        resultString = "false" + "^" + df.format(minPremiumDouble) + "^" + df.format(maxPremiumDouble);
                    } else {
                        resultString = "true";
                    }

                    //resultString = 	minPremiumDouble + " " + maxPremiumDouble + " " + ModalPremiumDouble + " " + test;				
                }
                break;
                
                
                
               case "COLUMN_VISIBLE":
                
                iFormRef.setColumnVisible("QC_REQUIREMENTS", "1", true);
                
               break;
               
                case "COLUMN_VISIBLE_FALSE":
                
                iFormRef.setColumnVisible("QC_REQUIREMENTS", "1", false);
               
                
               break;

            case "validate_sumAssured":
                String sumAssured = stringData;
                Channel = (String) iFormRef.getControlValue("Q_AGENT_DETAILS.CHANNEL");
                ProductType = (String) iFormRef.getControlValue("Q_POLICY_DETAILS.PRODUCT_NAME");
                //resultString = "event dispatched";
                List dbDataSumAssured = (List) iFormRef.getDataFromDB("SELECT Minimum_Issue_Amount, Maximum_Issue_Amount FROM NG_Max_PlanMaster(NOLOCK) WHERE CHANNEL = '" + Channel + "' and Product_Type = '" + ProductType + "'");
                if (!dbDataSumAssured.isEmpty()) {
                    //			IControl controlRef = formReference.getIFormControl("Decision");
                    //			((EComboControl)controlRef).getM_objControlOptions().getM_arrOptions().clear();            //clear the dropdown

                    String minSumAssured = "", maxSumAssured = "";
                    for (int i = 0; i < dbDataSumAssured.size(); i++) {
                        minSumAssured = (String) ((List) dbDataSumAssured.get(0)).get(0);
                        maxSumAssured = (String) ((List) dbDataSumAssured.get(0)).get(1);
                    }
                    //String test = "";
                    //resultString = 	minPremium + " " + maxPremium + " " + ModalPremium + " " + Channel;				
                    double SumAssuredDouble = Double.parseDouble(sumAssured),
                            minSumAssuredDouble = Double.parseDouble(minSumAssured),
                            maxSumAssuredDouble = Double.parseDouble(maxSumAssured);
                    if (SumAssuredDouble < minSumAssuredDouble || SumAssuredDouble > maxSumAssuredDouble) {
                        resultString = "false" + "^" + df.format(minSumAssuredDouble) + "^" + df.format(maxSumAssuredDouble);
                    } else {
                        resultString = "true";
                    }

                    //resultString = 	minPremiumDouble + " " + maxPremiumDouble + " " + ModalPremiumDouble + " " + test;				
                }
                break;
                
                case "INSURED_MED":
                    
                    String WINAME1=stringData;
                    String diabetes="",hypertension="", heartdisorder="";
                    String INSURED_MED="select DIABETES,HYPERTENSION_BP,HEART_DISORDER from NG_NB_MEDICAL_INFORMATION_INSURED(nolock) where WI_NAME='"+WINAME1+"'";
                    List ISNUREDMEDDATA = (List) iFormRef.getDataFromDB(INSURED_MED);
                    
                     if (!ISNUREDMEDDATA.isEmpty()) {
                         
                         diabetes=(String) ((List) ISNUREDMEDDATA.get(0)).get(0);
                         hypertension=(String) ((List) ISNUREDMEDDATA.get(0)).get(1);
                         heartdisorder=(String) ((List) ISNUREDMEDDATA.get(0)).get(1);
                         
                         
                     }
                     if(diabetes.equalsIgnoreCase("") || hypertension.equalsIgnoreCase("") || heartdisorder.equalsIgnoreCase("") )
                     {
                         resultString="Y";
                     }
                
             
                break;
                
                case "PropulateVariant":
                    String planCode1=stringData;

                     String q1V="SELECT ',' + CODE FROM NG_NB_MS_VARIANT where PLAN_NAME='"+planCode1+"' ORDER BY (LABEL) FOR XML PATH('')";
              List queryResult1V = (List) iFormRef.getDataFromDB(q1V);
              String valueV="";
              if(queryResult1V!=null){
                     valueV=(String) ((List) queryResult1V.get(0)).get(0);
              }
                String[] Option_Code_ArrV = valueV.split(",");
                
                 for (int i = 0; i < Option_Code_ArrV.length; i++) {
            if(!Option_Code_ArrV[i].equalsIgnoreCase(""))
            iFormRef.addItemInCombo("Q_COVERAGE_DETAILS_VARIANT",
                    getLableNamefromId(Option_Code_ArrV[i].trim(), "NG_NB_MS_VARIANT", "LABEL", "CODE",iFormRef), Option_Code_ArrV[i].trim());
        }
                
        
                break;
                
                case "INSURED_MED_HEALTH":
                    
                    WINAME1=stringData;
                    String cnacerparent="",cough="";
                     INSURED_MED="select CANCER_PARENT,HEPATITIS_B_C,RECURR_COUGH from NG_NB_MEDICAL_INFORMATION_INSUREd(nolock) where WI_NAME='"+WINAME1+"'";
                   ISNUREDMEDDATA = (List) iFormRef.getDataFromDB(INSURED_MED);
                    
                     if (!ISNUREDMEDDATA.isEmpty()) {
                         
                         cnacerparent=(String) ((List) ISNUREDMEDDATA.get(0)).get(0);
                         cough=(String) ((List) ISNUREDMEDDATA.get(0)).get(1);
                         
                         
                     }
                     if(cough.equalsIgnoreCase("") || cnacerparent.equalsIgnoreCase("") )
                     {
                         resultString="Y";
                     }
                
             
                break;
                case "PROP_MED_HEALTH":
                    
                      WINAME1=stringData;
                     cnacerparent="";cough="";
                     INSURED_MED="select CANCER_PARENT,HEPATITIS_B_C,RECURR_COUGH from NG_NB_MEDICAL_INFORMATION_PROPOSER(nolock) where WI_NAME='"+WINAME1+"'";
                   ISNUREDMEDDATA = (List) iFormRef.getDataFromDB(INSURED_MED);
                    
                     if (!ISNUREDMEDDATA.isEmpty()) {
                         
                         cnacerparent=(String) ((List) ISNUREDMEDDATA.get(0)).get(0);
                         cough=(String) ((List) ISNUREDMEDDATA.get(0)).get(1);
                         
                         
                     }
                     if(cough.equalsIgnoreCase("") || cnacerparent.equalsIgnoreCase("") )
                     {
                         resultString="Y";
                     }
                
                
             
                break;
                
                
                case "QC_Typeofinfo":
            	//Date currentDate = new Date();
                String TypeofREQ="";
            	String REQNAME=stringData;
            	List TYPEOFREQ=(List) iFormRef.getDataFromDB("select top 1 TYPE_OF_REQUIREMENT from NG_NB_MS_QC_REQUIREMENTS(NOLOCK) where REQUIREMENT_NAME='"+REQNAME+"'");
            	if (!TYPEOFREQ.isEmpty()) {
            		TypeofREQ = (String) ((List) TYPEOFREQ.get(0)).get(0);
            	}
            	
                resultString=TypeofREQ;
            break;
            case "getserverdate":
            	//Date currentDate = new Date();
            	String CD="";
            	List currentDate=(List) iFormRef.getDataFromDB("select getDate()");
            	if (!currentDate.isEmpty()) {
            		CD = (String) ((List) currentDate.get(0)).get(0);
            	}
            	
                resultString=CD;
            break;
            case "validate_coverageTerm":
                String coverageTerm = stringData;
                Channel = (String) iFormRef.getControlValue("Q_AGENT_DETAILS.CHANNEL");
                ProductType = (String) iFormRef.getControlValue("Q_POLICY_DETAILS.PRODUCT_NAME");
                //resultString = "event dispatched";
                List dbDataCoverageTerm = (List) iFormRef.getDataFromDB("SELECT Minimum_Term, Maximum_Term FROM NG_Max_PlanMaster(NOLOCK) WHERE CHANNEL = '" + Channel + "' and Product_Type = '" + ProductType + "'");
                if (!dbDataCoverageTerm.isEmpty()) {
                    //			IControl controlRef = formReference.getIFormControl("Decision");
                    //			((EComboControl)controlRef).getM_objControlOptions().getM_arrOptions().clear();            //clear the dropdown

                    String minTerm = "", maxTerm = "";
                    for (int i = 0; i < dbDataCoverageTerm.size(); i++) {
                        minTerm = (String) ((List) dbDataCoverageTerm.get(0)).get(0);
                        maxTerm = (String) ((List) dbDataCoverageTerm.get(0)).get(1);
                    }
                    //String test = "";
                    //resultString = 	minPremium + " " + maxPremium + " " + ModalPremium + " " + Channel;				
                    double CoverageTermDouble = Double.parseDouble(coverageTerm),
                            minTermDouble = Double.parseDouble(minTerm),
                            maxTermDouble = Double.parseDouble(maxTerm);
                    if (CoverageTermDouble < minTermDouble || CoverageTermDouble > maxTermDouble) {
                        resultString = "false" + "^" + df.format(minTermDouble) + "^" + df.format(maxTermDouble);
                    } else {
                        resultString = "true";
                    }

                    //resultString = 	minPremiumDouble + " " + maxPremiumDouble + " " + ModalPremiumDouble + " " + test;				
                }
                break;
                
              case "GSTWAIVER":
                  String queryGST="";
                  
                  queryGST = "UPDATE NG_NB_COVERAGE_DETAILS SET GSTWAIVER='N' WHERE WI_NAME='" + stringData + "'";
                   List queryListGST  = (List) iFormRef.getDataFromDB(queryGST);
                  
               break;
               
              case "EIA_Repository_Name":
     
                String eia_no=(iFormRef.getControlValue("Q_PROPOSER_DETAILS.EIA_NUMBER").toString()).trim();
                  if(eia_no.equals("")){
                      iFormRef.setValue("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME","");
                  }
                  else{
                  String eia_no_with=eia_no.substring(0, 1);
                  
                
                List queryListEIA=(List) iFormRef.getDataFromDB("SELECT REPOSITORY_NAME from NG_NB_EIA_REPOSITORY_NAME_DETAILS(NOLOCK) WHERE EIA_NO_WITH='"+eia_no_with+"'");
                String repo_name="";
                if (!queryListEIA.isEmpty()) {
                     repo_name = (String) ((List) queryListEIA.get(0)).get(0);
                         iFormRef.setValue("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME",repo_name);
                 }else{
                    iFormRef.setValue("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME","");
                    resultString="error";
                }
                 }
                break;

              case "PAN_LINKAGE":
                   String PANLINKResponseJSON = "";
                String msgCode1 = "",panlinkage="";
                JSONParser jsonParserPL = new JSONParser();
                boolean isServiceEnabled1 = isAdminEnabled("PAN_VALIDATE_SERVICE", iFormRef);

                if (isServiceEnabled1) {
                    PANLINKResponseJSON = callAPI.validatePANLIINKAGE(stringData);
                    try {
                        JSONObject jsonObj = (JSONObject) jsonParserPL.parse(PANLINKResponseJSON);
                        JSONObject msgInfoObj = (JSONObject) jsonParserPL.parse(jsonObj.get("msgInfo").toString());
                        JSONObject payloadOBJ = (JSONObject) jsonParserPL.parse(jsonObj.get("payload").toString());

                        if (null != (String) msgInfoObj.get("msgCode")) {
                            msgCode1 = (String) msgInfoObj.get("msgCode");
                            panlinkage= (String) payloadOBJ.get("panAadharLinked");
                        } else {
                            return "Error in calling web service method!";
                        }
                        

                    } catch (org.json.simple.parser.ParseException ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    if (msgCode1.equalsIgnoreCase("200")) {
                        resultString = panlinkage;
                    } else {
                        resultString = "Please retry!";
                    }
                } else {
                    resultString = ADMIN_DISABLE_ERROR_MESSAGE;
                }

        
                break;
            case "API_validatePAN":
                String PANResponseJSON = "";
                String msgDescription = "";
                JSONParser jsonParser = new JSONParser();
                boolean isServiceEnabled = isAdminEnabled("PAN_VALIDATE_SERVICE", iFormRef);

                if (isServiceEnabled) {
                    PANResponseJSON = callAPI.validatePAN(stringData);
                    try {
                        JSONObject jsonObj = (JSONObject) jsonParser.parse(PANResponseJSON);
                        JSONObject msgInfoObj = (JSONObject) jsonParser.parse(jsonObj.get("msgInfo").toString());

                        if (null != (String) msgInfoObj.get("msgDescription")) {
                            msgDescription = (String) msgInfoObj.get("msgDescription");
                        } else {
                            return "Error in calling web service method!";
                        }

                    } catch (org.json.simple.parser.ParseException ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    if (msgDescription.equalsIgnoreCase("PAN Validated")) {
                        resultString = msgDescription;
                    } else {
                        resultString = "PAN Not Authenticated";
                    }
                    if(PANResponseJSON.equalsIgnoreCase("PAN Validated"))
                    {
                        resultString="PAN Validated";
                    }
                } else {
                    resultString = ADMIN_DISABLE_ERROR_MESSAGE;
                }

                break;

            case "API_getData_PAN":
                //Calling procedure to Check if API needs to be called or not 
                String winame = "",
                 procResult = "";
                String isDataMatch = "false";
                winame = (String) iFormRef.getControlValue("WorkItemName");
                List returnData = (List) iFormRef.getDataFromDB("EXEC NG_SP_NB_API_GET_DATA '" + winame + "','PAN'");
                if (!returnData.isEmpty()) {
                    procResult = (String) ((List) returnData.get(0)).get(0);
                }
                resultString = procResult;
                break;
              case "IS_POS":
                //Calling procedure to Check if API needs to be called or not 
                  
                  String plantype = (String) iFormRef.getControlValue("PLAN_TYPE");
            	String planN = (String) iFormRef.getControlValue("PLAN_NAME");
            	String chnl = (String) iFormRef.getControlValue("CHANNEL");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("HEALTH"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                String IS_POS="";
                	  List queryResult_POS = (List) iFormRef.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }
                resultString = IS_POS;
               break;
            case "API_validateDOB":
                //Q_PROPOSER_DETAILS.PAN_NUMBER
                String DOB = stringData;
                String DOBResponseJSON = "";
                msgDescription = "";
                DOBResponseJSON = callAPI.validateDOB(DOB);
                JSONParser jsonDOBParser = new JSONParser();

                try {
                    JSONObject jsonObj = (JSONObject) jsonDOBParser.parse(DOBResponseJSON);
                    JSONObject msgInfoObj = (JSONObject) jsonDOBParser.parse(jsonObj.get("msgInfo").toString());

                    if (null != (String) msgInfoObj.get("msgDescription")) {
                        msgDescription = (String) msgInfoObj.get("msgDescription");
                    } else {
                        return "Error in calling web service method!";
                    }

                } catch (org.json.simple.parser.ParseException ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                }

                if (msgDescription.equalsIgnoreCase("DOB Authenticated")) {
                    resultString = "true";
                } else {
                    resultString = "false";
                }
                break;

            case "API_generateLEDoc":
                propertiesFileData = new Properties();
                String configPath = System.getProperty("user.dir") + "\\" + CONFIG_PATH;
                FileReader reader;
                try {
                    reader = new FileReader(configPath);
                    propertiesFileData.load(reader);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                }

                String docIndex = "",
                 base64String = "",
                 resultODCall = "",
                 op_OD_call = "";
                winame = "";
                String sessionId = "";
                String[] stringDataArrLE = stringData.split("~~");
                winame = stringDataArrLE[0];
                sessionId = stringDataArrLE[1];
                String volId = propertiesFileData.getProperty("volID");

                String planNameForm = (String) iFormRef.getControlValue("PLAN_NAME");
                String planCode = "";
                //planCode = DolphinUtil.getPlanCodeFromName(planNameForm);
                
                
                 String ProdSolution   = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
               String PLANTYPE   = (String) iFormRef.getControlValue("PLAN_TYPE");

                planCode = DolphinUtil.getPlanCodeFromName(planNameForm);
                if(PLANTYPE.equalsIgnoreCase("COMBO"))
                {
                    planCode=ProdSolution;
                }
                
                
                String proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                 {
                    try {
                         Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, "aan0","aan0" );
                            
                        base64String = callAPI.generateLEDoc(iFormRef, winame, planCode);
                          //Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, base64String,base64String );
                        if (!base64String.equalsIgnoreCase("")) {
//                            resultODCall = uploadDocToOD(winame, proposalNumber, base64String, iFormRef, sessionId);	
                            String filePath = getFileFromBase64(base64String, winame);
                             Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, filePath+"aan1",filePath+"aan2" );
                            
                            String folderIndex = "";
                            String folderIndexQuery = "SELECT ITEMINDEX FROM NG_NB_EXT_TABLE(NOLOCK) WHERE WI_NAME='" + winame + "'";
                            List queryResult = iFormRef.getDataFromDB(folderIndexQuery);
                            folderIndex = (String) ((List) queryResult.get(0)).get(0);
                            resultODCall = uploadDocToOD2(filePath, sessionId, folderIndex, iFormRef, volId);
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, resultODCall,resultODCall );
                            //deleting the temp folder	
                            try {
                                File myObj = new File(System.getProperty("user.dir") + "\\CreateWorkitemService\\tmpIllustration\\" + winame);
                                deleteDirectory(myObj);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }

                            String[] resultODCallArr = resultODCall.split("~~");
                            docIndex = resultODCallArr[0];
                            op_OD_call = resultODCallArr[1];
                        }
                    } catch (ParseException ex) {
                        ex.printStackTrace();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    } catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
                resultString = docIndex + "~~" + op_OD_call;
                break;
         /*   
            case "API_generateLEDoc_Test":
                propertiesFileData = new Properties();
                 volId = propertiesFileData.getProperty("volID");
                 resultODCall="";
                 docIndex="";op_OD_call="";
                  sessionId = "";
                  stringDataArrLE = stringData.split("~~");
                 winame = stringDataArrLE[0];
                 sessionId = stringDataArrLE[1];
                
                //String proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                 //{
                    try {
                         Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, "aan0","aan0" );
                            
                          //Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, base64String,base64String );
                       // if (!base64String.equalsIgnoreCase("")) {
//                            resultODCall = uploadDocToOD(winame, proposalNumber, base64String, iFormRef, sessionId);	
                            String filePath = "D:\\myflow_dolphin\\node1\\bin\\CreateWorkitemService\\tmpIllustration\\NB-0800128087-Dolphin\\Illustrations.pdf";
                             Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, filePath+"aan1",filePath+"aan2" );
                             
                            resultODCall = uploadDocToOD2(filePath, sessionId, "47670525", iFormRef, volId);
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, resultODCall,resultODCall );
                            //deleting the temp folder	
                         /*   try {
                                File myObj = new File(System.getProperty("user.dir") + "\\CreateWorkitemService\\tmpIllustration\\" + );
                                deleteDirectory(myObj);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }*/

       /*                     String[] resultODCallArr = resultODCall.split("~~");
                            docIndex = resultODCallArr[0];
                            op_OD_call = resultODCallArr[1];
                        //}
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                
                resultString = docIndex + "~~" + op_OD_call;
                break;
    */
            case "API_calculateLEPremium":
                winame = stringData;
                String calculatePremiumJson = "";
                planNameForm = (String) iFormRef.getControlValue("PLAN_NAME");
                ProdSolution   = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
               PLANTYPE   = (String) iFormRef.getControlValue("PLAN_TYPE");

                planCode = DolphinUtil.getPlanCodeFromName(planNameForm);
                if(PLANTYPE.equalsIgnoreCase("COMBO"))
                {
                    planCode=ProdSolution;
                }
                 {
                   try {
                        if (controlName.equals("button214"))//for Counter Offer
                        {
                            calculatePremiumJson = callAPI.calculateLEPremium(iFormRef, winame, planCode, controlName);
                        } else //for Normaol Cases
                        {
                            calculatePremiumJson = callAPI.calculateLEPremium(iFormRef, winame, planCode, controlName);
                        }
                    } catch (Exception | Error e) {
                        e.printStackTrace();      //Aanchal
                    }
                }
                //handling the response of API for respective cases
                if (planCode.equalsIgnoreCase("LPPS")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                if (planCode.equalsIgnoreCase("AWP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;

                } else if (planCode.equalsIgnoreCase("WLS")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                if (planCode.equalsIgnoreCase("GIP")) {
                    if (!calculatePremiumJson.equalsIgnoreCase("")) {
                        resultString = planCode + " ~~" + calculatePremiumJson;
                    }
                } else if (planCode.equalsIgnoreCase("FTSP") || planCode.equalsIgnoreCase("FYPP") || planCode.equalsIgnoreCase("OSP")
                        || planCode.equalsIgnoreCase("SPS")) {
                    try {
                        resultString = planCode + "~~" + calculatePremiumJson;
                    } catch (Exception ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else if (planCode.equalsIgnoreCase("MIAP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("PWP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;

                } else if (planCode.equalsIgnoreCase("FGEP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("FWP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("STP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("SAP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("OTP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } else if (planCode.equalsIgnoreCase("SWP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("SJB")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }   //aanchal //16feb
                 else if (planCode.equalsIgnoreCase("SSP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }   //aanchal //17March
                else if (planCode.equalsIgnoreCase("GLIP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }   //aanchal //17March
                else if (planCode.equalsIgnoreCase("SPP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                } 
                 else if (planCode.equalsIgnoreCase("SWIP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("FWAP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                 else if (planCode.equalsIgnoreCase("SGPP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("CIP")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                 else if (ProdSolution.equalsIgnoreCase("CG")) {
                    resultString = ProdSolution + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("SFRD")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("SWAG")) {
                    resultString = planCode + "~~" + calculatePremiumJson;
                }
                else if (planCode.equalsIgnoreCase("SWAGP")) { //added by sparsh DR-24153
                    resultString = planCode + "~~" + calculatePremiumJson;
                }else if (planCode.equalsIgnoreCase("SEWA")) { //added by sparsh DR-31327
                    resultString = planCode + "~~" + calculatePremiumJson;
                }else if (planCode.equalsIgnoreCase("STEP")) { //added by Nikita DR-33983
                    resultString = planCode + "~~" + calculatePremiumJson;
                }else if (ProdSolution.equalsIgnoreCase("CG1")) {//added by Nikita DR-31452
                    resultString = ProdSolution + "~~" + calculatePremiumJson;
                }else if (ProdSolution.equalsIgnoreCase("CG3")) {//added by Nikita DR-34154
                    resultString = ProdSolution + "~~" + calculatePremiumJson;
                }else if (planCode.equalsIgnoreCase("SWAGPP")) { //added by Nikita 33955
                    resultString = planCode + "~~" + calculatePremiumJson;
                }else if (planCode.equalsIgnoreCase("SWAGE")) { //added by Nikita DR-40123
                    resultString = planCode + "~~" + calculatePremiumJson;
                }else if (ProdSolution.equalsIgnoreCase("CG4")) {//added by Nikita and Ezaz DR-44302
                    resultString = ProdSolution + "~~" + calculatePremiumJson;
                }
                
                //aanchal //17March


                break;
            case "API_getData_LE_AWP_TRAD":
                //Calling procedure to Check if API needs to be called or not 
                winame = "";
                procResult = "";
                winame = (String) iFormRef.getControlValue("WorkItemName");
                returnData = (List) iFormRef.getDataFromDB("EXEC NG_SP_NB_API_GET_DATA '" + winame + "','LE_AWP_TRAD'");
                if (!returnData.isEmpty()) {
                    procResult = (String) ((List) returnData.get(0)).get(0);
                }
                resultString = procResult;
                break;
            case "API_MICR_IFSC":
                String bankData = "",
                 ifscCode = "";
                ifscCode = stringData;
                bankData = callAPI.generate_MICR_IFSC(ifscCode);
                resultString = bankData;
                break;

            case "API_Mask_Aadhaar":
                String aadharResultAPI = "";
                String aadharNumber = stringData;
                isServiceEnabled = isAdminEnabled("AADHAAR_MASK_SERVICE", iFormRef);
                if (isServiceEnabled) {
                    aadharResultAPI = callAPI.maskAadhaar(aadharNumber);
                    resultString = aadharResultAPI;
                } else {
                    resultString = stringData + "~~" + ADMIN_DISABLE_ERROR_MESSAGE;
                }
                break;

            case "API_insertDataToTemp":
                String[] data = stringData.split("~");
                String fname = "",
                 lname = "",
                 dob = "";
                fname = data[0];
                lname = data[1];
                dob = data[2];
                String wi_name = (String) iFormRef.getControlValue("wi_name");
                resultString = "Success";
                break;

            case "PLAN_TYPE":
                String planName = stringData,
                 planType = "", jointLife="", IsJoint=""; //DR-23942 sparsh
                IsJoint=(String) iFormRef.getControlValue("IS_JOINTLIFE");
                
                String planQuery = "SELECT TOP 1 PRODUCT_TYPE, IS_JOINT FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE='" + planName + "'";
                List plantypeList = (List) iFormRef.getDataFromDB(planQuery);
                if (!plantypeList.isEmpty()) {
                    planType = (String) ((List) plantypeList.get(0)).get(0);
                    jointLife = (String) ((List) plantypeList.get(0)).get(1);
                }
                
                if(jointLife.equalsIgnoreCase("Y") && IsJoint.equalsIgnoreCase("Y")){
                    planType="JOINT";
                }
                resultString = planType;
                break;

            case "setHeaderData":
                String Proposal_No = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                String Q_Personal_Proposer_Details_First_Name = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
                String Q_PROPOSER_DETAILS_MIDDLE_NAME = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.MIDDLE_NAME");
                String Q_PROPOSER_DETAILS_LAST_NAME = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.LAST_NAME");
                String Q_Personal_Other_First_Name1 = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
                String Q_L2BI_DETAILS_MIDDLE_NAME = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.MIDDLE_NAME");
                String Q_L2BI_DETAILS_LAST_NAME = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.LAST_NAME");
                String Objective_of_insurance = (String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                String Product_Name = (String) iFormRef.getControlValue("PLAN_NAME");
                String Q_Personal_Proposer_Details_Nationality = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.NATIONALITY");
                String Q_Personal_Proposer_Details_Client_type = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
                String AFYP = (String) iFormRef.getControlValue("AFYP");

                resultString = Proposal_No + "~~"
                        + Q_Personal_Proposer_Details_First_Name + " " + Q_PROPOSER_DETAILS_MIDDLE_NAME + " " + Q_PROPOSER_DETAILS_LAST_NAME + "~~"
                        + Q_Personal_Other_First_Name1 + " " + Q_L2BI_DETAILS_MIDDLE_NAME + " " + Q_L2BI_DETAILS_LAST_NAME + "~~"
                        + Objective_of_insurance + "~~"
                        + Product_Name + "~~"
                        + Q_Personal_Proposer_Details_Nationality + "~~"
                        + Q_Personal_Proposer_Details_Client_type + "~~"
                        + AFYP;

                break;

            case "PINCODE_POPULATE_PROP":
                String pinCode = stringData;
                String city = "",
                 state = "";
                List cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE= '" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
            case "PINCODE_PERM_POPULATE_PROP":
                pinCode = stringData;
                //String city="",state="";
                cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE='" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
            case "PINCODE_POPULATE_L2BI":
                pinCode = stringData;
                //String city="",state="";
                cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE= '" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
            case "PINCODE_PERM_POPULATE_L2BI":
            case "QC_PINCODE_PERM_POPULATE_L2BI":
            case "QC_PINCODE_POPULATE_L2BI":
                pinCode = stringData;
                //String city="",state="";
                cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE= '" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
               
            case "QC_PINCODE_POPULATE_PROP":
                pinCode = stringData;
                //String city="",state="";
                cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE= '" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
          
                //aanchal
            case "discount_validation_prop":
            	String plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
            	String planname = (String) iFormRef.getControlValue("PLAN_NAME");
            	String ch = (String) iFormRef.getControlValue("CHANNEL");
                String secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                String Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	  String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_disc ="";
       		 if(plan_type.equalsIgnoreCase("TRAD"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' ";
       		 }
       		 else if(plan_type.equalsIgnoreCase("JOINT"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "'"; 
       		 }
       		 else if(plan_type.equalsIgnoreCase("ULIP"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
                {
                    query_disc="SELECT top 1 Discount FROM NG_NB_MS_COMBO(NOLOCK) WHERE PLAN_CODE ='"+planname+"' AND  combo_plan_code='"+secplanCode+"' and product_Solution='"+Product_Solution+"' and Channel='"+ch+"'";
                } 
                 
       	  List queryResult_disc = (List) iFormRef.getDataFromDB(query_disc);
       	 if (queryResult_disc != null) {
             String Discount = (String) ((List) queryResult_disc.get(0)).get(0);
             if (Discount != null && !Discount.isEmpty())
             {
            	 String query1="Select Policy_Status from NG_NB_MS_POLICY_STATUS";
            	 List queryResult1 = ((List) iFormRef.getDataFromDB(query1));
            	
                 if (!queryResult1.isEmpty()) {
                     for ( int i = 0; i < queryResult1.size(); i++) {
                    	 String PolicyStatus=(String) ((List) queryResult1.get(i)).get(0);
                    	 if(PolicyStatus.equalsIgnoreCase(PS))
                    	 {
                    		 iFormRef.setValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT", "EC");
                    		 iFormRef.setValue("PARTIAL_EXACT_FLAG", "YDP");
                    		
                    		 
                    	 }
                            
                     }
                     
                 }
            	 
             }
       	 }
                break;
             case "discount_validation_insur":
            	plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
            	 planname = (String) iFormRef.getControlValue("PLAN_NAME");
                 ch = (String) iFormRef.getControlValue("CHANNEL");
                   secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                 Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 query_disc ="";
       		 if(plan_type.equalsIgnoreCase("TRAD"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' ";
       		 }
       		 else if(plan_type.equalsIgnoreCase("JOINT"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "'"; 
       		 }
       		 else if(plan_type.equalsIgnoreCase("ULIP"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
       		 {
       			query_disc = "SELECT Discount"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planname + "' AND Channel='" + ch + "' "; 
       		 }
                 else if(plan_type.equalsIgnoreCase("COMBO"))
                {
                    query_disc="SELECT top 1 Discount FROM NG_NB_MS_COMBO(NOLOCK) WHERE PLAN_CODE ='"+planname+"' AND  combo_plan_code='"+secplanCode+"' and product_Solution='"+Product_Solution+"' and Channel='"+ch+"'";
                } 
       	  queryResult_disc = (List) iFormRef.getDataFromDB(query_disc);
       	 if (queryResult_disc != null) {
             String Discount = (String) ((List) queryResult_disc.get(0)).get(0);
             if (Discount != null && !Discount.isEmpty())
             {
            	 String query1="Select Policy_Status from NG_NB_MS_POLICY_STATUS";
            	 List queryResult1 = ((List) iFormRef.getDataFromDB(query1));
            	
                 if (!queryResult1.isEmpty()) {
                     for ( int i = 0; i < queryResult1.size(); i++) {
                    	 String PolicyStatus=(String) ((List) queryResult1.get(i)).get(0);
                    	 if(PolicyStatus.equalsIgnoreCase(PS))
                    	 {
                    		 iFormRef.setValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT", "EC");
                    		 iFormRef.setValue("PARTIAL_EXACT_FLAG", "YDI");
                    		
                    		 
                    	 }
                            
                     }
                     
                 }
            	 
             }
       	 }
                break;
            case "QC_PINCODE_PERM_POPULATE_PROP":
                pinCode = stringData;
                //String city="",state="";
                cityStateList = (List) iFormRef.getDataFromDB("SELECT ISNULL(P.CITY_LABEL,''),ISNULL(S.LABEL,'') FROM NG_NB_MS_PINCODE_CITY_STATE P(NOLOCK)\n"
                        + "INNER JOIN NG_NB_MS_STATE S(NOLOCK) ON P.STATE_LABEL=S.VALUE\n"
                        + "WHERE P.PINCODE= '" + pinCode + "' ");
                if (!cityStateList.isEmpty()) {
                    city = (String) ((List) cityStateList.get(0)).get(0);
                    state = (String) ((List) cityStateList.get(0)).get(1);
                    resultString = city + "," + state;
                }
                break;
            case "UW_Level_Validation":
                //stringData-> msa + "~~" + suc + "~~" + category + "~~" + emr; 
                if (stringData.indexOf("~~") != -1) {
                    String[] stringDataArr = stringData.split("~~");
                    String msa = (String) iFormRef.getControlValue("Q_SUC_PARAMETERES.MSA");
                    //stringDataArr[0];
                    String suc = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 1);
                    //stringDataArr[1];
                    String category = stringDataArr[2];
                    category = category.replace(",", ""); //removing last , from category
                    String emr = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 9);
                    //stringDataArr[3];
                    int userlevel = 0, caselevel = 0;
                    if (emr.equalsIgnoreCase("")) {
                        emr = "0";
                    }
                    String level = "", uwLevel = "";
                    String username = iFormRef.getUserName();
                    List userLevelData = (List) iFormRef.getDataFromDB("SELECT LEVEL FROM NG_NB_UW_USERS(NOLOCK) WHERE USERNAME ="
                            + "'" + username + "'");
                    if (!userLevelData.isEmpty()) {
                        level = (String) ((List) userLevelData.get(0)).get(0);
                        userlevel = Integer.parseInt(level.substring(2, 3));
                    }

                    String test = "SELECT LEVEL FROM NG_NB_UW_LEVEL(NOLOCK) WHERE MSA_FROM<=" + msa + ""
                            + " AND MSA_TO>=" + msa + " AND SUC_FROM<=" + suc + " AND SUC_TO>=" + suc + " AND CATEGORY IN (SELECT CATEGORY FROM NG_NB_UW_LEVEL(nolock) WHERE LEVEL='" + level + "') AND EMR!<" + emr + "";
//                    List validateUWData = (List) iFormRef.getDataFromDB("SELECT LEVEL FROM NG_NB_UW_LEVEL(NOLOCK) WHERE MSA_FROM<=" + msa + ""
//                            + " AND MSA_TO>=" + msa + " AND SUC_FROM<=" + suc + " AND SUC_TO>=" + suc + " AND '" + category + "' IN(SELECT ITEM FROM SPLITSTRING((SELECT L1.CATEGORY FROM NG_NB_UW_LEVEL L1(NOLOCK) WHERE L1.LEVEL='" + level + "'),',')) AND EMR!<" + emr + "");
                    /*List validateUWData = (List) iFormRef.getDataFromDB("SELECT LEVEL FROM NG_NB_UW_LEVEL L(NOLOCK) WHERE MSA_FROM<=" + msa + ""
                            + " AND MSA_TO>=" + msa + " AND SUC_FROM<=" + suc + " AND SUC_TO>=" + suc + " AND '" + category + "' IN (SELECT ITEM FROM SPLITSTRING((SELECT L1.CATEGORY FROM NG_NB_UW_LEVEL L1(NOLOCK) WHERE L1.LEVEL=L.LEVEL),',') ) AND EMR!<" + emr + "");*/
                    List validateUWData = (List) iFormRef.getDataFromDB("SELECT LEVEL FROM NG_NB_UW_LEVEL L(NOLOCK) WHERE EMR!<" + emr + " AND L.LEVEL =(SELECT TOP 1 LEVEL FROM NG_NB_UW_USERS(NOLOCK) WHERE username='" + username + "')");

                    if (!validateUWData.isEmpty()) {
                        uwLevel = (String) ((List) validateUWData.get(0)).get(0);
                        caselevel = Integer.parseInt(uwLevel.substring(2, 3));
                    }
                    if (userlevel >= caselevel && (!level.equalsIgnoreCase("")) && (!uwLevel.equalsIgnoreCase(""))) {
                        resultString = "true";
                    } else {
                        resultString = "false";
                    }
                }
                break;
            case "MDM_Validate":
                 plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                //for trad cases
                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH")||plan_type.equalsIgnoreCase("ANNUITY") ) 
                {  //aanchal //JOINT
                    String subChannel="";
                    WorkItemName = (String) iFormRef.getControlValue("WorkItemName");
                     String queryDC = "select DEFENCE_CHANNEL_CASE from NG_NB_DEFENCE_DETAILS(nolock) WHERE WI_NAME='"+WorkItemName+"'";
               List queryResultDC = iFormRef.getDataFromDB(queryDC);
                if (!queryResultDC.isEmpty()) {
                     subChannel = (String) ((List) queryResultDC.get(0)).get(0);
                }
                    // subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                   Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                    
                    if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411

                    Validate_MDM validateMDM = new Validate_MDM(controlName, stringData,iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);

                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getErrorMessage(controlName);
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = ulipValidator.getErrorMessage();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                else if (plan_type.equalsIgnoreCase("COMBO")) {
                    ComboValidator comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                     String subChannel ="";
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                   Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                    Validate_MDM validateMDM = new Validate_MDM(controlName, stringData,iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getErrorMessage(controlName);
                            resultString = resultString+ comboValidator.getErrorMessage();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;

            case "MDM_getAllErrorMessages":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH") ||plan_type.equalsIgnoreCase("ANNUITY") ) {
                    String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    
                    
                      if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                      secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
               Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");

                    Validate_MDM validateMDM = new Validate_MDM(controlName, stringData,iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);

                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getAllErrorMessagesJSON();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = ulipValidator.getAllErrorMessagesJSON();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;
                     case "MDM_getAllErrorMessages_PRIM":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

                if (plan_type.equalsIgnoreCase("COMBO") ) {
                    String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    
                    
                      if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                      secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                 Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");

                    Validate_MDM validateMDM = new Validate_MDM(controlName, stringData,iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);

                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getAllErrorMessagesJSON();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } 
                break;
                     case "MDM_getAllErrorMessages_SEC":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

               if (plan_type.equalsIgnoreCase("COMBO")) {
                    ComboValidator comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = comboValidator.getAllErrorMessagesJSON();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;
                
            case "ISVALID_OBJOFINSURANCE":
                 planname = (String) iFormRef.getControlValue("PLAN_NAME");
                 String clientType = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
                 String objofin=stringData;
                 String query_1="";
                 String applicable="";
                 
                 
                 if(clientType.equalsIgnoreCase("ProposerInsured"))
                 {
                     query_1="SELECT FORM1_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Proposer"))
                 {
                     query_1="SELECT FORM2_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Company"))
                 {
                     query_1="SELECT SCHEMEA_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 
                  List dbData_1 = iFormRef.getDataFromDB(query_1);
                if (!dbData_1.isEmpty()) {
                    String OBJOFINSURANCE = "", visibleFields = "";
                    for (int i = 0; i < dbData_1.size(); i++) {
                        OBJOFINSURANCE = (String) ((List) dbData_1.get(i)).get(0);


                        String[] fieldArray = OBJOFINSURANCE.split(",");

                        for (int k = 0; k < fieldArray.length; k++) {
                            String OBJOFINSURANCEAPPLICABLE=fieldArray[k];
                            if(OBJOFINSURANCEAPPLICABLE.equalsIgnoreCase(objofin))
                                applicable="Y";
                            // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                        }

                    }
                  
                }
                 resultString=applicable;
                  
                 
                
                
               break;
               
                case "ISVALID_PLANNAME":
                 planname = stringData;
                  clientType = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
                  objofin=(String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                  query_1="";
                  applicable="";
                 
                 
                 if(clientType.equalsIgnoreCase("ProposerInsured"))
                 {
                     query_1="SELECT FORM1_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Proposer"))
                 {
                     query_1="SELECT FORM2_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Company"))
                 {
                     query_1="SELECT SCHEMEA_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 
                   dbData_1 = iFormRef.getDataFromDB(query_1);
                if (!dbData_1.isEmpty()) {
                    String OBJOFINSURANCE = "", visibleFields = "";
                    for (int i = 0; i < dbData_1.size(); i++) {
                        OBJOFINSURANCE = (String) ((List) dbData_1.get(i)).get(0);


                        String[] fieldArray = OBJOFINSURANCE.split(",");

                        for (int k = 0; k < fieldArray.length; k++) {
                            String OBJOFINSURANCEAPPLICABLE=fieldArray[k];
                            if(OBJOFINSURANCEAPPLICABLE.equalsIgnoreCase(objofin))
                                applicable="Y";
                            // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                        }

                    }
                  
                }
                 resultString=applicable;
                  
                 
                
                
               break;
               
               
            case "ISVALID_CLIENTTYPE":
                 planname = (String) iFormRef.getControlValue("PLAN_NAME");
                  objofin = (String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                  clientType=stringData;
                  query_1="";
                  applicable="";
                 
                 
                 if(clientType.equalsIgnoreCase("ProposerInsured"))
                 {
                     query_1="SELECT FORM1_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Proposer"))
                 {
                     query_1="SELECT FORM2_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 if(clientType.equalsIgnoreCase("Company"))
                 {
                     query_1="SELECT SCHEMEA_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 }
                 
                   dbData_1 = iFormRef.getDataFromDB(query_1);
                if (!dbData_1.isEmpty()) {
                    String OBJOFINSURANCE = "", visibleFields = "";
                    for (int i = 0; i < dbData_1.size(); i++) {
                        OBJOFINSURANCE = (String) ((List) dbData_1.get(i)).get(0);


                        String[] fieldArray = OBJOFINSURANCE.split(",");

                        for (int k = 0; k < fieldArray.length; k++) {
                            String OBJOFINSURANCEAPPLICABLE=fieldArray[k];
                            if(OBJOFINSURANCEAPPLICABLE.equalsIgnoreCase(objofin))
                                applicable="Y";
                            // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                        }

                    }
                  
                }
                 resultString=applicable;
                  
                 
                
                
               break;
               
             case "IS_SCHEMEA":
                
                 applicable="";
                 
                 String queryfetch=("SELECT PLAN_NAME,OBJ_OF_INSURANCE FROM  NG_NB_EXT_TABLE(NOLOCK) WHERE WI_NAME='" + stringData + "';");
                 List queryResult_fetch = iFormRef.getDataFromDB(queryfetch);
                 planname = (String) ((List) queryResult_fetch.get(0)).get(0);
                 objofin = (String) ((List) queryResult_fetch.get(0)).get(1);
               
                 String queryfetch1=("SELECT CLIENT_TYPE FROM NG_NB_PROPOSER_DETAILS(NOLOCK) WHERE WI_NAME='" + stringData + "';");
                 List queryResult_fetch1 = iFormRef.getDataFromDB(queryfetch1);
                 clientType = (String) ((List) queryResult_fetch1.get(0)).get(0);
               
                
                     
                query_1 = "SELECT SCHEMEA_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 
                 
                   dbData_1 = iFormRef.getDataFromDB(query_1);
                if (!dbData_1.isEmpty()) {
                    String OBJOFINSURANCE = "", visibleFields = "";
                    for (int i = 0; i < dbData_1.size(); i++) {
                        OBJOFINSURANCE = (String) ((List) dbData_1.get(i)).get(0);


                        String[] fieldArray = OBJOFINSURANCE.split(",");

                        for (int k = 0; k < fieldArray.length; k++) {
                            String OBJOFINSURANCEAPPLICABLE=fieldArray[k];
                            if(OBJOFINSURANCEAPPLICABLE.equalsIgnoreCase(objofin)  && clientType.equalsIgnoreCase("Company"))
                                applicable="Y";
                            // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                        }

                    }
                  
                }
                 resultString=applicable;
                  
                 
                
                
               break;
              case "IS_SCHEMEB":
                 applicable="";
                 
                  queryfetch=("SELECT PLAN_NAME,OBJ_OF_INSURANCE FROM  NG_NB_EXT_TABLE(NOLOCK) WHERE WI_NAME='" + stringData + "';");
                  queryResult_fetch = iFormRef.getDataFromDB(queryfetch);
                 planname = (String) ((List) queryResult_fetch.get(0)).get(0);
                 objofin = (String) ((List) queryResult_fetch.get(0)).get(1);
               
                  queryfetch1=("SELECT CLIENT_TYPE FROM NG_NB_PROPOSER_DETAILS(NOLOCK) WHERE WI_NAME='" + stringData + "';");
                  queryResult_fetch1 = iFormRef.getDataFromDB(queryfetch1);
                 clientType = (String) ((List) queryResult_fetch1.get(0)).get(0);
               
                
                     
                query_1 = "SELECT SCHEMEB_OBJOFINS FROM NG_NB_MS_PLAN_CODE(NOLOCK) where PLAN_CODE='"+planname+"'";
                 
                 
                   dbData_1 = iFormRef.getDataFromDB(query_1);
                if (!dbData_1.isEmpty()) {
                    String OBJOFINSURANCE = "", visibleFields = "";
                    for (int i = 0; i < dbData_1.size(); i++) {
                        OBJOFINSURANCE = (String) ((List) dbData_1.get(i)).get(0);


                        String[] fieldArray = OBJOFINSURANCE.split(",");

                        for (int k = 0; k < fieldArray.length; k++) {
                            String OBJOFINSURANCEAPPLICABLE=fieldArray[k];
                            if(OBJOFINSURANCEAPPLICABLE.equalsIgnoreCase(objofin) && clientType.equalsIgnoreCase("ProposerInsured"))
                                applicable="Y";
                            // iFormRef.getIFormControl("ULIP_CHECK").getM_objControlStyle().setM_strVisible("true");
                        }

                    }
                  
                }
                 resultString=applicable;
                
               break;
            case "MDM_getAllErrorMessages_UW":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT") ||plan_type.equalsIgnoreCase("HEALTH")||plan_type.equalsIgnoreCase("ANNUITY") ) {
                    String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    
                            if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411

                            secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                    Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                    Validate_MDM validateMDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);

                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getAllErrorMessagesJSON_UW();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = ulipValidator.getAllErrorMessagesJSON_UW();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;
                case "MDM_getAllErrorMessages_UW_PRIM":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

                if (plan_type.equalsIgnoreCase("COMBO")) {
                    String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    
                            if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411

                            secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
            Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                    Validate_MDM validateMDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);

                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = validateMDM.getAllErrorMessagesJSON_UW();
                        } catch (ParseException ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }

                } 
                break;
                case "MDM_getAllErrorMessages_UW_SEC":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");

                 if (plan_type.equalsIgnoreCase("COMBO")) {
                    ComboValidator comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = comboValidator.getAllErrorMessagesJSON_UW();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;

            case "isEDCVisible":
                String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                
                 secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
            Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
	
                        if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                        
                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH") ||plan_type.equalsIgnoreCase("ANNUITY")||plan_type.equalsIgnoreCase("COMBO") ) {
                    Validate_MDM hide_populate_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                    resultString = hide_populate_MDM.isEDCVisible();
                } else {
                    UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    resultString = ulipValidator.isEDCVisible();

                }
                break;

            case "MDM_OnChangeValidations":
                 Channel = (String) iFormRef.getControlValue("CHANNEL");
                if(controlName.equalsIgnoreCase("Q_DEFENCE_DETAILS_DEFENCE_CHANNEL_CASE"))
                {
                    subChannel = stringData;
                     planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    
                }
                else if(controlName.equalsIgnoreCase("Q_DEFENCE_DETAILS_DEFENCE_CHANNEL_CASE"))
                {
                     subChannel = stringData;
                     planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                }
                else
                {
                subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                                if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                planCode = stringData;
                }
                
             secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
            Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
	
               
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH") ||plan_type.equalsIgnoreCase("ANNUITY") ) {
                    Validate_MDM hide_populate_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                    if (hide_populate_MDM.isPlanValid()) {
                        try {
                            hide_populate_MDM.hideFields();
                            hide_populate_MDM.clearFields();
                            hide_populate_MDM.populateCombos();  //7554
                        } catch (Exception Ex) {
                            Ex.printStackTrace();
                        }
                        try {
                            //hide_populate_MDM.populateCombos();
                        } catch (Exception Ex) {
                            Ex.printStackTrace();
                        }
                        resultString = "true";
                    } else {
                        resultString = "false";
                    }
                } else if (plan_type.equalsIgnoreCase("ULIP")) {

                    UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    if (ulipValidator.isPlanValid()) {
                        if (!controlName.equalsIgnoreCase("")) {
                            ulipValidator.setFieldsOnPlanChange();
                            ulipValidator.hideFields();
                            ulipValidator.clearFields();
                            ulipValidator.populateCombos();

                            //ulipValidator.addMandatoryBenefitRiders();
                        }
                        resultString = "true";
                    } else {
                        resultString = "false";
                    }
                }

                RiderBenefit riderObj = new RiderBenefit(iFormRef, planCode, Channel, subChannel, plan_type);
                riderObj.addInbuildRiderBenefit();

                break;

            case "MDM_validateULIPFund":
                UlipValidator ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                resultString = ulipValidator.isULIPFundValid();
                break;
                
              case "MDM_validateCOMBOFund":
                ComboValidator comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                resultString = comboValidator.isCOMBOFundValid();
                break;

            case "MDM_getProductDating":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                String prodDatingQuery = "";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                  Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                if (plan_type.equalsIgnoreCase("TRAD")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("JOINT")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("ANNUITY")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("HEALTH")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                 else if (plan_type.equalsIgnoreCase("COMBO")) {
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' and Combo_Plan_Code='"+secplanCode+"' and Product_Solution='"+Product_Solution+"' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                List queryList = (List) iFormRef.getDataFromDB(prodDatingQuery);
                if (!queryList.isEmpty()) {
                    String productDating = (String) ((List) queryList.get(0)).get(0);
                    resultString = productDating;
                }
                break;

            //            case "MDM_GetRiders":
            //                subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
            //                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
            //                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
            //                Channel = (String) iFormRef.getControlValue("CHANNEL");
            //                Validate_MDM addRiders_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel);
            //                resultString = addRiders_MDM.getRiders();
            //
            //                break;
                case "MDM_getProdEffDating":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                String prodEffDatingQuery = "";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                  Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                if (plan_type.equalsIgnoreCase("TRAD")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("JOINT")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("ANNUITY")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("HEALTH")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                 else if (plan_type.equalsIgnoreCase("COMBO")) {
                    prodEffDatingQuery = "SELECT PROD_EFF_DATING FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' and Combo_Plan_Code='"+secplanCode+"' and Product_Solution='"+Product_Solution+"' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                List queryListPE = (List) iFormRef.getDataFromDB(prodEffDatingQuery);
                if (!queryListPE.isEmpty()) {
                    String productEffDating = (String) ((List) queryListPE.get(0)).get(0);
                    resultString = productEffDating;
                }
                break;

                
                case "MDM_getTermCalCode":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                String TERMCALCODE = "";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                  Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                if (plan_type.equalsIgnoreCase("TRAD")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("JOINT")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("ANNUITY")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("HEALTH")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                 else if (plan_type.equalsIgnoreCase("COMBO")) {
                    TERMCALCODE = "SELECT Term_CalC_Code FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' and Combo_Plan_Code='"+secplanCode+"' and Product_Solution='"+Product_Solution+"' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                List queryListTERM = (List) iFormRef.getDataFromDB(TERMCALCODE);
                if (!queryListTERM.isEmpty()) {
                    String TERMCALCODEV = (String) ((List) queryListTERM.get(0)).get(0);
                    resultString = TERMCALCODEV;
                }
                break;
                
                case "MDM_getIncomePeriod":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                String INCOMEPERIOD = "";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                  Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                if (plan_type.equalsIgnoreCase("TRAD")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";

                } else if (plan_type.equalsIgnoreCase("ULIP")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("JOINT")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("ANNUITY")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                else if (plan_type.equalsIgnoreCase("HEALTH")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                 else if (plan_type.equalsIgnoreCase("COMBO")) {
                    INCOMEPERIOD = "SELECT INCOME_PERIOD_CD FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' and Combo_Plan_Code='"+secplanCode+"' and Product_Solution='"+Product_Solution+"' AND Channel='" + Channel + "' AND "
                            + "Sub_Channel='" + getValueFromMaster(iFormRef, Channel, "NG_NB_MS_CHANNEL_MAPPING_CODE_DESC", "CHANNEL_CODE", "SUB_CHANNEL") + "'";
                }
                List queryListIP = (List) iFormRef.getDataFromDB(INCOMEPERIOD);
                if (!queryListIP.isEmpty()) {
                    String INCOMEPERRIOD = (String) ((List) queryListIP.get(0)).get(0);
                    resultString = INCOMEPERRIOD;
                }
                break;


            case "MDM_GetRiders":
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                effectiveDate = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
                
                 if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411

                String riderQuery = "EXEC NG_SP_NB_RIDER_SETUP '" + planCode + "','" + Channel + "','" + subChannel + "','" + effectiveDate + "','1','','0','0','','','',''";
                List riderList = (List) iFormRef.getDataFromDB(riderQuery);
                resultString = (String) ((List) riderList.get(0)).get(0);

                /*Validate_MDM addRiders_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel);	
                resultString = addRiders_MDM.getRiders();*/
                break;

            case "MDM_GetActiveRiders":
                subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                  Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
	
                
                 if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                Validate_MDM getActiveRiders_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                 {
                    try {
                        resultString = getActiveRiders_MDM.getActiveRiders();
                    } catch (ParseException ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                break;
            case "MDM_PopulateCombos":
                 Channel = (String) iFormRef.getControlValue("CHANNEL");
                if(controlName.equalsIgnoreCase("Q_DEFENCE_DETAILS_DEFENCE_CHANNEL_CASE"))
                {
                    subChannel = stringData;
                     planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    
                }
                else if(controlName.equalsIgnoreCase("Q_CUSTOMER_INFORMATION_ISYBLTELESALE"))
                {
                    subChannel = stringData;
                     planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                }
                else
                {
                subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                
                 if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                planCode = stringData;
                }
                //subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                //subChannel = subChannel.equalsIgnoreCase("Defence") ? "Defence" : "Agency";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
               
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH")||plan_type.equalsIgnoreCase("ANNUITY")||plan_type.equalsIgnoreCase("COMBO")) {
                    Validate_MDM populateMDM = new Validate_MDM(controlName, stringData, iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                    resultString = populateMDM.getComboValues();
                }
                break;
            //hide columns of Coverage Details Applied and Revised table on Manual UW WS
            //Also populate combo of death benefit in Coverage Details Revised Table on Man UW WS
            case "MDM_getHiddenColums":
                plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                if (plan_type.equalsIgnoreCase("ULIP")) {
                    ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = ulipValidator.getHiddenColumns();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } else if (plan_type.equalsIgnoreCase("TRAD")||plan_type.equalsIgnoreCase("JOINT")||plan_type.equalsIgnoreCase("HEALTH")||plan_type.equalsIgnoreCase("ANNUITY")) {
                    subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    
                      if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                       secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                    Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                    Validate_MDM hide_populate_MDM = new Validate_MDM(iFormRef, planCode, Channel, subChannel,secplanCode,Product_Solution);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = hide_populate_MDM.getHiddenColumns();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                else if (plan_type.equalsIgnoreCase("COMBO")) {
                    comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                    if (!controlName.equalsIgnoreCase("")) {
                        try {
                            resultString = comboValidator.getHiddenColumns();
                        } catch (Exception ex) {
                            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;

            //added by Prakhar to pupoluate funds dropdown dynamically on plan change
            case "MDM_populateDropdown":
                String dropdownQuery = stringData;
                String targetFieldId = controlName;
                iFormRef.clearCombo(targetFieldId);
                List queryResultDropdown = (List) iFormRef.getDataFromDB(dropdownQuery);
                if (!queryResultDropdown.isEmpty()) {
                    for (int i = 0; i < queryResultDropdown.size(); i++) {
                        iFormRef.addItemInCombo(targetFieldId, ((List) queryResultDropdown.get(i)).get(0).toString(), ((List) queryResultDropdown.get(i)).get(1).toString());
                    }
                }
                break;

            case "CheckPercentage":
                String commisionShare = "",
                 percentage = "",
                 allocationPer = "";
                winame = stringData;
                String query = "SELECT SUM(CAST(ISNULL(COMMISSION_SHARE,0) AS INT)) FROM NG_NB_LIST_AGENT_DETAILS_GRID(NOLOCK) WHERE WI_NAME=  '" + stringData + "'";
                List commisionShareList = (List) iFormRef.getDataFromDB(query);
                if (!commisionShareList.isEmpty()) {
                    commisionShare = (String) ((List) commisionShareList.get(0)).get(0);
                }
                query = "SELECT SUM(CAST(ISNULL(PERCENTAGE,0) AS INT)) FROM NG_NB_LIST_NOMINEE_DETAILS(NOLOCK) WHERE WI_NAME= '" + stringData + "'";
                List percentageList = (List) iFormRef.getDataFromDB(query);
                if (!percentageList.isEmpty()) {
                    percentage = (String) ((List) percentageList.get(0)).get(0);
                }
                query = "SELECT SUM(CAST(ISNULL(TOTAL_ALLOCATION_PERCENT ,0) AS INT)) FROM NG_NB_LIST_FUND_SELECTED_GRID(NOLOCK) WHERE WI_NAME= '" + stringData + "'";
                List allocationPerList = (List) iFormRef.getDataFromDB(query);
                if (!allocationPerList.isEmpty()) {
                    allocationPer = (String) ((List) allocationPerList.get(0)).get(0);
                }
                resultString = commisionShare + "^" + percentage + "^" + allocationPer;
                break;
            /*
                case "MDM_OnProdChange":
                    String productFamily="";  
                    productFamily = stringData;
                    Validate_MDM getPlanCombo = new Validate_MDM(iFormRef,productFamily);
                    resultString = getPlanCombo.getProductNameComboValues();
                    break;
             */
            //added by Pranav
            case "FetchChannel":
                winame = stringData;
                String channelName = "";
                query = "SELECT TOP 1 ISNULL(CHANNEL,'') FROM NG_NB_LIST_AGENT_DETAILS_GRID(NOLOCK) WHERE WI_NAME='" + stringData + "'";
                List channelList = (List) iFormRef.getDataFromDB(query);
                if (!channelList.isEmpty()) {
                    channelName = (String) ((List) channelList.get(0)).get(0);
                }
                resultString = channelName;
                break;
            case "TestEvent":
                String dataFromClient = stringData;
                //iFormRef.clearCombo(dataFromClient);
                //                IControl controlRef = iFormRef.getIFormControl(dataFromClient);
                //                ((EComboControl)controlRef).getM_objControlOptions().getM_arrOptions().clear();

                /*String optionLabel="test",optionValue="val";
                    EControlOption option = new EControlOption();
                    option.setM_strOptionLabel(optionLabel);
                    option.setM_strOptionValue(optionValue);
                    ((EComboControl)controlRef).getM_objControlOptions().getM_arrOptions().add(option);
                 */
                //iFormRef.addItemInCombo(stringData, "testKey", "testVal");
                //WDGeneralData wd =  iFormRef.getObjGeneralData();
                //iFormRef.clearCombo(dataFromClient);
                JSONArray jArr = new JSONArray();
                JSONObject jRow = new JSONObject();
                jRow.put("Fund Name", "");
                jRow.put("Initial Allocation", "");
                jArr.add(jRow);
                iFormRef.addDataToGrid("table48", jArr);
                iFormRef.addItemInTableCellCombo("table48", 0, 0, "prakhar", "saxena");
                iFormRef.setTableCellValue("table48", 0, 0, "prakhar");
                //iFormRef.addItemInCombo(dataFromClient, "prakhar", "saxena");

                resultString = "true";
                break;

            case "MyMoneyService":
                String proposalNo,
                 modalPremium,
                 response;
                proposalNo = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                modalPremium = (String) (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
                System.out.println(proposalNo);
                System.out.println(modalPremium);
                resultString = callAPI.callSocket("MyMoneyService", proposalNo + "|" + modalPremium);
                winame = (String) iFormRef.getControlValue("WorkItemName");
                planName=(String) iFormRef.getControlValue("PLAN_NAME");
                //parameters += AgentCodes + "|" + spNo + "|" + channel + "|" + customerSignDate + "|" + insuranceStatus + "|" + CommissionShare + "|" + productType + "|" + customerPan;	
                
                String query2 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + proposalNo + "',GETDATE(),'" + planName + "','" + modalPremium + "','" + resultString + "')";

                iFormRef.getDataFromDB(query2);
                
                break;

            case "MyAgentService":
                
                
                String AgentCodes = "",
                 parameters = "",
                 spNo = "",
                 channel = "",
                 customerSignDate,
                 productType,
                 customerPan,
                 insuranceStatus,
                 branchCode,
                 policyNumber,
                 agentId1 = "",
                 agentId2 = "",
                   source="", // DR-15370
                 isOnline=""; // DR-15370
                int CommissionShare = 0,
                 rowCounter = 1;
                JSONArray agentDetailsTable = iFormRef.getDataFromGrid("table47");
                String query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'My Agent','"+iFormRef.getActivityName()+"' )";

                iFormRef.getDataFromDB(query_S);
                System.out.println("MyAgentService - resultString" + resultString);
                for (Object i : agentDetailsTable) {
                    JSONObject obj = (JSONObject) i;
                    if (rowCounter == 1) {
                        agentId1 = obj.get("Agent Code").toString();
                    } else {
                        agentId2 = obj.get("Agent Code").toString();
                    }
                    //AgentCodes += obj.get("Agent Code").toString() + "^";	
                    //channel = obj.get("Channel").toString();	
                    CommissionShare += Integer.parseInt(obj.get("Commission Share").toString());
                    rowCounter++;
                }
                channel = iFormRef.getValue("CHANNEL").toString();
                branchCode = iFormRef.getValue("BRANCH_CODE").toString();
                policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                customerSignDate = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
                productType = (String) iFormRef.getControlValue("PLAN_TYPE");
                insuranceStatus = (String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                customerPan = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PAN_NUMBER");
                 source= (String) iFormRef.getControlValue("SOURCING_SYSTEM"); //DR-15370
                if (channel.equalsIgnoreCase("X") || channel.equalsIgnoreCase("BY") || channel.equalsIgnoreCase("LVB")
                        || channel.equalsIgnoreCase("F") || channel.equalsIgnoreCase("P") || channel.equalsIgnoreCase("B9")|| channel.equalsIgnoreCase("BU")|| channel.equalsIgnoreCase("BW") || channel.equalsIgnoreCase("BO") || channel.equalsIgnoreCase("C") || channel.equalsIgnoreCase("BX") || channel.equalsIgnoreCase("C0") || channel.equalsIgnoreCase("BC")) { //DR-44145 Lovnish new channel 'C0' added  //47311 Channel BC by ezaz
                    spNo = (String) iFormRef.getControlValue("Q_AGENT_DETAILS.SP_CERTIFICATE_NO");
                }
                if(source.equalsIgnoreCase("Offline"))
                	isOnline="N";
                else if(source.equalsIgnoreCase("Online"))
                	isOnline="Y";
                /*if (AgentCodes.contains("^")) {	
                    AgentCodes = AgentCodes.substring(0, AgentCodes.length() - 1);	
                }*/

                // On Adding new Agent					  
                if (stringData.length() > 0) {
                    String params[] = stringData.split("\\|");
                    agentId1 = params[0];
                    agentId2 = "";
                    CommissionShare = Integer.parseInt(params[1]);
                }
                JSONObject agentMetadataObj = new JSONObject();
                proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                agentMetadataObj.put("X-Correlation-ID", proposalNumber + "-" + DolphinUtil.generateRandomString(15));
                agentMetadataObj.put("X-App-ID", "IBPS");
                agentMetadataObj.put("policyNumber", policyNumber);
                agentMetadataObj.put("requestType", "agentDetails"); //DR-8003
                JSONObject agentPayloadObj = new JSONObject();
                agentPayloadObj.put("agentId1", agentId1);
                agentPayloadObj.put("spNo1", spNo);
                agentPayloadObj.put("agentId2", agentId2);
                agentPayloadObj.put("spNo2", "");
                agentPayloadObj.put("twoAgents", "n");
                agentPayloadObj.put("channel", channel);
                agentPayloadObj.put("branchCode", branchCode);
                agentPayloadObj.put("type", "CertificationDetailsRequest");
                agentPayloadObj.put("transTrackingId", "");
                agentPayloadObj.put("customerSignDate", customerSignDate);
                agentPayloadObj.put("insuranceStatus", insuranceStatus);
                agentPayloadObj.put("splitRatio", CommissionShare);
                agentPayloadObj.put("productType", productType);
                agentPayloadObj.put("customerPan", customerPan);
                 agentPayloadObj.put("isOnline", isOnline);//DR-15370
                JSONObject agentJSONOBody = new JSONObject();
                agentJSONOBody.put("metadata", agentMetadataObj);
                agentJSONOBody.put("payload", agentPayloadObj);
                String agentRequestJson = agentJSONOBody.toJSONString();
                winame = (String) iFormRef.getControlValue("WorkItemName");
                planName = (String) iFormRef.getControlValue("PLAN_NAME");
                //parameters += AgentCodes + "|" + spNo + "|" + channel + "|" + customerSignDate + "|" + insuranceStatus + "|" + CommissionShare + "|" + productType + "|" + customerPan;	
                System.out.println("MyAgentService - parameters" + agentRequestJson);
                resultString = callAPI.callSocket("MyAgentService", agentRequestJson);

                String query1 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + proposalNumber + "',GETDATE(),'" + planName + "','" + agentRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query1);
                System.out.println("MyAgentService - resultString" + resultString);
                
                
                  query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'MyAgentEnd','"+iFormRef.getActivityName()+"' )";

                iFormRef.getDataFromDB(query_S);
                System.out.println("myagentend");
                break;
             case "MyManagerService":
                 AgentCodes = "";
                 parameters = "";
                 spNo = "";
                 channel = "";
               
                 agentId1 = "";
                 agentId2 = "";
                 CommissionShare = 0;
                 rowCounter = 1;
                agentDetailsTable = iFormRef.getDataFromGrid("table47");
                for (Object i : agentDetailsTable) {
                    JSONObject obj = (JSONObject) i;
                    if (rowCounter == 1) {
                        agentId1 = obj.get("Agent Code").toString();
                    } else {
                        agentId2 = obj.get("Agent Code").toString();
                    }
                    //AgentCodes += obj.get("Agent Code").toString() + "^";	
                    //channel = obj.get("Channel").toString();	
                    CommissionShare += Integer.parseInt(obj.get("Commission Share").toString());
                    rowCounter++;
                }
                channel = iFormRef.getValue("CHANNEL").toString();
                branchCode = iFormRef.getValue("BRANCH_CODE").toString();
                policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                customerSignDate = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
                productType = (String) iFormRef.getControlValue("PLAN_TYPE");
                insuranceStatus = (String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                customerPan = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PAN_NUMBER");
                if (channel.equalsIgnoreCase("X") || channel.equalsIgnoreCase("BY") || channel.equalsIgnoreCase("LVB")
                        || channel.equalsIgnoreCase("F") || channel.equalsIgnoreCase("P") || channel.equalsIgnoreCase("C0")) { //DR-44145 Lovnish new channel 'C0' added
                    spNo = (String) iFormRef.getControlValue("Q_AGENT_DETAILS.SP_CERTIFICATE_NO");
                }
                /*if (AgentCodes.contains("^")) {	
                    AgentCodes = AgentCodes.substring(0, AgentCodes.length() - 1);	
                }*/

                // On Adding new Agent					  
                if (stringData.length() > 0) {
                    String params[] = stringData.split("\\|");
                    agentId1 = params[0];
                    agentId2 = "";
                    CommissionShare = Integer.parseInt(params[1]);
                }
                agentMetadataObj = new JSONObject();
                proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                agentMetadataObj.put("X-Correlation-ID", proposalNumber + "-" + DolphinUtil.generateRandomString(15));
                agentMetadataObj.put("X-App-ID", "IBPS");
                agentMetadataObj.put("policyNumber", policyNumber);
                agentMetadataObj.put("requestType", "managerDetails"); //DR-8003
                agentPayloadObj = new JSONObject();
                agentPayloadObj.put("agentId1", agentId1);
                agentPayloadObj.put("spNo1", spNo);
                agentPayloadObj.put("agentId2", agentId2);
                agentPayloadObj.put("spNo2", "");
                agentPayloadObj.put("twoAgents", "n");
                agentPayloadObj.put("channel", channel);
                agentPayloadObj.put("branchCode", branchCode);
                agentPayloadObj.put("type", "CertificationDetailsRequest");
                agentPayloadObj.put("transTrackingId", "");
                agentPayloadObj.put("customerSignDate", customerSignDate);
                agentPayloadObj.put("insuranceStatus", insuranceStatus);
                agentPayloadObj.put("splitRatio", CommissionShare);
                agentPayloadObj.put("productType", productType);
                agentPayloadObj.put("customerPan", customerPan);
                agentJSONOBody = new JSONObject();
                agentJSONOBody.put("metadata", agentMetadataObj);
                agentJSONOBody.put("payload", agentPayloadObj);
                agentRequestJson = agentJSONOBody.toJSONString();
                winame = (String) iFormRef.getControlValue("WorkItemName");
                planName = (String) iFormRef.getControlValue("PLAN_NAME");
                //parameters += AgentCodes + "|" + spNo + "|" + channel + "|" + customerSignDate + "|" + insuranceStatus + "|" + CommissionShare + "|" + productType + "|" + customerPan;	
                System.out.println("MyAgentService - parameters" + agentRequestJson);
                resultString = callAPI.callSocket("MyAgentService", agentRequestJson);

                query1 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + proposalNumber + "',GETDATE(),'" + planName + "','" + agentRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query1);
                System.out.println("MyAgentService - resultString" + resultString);
                break;
                // DR-16954
              case "EDCValidate":
            	String policyNo="", illustrationDate="", edcSelectedByCustomer="", signDate="", uwDecisionDate="", uinChangeDate_old="",
            	moneyReceivedDate="", dobInsured="", uinChangeDate="", financialYearStartDate="", financialYearEndDate="",
            	edcSelectedFlag="",Channel_edc="", PlanCode_edc="", premiumAmount="", edcServiceFlag="",
                isRollbackCase="", previousUwDecision="",previousClearCaseFlag="",previousEdc="",X_Correlation_ID="",
                FINAL_EDC="",ING_BATCH_DATE="",DEFAULT_EDC_FLAG="",IsJointLife=""; 
                
            	 
            	 String query_edc = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'EDCValidateStart','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_edc);
                 
                 policyNo=iFormRef.getValue("PROPOSAL_NUMBER").toString();
                 illustrationDate= (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.BI_GEN_DATE");
                 edcSelectedByCustomer= (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
                 signDate=(String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
               //  moneyReceivedDate=iFormRef.getControlValue("Q_PAYMENT_DETAILS.MONEY_RECEIVED_DATE").toString(); 
                 IsJointLife=(String) iFormRef.getControlValue("IS_JOINTLIFE");
                 if(IsJointLife.equalsIgnoreCase("Y"))
                     dobInsured=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                 else        
                    dobInsured=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.DOB");
                 Channel_edc = (String) iFormRef.getControlValue("CHANNEL");
                 PlanCode_edc = (String) iFormRef.getControlValue("PLAN_NAME");
                 premiumAmount = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
                 edcServiceFlag = stringData;
                 isRollbackCase = (String) iFormRef.getControlValue("IS_ROLLBACK");
                 if(isRollbackCase.equalsIgnoreCase("")){
                	 isRollbackCase="N";
                 }
                 previousUwDecision = (String) iFormRef.getControlValue("PREV_UW_DECISION");
                 previousClearCaseFlag = (String) iFormRef.getControlValue("PREV_AUTOUW_FLAG");
                 previousEdc = (String) iFormRef.getControlValue("PREV_EDC");
                    
                 if(previousUwDecision.equalsIgnoreCase("Counter Offer Accept"))
                    previousUwDecision="COA";
                  else if(previousUwDecision.equalsIgnoreCase("CO Reconsider"))
                      previousUwDecision="COR";
                  else if(previousUwDecision.equalsIgnoreCase("Accept -Standard"))
                      previousUwDecision="Accept";
                 
                 List queryList_edc;
                 uinChangeDate="";
                 queryList_edc = (List) iFormRef.getDataFromDB("SELECT MAX(UIN_EFFECTIVE_DT) FROM NG_NB_MS_UIN_LOGIC(NOLOCK) "
                         + "WHERE Plan_Code='" + PlanCode_edc + "' "
                         + "AND Channel='" + Channel_edc + "'");
                 if (!queryList_edc.isEmpty()) {
                	 uinChangeDate_old = (String) ((List) queryList_edc.get(0)).get(0);
                     uinChangeDate_old = uinChangeDate_old.substring(0,10);
                	 String date1="", month1="", year1="";
                     String[] d=uinChangeDate_old.split("/");       
                     year1=d[2];
                     month1=d[1];
                     date1=d[0];
                     uinChangeDate=year1+"-"+month1+"-"+date1;
                     System.out.println(uinChangeDate);
                 }
                 
                 String CurrentFinancialDate="", year="", month="",CurrentFinancialmonth="";
         		int financialYear=0;
         		
         		/*List CurrentDate_edc=(List) iFormRef.getDataFromDB("select year(getdate())");
            	if (!CurrentDate_edc.isEmpty()) {
            		CurrentFinancialDate = (String) ((List) CurrentDate_edc.get(0)).get(0);
            	}*/
                        Date d= new Date();
                                
                
                
                /*List CurrentDate_edc_month=(List) iFormRef.getDataFromDB("select month(getdate())");
            	if (!CurrentDate_edc_month.isEmpty()) {
            		CurrentFinancialmonth = (String) ((List) CurrentDate_edc_month.get(0)).get(0);
            	}*/
         		
         		
            	try {
         		{
         			       
         		       
         		      
         		      int y=d.getYear() + 1900;
         		       int m=d.getMonth() + 1;
         		       if(m<=3) {
         		    	   financialYear=y-1;
         		       }
         		       else {
         		    	   financialYear=y;
         		       }

           		     financialYearStartDate=financialYear + "-04-01";
           		     financialYearEndDate=(financialYear+1) + "-03-31";
         			}
            	}catch (Exception ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                String patterm="yyyy-MM-dd";
                SimpleDateFormat sfd=new SimpleDateFormat(patterm);
                uwDecisionDate=(String)sfd.format(new Date());
                edcSelectedByCustomer=sfd.format(sfd.parse(edcSelectedByCustomer));
        
         	    
                //Money received date
                winame = (String) iFormRef.getControlValue("WorkItemName");
                planName = (String) iFormRef.getControlValue("PLAN_NAME");
               
                String query_date="";
                List queryResult_1;
                query_date = "select MONEY_RECEIVED_DATE from NG_NB_PAYMENT_DETAILS(nolock) WHERE WI_NAME='"+winame+"'";
                queryResult_1 = iFormRef.getDataFromDB(query_date);
                if (!queryResult_1.isEmpty()) {
               	 moneyReceivedDate = (String) ((List) queryResult_1.get(0)).get(0);
                }
                // added by sparsh DR-21502
                String query_date_1="", AppReceivedDate="";
                List queryResult_2;
                query_date_1 = "select APP_RECEIVE_DATE from NG_NB_POLICY_DETAILS(nolock) WHERE WI_NAME='"+winame+"'";
                queryResult_2 = iFormRef.getDataFromDB(query_date_1);
                if (!queryResult_2.isEmpty()) {
               	AppReceivedDate = (String) ((List) queryResult_2.get(0)).get(0);
                }
            	 //uwDecisionDate=(String)CurrentFinancialDate.substring(0,10);
            	 edcSelectedFlag= (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.Customer_Selected_EDC_Tag");
            	 X_Correlation_ID= policyNo + "-" + DolphinUtil.generateRandomString(15);
                 //added by mansi
                try{     
                    AppReceivedDate=sfd.format(sfd.parse(AppReceivedDate)); // mansi edc error
                    moneyReceivedDate=sfd.format(sfd.parse(moneyReceivedDate));
                    illustrationDate=sfd.format(sfd.parse(illustrationDate));
                    signDate=sfd.format(sfd.parse(signDate));
                    dobInsured=sfd.format(sfd.parse(dobInsured));
                    uinChangeDate=sfd.format(sfd.parse(uinChangeDate));
                    previousEdc=sfd.format(sfd.parse(previousEdc));
                }catch(Exception ex){
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null,"EDC"+ ex);
                }
                 JSONObject EdcMetadataObj = new JSONObject();
               //  proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                EdcMetadataObj.put("X-Correlation-ID",X_Correlation_ID);
                EdcMetadataObj.put("X-App-ID", "IBPS");
                JSONObject EdcPayloadObj = new JSONObject();
                EdcPayloadObj.put("policyNo", policyNo);
                EdcPayloadObj.put("illustrationDate", illustrationDate);
                EdcPayloadObj.put("edcSelectedByCustomer", edcSelectedByCustomer);
                EdcPayloadObj.put("signDate", signDate);
                EdcPayloadObj.put("uwDecisionDate", uwDecisionDate);
                EdcPayloadObj.put("moneyReceivedDate", moneyReceivedDate);
                EdcPayloadObj.put("dob", dobInsured);
                EdcPayloadObj.put("uinChangeDate", uinChangeDate);
                EdcPayloadObj.put("financialYearStartDate", financialYearStartDate);
                EdcPayloadObj.put("financialYearEndDate", financialYearEndDate);
                EdcPayloadObj.put("edcSelectedFlag", edcSelectedFlag);
                EdcPayloadObj.put("premiumAmount", premiumAmount);
                EdcPayloadObj.put("edcServiceFlag", edcServiceFlag);
                EdcPayloadObj.put("isRollbackCase", isRollbackCase); 
                EdcPayloadObj.put("previousUwDecision", previousUwDecision); 
                EdcPayloadObj.put("previousClearCaseFlag", previousClearCaseFlag);
                EdcPayloadObj.put("previousEdc", previousEdc);
                EdcPayloadObj.put("appReceiveDate", AppReceivedDate);
                EdcPayloadObj.put("planCode", planName);

               
                winame = (String) iFormRef.getControlValue("WorkItemName");
                planName = (String) iFormRef.getControlValue("PLAN_NAME");
               
                 JSONObject EdcJSONOBody = new JSONObject();
                 EdcJSONOBody.put("metadata", EdcMetadataObj);
                 EdcJSONOBody.put("payload", EdcPayloadObj);
                String EdcRequestJson = EdcJSONOBody.toJSONString();
                
                
                
                query_edc = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + policyNo + "',GETDATE(),'" + planName + "','" + EdcRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query_edc);
                
                resultString = callAPI.callSocket("EDCValidateService", EdcRequestJson);
                
                query_edc = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + policyNo + "',GETDATE(),'" + planName + "','" + EdcRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query_edc);
                
                System.out.println("EDCValidateService - Inserting val into table");
                
              //  resultString="{\"payload\":{\"finalEdc\":\"2022-12-12\",\"ingBatchDate\":\"\",\"defaultEdcFlag\":\"Y\"},\"msgInfo\":{\"msg\":\"Success\",\"msgDescription\":\"Details Fetched\",\"msgCode\":\"200\"}}";
                
    			 JSONParser jsonParserEDC = new JSONParser();
    			 JSONObject jsonObj = (JSONObject) jsonParserEDC.parse(resultString);
                 JSONObject msgInfoObj_EDC = (JSONObject) jsonParserEDC.parse(jsonObj.get("msgInfo").toString());
                 JSONObject payloadOBJ_EDC = (JSONObject) jsonParserEDC.parse(jsonObj.get("payload").toString());
                          	 
                 if(msgInfoObj_EDC.get("msgCode").toString().equalsIgnoreCase("200")){
                	 FINAL_EDC = payloadOBJ_EDC.get("finalEdc").toString();
                	 ING_BATCH_DATE = payloadOBJ_EDC.get("ingBatchDate").toString();
                	 DEFAULT_EDC_FLAG = payloadOBJ_EDC.get("defaultEdcFlag").toString();
                	 
                	 query_edc = "INSERT INTO NG_NB_REST_VALIDATE_EDC(WI_NAME,ENTRY_DATE_TIME,X_APP_ID,X_CORRELATION_ID,POLICY_NO,ILLUSTRATION_DATE,EDC_SELECTED_BY_CUSTOMER,"
                     		+"SIGN_DATE,UW_DECISION_DATE,MONEY_RECEIVED_DATE,INSURED_DOB,UIN_CHANGE_DATE,FINANCIAL_YEAR_START_DATE,FINANCIAL_YEAR_END_DATE,EDC_SELECTED_FLAG,"
                     		+"PREMIUM_AMOUNT,EDC_SERVICE_FLAG,PREV_UW_DECISION,PREV_AUTOUW_FLAG,PREV_EDC,IS_ROLLBACK,PLAN_CODE,APP_RECEIVE_DATE)"
                             + "VALUES('" + winame + "',GETDATE(),'IBPS','"+X_Correlation_ID+"','" + policyNo + "','" + illustrationDate + "','" + edcSelectedByCustomer + "','" + signDate + "','"
                             + uwDecisionDate +"','" +moneyReceivedDate +"','"+dobInsured+"','"+uinChangeDate+"','"+financialYearStartDate+"','"+financialYearEndDate+"','"
                             + edcSelectedFlag+"','"+premiumAmount+"','"+edcServiceFlag+"','"+previousUwDecision+"','"+previousClearCaseFlag+"','"+previousEdc+"','"+isRollbackCase+"','"+planName+"','"+AppReceivedDate+"')";

                     iFormRef.getDataFromDB(query_edc);
                     
                	 query_edc = "INSERT INTO NG_NB_REST_VALIDATE_EDC_SERVICE_STATUS(WI_NAME,ENTRYDATETIME,FINAL_EDC,ING_BATCH_DATE,DEFAULT_EDC_FLAG)\n"
                             + "VALUES('" +winame+ "',GETDATE(),'"+FINAL_EDC+"','"+ING_BATCH_DATE+"','"+DEFAULT_EDC_FLAG+"')";

                	 iFormRef.getDataFromDB(query_edc);
                 }
                
                System.out.println("EDCValidateService - resultString" + resultString);
                
                
                  query_edc = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'EDCValidateEnd','"+iFormRef.getActivityName()+"' )";

                iFormRef.getDataFromDB(query_edc);
             
            	 break;

            	// DR-21511 UW GOVERNANCE SERVICE

              case "UW_GOVERNANCE":
                  try
                  {
            	String policyno="", registrationNumber="", appReceiveDate="", workstepName="", uwDecisionDate_uw="", sumAssured_uw="",
            	PLAN_DESC="", agent1Id="", agent2Id="", agent3Id="", agent1Share="",agent2Share="",agent3Share="",clientIdP="",
            	agent1StarAgentFlag="", agent2StarAgentFlag="", agent3StarAgentFlag="",agent1Level="",clientIdI="",
            	agent2Level="", agent3Level="",AssessedIncome="",atrTag="",autoUwFlag="",bloodProfileKickout="",
            	Case_status="",ccFlag="",cibilScore="",estimatedIncome="", Decision="",
            	isCounterOffer="N", currentCityI="", currentCityp="",currentCountryI="",currentCountryP="",currentPinCodeI="",
            	currentPinCodeP="", currentStateI="",currentStateP="",DedupeFlagP="",DedupeFlagI="", customerClassificationCode="",declaredIncomeI="",
            	declaredIncomeP="",EMPdiscount="",dobP="",educationP="",educationI="", genderI="",genderP="",industryI="",
            	industryP="",nationalityI="",nationalityP="",occupationI="",occupationP="",pepFlagP="",permCityI="",
            	permCityP="",permPinCodeI="",permPinCodeP="",premStateI="",premStateP="",insuredRelationWithProposer="",nomineeRelationWithProposer="",
            	initiativeType="",rollback="",bankingSince="",annualizedPremium="",covidQues1="",covidQues3="",lastUwSsoId="",
            	stpFlag="",sourceApplication="",totalPrevSumAssuredPF="", modifiedinitiativeType="", axisCustomerClassification="", yblCustomerClassification="";
            	  Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 00 Sparsh");
                
            	 String query_UW = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW);
                 policyno=iFormRef.getControlValue("PROPOSAL_NUMBER").toString();
                 registrationNumber=iFormRef.getControlValue("WI_NAME").toString();
                 productType =iFormRef.getControlValue("PLAN_TYPE").toString();
                Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 01 Sparsh");
                 String query_UW1 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart01Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW1);
                 //RELATIONSHIP_WITH_PROPOSER
                 clientType = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
                 if(clientType.equalsIgnoreCase("Proposer")) {
                	 insuredRelationWithProposer=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.RELATIONSHIP_WITH_PROPOSER");
                	 clientIdP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_ID");
                     clientIdI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.CLIENT_ID");
                      
                 }else if(clientType.equalsIgnoreCase("ProposerInsured")) {
                	 insuredRelationWithProposer="SELF";
                	 clientIdP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_ID");
                     clientIdI = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_ID");
                      
                 }else{
                	insuredRelationWithProposer=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.RELATIONSHIP_WITH_PROPOSER");
                	clientIdP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_ID");
                    clientIdI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.CLIENT_ID");
                 }
                 
                 rollback = (String) iFormRef.getControlValue("IS_ROLLBACK");
                 if(rollback.equalsIgnoreCase("")){
                	 rollback="N";
                 }
                  Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 02 Sparsh");
                
                 // Annualized Premium logic
                 if(productType.equalsIgnoreCase("ULIP")) {
                	 annualizedPremium=(String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.ATP");
                 }else {
                	 annualizedPremium=(String) iFormRef.getControlValue("AFYP");
                 }
                 
                    String query_UW2 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart02Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW2);
                 // Kick Out Messages logic
                 String financialKickout="",clientLevelAfyp="",miscKickout="",merKickout="",proposalFormKickout="",teleMerKickout="",smokerTagI="",
                 urmuKickout="",diagnosticCentreKickout="",edc_UW="",emr_UW="",flatExtra="",multExtra="",objOfInsurance="",
                 revisedSumAssured="",relativeHealthScore="",mirrorReportStatus="",dcGradingStatus="",shieldRiskTag="",suc="",
                 MSA="",iibFsa="",iibKickout="",iibPrismScore="",fsa="",medicalTrigerred="",uwLevel="";
                 
                 if(productType.equalsIgnoreCase("ANNUITY") || productType.equalsIgnoreCase("JOINT")) {
                	 bloodProfileKickout = (String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.BLOOD_PROFILE_MOD_OP");
                	 financialKickout = (String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.FINANCIAL_MOD_OP");
                	 miscKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.MISC_MOD_OP");
                	 merKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.MER_MOD_OP");
                	 proposalFormKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.PROPOSAL_FORM_MOD_OP");
                	 teleMerKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.TELE_MER_MOD_OP");
                	 urmuKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.URMU_MOD_OP");
                	 diagnosticCentreKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP_PROP.DIAGNOSTIC_CENTRE_OP");
                	 relativeHealthScore =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS_PROP.RELATIVE_HEALTH_SCORE");
                	 mirrorReportStatus =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS_PROP.MIROR_REPORT");
                	 dcGradingStatus =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS_PROP.DC_GRADING");
                	 suc=(String) iFormRef.getControlValue("Q_SUC_PARAMETERS_PROP.SUM_UNDER_CONSIDERATION");
                        MSA=(String) iFormRef.getControlValue("Q_SUC_PARAMETERS_PROP.MSA");
                        fsa=(String) iFormRef.getControlValue("Q_SUC_PARAMETERS_PROP.FSA");
                        medicalTrigerred=(String) iFormRef.getControlValue("Q_BRMS_MED_GRID_OP_PROP.GRID_OUTPUT");
                        clientLevelAfyp=(String) iFormRef.getControlValue("Q_SUC_PARAMETERS_PROP.AFYP");
                 }else
                 	{
                	 bloodProfileKickout = (String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.BLOOD_PROFILE_MOD_OP");
                	 financialKickout = (String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.FINANCIAL_MOD_OP");
                	 miscKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.MISC_MOD_OP");
                	 merKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.MER_MOD_OP");
                	 proposalFormKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.PROPOSAL_FORM_MOD_OP");
                	 teleMerKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.TELE_MER_MOD_OP");
                	 urmuKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.URMU_MOD_OP");
                	 diagnosticCentreKickout =(String) iFormRef.getControlValue("Q_BRMS_UW_MOD_OP.DIAGNOSTIC_CENTRE_OP");
                	 relativeHealthScore =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS.RELATIVE_HEALTH_SCORE");
                	 mirrorReportStatus =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS.MIROR_REPORT");
                	 dcGradingStatus =(String) iFormRef.getControlValue("Q_BRMS_UW_DIAGNOSTIC_CENTRE_DETAILS.DC_GRADING");
                	 suc=(String) iFormRef.getControlValue("Q_SUC_PARAMETERES.SUM_UNDER_CONSIDERATION");
                        MSA=(String) iFormRef.getControlValue("Q_SUC_PARAMETERES.MSA");
                        fsa=(String) iFormRef.getControlValue("Q_SUC_PARAMETERES.FSA");
                        medicalTrigerred=(String) iFormRef.getControlValue("Q_BRMS_MED_GRID_OP.GRID_OUTPUT");
                        clientLevelAfyp=(String) iFormRef.getControlValue("Q_SUC_PARAMETERES.AFYP");
                 }
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 1 Sparsh");
                    String query_UW3 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart03Sparsh','"+iFormRef.getActivityName()+"' )";
                 iFormRef.getDataFromDB(query_UW3);// EDC LOGIC
                 edc_UW=(String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.EDC");
                 if(edc_UW.equalsIgnoreCase("")) {
                	 edc_UW=(String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
                 }

                 stpFlag=(String) iFormRef.getControlValue("Q_POLICY_VALIDATION_DETAILS.STRAIGHT_PASS_CASE");
                 revisedSumAssured = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 1);
                 emr_UW = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 9);
                 multExtra = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 10);
                 flatExtra = (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 11);
                 smokerTagI = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SMOKER_CLASS");
                 shieldRiskTag =(String) iFormRef.getControlValue("Q_MORTALITY_RELATED.SHIELD_MODULE_CATEGORY");
                 iibFsa=(String) iFormRef.getControlValue("Q_SUC_PARAMETERES.IIB_FSA");
                 iibKickout=(String) iFormRef.getControlValue("Q_MORTALITY_RELATED.IIB_KICKOUT");
                 if(iibKickout.equalsIgnoreCase("")){
                	 iibKickout="NA";
                 }
                 iibPrismScore=(String) iFormRef.getControlValue("Q_MORTALITY_RELATED.IIB_PRISM_SCORE");
                 objOfInsurance=(String) iFormRef.getControlValue("OBJ_OF_INSURANCE");
                 covidQues1=(String) iFormRef.getControlValue("Q_MED_INFO_INSUR.COVID_QUESTIONS");
                 covidQues3=(String) iFormRef.getControlValue("Q_MED_INFO_PROP.COVID_QUESTIONS");
                 bankingSince = (String) iFormRef.getControlValue("Q_BANKING_INFO.BANKING_SINCE");
                 uwLevel  = (String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.UW_LEVEL");
                 AssessedIncome = (String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.ASSESSED_INCOME");
                 initiativeType= (String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.UW_INITIATIVE");
                modifiedinitiativeType=(String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.UW_INITIATIVE_MODIFICATION");//DR-46364 Farman
                axisCustomerClassification=(String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_CLASS_DESC");//DR-46364 Farman
                yblCustomerClassification=(String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.YBL_CUST_CLASS");//DR-46364 Farman
                 //nomineeRelationWithProposer=(String) iFormRef.getControlValue("Q_LIST_NOMINEE_DETAILS.RELATIONSHIP_PROPOSER");
                 permCityI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.PERM_CITY_DISTRICT");
                 permCityP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PERM_CITY_DISTRICT");
                 permPinCodeI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.PERM_PIN_CODE");
                 permPinCodeP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PERM_PIN_CODE");
                 premStateI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.PERM_STATE_UT");
                 premStateP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PERM_STATE_UT");
                 pepFlagP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.POLITICALLY_EXPOSED");
                 nationalityI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.NATIONALITY");
                 nationalityP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.NATIONALITY");
                 occupationI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.OCCUPATION");
                 occupationP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.OCCUPATION");
                 sumAssured_uw=(String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SUM_ASSURED");
                 winame = (String) iFormRef.getControlValue("WorkItemName");
                 planName = (String) iFormRef.getControlValue("PLAN_NAME");
                 modalPremium = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
                 branchCode = iFormRef.getValue("BRANCH_CODE").toString();
                 Case_status = iFormRef.getValue("WORK_STATUS").toString();
                 ccFlag = iFormRef.getValue("CC_Flag").toString();
                // clientIdP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_ID");
                 //clientIdI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.CLIENT_ID");
                 currentCityI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.CITY_DISTRICT");
                 currentCityp=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CITY_DISTRICT");
                 currentCountryI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.COUNTRY");
                 currentCountryP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.COUNTRY");
                 currentPinCodeI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.PIN_CODE");
                 currentPinCodeP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.PIN_CODE");
                 currentStateI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.STATE_UT");
                 currentStateP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.STATE_UT");
                 autoUwFlag=iFormRef.getControlValue("Auto_UW_Flag").toString(); 
                 dobInsured=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.DOB");
                 Channel = (String) iFormRef.getControlValue("CHANNEL");
                 declaredIncomeI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.EXACT_INCOME");
                 declaredIncomeP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.EXACT_INCOME");
                 EMPdiscount = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
                 if(EMPdiscount.equalsIgnoreCase("")){
                	 EMPdiscount="N";
                 }
                 dobP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                 educationI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.EDUCATION");
                 educationP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.EDUCATION");
                 genderI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.GENDER");
                 genderP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.GENDER");
                 industryI = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.INDUSTRY_TYPE");
                 industryP = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.INDUSTRY_TYPE");
                 atrTag = (String) iFormRef.getControlValue("ATR");
                 if(atrTag==null)
                 {
                	 atrTag="N";
                 }
                 String rural_urban=(String) iFormRef.getControlValue("Q_POLICY_DETAILS.Rural_urban_Social");
                 lastUwSsoId = (String) iFormRef.getControlValue("LAST_UW_SSO_ID");
                    String query_UW5 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart05Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW5);
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 2 Sparsh");
                 
                 // Customer Classification Code logic
                 if(Channel.equalsIgnoreCase("X")) {
                	 customerClassificationCode = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.AXIS_CUST_CLASS");
                 }else if(Channel.equalsIgnoreCase("BY")) {
                	 customerClassificationCode = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.YBL_CUST_CLASS");
                 }
                 
                 // dedupe logic Proposer
                 DedupeFlagP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.DOLPPHINDEDUPE");
                 if(DedupeFlagP.equalsIgnoreCase(""))
                 {
                	 DedupeFlagP=(String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.MproDedupe");
                 }
				 /*else if(DedupeP.equalsIgnoreCase("EXACT")) {
                	 DedupeFlagP="Y";
                 }else
                	 DedupeFlagP="N";
                 */
                 // dedupe logic Insured
                 DedupeFlagI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.DOLPPHINDEDUPE");
                 if(DedupeFlagI.equalsIgnoreCase(""))
                 {
                	 DedupeFlagI=(String) iFormRef.getControlValue("Q_L2BI_DETAILS.MproDedupe");
                 }/*else if(DedupeP.equalsIgnoreCase("EXACT")) {
                	 DedupeFlagI="Y";
                 }else
                	 DedupeFlagI="N";
                 */
                 Decision = (String) iFormRef.getControlValue("Decision");
               	 if(Decision.equalsIgnoreCase("Counter Offer") || Decision.equalsIgnoreCase("Counter Offer Accept") || Decision.equalsIgnoreCase("CO Reconsider"))
                  {
                        if(Decision.equalsIgnoreCase("Counter Offer")){
                            isCounterOffer="Y";
                        }
                        smokerTagI = (String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED"); //DR-39167 mansi
                  }
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 3 Sparsh");
                 
                 List queryResult_uw;
                 query_date = "EXEC NG_SP_NB_UW_GOVERNANCE_REQ '"+winame+"','"+planName+"'";
                 queryResult_uw = iFormRef.getDataFromDB(query_date);
                 if (!queryResult_uw.isEmpty()) {
                	 appReceiveDate = (String) ((List) queryResult_uw.get(0)).get(0);
                         cibilScore= (String) ((List) queryResult_uw.get(0)).get(1);
                         estimatedIncome = (String) ((List) queryResult_uw.get(0)).get(2);
                         nomineeRelationWithProposer = (String) ((List) queryResult_uw.get(0)).get(3);
                         PLAN_DESC = (String) ((List) queryResult_uw.get(0)).get(4);
                         sourceApplication = (String) ((List) queryResult_uw.get(0)).get(5);
                         totalPrevSumAssuredPF = (String) ((List) queryResult_uw.get(0)).get(6); //DR-39672 mansi
                      }
                 
                 workstepName= (String) iFormRef.getActivityName();
                  String query_UW6 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart06Sparsh','"+iFormRef.getActivityName()+"' )";
                  try
                  {
                 iFormRef.getDataFromDB(query_UW6);
                 String pattern="yyyy-MM-dd";
                 SimpleDateFormat sfdd=new SimpleDateFormat(pattern);
                 appReceiveDate=sfdd.format(new SimpleDateFormat("MM/dd/yy HH:mm:ss").parse(appReceiveDate));
 
                 String patternTime="yyyy-MM-dd hh:mm:s";
                 sfdd=new SimpleDateFormat(patternTime);
                 uwDecisionDate_uw=(String)sfdd.format(new Date());
                 edc_UW=sfdd.format(new SimpleDateFormat("yyyy-MM-dd").parse(edc_UW));
                  }
                  catch (Exception exG) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null,"Governance"+ exG);
                    }
                 
                  String query_UW7 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart07Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW7);
                
                 CommissionShare = 0;
                 rowCounter = 1;
                 agentDetailsTable = iFormRef.getDataFromGrid("table47");
                 for (Object i : agentDetailsTable) {
                    JSONObject obj = (JSONObject) i;
                    if (rowCounter == 1) {
                    	agent1Id = obj.get("Agent Code").toString();
                    	agent1Share = obj.get("Commission Share").toString();
                    	agent1StarAgentFlag = obj.get("Star Agent").toString();
                    	agent1Level = obj.get("Agent Level").toString();
                    } else if(rowCounter == 2) {
                    	agent2Id = obj.get("Agent Code").toString();
                    	agent2Share = obj.get("Commission Share").toString();
                    	agent2StarAgentFlag = obj.get("Star Agent").toString();
                    	agent2Level = obj.get("Agent Level").toString();
                    } else {
                    	agent3Id = obj.get("Agent Code").toString();
                    	agent3Share = obj.get("Commission Share").toString();
                    	agent3StarAgentFlag = obj.get("Star Agent").toString();
                    	agent3Level = obj.get("Agent Level").toString();
                    }
                    rowCounter++;
                }
                 
                 String riderCode="",riderDesc="",riderSumAssured_uw="",termOfRider="",emrOnRider="",MultExtra1="",FlatExtra1="",riderPremium="";
              
                 //Rider Details
                 JSONArray riderGridArray = new JSONArray();
                 JSONArray ja = new JSONArray();
                 
                 if(isCounterOffer.equalsIgnoreCase("Y")) {                 
                 riderGridArray = iFormRef.getDataFromGrid("COVERAGE_DETAILS_REVISED");
                 int i=0;
                  
                //for (Object obj : riderGridArray) 
                 for(int j=1;j<riderGridArray.size();j++){
                 JSONObject UWja = new JSONObject();
                 
                     JSONObject rowObj = new JSONObject();
                     rowObj = (JSONObject) riderGridArray.get(j);
                     
                     riderDesc= (String) iFormRef.getTableCellValue("table37", i, 0);
                     riderCode=(String) rowObj.get("Base Coverage (Plan Name)");
                     riderSumAssured_uw=(String) rowObj.get("Approved Sum Assured");
                     termOfRider=(String) rowObj.get("Revised Coverage Term");
                     emrOnRider=(String) rowObj.get("EMR");
                     MultExtra1=(String) rowObj.get("Mult");
                     FlatExtra1=(String) rowObj.get("Flat Extra");
                     riderPremium=(String) rowObj.get("Revised Modal Premium");
                     i++;
                     
                     UWja.put("riderCode", riderCode);
                     UWja.put("riderDescription", riderDesc);
                     UWja.put("riderSumAssured", riderSumAssured_uw);
                     UWja.put("termOfRider", termOfRider);
                     UWja.put("emrOnRider", emrOnRider);
                     UWja.put("MultExtraOnRider", MultExtra1);
                     UWja.put("FlatExtraOnRider", FlatExtra1);
                     UWja.put("riderPremium", riderPremium);
                     
                     ja.add(UWja);
                     
                     
                 }
               }else {
            	   riderGridArray = iFormRef.getDataFromGrid("table37");
                   int i=1;
                
                   for(int j=0;j<riderGridArray.size();j++){
                     JSONObject UWja = new JSONObject();
                 
                       JSONObject rowObj = new JSONObject();
                       rowObj = (JSONObject) riderGridArray.get(j);
                       
                       riderCode= (String) iFormRef.getTableCellValue("COVERAGE_DETAILS_APPLIED", i, 0);
                       riderDesc=(String) rowObj.get("Rider Type");
                       riderSumAssured_uw=(String) rowObj.get("Sum Assured");
                       termOfRider=(String) rowObj.get("Coverage Term");
                       emrOnRider="";
                       MultExtra1="";
                       FlatExtra1="";
                       riderPremium=(String) rowObj.get("Modal Premium");
                       i++;
                       
                       UWja.put("riderCode", riderCode);
                       UWja.put("riderDescription", riderDesc);
                       UWja.put("riderSumAssured", riderSumAssured_uw);
                       UWja.put("termOfRider", termOfRider);
                       UWja.put("emrOnRider", emrOnRider);
                       UWja.put("MultExtraOnRider", MultExtra1);
                       UWja.put("FlatExtraOnRider", FlatExtra1);
                       UWja.put("riderPremium", riderPremium);
                       ja.add(UWja);
                   }
                   
               }
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "line 5 Sparsh");
                 
                  String query_UW9 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart09Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW9);
            	 X_Correlation_ID= policyno + "-" + DolphinUtil.generateRandomString(15);
                 JSONObject UWMetadataObj = new JSONObject();
                 UWMetadataObj.put("X-Correlation-ID",X_Correlation_ID);
                 UWMetadataObj.put("X-App-ID", "IBPS");
                JSONObject UWPayloadObj = new JSONObject();
                
                UWPayloadObj.put("policyNumber",policyno );
                UWPayloadObj.put("registrationNumber", registrationNumber);
                UWPayloadObj.put("appReceiveDate", appReceiveDate);
                UWPayloadObj.put("workstepName", workstepName);
                UWPayloadObj.put("sourceApplication", sourceApplication);
                UWPayloadObj.put("uwDecisionDate", uwDecisionDate_uw);
                UWPayloadObj.put("sumAssured", sumAssured_uw);
                UWPayloadObj.put("annualizedPremium", annualizedPremium);
                UWPayloadObj.put("modalPremium", modalPremium);
                UWPayloadObj.put("planName", PLAN_DESC);
                UWPayloadObj.put("planCode", planName);
                UWPayloadObj.put("branchCode", branchCode);
                UWPayloadObj.put("channel", Channel); 
                UWPayloadObj.put("agent1Id", agent1Id); 
                UWPayloadObj.put("agent1Share", agent1Share);
                UWPayloadObj.put("agent1StarAgentFlag", agent1StarAgentFlag);
                UWPayloadObj.put("agent1Level", agent1Level);
                UWPayloadObj.put("agent2Id", agent2Id);
                UWPayloadObj.put("agent2Share", agent2Share);
                UWPayloadObj.put("agent2StarAgentFlag", agent2StarAgentFlag);
                UWPayloadObj.put("agent2Level", agent2Level);
                UWPayloadObj.put("agent3Id", agent3Id);
                UWPayloadObj.put("agent3Share", agent3Share);
                UWPayloadObj.put("agent3StarAgentFlag", agent3StarAgentFlag);
                UWPayloadObj.put("agent3Level", agent3Level);
                UWPayloadObj.put("assessedIncome", AssessedIncome); 
                UWPayloadObj.put("atrTag", atrTag);
                UWPayloadObj.put("autoUwFlag", autoUwFlag);
                UWPayloadObj.put("bankingSince", bankingSince);
                UWPayloadObj.put("bloodProfileKickout", bloodProfileKickout);
                UWPayloadObj.put("bmiMer", "");
                UWPayloadObj.put("bmiPf", "");
                UWPayloadObj.put("bmiTelemer", "");
                UWPayloadObj.put("caseStatus", Case_status);
                UWPayloadObj.put("ccFlag", ccFlag);
                UWPayloadObj.put("cibilEstimatedIncome", estimatedIncome);
                UWPayloadObj.put("cibilScore", cibilScore);
                UWPayloadObj.put("clientIdI", clientIdI);
                UWPayloadObj.put("clientIdP", clientIdP); 
                UWPayloadObj.put("clientLevelAfyp", clientLevelAfyp);
                UWPayloadObj.put("counterOfferFlag", isCounterOffer);
                UWPayloadObj.put("covidQues1", covidQues1);
                UWPayloadObj.put("covidQues2", "N");
                UWPayloadObj.put("covidQues3", covidQues3);
                UWPayloadObj.put("covidQues4", "N");
                UWPayloadObj.put("currentCityI", currentCityI);
                UWPayloadObj.put("currentCityP", currentCityp);
                UWPayloadObj.put("currentCountryI", currentCountryI);
                UWPayloadObj.put("currentCountryP", currentCountryP);
                UWPayloadObj.put("currentPinCodeI", currentPinCodeI);
                UWPayloadObj.put("currentPinCodeP", currentPinCodeP);
                UWPayloadObj.put("currentStateI", currentStateI);
                UWPayloadObj.put("currentStateP", currentStateP);
                UWPayloadObj.put("customerClassificationCode", customerClassificationCode);
                UWPayloadObj.put("dcGradingStatus", dcGradingStatus);
                UWPayloadObj.put("declaredIncomeI", declaredIncomeI);
                UWPayloadObj.put("declaredIncomeP", declaredIncomeP);
                UWPayloadObj.put("dedupeFlagI", DedupeFlagI);
                UWPayloadObj.put("dedupeFlagP", DedupeFlagP);
                UWPayloadObj.put("diagnosticCentreKickout", diagnosticCentreKickout);
                UWPayloadObj.put("discountFlag", EMPdiscount);
                UWPayloadObj.put("dobI", dobInsured);
                UWPayloadObj.put("dobP", dobP); 
                UWPayloadObj.put("educationI", educationI);
                UWPayloadObj.put("educationP", educationP);
                UWPayloadObj.put("effectiveDateOfCommencement", edc_UW);
                UWPayloadObj.put("emr", emr_UW);
                UWPayloadObj.put("financialKickout", financialKickout);
                UWPayloadObj.put("flatExtra", flatExtra);
                UWPayloadObj.put("fsa", fsa);
                UWPayloadObj.put("genderI", genderI);
                UWPayloadObj.put("genderP", genderP);
                UWPayloadObj.put("iibFsa", iibFsa);
                UWPayloadObj.put("iibKickout", iibKickout);
                UWPayloadObj.put("iibPrismScore", iibPrismScore);
                UWPayloadObj.put("industryI", industryI);
                UWPayloadObj.put("industryP", industryP);
                UWPayloadObj.put("lastUwSsoId", lastUwSsoId);
                UWPayloadObj.put("medicalTrigerred", medicalTrigerred);
                UWPayloadObj.put("merKickout", merKickout);
                UWPayloadObj.put("mirrorReportStatus", mirrorReportStatus);
                UWPayloadObj.put("miscKickout", miscKickout);
                UWPayloadObj.put("msa", MSA);
                UWPayloadObj.put("multExtra", multExtra);
                UWPayloadObj.put("nationalityI", nationalityI);
                UWPayloadObj.put("nationalityP", nationalityP);
                UWPayloadObj.put("objOfInsurance", objOfInsurance);
                UWPayloadObj.put("occupationI", occupationI);
                UWPayloadObj.put("occupationP", occupationP);
                UWPayloadObj.put("pepFlagP", pepFlagP);
                UWPayloadObj.put("permCityI", permCityI);
                UWPayloadObj.put("permCityP", permCityP);
                UWPayloadObj.put("permPinCodeI", permPinCodeI);
                UWPayloadObj.put("permPinCodeP", permPinCodeP);
                UWPayloadObj.put("premStateI", premStateI);
                UWPayloadObj.put("premStateP", premStateP);
                UWPayloadObj.put("productType", productType);
                UWPayloadObj.put("proposalFormKickout", proposalFormKickout);
                UWPayloadObj.put("insuredRelationWithProposer", insuredRelationWithProposer);
                UWPayloadObj.put("nomineeRelationWithProposer", nomineeRelationWithProposer);
                UWPayloadObj.put("clientType", clientType);
                UWPayloadObj.put("initiativeType", initiativeType);
                UWPayloadObj.put("relativeHealthScore", relativeHealthScore);
                UWPayloadObj.put("revisedSumAssured", revisedSumAssured);
                UWPayloadObj.put("riderDetails", ja);
                UWPayloadObj.put("rollback", rollback);
                UWPayloadObj.put("ruralUrbanFlag", rural_urban);
                UWPayloadObj.put("shieldRiskTag", shieldRiskTag);
                UWPayloadObj.put("smokerTagI", smokerTagI);
                UWPayloadObj.put("suc", suc);
                UWPayloadObj.put("teleMerKickout", teleMerKickout);
                UWPayloadObj.put("urmuKickout", urmuKickout);
                UWPayloadObj.put("uwDecision", Decision);
                UWPayloadObj.put("uwLevel", uwLevel);
                UWPayloadObj.put("stpFlag", stpFlag);
                UWPayloadObj.put("totalPrevSumAssuredPF",totalPrevSumAssuredPF); //DR-39672 mansi
                UWPayloadObj.put("modifiedinitiativeType", modifiedinitiativeType); //DR-46364 Farman
		UWPayloadObj.put("axisCustomerClassification", axisCustomerClassification); //DR-46364 Farman		
                UWPayloadObj.put("yblCustomerClassification", yblCustomerClassification); //DR-46364 Farman
                
                 String query_UW10 = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                         + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceStart10Sparsh','"+iFormRef.getActivityName()+"' )";

                 iFormRef.getDataFromDB(query_UW10);
                
                 JSONObject UWJSONOBody = new JSONObject();
                 UWJSONOBody.put("metadata", UWMetadataObj);
                 UWJSONOBody.put("payload", UWPayloadObj);
                String UWRequestJson = UWJSONOBody.toJSONString();
                
                query_edc = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + policyno + "',GETDATE(),'" + planName + "','" + UWRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query_edc);
                
                
                resultString = callAPI.callSocket("UWGovernanceService", UWRequestJson);
                
                query_edc = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                        + "VALUES('" + winame + "','" + policyno + "',GETDATE(),'" + planName + "','" + UWRequestJson + "','" + resultString + "')";

                iFormRef.getDataFromDB(query_edc);
                
                System.out.println("UWGovernanceService - Inserting val into table");
                
              //  resultString="{\"payload\":{\"finalEdc\":\"2022-12-12\",\"ingBatchDate\":\"\",\"defaultEdcFlag\":\"Y\"},\"msgInfo\":{\"msg\":\"Success\",\"msgDescription\":\"Details Fetched\",\"msgCode\":\"200\"}}";
               /* resultString="{\r\n"
                		+ "    \"metadata\": {\r\n"
                		+ "        \"X-App-ID\": \"IBPS\",\r\n"
                		+ "        \"X-Correlation-ID\": \"25478965874\"\r\n"
                		+ "    },\r\n"
                		+ "    \"payload\": {\r\n"
                		+ "        \"policyNumber\": \"310799242\",\r\n"
                		+ "        \"scoringDate\": \"2023-01-31 16:23:45\",\r\n"
                		+ "        \"planCat\": \"ULIP\",\r\n"
                		+ "        \"channel\": \"Agency\",\r\n"
                		+ "        \"calculatedMsa\": \"1234.00\",\r\n"
                		+ "        \"calculatedFsa\": \"1234.00\",\r\n"
                		+ "        \"guwernApiStatus\": \"NOTVALIDATED\",\r\n"
                		+ "        \"guwernGrid\": \"abc\",\r\n"
                		+ "        \"guwernResult\": \"#NOTVALIDATED\",\r\n"
                		+ "        \"reasonOfBreach\": \"Comment\",\r\n"
                		+ "        \"msaMatchResult\": \"123.00\",\r\n"
                		+ "        \"fsaMatchResult\": \"false\",\r\n"
                		+ "        \"maxSucLimit\": \"true\",\r\n"
                		+ "        \"sucOverIssuedPerc\": \"100\",\r\n"
                		+ "        \"errorCode\": \"402\",\r\n"
                		+ "        \"errorMessage\": \"ERROR402: Non Protection Plans Not allowed\"\r\n"
                		+ "    },\r\n"
                		+ "    \"msgInfo\": {\r\n"
                		+ "        \"msg\": \"Success\",\r\n"
                		+ "        \"msgDescription\": \"Details Fetched\",\r\n"
                		+ "        \"msgCode\": \"200\"\r\n"
                		+ "    }\r\n"
                		+ "}";
                */
                     
                
                System.out.println("UWGovernanceService - resultString" + resultString);
                
                
                  query_edc = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'UWGovernanceEnd','"+iFormRef.getActivityName()+"' )";

                iFormRef.getDataFromDB(query_edc);
                  }
                   catch (Exception ex1) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null,"Governance"+ ex1);
                    }
            	 break;
                
            case "HideSection":
                iFormRef.setStyle(stringData, "visible", "false");
                break;
            case "SUC_FROM":
                 String query_SUC="";
                 String isSwissRe=(String) iFormRef.getControlValue("IS_SWISSRE"); //dr-24067 mansi
                    query_SUC="SELECT SUC_FROM from NG_NB_MS_COASSIGNEE(NOLOCK) WHERE ISNULL(IS_SWISSRE,'')='"+isSwissRe+"' ";
                
                
                response = "";
               
               queryList= (List)iFormRef.getDataFromDB(query_SUC);
               if (!queryList.isEmpty()){
                    response = (String) ((List) queryList.get(0)).get(0);
                }
                
               resultString=response; 
               break;
            case "SUC_TO":
                query="";
                String is_SwissRe=(String) iFormRef.getControlValue("IS_SWISSRE");  //dr-24067 mansi
                    query="SELECT SUC_TO from NG_NB_MS_COASSIGNEE(NOLOCK) WHERE ISNULL(IS_SWISSRE,'')='"+is_SwissRe+"' ";
                
                
                response = "";
               
               queryList = (List)iFormRef.getDataFromDB(query);
               if (!queryList.isEmpty()){
                    response = (String) ((List) queryList.get(0)).get(0);
                }
                
               resultString=response;
               break;
            
            case "ShowSection":
                iFormRef.setStyle(stringData, "visible", "true");
                break;
            //added by Prakhar for populating ULIP funds	
            case "MDM_PopulateFunds":
                plantype = (String) iFormRef.getControlValue("PLAN_TYPE");
                if(plantype.equalsIgnoreCase("COMBO"))
                {
                    comboValidator = new ComboValidator(controlName, stringData, iFormRef);
                if (!controlName.equalsIgnoreCase("")) {
                    resultString = comboValidator.getFundsCombos();
                }
                }
                else
                {
                ulipValidator = new UlipValidator(controlName, stringData, iFormRef);
                if (!controlName.equalsIgnoreCase("")) {
                    resultString = ulipValidator.getFundsCombos();
                }
                }
                break;
            case "copyDataToQCSummary":
                //System.out.println("hi");  ///totest
                BusinessRules copyObj = new BusinessRules(iFormRef);
                copyObj.copyDataToQCSummary();  //1083058
                break;
            case "ExtraSumAssuredApplicable":
                query="";
                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                    query="select PROTECTION from NG_NB_MS_PLAN_CODE where plan_code='"+planCode+"' ";
                
                
                response = "";
               
               queryList = (List)iFormRef.getDataFromDB(query);
               if (!queryList.isEmpty()){
                    response = (String) ((List) queryList.get(0)).get(0);
                }
                
               resultString=response; 
             break;
            case "headerLoad":
            BusinessRules header = new BusinessRules(iFormRef);
            header.headerLoad();
            break;
            case "MedicalInfoProp":
                BusinessRules medInfo = new BusinessRules(iFormRef);
                medInfo.medicalInfoProposer();
                break;
            case "MedicalInfoInsur":
                medInfo = new BusinessRules(iFormRef);
                medInfo.medicalInfoInsured();  //1078779
                break;
                
                //OPTIMIZATION PHASE 2
             case "Medical_Information_PROP":
                 
               JSToJava jstoJavaobj=new JSToJava(iFormRef);
               
                //String Nationality=jstoJavaobj.getValue("Q_PROPOSER_DETAILS_OCCUPATION");
                
                //jstoJavaobj.setValues("{'Q_PROPOSER_DETAILS_OCCUPATION':'test'}",true);
                 String id_medprop = controlName;
                  String value_medprop = stringData;
                  int j = 0;
                try {
                    if (value_medprop.equalsIgnoreCase("sectionload")) {
                        String[] control_arr = {"Q_MED_INFO_PROP_DIABETES","Q_MED_INFO_PROP_HYPERTENSION_BP","Q_MED_INFO_PROP_HEART_DISORDER","Q_MED_INFO_PROP_LUNG_DISORDERS",
                            "Q_MED_INFO_PROP_LIVER_RELATED_DISORDER","Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD","Q_MED_INFO_PROP_KIDNEY_DISORDER","Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM",
                            "Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS","Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION","Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY",
                            "Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY","Q_MED_INFO_PROP_HAD_GENETIC_TESTING","Q_MED_INFO_PROP_COVID_QUESTIONS",
                            "Q_MED_INFO_PROP_BP_UNDER_CONTROL","Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL","Q_MED_INFO_PROP_THYROID_UNDER_CONTROL",
                            "Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS","Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN","Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS",
                            "Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS","Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS","Q_MED_INFO_PROP_HISTORY_OF_ASTHMA","Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS",
                            "Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE","Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION","Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER","Q_MED_INFO_PROP_HISTORY_OF_STONES",
                            "Q_MED_INFO_PROP_LIVER_OTHER_DETAILS","Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY","Q_MED_INFO_PROP_HISTORY_OF_LIPOMA","Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS",
                            "Q_MED_INFO_PROP_HISTORY_OF_UTI","Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY","Q_MED_INFO_PROP_HISTORY_OF_STONE","Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS",
                            "Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC","Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY","Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE","Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS",
                            "Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE","Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS","Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER",
                            "Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING","Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT","Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION",
                            "Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA","Q_MED_INFO_PROP_HISTORY_OF_COLD","Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS","Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY",
                            "Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY","Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY","Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY",
                            "Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS","Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK","Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY",
                            "Q_MED_INFO_PROP_SURGERY_FOR_DNS","Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK","Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL","Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS",
                            "Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY","Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION","Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY","Q_MED_INFO_PROP_CANCER_INVEST","Q_MED_INFO_PROP_CANC_PARENT","Q_MED_INFO_PROP_HEPATITIS_B_C","Q_MED_INFO_PROP_RECURR_COUGH","Q_MED_INFO_PROP_MEDICAL_ULTRASOUND","Q_MED_INFO_PROP_MEDICAL_ALCOHOL","Q_MED_INFO_PROP_HISTORY_OF_HIV_STD","Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST","Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA"}; // dr-41542 mansi//dr-43033 dhu by mansi
                      {
                             for (; j < control_arr.length; j++) {
                                 
                             
                            String value1 = iFormRef.getValue(control_arr[j]).toString();
                            Medical_Information_PROP_section_load(control_arr[j], value1, iFormRef);
                             }
                             if(j==control_arr.length)
                             {
                                  BusinessRules medInfo1 = new BusinessRules(iFormRef);
                                   medInfo1.medicalInfoProposer();
                                 
                             }
                        }
                    } else {
                        Medical_Information_PROP_section_load(id_medprop, value_medprop, iFormRef);
                    }
                } catch (Exception e) {
                    System.out.println("Error in MED PROP LOAD details" + e.toString());
                }
                
                break;
                
             case "AgentDetails_load":
                 
                 JSToJava jstoJavaobj1=new JSToJava(iFormRef);
                 Section_Load agentsectionload= new Section_Load();
               
                //String Nationality=jstoJavaobj.getValue("Q_PROPOSER_DETAILS_OCCUPATION");
                
                //jstoJavaobj.setValues("{'Q_PROPOSER_DETAILS_OCCUPATION':'test'}",true);
                 String id_agent = controlName;
                  String value_agent = stringData;
                  j = 0;
                try {
                    if (value_agent.equalsIgnoreCase("sectionload")) {
                        String[] control_arr ={"Q_AGENT_DETAILS_CHANNEL"};
                        for (; j < control_arr.length; j++) {
                                String value1 = iFormRef.getValue(control_arr[j]).toString();
                            agentsectionload.AgentDetalsLoad(control_arr[j], value1, iFormRef);
                        }
                        }
                    
                } catch (Exception e) {
                    System.out.println("Error in MED PROP LOAD details" + e.toString());
                }
                
                break;
               
                //OPTIMIZATION PHASE 2
            case "formLoadLater":
                medInfo = new BusinessRules(iFormRef);
                medInfo.formLoadDolphinLater();  //1080325
                break;
            case "L2bi_Details":
                System.out.println("hi");
                String id_insur = controlName;
                System.out.println(id_insur);
                String value_insur = stringData;
                System.out.println(value_insur);
                try {
                    if (value_insur.equalsIgnoreCase("sectionload")) {
                        String[] control_arr = {"Q_L2BI_DETAILS_NATIONALITY", "Q_L2BI_DETAILS_TITLE", "Q_L2BI_DETAILS_INDUSTRY_TYPE", "Q_L2BI_DETAILS_NATURE_OF_DUTIES", "Q_L2BI_DETAILS_CURRENTLY_POSTED", "Q_L2BI_DETAILS_PROFESSIONAL_DIVER", "Q_L2BI_DETAILS_ROLE_INVOLVE", "Q_L2BI_DETAILS_GENDER", "Q_L2BI_DETAILS_MARITAL_STATUS", "Q_L2BI_DETAILS_RELATIONSHIP_WITH_PROPOSER", "Q_L2BI_DETAILS_INCOME_SOURCE", "Q_L2BI_DETAILS_COUNTRY", "Q_L2BI_DETAILS_FTIN_PRESENT"};
                        for (int i = 0; i < control_arr.length; i++) {
                            String value1 = iFormRef.getValue(control_arr[i]).toString();
                            L2BI_section_load(control_arr[i], value1, iFormRef);
                        }
                    } else {
                        L2BI_section_load(id_insur, value_insur, iFormRef);
                    }
                } catch (Exception e) {
                    System.out.println("Error in L2BI details" + e.toString());
                }
                //BusinessRules prop = new BusinessRules(iFormRef);
                //prop.Sourcing_System_Validations();
                break;

            case "Proposer_Details":
                System.out.println("hi");
                String id = controlName;
                System.out.println(id);
                String value = stringData;
                System.out.println(value);
                try {
                    if (value.equalsIgnoreCase("sectionload")) {
                        String[] control_arr = {"Q_PROPOSER_DETAILS_CLIENT_ID", "Q_PROPOSER_DETAILS_OCCUPATION", "Q_PROPOSER_DETAILS_CLIENT_ID", "Q_PROPOSER_DETAILS_CLIENT_TYPE", "Q_PROPOSER_DETAILS_ID_PROOF_PROP", "Q_PROPOSER_DETAILS_TITLE", "Q_PROPOSER_DETAILS_PAN_NUMBER", "Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "Q_PROPOSER_DETAILS_DO_YOU_HAVE_CKYC", "Q_PROPOSER_DETAILS_NATIONALITY", "Q_PROPOSER_DETAILS_GENDER", "Q_PROPOSER_DETAILS_MARITAL_STATUS", "Q_PROPOSER_DETAILS_OCCUPATION", "Q_PROPOSER_DETAILS_FTIN_PRESENT", "Q_PROPOSER_DETAILS_COUNTRY", "Q_PROPOSER_DETAILS_PERM_COUNTRY", "Q_PROPOSER_DETAILS_OPT_FOR_POLICY", "Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE", "Q_PROPOSER_DETAILS_POLITICALLY_EXPOSED", "Q_PROPOSER_DETAILS_PERON_PEP", "Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY", "Q_PROPOSER_DETAILS_PEP_POSTED", "Q_PROPOSER_DETAILS_PEP_CONVICTED", "Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "Q_PROPOSER_DETAILS_INDUSTRY_TYPE", "Q_PROPOSER_DETAILS_NATURE_OF_DUTIES", "Q_PROPOSER_DETAILS_CURRENTLY_POSTED", "Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER", "Q_PROPOSER_DETAILS_ROLE_INVOLVE","Q_PROPOSER_DETAILS_OPT_FOR_POLICY"};
                        for (int i = 0; i < control_arr.length; i++) {
                            String value1 = iFormRef.getValue(control_arr[i]).toString();
                            proposer_section_load(control_arr[i], value1, iFormRef);
                        }
                    } else {
                        proposer_section_load(id, value, iFormRef);
                    }

                } catch (Exception e) {
                    System.out.println("Error in Proposer_Details " + e.toString());
                }
                //BusinessRules prop = new BusinessRules(iFormRef);
                //prop.Sourcing_System_Validations();
                break;
            case "Req_receiveAt_submit":
                //Calling procedure to Check requirements
                copyObj = new BusinessRules(iFormRef);
                resultString = copyObj.receiveReqAtmPROCET();
                break;
             case "UPDATE_DOCNAME":    //aanchal //to submit //DR_7085
                //Calling procedure to Check requirements
                winame = (String) iFormRef.getControlValue("WorkItemName");
                query = "EXEC NG_SP_NB_LIST_DOCUMENT_UPDATE '" + winame + "'";
                response = "";
               
                queryList = iFormRef.getDataFromDB(query);
                if (queryList != null) {
                    response = (String) ((List) queryList.get(0)).get(0);
                }
                
                break;
              case "SELECT_DOCNAME":    //aanchal //to submit //DR_7085
                //Calling procedure to Check requirements
                String REQ_NAME=stringData,addinfo="",decision="",Category="",ClientType="";
                decision = (String) iFormRef.getControlValue("Decision");
                query="";
                if(!controlName.equalsIgnoreCase("")){
                String[] stringDataArrReq = controlName.split("#");
                Category = stringDataArrReq[0];
                ClientType = stringDataArrReq[1];
                }
                
                if(iFormRef.getActivityName().equalsIgnoreCase("QC")||iFormRef.getActivityName().equalsIgnoreCase("CT"))
                    query="select top 1 DOC_NAME from NG_NB_MS_QC_REQUIREMENTS(NOLOCK) where REQUIREMENT_NAME='" + REQ_NAME + "' and DISPLAY_ON_UI='Y' and PARTIES_ASSOCIATED='"+ClientType+"' and REQUIREMENT_TYPE='"+Category+"'";
                if(iFormRef.getActivityName().equalsIgnoreCase("Manual_UW") || (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") )|| (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor")) ){
                    query="select top 1 document_type from NG_NB_MS_UW_REQUIREMENTS_CODE(NOLOCK) where REQUIREMENT_NAME='" + REQ_NAME + "'";
                    if(decision.equalsIgnoreCase("Add Info")){
                        query="select top 1 document_type,REQUIREMENT_TYPE_FOR_BACKFLOW from NG_NB_MS_UW_REQUIREMENTS_CODE(NOLOCK) UW INNER JOIN NG_NB_MS_ADD_INFO(NOLOCK) A ON A.REQUIREMENT_NAME=UW.REQUIREMENT_NAME where A.DISPLAY_ON_UI='Y' AND  UW.REQUIREMENT_NAME='" + REQ_NAME + "' AND A.TYPE='" + Category + "' AND UW.Client_Type='" + ClientType + "'";
                        addinfo="Y";
                    }
                }
                if(iFormRef.getActivityName().equalsIgnoreCase("URMU")){
                    query="select top 1 DOCUMENT_NAME,REQUIREMENT_TYPE_FOR_BACKFLOW from NG_NB_MS_URMU_REQUIREMENTS(NOLOCK) where REQUIREMENT_NAME='" + REQ_NAME + "' and DISPLAY_ON_UI='Y' and CLIENT_TYPE='"+ClientType+"' and TYPE='"+Category+"'";
                    addinfo="Y";
                }
                
                
                response = "";
               
               queryList = (List)iFormRef.getDataFromDB(query);
               if (!queryList.isEmpty()){
                    response = (String) ((List) queryList.get(0)).get(0);
                    if(addinfo.equalsIgnoreCase("Y")){
                        response = response + "#" +((String) ((List) queryList.get(0)).get(1)); 
                    }
                }
                if((iFormRef.getActivityName().equalsIgnoreCase("Manual_UW") || (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") )|| (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor"))) && response.equalsIgnoreCase("") )
                {
                   query="select top 1 DOC_NAME from NG_NB_MS_QC_REQUIREMENTS(NOLOCK) where REQUIREMENT_NAME='" + REQ_NAME + "' and DISPLAY_ON_UI='Y' and PARTIES_ASSOCIATED='"+ClientType+"' and REQUIREMENT_TYPE='"+Category+"'";
                   queryList = iFormRef.getDataFromDB(query);
                    if (queryList != null) {
                    response = (String) ((List) queryList.get(0)).get(0);
                     }
                }
                
                resultString=response;
                break;
                
            case "COUNTRY_VALUE":    //ujjawal DR-48766
                     String countryLabel =stringData;
		     query="";
		     response = "";
				
		     query="SELECT COUNTRY_LABEL FROM NG_NB_MS_COUNTRY(NOLOCK)where COUNTRY_VALUE='"+countryLabel+"'";
		     queryList = iFormRef.getDataFromDB(query);
		     if (queryList != null) {
                     response = (String) ((List) queryList.get(0)).get(0);
                     }
		     resultString=response;
				
                break;
            case "ValidateRider":
                System.out.println("inside ValidateRider");
                String rider,
                 riderSumAssured,
                 riderCoverageTerm,
                 defenceChannel;
                rider = iFormRef.getValue("table37_RIDER_TYPE").toString();
                riderSumAssured = iFormRef.getValue("table37_SUM_ASSURED").toString();
                if (riderSumAssured.equalsIgnoreCase("")) {
                    riderSumAssured = "0";
                }

                riderCoverageTerm = iFormRef.getValue("table37_COVERAGE_TERM").toString();
                if (riderCoverageTerm.equalsIgnoreCase("")) {
                    riderCoverageTerm = "0";
                }

                planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                Channel = (String) iFormRef.getControlValue("CHANNEL");
                defenceChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                  if(Channel.equalsIgnoreCase("BY"))
                      defenceChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                productType = (String) iFormRef.getControlValue("PLAN_TYPE");

                effectiveDate = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
                 clientType = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");

                String insuredDOB = (String) iFormRef.getControlValue("Q_L2BI_DETAILS.DOB");

                if (clientType.equalsIgnoreCase("ProposerInsured")) {
                    insuredDOB = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                }

                JSONArray riderDetailsTable = iFormRef.getDataFromGrid("table37");
                String riderJsonString = riderDetailsTable.toString();

                String modeOfPay = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");

                riderQuery = "EXEC NG_SP_NB_RIDER_SETUP '" + planCode + "','" + Channel + "','" + defenceChannel + "','" + effectiveDate
                        + "','" + stringData + "','" + rider + "','" + riderSumAssured + "','" + riderCoverageTerm + "','" + insuredDOB + "','" + riderJsonString + "','" + controlName + "','" + modeOfPay + "'";

                //RiderBenefit Class	
                riderObj = new RiderBenefit(iFormRef, planCode, Channel, defenceChannel, productType);
                if (controlName.equals("RiderOnSaveModal")) {
                    return riderObj.RiderOnSaveModal();
                } else if (controlName.equals("GetValidRiders")) {
                    return riderObj.getValidRiders();
                } /*else if (controlName.equals("ClientTypeChange")) {
                    return riderObj.validateClientType();
                }*/ /*
                                   (For ULIP products)
                                   On ATP Change - Validate Sum Assured of Benefit 1 and 2
                                   Sum Assured of Benefit 1 = ATP
                                   Sum Assured of Benefit 2 = Base Sum Assured = ATP * Cover Multiple
                 */ else if (controlName.equals("ATPChange")) {
                    return riderObj.validateSumAssuredOfBenefit();
                } /*else if (controlName.equals("EffectiveCustomerSignChange")) {
                    return riderObj.validateEffectiveDate();
                }*/ //Insured Age will change when DOB of insured or effective Date is changed
                /*else if (controlName.equals("EffectiveDOBChange")) {
                    return riderObj.validateInsuredAge();
                } *//*else if (controlName.equals("ValidateModalPremium")) {
                    return riderObj.validateModalPremium();
                }else if (controlName.equals("ValidateCoverageTerm")) {
                    return riderObj.validateCoverageTerm();
                } */ else if (controlName.equals("OnCalculateBtnClick")) {
                    return riderObj.CalculateBtnClick();
                }//To be Called when LE Calculation is successful
                else if (controlName.equals("PostCalculateBtnClick")) {
                    return riderObj.PostCalculateBtnClick();
                } else if (controlName.equals("onRiderChangeFromModal")) {
                    riderObj.onRiderChangeFromModal();
                } else if (controlName.equals("onLoadCoverageDetails")) {
                    return riderObj.onLoadCoverageDetails();
                } else if (controlName.equals("uwReviewPreCalculateClick")) {
                    return riderObj.uwReviewPreCalculateClick();
                } else if (controlName.equals("uwReviewPostCalculateClick")) {
                    return riderObj.uwReviewPostCalculateClick();
                } else if (controlName.equals("uwSumAssuredChange")) {
                    return riderObj.uwSumAssuredChange(stringData);
                } else if (controlName.equals("uwCTChange")) {
                    return riderObj.uwCTChange(stringData);
                } else if (controlName.equals("uwPPTChange")) {
                    return riderObj.uwPPTChange(stringData);
                } else if (controlName.equals("getPlanPayOtionCode")) {
                    return riderObj.getPlanPayOptionCode();
                } else if (controlName.equals("uinLogic")) {
                    return riderObj.uinLogic();
                }

                /*riderList = (List) iFormRef.getDataFromDB(riderQuery);
                resultString = (String)((List) riderList.get(0)).get(0);*/
                break;

            case "UnderWriterDecisionRules":
                BusinessRules rulesObj = new BusinessRules(iFormRef);

                if (controlName.equals("CheckUserCaseLevel")) {
                    resultString = rulesObj.validateCaseUserLevel();
                } else if (controlName.equals("addInfoRule")) {
                    resultString = rulesObj.validateAddInfoLevel();
                } else if (controlName.equals("getUserLevel")) {
                    iFormRef.setValue("CASE_TYPE", rulesObj.getCaseType());
                    resultString = rulesObj.getUserLevel();
                }
                break;

            case "userInUWGroup":
                rulesObj = new BusinessRules(iFormRef);
                resultString = rulesObj.checkUserInUWGroups();
                break;

            case "API_compare_agent_cust_date":
                resultString = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
                break;
            case "userRole":
                rulesObj = new BusinessRules(iFormRef);
                resultString = rulesObj.userRole();
                break;
            
            case "userPersonalName":
               String userPname=stringData;
                queryList = (List) iFormRef.getDataFromDB("select username from NG_NB_USER_NAME_MAPP(nolock) where userID='" + stringData + "'");
                 if (!queryList.isEmpty()) {
                        userPname = (String) ((List) queryList.get(0)).get(0);
                       
                    }
               resultString=userPname;
               break;

            case "policySplittingAPI":  //stringData-> wi_name
                 query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'PolicySplttingStart','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("DEDUPE");
                String requestJson = "";
                JSONObject json = null;
                JSONObject jsonPayload = null;
                JSONObject payloadObj = new JSONObject();
                isServiceEnabled = isAdminEnabled("POLICY_SPLIT_SERVICE", iFormRef);
                clientType = (String) iFormRef.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
                if (isServiceEnabled) {
                    //creating metadata json object
                    JSONObject metadataObj = new JSONObject();
                    proposalNumber = (String) iFormRef.getControlValue("PROPOSAL_NUMBER");
                    metadataObj.put("X-Correlation-ID", proposalNumber + "-" + DolphinUtil.generateRandomString(15));
                    metadataObj.put("X-App-ID", "IBPS");

                    String proposerClientId = "";
                    String insuredClientId = "";
                    String currentPolicyNumber = "";
                    queryList = (List) iFormRef.getDataFromDB("SELECT PROPOSER_CLIENT_ID,INSURED_CLIENT_ID,"
                            + "PROPOSAL_NUMBER "
                            + "FROM  NG_NB_EXT_TABLE(NOLOCK) "
                            + "WHERE WI_NAME='" + stringData + "';");
                    if (!queryList.isEmpty()) {
                        proposerClientId = (String) ((List) queryList.get(0)).get(0);
                        insuredClientId = (String) ((List) queryList.get(0)).get(1);
                        currentPolicyNumber = (String) ((List) queryList.get(0)).get(2);
                    }

                    //Added by Prakhar for blank proposerId issue
                    proposerClientId = (String) iFormRef.getControlValue("PROPOSER_CLIENT_ID");
                    insuredClientId = (String) iFormRef.getControlValue("INSURED_CLIENT_ID");
                    planCode = (String) iFormRef.getControlValue("PLAN_NAME"); //DR-42365 BY DRON

                    //Added by Pranav
                    if (clientType.equalsIgnoreCase("ProposerInsured")) {
                        insuredClientId = proposerClientId;
                    }
                    //End by Pranav
                    payloadObj.put("planCode", planCode); //DR-42365 BY DRON
                    payloadObj.put("proposerClientId", proposerClientId);
                    payloadObj.put("insuredClientId", insuredClientId);
                    payloadObj.put("currentPolicyNumber", currentPolicyNumber);
                    payloadObj.put("currentPolicySignDate", (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE"));
                    //payloadObj.put("currentPolicySignDate", "23-06-2020");

                    //uin No. Logic
                    
                    String planTYPE = (String) iFormRef.getControlValue("PLAN_TYPE");
                   String  planCodeCombo = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                     String  IS_COMBO = (String) iFormRef.getControlValue("IS_COMBO");
                       String  ComboProposal = (String) iFormRef.getControlValue("COMBO_POPROSAL_NUMBER");
                        String ProductSolution = "";
            ProductSolution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
          
            
                    Channel = (String) iFormRef.getControlValue("CHANNEL");
                    subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                    if(Channel.equalsIgnoreCase("BY"))
                      subChannel = (String) iFormRef.getControlValue("Q_CUSTOMER_INFORMATION.ISYBLTELESALE"); //DR12411
                    if (subChannel.equalsIgnoreCase("Y")) {
                        if(Channel.equalsIgnoreCase("BY"))
                        {
                             subChannel = "TeleSale";
                        }
                        else
                            subChannel = "Defence";
                    } 
                    else {
                        subChannel = getChannelDescFromVal(Channel, iFormRef);
                    }
                    String uinNo = "";
                    queryList = (List) iFormRef.getDataFromDB("SELECT EFFECTIVE_DATE FROM NG_NB_COVERAGE_DETAILS(nolock) WHERE WI_NAME='" + stringData + "'");
                    if (!queryList.isEmpty()) {

                        String edc = (String) ((List) queryList.get(0)).get(0);
                        queryList = (List) iFormRef.getDataFromDB("SELECT UIN_Number FROM NG_NB_MS_UIN_LOGIC(NOLOCK) "
                                + "WHERE CONVERT(DATE,UIN_EFFECTIVE_DT)<='" + edc + "' AND CONVERT(DATE,UIN_EXPIRY_DT)>='" + edc + "' AND Plan_Code='" + planCode + "' "
                                + "AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'");
                        if (!queryList.isEmpty()) {
                            uinNo = (String) ((List) queryList.get(0)).get(0);
                        }

                    }
                    
                    
                    String uinNocombo="";
                    queryList = (List) iFormRef.getDataFromDB("SELECT EFFECTIVE_DATE FROM NG_NB_COVERAGE_DETAILS(nolock) WHERE WI_NAME='" + stringData + "'");
                    if (!queryList.isEmpty()) {

                        String edc = (String) ((List) queryList.get(0)).get(0);
                        queryList = (List) iFormRef.getDataFromDB("SELECT UIN_Number FROM NG_NB_MS_UIN_LOGIC(NOLOCK) "
                                + "WHERE CONVERT(DATE,UIN_EFFECTIVE_DT)<='" + edc + "' AND CONVERT(DATE,UIN_EXPIRY_DT)>='" + edc + "' AND Plan_Code='" + planCodeCombo + "' "
                                + "AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'");
                        if (!queryList.isEmpty()) {
                            uinNocombo = (String) ((List) queryList.get(0)).get(0);
                        }

                    }
                    //to be un-comment later
                    payloadObj.put("uinNo", uinNo);
                    
                       String policyTerm = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
                    payloadObj.put("policyTerm", policyTerm);

                    String premiumPayingTerm = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
                    payloadObj.put("premiumPayingTerm", premiumPayingTerm);
                    
                     payloadObj.put("uinNoCombo", uinNocombo);
                    
                       String policyTermCOMBO = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
                    payloadObj.put("policyTermCombo", policyTermCOMBO);

                    String premiumPayingTermcombo = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.SEC_PPT");
                    payloadObj.put("premiumPayingTermCombo", premiumPayingTermcombo);
                    
                    String ISCOMBO = "";
                    ISCOMBO = (String) iFormRef.getControlValue("IS_COMBO");
                    payloadObj.put("isCombo", ISCOMBO);
            
            
            
                    String ComboProposalNo = "";
                    ComboProposalNo = (String) iFormRef.getControlValue("COMBO_PROPOSAL_NUMBER");
                    payloadObj.put("comboProposalNumber", ComboProposalNo);
                                //payloadObj.put("uinNo", "104N091V05");

                     String ReplacementUINNO="" ;
                     String ReplacementUINPLAN="" ;
                     queryList = (List) iFormRef.getDataFromDB("select Replacement_Plan_Code from NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='"+planCode+"' and Combo_Plan_Code='"+planCodeCombo+"' and Product_Solution='"+ProductSolution+"' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "' ");
                    if (!queryList.isEmpty()) {

                         ReplacementUINPLAN = (String) ((List) queryList.get(0)).get(0);
                        

                    }
                     if(ReplacementUINPLAN.equalsIgnoreCase(planCodeCombo))
                     {
                         ReplacementUINNO=uinNocombo;
                     }
                     else
                     {
                         ReplacementUINNO=uinNo;
                     }
                       payloadObj.put("replacementUinNo", ReplacementUINNO);
                     
                                
                    JSONObject JSONOBody = new JSONObject();
                    JSONOBody.put("metadata", metadataObj);
                    JSONOBody.put("payload", payloadObj);
                    requestJson = JSONOBody.toJSONString();
                    resultString = callAPI.callSocket("policySplittingAPI", requestJson);
                    policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                    //aanchal
                    winame = (String) iFormRef.getControlValue("WorkItemName");
                    planName=(String) iFormRef.getControlValue("PLAN_NAME");
                    //parameters += AgentCodes + "|" + spNo + "|" + channel + "|" + customerSignDate + "|" + insuranceStatus + "|" + CommissionShare + "|" + productType + "|" + customerPan;	
                    
                    String query4 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                            + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "','" + requestJson + "','" + resultString + "')";

                    iFormRef.getDataFromDB(query4);

                    //parsing output from Response JSON
                    jsonParser = new JSONParser();

                    try {
                        json = (JSONObject) jsonParser.parse(resultString);
                        String payload = json.get("payload").toString();
                        jsonPayload = (JSONObject) jsonParser.parse(payload);
                    } catch (org.json.simple.parser.ParseException ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    String replacementSale = jsonPayload.get("replacementSale").toString();
                    String splitFlag = jsonPayload.get("splitFlag").toString();

                        String query_L1= "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                            + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "','" + splitFlag + "','" + stringData + "')";

                    iFormRef.getDataFromDB(query_L1);
                     /*if (splitFlag.equals("Y"))
                     {
                          String query_Ex = "UPDATE NG_NB_EXT_TABLE SET POLSPLITFLAG='" + splitFlag + "' WHERE WI_NAME='" + stringData + "'";
                            iFormRef.getDataFromDB(query_Ex);
                             String query_Lt= "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                            + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "','" + splitFlag + "','" +"updated" + "')";
                         iFormRef.getDataFromDB(query_Lt);
                            
                     }*/
 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, "POLsPLIT");
                       try {
                    if (splitFlag.equals("Y") || splitFlag.equals("N")) {
                        
                        
                        query = "UPDATE NG_NB_EXT_TABLE SET POLSPLITFLAG='" + splitFlag + "' WHERE WI_NAME='" + stringData + "'";
                         Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, query);
                         
                          
                        queryList = (List) iFormRef.getDataFromDB(query);
                    }
                       }
                         catch (Exception ex1) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex1);
                    }

                    if (replacementSale.equals("Y") || replacementSale.equals("N")) {
                        query = "UPDATE NG_NB_CUSTOMER_INFORMATION SET REPLACEMENT_POLICY_SALE='" + replacementSale + "' WHERE WI_NAME='" + stringData + "'";
                        queryList = (List) iFormRef.getDataFromDB(query);
                    }
                }
                 query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'PolicySplittingEND','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("DEDUPE");
                break;

            case "PSM_API": //stringData-> wi_name    
                isServiceEnabled = isAdminEnabled("PSM_SERVICE", iFormRef);
                        //aanchal
                        winame = (String) iFormRef.getControlValue("WorkItemName");
                        planName=(String) iFormRef.getControlValue("PLAN_NAME");
                        policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                        
                           query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'PSMServiceStart','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("PSM Start");
                        
                        String query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "_PSM_1" + "','PSM_1','PSM_1')";
                        iFormRef.getDataFromDB(query3);
                        
                if (isServiceEnabled) {
                    query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'"+planName + "_PSM_2"+"','PSM_2','PSM_2')";
                        iFormRef.getDataFromDB(query3);
                    requestJson = callREST_API.createRequest("PSM_API", iFormRef);
                    resultString = callAPI.callSocket("PSM_API", requestJson);
                    
                    query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "_PSM_3"+ "','"+requestJson+"','"+resultString+"')";
                        iFormRef.getDataFromDB(query3);
                    //parsing output from Response JSON
                    jsonParser = new JSONParser();
                    json = null;
                    jsonPayload = null;
                    JSONObject responseObj = new JSONObject();
                    try {
                        json = (JSONObject) jsonParser.parse(resultString);
                        response = json.get("response").toString();
                        responseObj = (JSONObject) jsonParser.parse(response);
                        String payload = responseObj.get("payload").toString();
                        jsonPayload = (JSONObject) jsonParser.parse(payload);
                        policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                       
                        //parameters += AgentCodes + "|" + spNo + "|" + channel + "|" + customerSignDate + "|" + insuranceStatus + "|" + CommissionShare + "|" + productType + "|" + customerPan;	
                        
                        query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "_PSM_4"+ "','" + requestJson + "','" + resultString + "')";

                        iFormRef.getDataFromDB(query3);
                    } catch (org.json.simple.parser.ParseException ex) {
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if (jsonPayload != null) {
                        
                        query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "_PSM_5"+ "','" + requestJson + "','" + resultString + "')";

                        iFormRef.getDataFromDB(query3);
                        
                        String psmCheckFlag = "";
                        String psmRecommendationCheck = jsonPayload.get("psmRecommendationCheck").toString();
                        String psmIncomeCheck = jsonPayload.get("psmIncomeCheck").toString();
                        String psmPayorCheck = jsonPayload.get("psmPayorCheck").toString();
                        String psmIRPFundCheck = jsonPayload.get("psmIRPFundCheck").toString();
                        if (iFormRef.getControlValue("PLAN_TYPE").toString().equals("ULIP")) {
                            if (psmRecommendationCheck.equals("PASS")
                                    && psmIncomeCheck.equals("PASS")
                                    && psmPayorCheck.equals("PASS")
                                    && psmIRPFundCheck.equals("PASS")) {
                                psmCheckFlag = "N";
                            } else {
                                psmCheckFlag = "Y";
                            }
                        } else//TRAD 
                        {
                            if (psmRecommendationCheck.equals("PASS")
                                    && psmIncomeCheck.equals("PASS")
                                    && psmPayorCheck.equals("PASS")) {
                                psmCheckFlag = "N";
                            } else {
                                psmCheckFlag = "Y";
                            }
                        }
                        query = "UPDATE NG_NB_EXT_TABLE SET PSMRESFLAG='" + psmCheckFlag + "' ,"
                                + "PSMRECOMMENDATIONCHECK='" + psmRecommendationCheck + "',PSMINCOMECHECK='" + psmIncomeCheck + "',"
                                + "PSMPAYORCHECK='" + psmPayorCheck + "',PSMIRPFUNDCHECK='" + psmIRPFundCheck + "' "
                                + " WHERE WI_NAME='" + stringData + "'";
                        queryList = (List) iFormRef.getDataFromDB(query);

                        //SET PSM FAIL REASON
                        String psmFailReason = "";
                        if (!psmRecommendationCheck.equals("PASS")) {
                            psmFailReason = psmFailReason + "psmRecommendationCheck" + ";";
                        }
                        if (!psmIncomeCheck.equals("PASS")) {
                            psmFailReason = psmFailReason + "psmIncomeCheck" + ";";
                        }
                        if (!psmPayorCheck.equals("PASS")) {
                            psmFailReason = psmFailReason + "psmPayorCheck" + ";";
                        }
                        if (!psmIRPFundCheck.equals("PASS")) {
                            psmFailReason = psmFailReason + "psmIRPFundCheck" + ";";
                        }
                        if (!psmFailReason.equals("")) {
                            query = "IF EXISTS (SELECT * FROM NG_NB_WELCOME_CALL(NOLOCK) WHERE WI_NAME='" + stringData + "') "
                                    + "UPDATE NG_NB_WELCOME_CALL SET REA_FOR_PSM_FAIL='" + psmFailReason + "' WHERE  WI_NAME='" + stringData + "' "
                                    + "ELSE "
                                    + "INSERT INTO NG_NB_WELCOME_CALL(WI_NAME,REA_FOR_PSM_FAIL) VALUES('" + stringData + "','')";
                            iFormRef.getDataFromDB(query);
                        }

                    } else {
                        query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "_PSM_6"+ "','" + requestJson + "','" + resultString + "')";
                        iFormRef.getDataFromDB(query3);
                        
                        query = "UPDATE NG_NB_EXT_TABLE SET PSMRESFLAG='N' "   //PSMDEFAULT
                                + "WHERE WI_NAME='" + stringData + "'";
                        queryList = (List) iFormRef.getDataFromDB(query);
                    }
                }
                 query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'PSMServiceEND','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("PSM END");
                break;

            case "callDedupe_API":  //stringData:> Proposer/Payaor/Insured
                String dedupeType = stringData;
                query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'DEDUPE START','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("DEDUPE");
                isServiceEnabled = isAdminEnabled("DEDUPE_SERVICE", iFormRef);
                if (isServiceEnabled) {
                    String wiName = (String) iFormRef.getControlValue("WorkItemName");
                    requestJson = callREST_API.createDedupeRequest("callDedupe_API", iFormRef, dedupeType);
                    resultString = callAPI.callSocket("callDedupe_API", requestJson);
                    //parsing response and inserting to table
                    jsonParser = new JSONParser();
                    json = null;
                    JSONObject msgInfoObj = new JSONObject();
                    payloadObj = new JSONObject();
                    JSONArray dedupeArray = new JSONArray();
                    String msgInfo = "",
                            msgCode = "";
                    try {
                        json = (JSONObject) jsonParser.parse(resultString);
                        msgInfo = json.get("msgInfo").toString();
                        msgInfoObj = (JSONObject) jsonParser.parse(msgInfo);
                        msgCode = msgInfoObj.get("msgCode").toString();
                    } catch (Exception ex) {
                        resultString = "ERROR";
                        ex.printStackTrace();
                    }
                    try {
                        if (msgCode.equals("200")) {
                            String payload = json.get("payload").toString();
                            payloadObj = (JSONObject) jsonParser.parse(payload);
                            dedupeArray = (JSONArray) payloadObj.get("dedupe");
                            JSONObject jsonRowDedupe = new JSONObject();
                            JSONArray jsonArray = new JSONArray();
                            for (Object obj : dedupeArray) {
                                jsonRowDedupe = (JSONObject) obj;
                                JSONObject rowObj = new JSONObject();
                                rowObj.put("Dedupe Flag", jsonRowDedupe.getOrDefault("dedupeFlag", ""));
                                rowObj.put("Client ID", jsonRowDedupe.getOrDefault("clientId", ""));
                                rowObj.put("Full Name", jsonRowDedupe.getOrDefault("fullName", ""));
                                rowObj.put("Previous Policy", jsonRowDedupe.getOrDefault("previousPolicy", ""));
                                rowObj.put("Policy Status", jsonRowDedupe.getOrDefault("policyStatus", ""));
                                rowObj.put("Policy Plan Code", jsonRowDedupe.getOrDefault("policyPlanCode", ""));
                                rowObj.put("DOB", jsonRowDedupe.getOrDefault("dob", ""));
                                rowObj.put("Gender", jsonRowDedupe.getOrDefault("gender", ""));
                                rowObj.put("Father Name", jsonRowDedupe.getOrDefault("fatherName", ""));
                                rowObj.put("EIA Number", jsonRowDedupe.getOrDefault("eiaNumber", ""));
                                rowObj.put("CKYC Number", jsonRowDedupe.getOrDefault("ckycNumber", ""));
                                rowObj.put("Relationship", jsonRowDedupe.getOrDefault("relationshipToPolicyOrClient", ""));
                                rowObj.put("PAN", jsonRowDedupe.getOrDefault("panNumber", ""));
                                rowObj.put("Mobile", jsonRowDedupe.getOrDefault("mobileNumber", ""));
                                rowObj.put("Pin Code", jsonRowDedupe.getOrDefault("pinCode", ""));
                                rowObj.put("Search Criteria", jsonRowDedupe.getOrDefault("searchCriteria", ""));
                                rowObj.put("Aadhar Number", jsonRowDedupe.getOrDefault("aadharNumber", ""));
                                rowObj.put("Bank Account Number", jsonRowDedupe.getOrDefault("bankAccountNumber", ""));

                                jsonArray.add(rowObj);

                                //adding data to dedupe table for report -->>NG_NB_DEDUPE_PUSH
                                String dedupeQuery = "INSERT INTO NG_NB_DEDUPE_PUSH (WI_NAME,  dedupeFlag, clientId, fullName, previousPolicy, policyStatus, policyPlanCode, "
                                        + "dob, gender, fatherName, eiaNumber, ckycNumber, relationshipToPolicyOrClient, panNumber, mobileNumber, pinCode, searchCriteria, "
                                        + "aadharNumber, bankAccountNumber, WORKSTEP_NAME)"
                                        + "VALUES ('" + wiName + "',"
                                        + "'" + jsonRowDedupe.getOrDefault("dedupeFlag", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("clientId", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("fullName", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("previousPolicy", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("policyStatus", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("policyPlanCode", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("dob", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("gender", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("fatherName", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("eiaNumber", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("ckycNumber", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("relationshipToPolicyOrClient", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("panNumber", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("mobileNumber", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("pinCode", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("searchCriteria", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("aadharNumber", "") + "', "
                                        + "'" + jsonRowDedupe.getOrDefault("bankAccountNumber", "") + "',"
                                        + "'" + iFormRef.getActivityName() + "')";
                                List queryResult = iFormRef.getDataFromDB(dedupeQuery);
                            }
                            iFormRef.addDataToGrid("DEDUPE_TABLE", jsonArray);
                            resultString = "DATA ADDED";
                        }
                    } catch (Exception ex) {
                        resultString = "ERROR";
                        ex.printStackTrace();
                    }
                }
                 query_S = "INSERT INTO NG_NB_SERIVCE_CALL_STATUS(WI_NAME,EntryDateTime,Service,Workstep)\n"
                        + "VALUES('" + (String) iFormRef.getControlValue("WorkItemName") + "',GETDATE(),'DEDUPE END','"+iFormRef.getActivityName()+"' )";

                        iFormRef.getDataFromDB(query_S);
                        System.out.println("DEDUPE");
                break;
                
              case "CLIENT_LEVEL_CHECK_API": //stringData-> wi_name    
                isServiceEnabled = isAdminEnabled("CLIENT_LEVEL_CHECK_API", iFormRef);
                        //aanchal
                        winame = (String) iFormRef.getControlValue("WorkItemName");
                        planName=(String) iFormRef.getControlValue("PLAN_NAME");
                        policyNumber = iFormRef.getValue("PROPOSAL_NUMBER").toString();
                       
                        
                if (isServiceEnabled) {
                    
                    requestJson = callREST_API.createRequest("CLIENT_LEVEL_CHECK_API", iFormRef);
                    resultString = callAPI.callSocket("CLIENT_LEVEL_CHECK_API", requestJson);
                    
                    query3 = "INSERT INTO NG_NB_LE_SERVICE_STATUS(WI_NAME,PolicyNo,EntryDateTime,PlanName,Request,Response)\n"
                                + "VALUES('" + winame + "','" + policyNumber + "',GETDATE(),'" + planName + "Cleintlevelcheck"+ "','"+requestJson+"','"+resultString+"')";
                        iFormRef.getDataFromDB(query3);
                   jsonParser = new JSONParser();
                    json = null;
                    JSONObject msgInfoObj = new JSONObject();
                    payloadObj = new JSONObject();
                    JSONArray riderInfo = new JSONArray();
                    String msgInfo = "",
                            msgCode = "",
                            BaseExceeded="",
                            riderExceeded="",
                            Message="";
                    try {
                        json = (JSONObject) jsonParser.parse(resultString);
                        msgInfo = json.get("msgInfo").toString();
                        msgInfoObj = (JSONObject) jsonParser.parse(msgInfo);
                        msgCode = msgInfoObj.get("msgCode").toString();
                    } catch (Exception ex) {
                        resultString = "ERROR IN CLIENT LEVEL CHECK";
                        ex.printStackTrace();
                    }
                    try {
                        if (msgCode.equals("200")) {
                            String payload = json.get("payload").toString();
                            payloadObj = (JSONObject) jsonParser.parse(payload);
                            BaseExceeded=payloadObj.get("exceededSumAssured").toString();
                            if((!BaseExceeded.equals("")) && (!BaseExceeded.equals("0.0")) )
				Message=Message+ " Base sum assured is exceeded by " + BaseExceeded + " amount";
                            riderInfo = (JSONArray) payloadObj.get("riderInfo");JSONObject jsonRow = new JSONObject();
                            JSONArray jsonArray = new JSONArray();
                            for (Object obj : riderInfo) 
                            {
                                jsonRow = (JSONObject) obj;
                                JSONObject rowObj = new JSONObject();
                                riderExceeded= jsonRow.getOrDefault("exceededRiderSumAssured", "").toString();
				if((!riderExceeded.equals("")) && (!riderExceeded.equals("0.0")) )
                                    Message=Message+ " Rider sum assured is exceeded by " + riderExceeded + " amount";
                            }
                            resultString = Message;
                        }
                        else
                            resultString="ERROR IN CLIENT LEVEL CHECK";
                    } catch (Exception ex) {
                        resultString = "ERROR IN CLIENT LEVEL CHECK";
                        ex.printStackTrace();
                    }
							
                }
                break;


            case "creatClientID_API":
                //creating request
                JSONObject headerObj = new JSONObject();
                headerObj.put("soaCorrelationId", "aa6689001");
                headerObj.put("soaAppId", "DOLPHIN");

                payloadObj = new JSONObject();
                payloadObj.put("appTransactionId", "10111090");
                payloadObj.put("numberOfClientIdRequired", "1");

                JSONObject request = new JSONObject();
                request.put("header", headerObj);
                request.put("payload", payloadObj);

                JSONObject finalRequestObj = new JSONObject();
                finalRequestObj.put("request", request);

                requestJson = finalRequestObj.toJSONString();
                String responseJSON = callAPI.callSocket("creatClientID_API", requestJson);

                jsonParser = new JSONParser();
                JSONObject responseObj = new JSONObject();
                JSONObject responsePayloadObj = new JSONObject();
                try {
                    json = (JSONObject) jsonParser.parse(responseJSON);
                    response = json.get("response").toString();
                    responseObj = (JSONObject) jsonParser.parse(response);
                    String payload = responseObj.get("payload").toString();
                    responsePayloadObj = (JSONObject) jsonParser.parse(payload);

                    ArrayList<String> clientID = new ArrayList<String>();
                    clientID = (ArrayList<String>) responsePayloadObj.get("clientId");
                    resultString = clientID.get(0);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                break;
               case "DicsountApplicable":   //added by Aanchal 10FEB
                 plantype = iFormRef.getValue("PLAN_TYPE").toString();
                String plan_name=iFormRef.getValue("PLAN_NAME").toString();
                 secplanCode = (String) iFormRef.getControlValue("PLAN_NAME_COMBO");
                Product_Solution = (String) iFormRef.getControlValue("PRODUCT_SOLUTION");
                Channel=iFormRef.getValue("CHANNEL").toString();
                String Query="";
                String result="";
                if(plantype.equalsIgnoreCase("ULIP"))
                {
                     Query="SELECT Discount FROM NG_NB_MS_ULIP(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' and Channel='"+Channel+"'";
              
                }
                else if(plantype.equalsIgnoreCase("TRAD"))
                {
                    Query="SELECT Discount FROM NG_NB_MS_TRAD(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' and Channel='"+Channel+"'";
                }  
                else if(plantype.equalsIgnoreCase("JOINT"))
                {
                    Query="SELECT Discount FROM NG_NB_MS_JOINT(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' and Channel='"+Channel+"'";
                }
                else if(plantype.equalsIgnoreCase("ANNUITY"))
                {
                    Query="SELECT Discount FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' and Channel='"+Channel+"'";
                } 
                else if(plantype.equalsIgnoreCase("HEALTH"))
                {
                    Query="SELECT Discount FROM NG_NB_MS_HEALTH(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' and Channel='"+Channel+"'";
                } 
                else if(plantype.equalsIgnoreCase("COMBO"))
                {
                    Query="SELECT top 1 Discount FROM NG_NB_MS_COMBO(NOLOCK) WHERE PLAN_CODE ='"+plan_name+"' AND  combo_plan_code='"+secplanCode+"' and product_Solution='"+Product_Solution+"' and Channel='"+Channel+"'";
                } 
                List Discount = (List) iFormRef.getDataFromDB(Query);
                if (!Discount.isEmpty()) {
                    result = (String) ((List) Discount.get(0)).get(0);

                }
                resultString = result;
                break;   //added by Aanchal 10FEB
            case "COVERAGE_EMR_CHECK":   //27october
                String username = iFormRef.getUserName();
                String emr_check = "";
                List emr = (List) iFormRef.getDataFromDB("SELECT EMR FROM NG_NB_UW_LEVEL(NOLOCK) WHERE LEVEL =(SELECT TOP 1 LEVEL FROM NG_NB_UW_USERS(NOLOCK) WHERE username='" + username + "')");
                if (!emr.isEmpty()) {
                    emr_check = (String) ((List) emr.get(0)).get(0);

                }
                resultString = emr_check;
                break;
            case "getValueFromServer":   //03nov
                String[] clientData = stringData.split(";");
                String colName = clientData[0];
                String tableName = clientData[1];
                winame = (String) iFormRef.getControlValue("WorkItemName");
                query = "SELECT " + colName + " FROM " + tableName + "(NOLOCK) WHERE WI_NAME='" + winame + "' ";
                List queryResult = iFormRef.getDataFromDB(query);
                if (queryResult != null) {
                    resultString = (String) ((List) queryResult.get(0)).get(0);
                }
                break;
            case "productlaunchdate_ULIP":
            	
            	 String Plan_Code=iFormRef.getValue("PLAN_NAME").toString();
            	 Channel=iFormRef.getValue("CHANNEL").toString();
            	 
            	 queryList = (List) iFormRef.getDataFromDB("SELECT TOP 1 plan_Effective_Date FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + Plan_Code + "'AND Channel='" + Channel + "'");
            	 
            	 if (!queryList.isEmpty()) {

            		 resultString = (String) ((List) queryList.get(0)).get(0);
                 }
         
                break;
            case "productlaunchdate_TRAD":
            	 Plan_Code=iFormRef.getValue("PLAN_NAME").toString();
            	 Channel=iFormRef.getValue("CHANNEL").toString();
            	 queryList = (List) iFormRef.getDataFromDB("SELECT TOP 1 plan_Effective_Date FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + Plan_Code + "'AND Channel='" + Channel + "'");
            
            	 if (!queryList.isEmpty()) {

            		 resultString = (String) ((List) queryList.get(0)).get(0);
                 }
            	
                break;          
            case "GT":
                resultString = callAPI.generate_Token();
                break;
                
            case "Concat_Reject_Reasons":
                winame = (String) iFormRef.getControlValue("WorkItemName");
                String Concatdata="SELECT CONCAT_REJECT_REASONS FROM NG_NB_EXT_TABLE(NOLOCK) WHERE WI_NAME='" + winame + "'";
                 List Concatdata_fetch = iFormRef.getDataFromDB(Concatdata);
                 resultString = (String) ((List) Concatdata_fetch.get(0)).get(0);
            break;
                
            //DR 48459 Lovnish,Nikita
            case "Fields_Mandatory":
                String Plan_Type=iFormRef.getValue("PLAN_TYPE").toString();
                String Jointlife=iFormRef.getValue("IS_JOINTLIFE").toString();
                String Client_type =iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString();
            	String Proposer_First_Name =iFormRef.getValue("Q_PROPOSER_DETAILS_FIRST_NAME").toString();
                String Proposer_Last_Name =iFormRef.getValue("Q_PROPOSER_DETAILS_LAST_NAME").toString();
                String Proposer_First_Name_Dup =iFormRef.getValue("Q_PROPOSER_DETAILS_FIRST_NAME_DUP").toString();
                String Proposer_Last_Name_Dup =iFormRef.getValue("Q_PROPOSER_DETAILS_LAST_NAME_DUP").toString();
                String ID_Proof_Prop =iFormRef.getValue("Q_PROPOSER_DETAILS_ID_PROOF_PROP").toString();
                String Proposer_Proof_Number =iFormRef.getValue("Q_PROPOSER_DETAILS_PROOF_NUMBER").toString();
                String Do_you_have_PAN_Prop =iFormRef.getValue("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN").toString();
                String Proposer_PAN_Number =iFormRef.getValue("Q_PROPOSER_DETAILS_PAN_NUMBER").toString();
                String Proposer_PAN_Number_Dup =iFormRef.getValue("Q_PROPOSER_DETAILS_PAN_NUMBER_DUP").toString();
                String Payout_Credit =iFormRef.getValue("Q_NEFT_DETAILS_PAYOUTS_CREDITED").toString();
                String Payout_Credit_Annuitant =iFormRef.getValue("Q_NEFT_DETIALS_ANNUITANT_PAYOUTS_CREDITED").toString();
                String NEFT_Acc_NO =iFormRef.getValue("Q_NEFT_DETAILS_ACC_NO_NEFT").toString();
                String NEFT_Branch_Name =iFormRef.getValue("Q_NEFT_DETAILS_NAME_BRANCH_NEFT").toString();
                String NEFT_IFSC =iFormRef.getValue("Q_NEFT_DETAILS_IFSC_NEFT").toString();
                String NEFT_Acc_NO_Dup =iFormRef.getValue("Q_NEFT_DETAILS_ACC_NO_NEFT_DUP").toString();
                String NEFT_Branch_Name_Dup =iFormRef.getValue("Q_NEFT_DETAILS_NAME_BRANCH_NEFT_DUP").toString();
                String NEFT_IFSC_Dup =iFormRef.getValue("Q_NEFT_DETAILS_IFSC_NEFT_DUP").toString();
                String NEFT_Acc_NO_Annuitant =iFormRef.getValue("Q_NEFT_DETIALS_ANNUITANT_ACC_NO_NEFT").toString();
                String NEFT_Branch_Name_Annuitant =iFormRef.getValue("Q_NEFT_DETIALS_ANNUITANT_NAME_BRANCH_NEFT").toString();
                String NEFT_IFSC_Annuitant =iFormRef.getValue("Q_NEFT_DETIALS_ANNUITANT_IFSC_NEFT").toString();
                String L2BI_First_Name =iFormRef.getValue("Q_L2BI_DETAILS_FIRST_NAME").toString();
                String L2BI_Last_Name =iFormRef.getValue("Q_L2BI_DETAILS_LAST_NAME").toString();
                String L2BI_First_Name_Dup =iFormRef.getValue("Q_L2BI_DETAILS_FIRST_NAME_DUP").toString();
                String L2BI_Last_Name_Dup =iFormRef.getValue("Q_L2BI_DETAILS_LAST_NAME_DUP").toString();
                String Do_you_have_PAN_L2BI =iFormRef.getValue("Q_L2BI_DETAILS_DO_YOU_HAVE_PAN").toString();
                String L2BI_PAN_Number =iFormRef.getValue("Q_L2BI_DETAILS_PAN_NUMBER").toString();
                String L2BI_PAN_Number_Dup =iFormRef.getValue("Q_L2BI_DETAILS_PAN_NUMBER_DUP").toString();


            	 	if(Proposer_First_Name.equalsIgnoreCase("") || Proposer_First_Name_Dup.equalsIgnoreCase("")){
            	 		resultString = "Please Fill Mandatory Field 'Proposer First Name'";
            	 	} 
                        else if(Proposer_Last_Name.equalsIgnoreCase("") || Proposer_Last_Name_Dup.equalsIgnoreCase("")){
             			resultString = "Please Fill Mandatory Field 'Proposer Last Name'";
             		}
                        else if((ID_Proof_Prop.equalsIgnoreCase("PASPRT") ||ID_Proof_Prop.equalsIgnoreCase("PANCRD") || ID_Proof_Prop.equalsIgnoreCase("DL") ||
                                ID_Proof_Prop.equalsIgnoreCase("VOTRID") ||ID_Proof_Prop.equalsIgnoreCase("UID")) && Proposer_Proof_Number.equalsIgnoreCase("")){
                               resultString = "Please Fill Mandatory Field Proposer 'Proof Number'";
                        }
                        else if(Do_you_have_PAN_Prop.equalsIgnoreCase("Y") && (Proposer_PAN_Number.equalsIgnoreCase("") || Proposer_PAN_Number_Dup.equalsIgnoreCase("")) ){
                              resultString = "Please Fill Mandatory Field Proposer 'PAN Number'";
                        }
                        else if(Payout_Credit.equalsIgnoreCase("NEFT") && (NEFT_Acc_NO.equalsIgnoreCase("") || NEFT_Acc_NO_Dup.equalsIgnoreCase(""))){
                               resultString = "Please Fill Mandatory Field 'Bank Account Number'";
                        }
                        else if(Payout_Credit.equalsIgnoreCase("NEFT") && (NEFT_Branch_Name.equalsIgnoreCase("") || NEFT_Branch_Name_Dup.equalsIgnoreCase(""))){
                               resultString = "Please Fill Mandatory Field 'Bank Name and Branch'";
                        }
                        else if(Payout_Credit.equalsIgnoreCase("NEFT") && (NEFT_IFSC.equalsIgnoreCase("") || NEFT_IFSC_Dup.equalsIgnoreCase(""))){
                               resultString = "Please Fill Mandatory Field 'IFSC Code'";
                        }
                        
                        else if(Payout_Credit_Annuitant.equalsIgnoreCase("NEFT") && NEFT_Acc_NO_Annuitant.equalsIgnoreCase("")){
                        resultString = "Please Fill Mandatory Field 'Bank Account Number'";
                        }
                        else if(Payout_Credit_Annuitant.equalsIgnoreCase("NEFT") && NEFT_Branch_Name_Annuitant.equalsIgnoreCase("")){
                               resultString = "Please Fill Mandatory Field 'Bank Name and Branch'";
                        }
                        else if(Payout_Credit_Annuitant.equalsIgnoreCase("NEFT") && NEFT_IFSC_Annuitant.equalsIgnoreCase("") ){
                               resultString = "Please Fill Mandatory Field 'IFSC Code'";
                        }
                        
    
                        else if((Client_type.equalsIgnoreCase("Proposer")|| Client_type.equalsIgnoreCase("Company")) &&(L2BI_First_Name.equalsIgnoreCase("") || L2BI_First_Name_Dup.equalsIgnoreCase(""))){
                                resultString = "Please Fill Mandatory Field 'L2BI First Name'";
                        }
                        else if((Client_type.equalsIgnoreCase("Proposer")|| Client_type.equalsIgnoreCase("Company")) &&(L2BI_Last_Name.equalsIgnoreCase("") || L2BI_Last_Name_Dup.equalsIgnoreCase(""))){
                                resultString = "Please Fill Mandatory Field 'L2BI Last Name'";
                        }

                        else if((Plan_Type.equalsIgnoreCase("ANNUITY") || Client_type.equalsIgnoreCase("Company") || Jointlife.equalsIgnoreCase("Y")) && Do_you_have_PAN_L2BI.equalsIgnoreCase("Y") && (L2BI_PAN_Number.equalsIgnoreCase("") || L2BI_PAN_Number_Dup.equalsIgnoreCase(""))){
                                 resultString = "Please Fill Mandatory Field L2BI 'PAN Number'";
                        }

             	break; 
            case "GenerateToken":
                propertiesFileData = new Properties();
                String configPath_Token = System.getProperty("user.dir") + "\\" + CONFIG_PATH;
                FileReader reader1;
                try {
                    reader1 = new FileReader(configPath_Token);
                    propertiesFileData.load(reader1);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
                }

            	String token = "", UrlToken = propertiesFileData.getProperty("GenerateTokenUrl"),
		userNameToken = propertiesFileData.getProperty("GenerateTokenUser"),
		base64EncodedPasswordToken = propertiesFileData.getProperty("GenerateTokenPassword");

		String inputJson = "{\"metadata\":{\"X-App-ID\":\"IBPS\",\"X-Correlation-ID\":\"31873127329799381273192\"},"
				+ "\"payload\":{\"username\":\"" + userNameToken + "\",\"password\":\"" + base64EncodedPasswordToken + "\"}}";

		HashMap<String, String> hm = new HashMap<>();
		hm.put("Content-Type", "application/json");
		hm.put("x-api-key", propertiesFileData.getProperty("EEApiKey"));
		hm.put("cache-control", "no-cache");
		hm.put("host", propertiesFileData.getProperty("host"));
		hm.put("x-client-id", propertiesFileData.getProperty("XClientId"));
		hm.put("user-pool-id", propertiesFileData.getProperty("UserPoolId"));

		
		String jsonString = callRestAPI(UrlToken, "POST", inputJson, hm);
                  Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, jsonString+"sparsh",jsonString+"sparsh" );
                           
		//CompleteWI.logger.info("jsonString: " + jsonString);
		Object obj = null, tokenObj = null;
		try {
			obj = new JSONParser().parse(jsonString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jo = (JSONObject) obj;
		// String payload = (String) jo.get("payload").toString();

		tokenObj = new JSONParser().parse(jo.get("payload").toString());
		JSONObject joToken = (JSONObject) tokenObj;
		token = (String) joToken.get("token").toString();
		//CompleteWI.logger.info("token generated: " + token);
		resultString= token;
                break;      
        }
        return resultString;
        }
        catch(Exception e)
         {
             
             Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, e);
             return "";
         }
        
    }

    public String getCustomFilterXML(FormDef arg0, IFormReference arg1,
            String arg2) {
        // TODO Auto-generated method stub
        return null;
    }

    public String setMaskedValue(String controlID, String currentValue) {
        // TODO Auto-generated method stub
        return currentValue;
    }

    public JSONArray validateSubmittedForm(FormDef arg0, IFormReference arg1,
            String arg2) {
        // TODO Auto-generated method stub
        return null;
    }

    private static void applyGroup(String activitytype, IFormReference formReference) {
        //formReference.resetGroup("Not Invitation");            
        formReference.applyGroup("validate Form");
    }

    //Custom Functions
    //        public String callAPI(){
    //            String result="";
    //            try {
    //			InetAddress ip = InetAddress.getByName("localhost");
    //
    //			// establish the connection with server port 5056
    //			Socket s = new Socket(ip, 5056);
    //
    //			// obtaining input and out streams
    //			//DataInputStream dis = new DataInputStream(s.getInputStream());
    //			DataOutputStream dos = new DataOutputStream(s.getOutputStream());
    //			
    //			BufferedReader dis
    //	          = new BufferedReader(new InputStreamReader(s.getInputStream()));
    //
    //			dos.writeUTF("Exec REST API");
    //			
    //			StringBuffer outputStringBuffer = new StringBuffer();
    //			String tmp="";
    //			String finalResult = "";
    //			 while ((tmp = dis.readLine()) != null) {
    //				 outputStringBuffer.append(tmp);
    //	               // System.out.println(tmp);
    //				 finalResult = finalResult + tmp;
    //	            }
    //			
    //			finalResult = finalResult.substring(2, finalResult.length());
    //			System.out.println("finalResult: "+finalResult);
    //			
    //			JSONParser jsonParser = new JSONParser();
    //			JSONObject json = (JSONObject) jsonParser.parse(finalResult);	
    //			
    //			String metadata = json.get("metadata").toString();
    //			System.out.println("metadata: "+metadata);
    //                String outputString="";
    //			
    //			// the following loop performs the exchange of
    //			// information between client and client handler
    //			//System.out.println(dis.readUTF());
    //			//outputString = dis.readUTF().toString();
    //			// String tosend = scn.nextLine();
    //
    //			// closing resources
    //			// scn.close();
    //			// If client sends; exit,close this connection
    //			// and then break from the while loop
    //			System.out.println("outputString: "+outputString);
    //			System.out.println("Closing this connection : " + s);
    //			s.close();
    //			System.out.println("Connection closed");
    //
    //			dis.close();
    //			dos.close();
    //		} catch (IOException | org.json.simple.parser.ParseException e) {
    //			System.out.println(e);
    //		} 
    //            return result;
    //        }
         private void Medical_Information_PROP_section_load(String id, String stringData, IFormReference iFormRef) {
            String controlName = id;
            String value = stringData;
          
            JSToJava medpropobj=new JSToJava(iFormRef);
            try
            {
              String plantype = (String) iFormRef.getControlValue("PLAN_TYPE");
            	String planN = (String) iFormRef.getControlValue("PLAN_NAME");
            	String chnl = (String) iFormRef.getControlValue("CHANNEL");
                String isDhuCase=(String) iFormRef.getControlValue("isDhuCase");// dhu by mansi
               //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("HEALTH"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                String IS_POS="";
                	  List queryResult_POS = (List) iFormRef.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }
             
                if(IS_POS.equalsIgnoreCase("Y"))
	{
		medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_HEART_DISORDER","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDERS","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_KIDNEY_DISORDER","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_HAD_GENETIC_TESTING","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY","visible","false");
		
		medpropobj.setStyle("Q_MED_INFO_PROP_POS_MEDICAL_CONDITION","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_POS_HOSPITALIZED","visible","true");
		
		medpropobj.setMandatory("Q_MED_INFO_PROP_POS_MEDICAL_CONDITION");
		medpropobj.setMandatory("Q_MED_INFO_PROP_POS_HOSPITALIZED");
		medpropobj.setMandatory("Q_MED_INFO_PROP_COVID_QUESTIONS");
		
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_HAD_GENETIC_TESTING");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEART_DISORDER");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_KIDNEY_DISORDER");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM");


		medpropobj.setValue("Q_MED_INFO_PROP_COVID_QUESTIONS_label","3)Have you or any of your family member(s) been tested for Covid-19 or currently suffering/suffered from fever, cough, sore throat or Flu like symptoms in last 2 months or have you or your family members travelled overseas post 1st Jan'20 or have any plans to travel Overseas in next 6 Months?");
		value="N";
	}
	else
	{
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_POS_MEDICAL_CONDITION");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_POS_HOSPITALIZED");
		medpropobj.setnonMandatory("Q_MED_INFO_PROP_COVID_QUESTIONS");
		
		medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD");
		medpropobj.setMandatory("Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY");
		medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES");
		medpropobj.setMandatory("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY");
		medpropobj.setMandatory("Q_MED_INFO_PROP_HAD_GENETIC_TESTING");
		medpropobj.setMandatory("Q_MED_INFO_PROP_HEART_DISORDER");
		medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION");
		medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP");
		medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_DISORDER");
		medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER");
		medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS");
		medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS");
		medpropobj.setMandatory("Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM");
		
		
		medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_HEART_DISORDER","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDERS","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_KIDNEY_DISORDER","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_HAD_GENETIC_TESTING","visible","true");
		medpropobj.setStyle("Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY","visible","true");
		
		medpropobj.setStyle("Q_MED_INFO_PROP_POS_MEDICAL_CONDITION","visible","false");
		medpropobj.setStyle("Q_MED_INFO_PROP_POS_HOSPITALIZED","visible","false");

		medpropobj.setValue("Q_MED_INFO_PROP_COVID_QUESTIONS_label","14)Have you or any of your family member(s) been tested for Covid-19 or currently suffering/suffered from fever, cough, sore throat or Flu like symptoms in last 2 months or have you or your family members travelled overseas post 1st Jan'20 or have any plans to travel Overseas in next 6 Months?");
		
		
	}
	
                
                
	if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_DIABETES")) {

		if (value.equalsIgnoreCase("Y") ){
			medpropobj.setStyle("Q_MED_INFO_PROP_MANAGING_DIABETES", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_MANAGING_DIABETES");
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETIC_FOR", "visible", "true");
			//medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETIC_FOR")  //5oct
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS");
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "true");
			//medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS")                               //6oct	
                        //DR-43033 DHU by mansi
			if(isDhuCase.equalsIgnoreCase("Y")){				
				medpropobj.setStyle("MED_INFO_PROP_label194", "visible", "true");
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_MONTH", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_MONTH");
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_YEAR", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_YEAR");
				medpropobj.setStyle("Q_MED_INFO_PROP_SPECIFY_TYPE_DIABETES", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_SPECIFY_TYPE_DIABETES");	
				
				medpropobj.setStyle("Q_MED_INFO_PROP_MANAGING_DIABETES", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_MANAGING_DIABETES");
                               // iFormRef.addItemInCombo("Q_MED_INFO_PROP_MANAGING_DIABETES","Not on treatment/Diet control","NTDC"); //add combo id
				iFormRef.removeItemFromCombo("Q_MED_INFO_PROP_MANAGING_DIABETES",4);
				
				
				medpropobj.setStyle("Q_LIST_DIABETES_COMPLICATIONS_PROP", "visible", "true");
				medpropobj.setMandatory("Q_LIST_DIABETES_COMPLICATIONS_PROP");
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "false");
				
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETIC_FOR", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETIC_FOR");
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS");
				medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS");
			}else{
                        iFormRef.removeItemFromCombo("Q_MED_INFO_PROP_MANAGING_DIABETES",5);}
                } else {

			//clearValue("Q_MED_INFO_PROP_MANAGING_DIABETES", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_MANAGING_DIABETES", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_MANAGING_DIABETES");
			//clearValue("Q_MED_INFO_PROP_DIABETIC_FOR", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETIC_FOR", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETIC_FOR");
			//clearValue("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS");
			//clearValue("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS");
			
                        //dr-43033 DHU by mansi
			medpropobj.setStyle("MED_INFO_PROP_label194", "visible", "false");
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_MONTH", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_MONTH");
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_YEAR", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_YEAR");
			medpropobj.setStyle("Q_MED_INFO_PROP_SPECIFY_TYPE_DIABETES", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_SPECIFY_TYPE_DIABETES");	
			
			medpropobj.setStyle("Q_LIST_DIABETES_COMPLICATIONS_PROP", "visible", "false");
			medpropobj.setnonMandatory("Q_LIST_DIABETES_COMPLICATIONS_PROP");
			
                        medpropobj.setValues("{'Q_MED_INFO_PROP_MANAGING_DIABETES':'','Q_MED_INFO_PROP_DIABETIC_FOR':'','Q_MED_INFO_PROP_DIABETES_COMPLICATIONS':'','Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS':'','Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_MONTH':'','Q_MED_INFO_PROP_DIABETES_FIRST_DIAGONOSED_YEAR':'','Q_MED_INFO_PROP_SPECIFY_TYPE_DIABETES':'','Q_LIST_DIABETES_COMPLICATIONS_PROP':''}",false);

		}
		
	}
	if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_DIABETES_COMPLICATIONS")) {
		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "true"); //6oct
			//medpropobj.setMandatory("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS")
		} else {
			//medpropobj.setStyle("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_DIABETES_OTHER_DETAILS");
		}

	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HYPERTENSION_BP")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_BP_UNDER_CONTROL", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");

			medpropobj.setStyle("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");

			medpropobj.setStyle("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
;
			medpropobj.setStyle("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
                        //DR-43033 DHU by mansi
			/*if(isDhuCase.equalsIgnoreCase("Y")){
				medpropobj.setStyle("label_BP_FIRST_DIAGONOSED", "visible", "true");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT");
				medpropobj.setStyle("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST");				
				medpropobj.setStyle("Q_LIST_BP_ANY_COMPLICATIONS_PROP", "visible", "true");
				medpropobj.setMandatory("Q_LIST_BP_ANY_COMPLICATIONS_PROP");
			}*/

		} else {

			//clearValue("Q_MED_INFO_PROP_BP_UNDER_CONTROL", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_BP_UNDER_CONTROL", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");
			//clearValue("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");
			//clearValue("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
			//clearValue("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
			//DR-43033 dhu by mansi
				medpropobj.setStyle("label_BP_FIRST_DIAGONOSED", "visible", "false");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT");
				medpropobj.setStyle("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST");				
				medpropobj.setStyle("Q_LIST_BP_ANY_COMPLICATIONS_PROP", "visible", "false");
				medpropobj.setnonMandatory("Q_LIST_BP_ANY_COMPLICATIONS_PROP");
                                
			medpropobj.setValues("{'Q_MED_INFO_PROP_BP_UNDER_CONTROL':'','Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL':'','Q_MED_INFO_PROP_THYROID_UNDER_CONTROL':'','Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS':'','Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH':'','Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR':'','Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT':'','Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST':'','Q_LIST_BP_ANY_COMPLICATIONS_PROP':''}",false);
		}
		
	} else if(controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST")){ 	// dr-43033 by mansi
		if(value.equalsIgnoreCase("Y")){
			medpropobj.setStyle("Q_LIST_INVESTIGATED_FOR_PROP", "visible", "true");
			medpropobj.setMandatory("Q_LIST_INVESTIGATED_FOR_PROP");			
			medpropobj.setStyle("label_LAST_DOCTOR_CONSULATION", "visible", "true");
			medpropobj.setStyle("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_MONTH", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_MONTH");
			medpropobj.setStyle("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_YEAR", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_YEAR");
		}else{
			medpropobj.setStyle("Q_LIST_INVESTIGATED_FOR_PROP", "visible", "false");
			medpropobj.setnonMandatory("Q_LIST_INVESTIGATED_FOR_PROP");
			medpropobj.setStyle("label_LAST_DOCTOR_CONSULATION", "visible", "false");
			medpropobj.setStyle("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_MONTH", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_MONTH");
			medpropobj.setStyle("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_YEAR", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_YEAR");
                        
			medpropobj.setValues("{'Q_LIST_INVESTIGATED_FOR_PROP':'','Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_MONTH':'','Q_MED_INFO_PROP_LAST_DOCTOR_CONSULATION_YEAR':''}",true);
		}		
	} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_BP_UNDER_CONTROL") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_THYROID_UNDER_CONTROL") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS")) {

		if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_BP_UNDER_CONTROL")) {
			if (value.equalsIgnoreCase("true")) {  //tochekc by dbugeer
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
                                //DR-43033 DHU by mansi
			if(isDhuCase.equalsIgnoreCase("Y")){
				medpropobj.setStyle("label_BP_FIRST_DIAGONOSED", "visible", "true");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT");
				medpropobj.setStyle("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST");				
				medpropobj.setStyle("Q_LIST_BP_ANY_COMPLICATIONS_PROP", "visible", "true");
				medpropobj.setMandatory("Q_LIST_BP_ANY_COMPLICATIONS_PROP");
			}

			}else{
                            //DR-43033 dhu by mansi
				medpropobj.setStyle("label_BP_FIRST_DIAGONOSED", "visible", "false");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR");
				medpropobj.setStyle("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT");
				medpropobj.setStyle("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST", "visible", "false");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST");				
				medpropobj.setStyle("Q_LIST_BP_ANY_COMPLICATIONS_PROP", "visible", "false");
				medpropobj.setnonMandatory("Q_LIST_BP_ANY_COMPLICATIONS_PROP");
                                
			medpropobj.setValues("{'Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_MONTH':'','Q_MED_INFO_PROP_HYPERT_BP_FIRST_DIAGONOSED_YEAR':'','Q_MED_INFO_PROP_HYPERTENSION_BP_TREATMENT':'','Q_MED_INFO_PROP_LAST_2YR_ECG_XRAY_TEST':'','Q_LIST_BP_ANY_COMPLICATIONS_PROP':''}",false);

                        }
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS")) {
			if (!(value.equalsIgnoreCase(""))) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
			} else {
				if ((medpropobj.getValue("Q_MED_INFO_PROP_BP_UNDER_CONTROL").equalsIgnoreCase("false")) && (medpropobj.getValue("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL").equalsIgnoreCase("false")) &&( medpropobj.getValue("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL").equalsIgnoreCase("false"))) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_BP_UNDER_CONTROL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_CHOLESTEROL_UNDER_CONTROL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_THYROID_UNDER_CONTROL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BP_CHOLESTEROL_DETAILS");
				}

			}
		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HEART_DISORDER")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN");

			medpropobj.setStyle("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN");
			//clearValue("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN':'','Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN" )|| controlName.equalsIgnoreCase("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN")) {
			if (value.equalsIgnoreCase("Y") || value.equalsIgnoreCase("N")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS");
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS")) {
			if (!(value.equalsIgnoreCase(""))) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN").equalsIgnoreCase("")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CHEST_PAIN");
					medpropobj.setMandatory("Q_MED_INFO_PROP_CHEST_PAIN_OTHER_DETAILS");
				}
			}
		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LUNG_DISORDERS")) {

		if (value.equalsIgnoreCase( "Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");

			medpropobj.setStyle("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");

			medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
                        //DR-43033 dhu BY mansi
			if(isDhuCase.equalsIgnoreCase("Y")){
				medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA", "visible", "true");
				medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA");
				medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA", "visible", "false");
				medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
			}
		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");

			//clearValue("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");

			//clearValue("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
			//DR-43033 by mansi
			medpropobj.setStyle("Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS':'','Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS':'','Q_MED_INFO_PROP_HISTORY_OF_ASTHMA':'','Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS':'','Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA':''}",false);

		}
		
	}else if(controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LUNG_DISORDER_HISTORY_OF_ASTHMA")){ 		//DR-43033 DHU BY mansi
		if(value.equalsIgnoreCase("true")){
			medpropobj.setStyle("Q_MED_INFO_PROP_BREATH_LUNG_DISORDER_FREQUENCY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BREATH_LUNG_DISORDER_FREQUENCY");
			medpropobj.setStyle("Q_MED_INFO_PROP_DISORDER_TYPE_OF_TREATMENT", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_DISORDER_TYPE_OF_TREATMENT");
			medpropobj.setStyle("Q_MED_INFO_PROP_ADMITTED_TO_HOSPITAL", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ADMITTED_TO_HOSPITAL");
			medpropobj.setStyle("Q_MED_INFO_PROP_SMOKED_CIGARETTES_TOBACCO", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SMOKED_CIGARETTES_TOBACCO");
		}else{
			medpropobj.setStyle("Q_MED_INFO_PROP_BREATH_LUNG_DISORDER_FREQUENCY", "visible", "false");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BREATH_LUNG_DISORDER_FREQUENCY");
			medpropobj.setStyle("Q_MED_INFO_PROP_DISORDER_TYPE_OF_TREATMENT", "visible", "false");
			medpropobj.setMandatory("Q_MED_INFO_PROP_DISORDER_TYPE_OF_TREATMENT");
			medpropobj.setStyle("Q_MED_INFO_PROP_ADMITTED_TO_HOSPITAL", "visible", "false");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ADMITTED_TO_HOSPITAL");
			medpropobj.setStyle("Q_MED_INFO_PROP_SMOKED_CIGARETTES_TOBACCO", "visible", "false");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SMOKED_CIGARETTES_TOBACCO");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_BREATH_LUNG_DISORDER_FREQUENCY':'','Q_MED_INFO_PROP_DISORDER_TYPE_OF_TREATMENT':'','Q_MED_INFO_PROP_ADMITTED_TO_HOSPITAL':'','Q_MED_INFO_PROP_SMOKED_CIGARETTES_TOBACCO':''}",true);
		}		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA" )|| controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS")) {

		if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS")) {
				if (value.equalsIgnoreCase("true")) {  
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
			} else {
				if ((medpropobj.getValue("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS").equalsIgnoreCase( "false")) && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS").equalsIgnoreCase( "")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS")) {
				if (value.equalsIgnoreCase("true")) {  
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS").equalsIgnoreCase("") ){
					medpropobj.setMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_ASTHMA") ){
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS").equalsIgnoreCase("")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS")) {
			if (!(value.equalsIgnoreCase( ""))) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_ALLERGIC_BRONCHITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ASTHMA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LUNG_DISORDERS_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TUBERCULOSIS");
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LIVER_RELATED_DISORDER")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");

			medpropobj.setStyle("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONES", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");

			medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");

			//clearValue("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_STONES", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONES", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");

			//clearValue("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE':'','Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION':'','Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER':'','Q_MED_INFO_PROP_HISTORY_OF_STONES':'','Q_MED_INFO_PROP_LIVER_OTHER_DETAILS':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE" )|| controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_STONES") || 
	controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONES").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS").equalsIgnoreCase( "")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONES").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS").equalsIgnoreCase( "")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONES").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_STONES")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONES").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_JAUNDICE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_INDIGESTION_CONSTIPATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_GALL_BLADDER");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONES");
					medpropobj.setMandatory("Q_MED_INFO_PROP_LIVER_OTHER_DETAILS");

				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OR_STD")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA", "visible", "true");
			medpropobj.setStyle("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS", "visible", "true");
                        //DR-41542 mansi
                            medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD", "visible", "true");
                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");

			//clearValue("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
			// DR-41542 mansi
                            medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD", "visible", "false");
                            medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY':'','Q_MED_INFO_PROP_HISTORY_OF_LIPOMA':'','Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS':'','Q_MED_INFO_PROP_HISTORY_OF_HIV_STD':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_LIPOMA") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                // DR-41542 mansi
                                    medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
                                
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS").equalsIgnoreCase("") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD").equalsIgnoreCase("false")) {
                                        // DR-41542 mansi
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                // DR-41542 mansi
                                    medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS").equalsIgnoreCase( "") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD").equalsIgnoreCase("false")) {
                                        // DR-41542 mansi
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
                                        
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
                               
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA").equalsIgnoreCase("false") && medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD").equalsIgnoreCase("false")) {
                                        // DR-41542 mansi
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
                                        
				}
			}
		}else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD")) { // DR-41542 mansi
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS"); 
                                medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS").equalsIgnoreCase( "")) {
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_IRON_DEFICIENCY");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_LIPOMA");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_ABNORMAL_GROWTH_OTHER_DETAILS");
                                            medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HIV_STD");
                                       
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_KIDNEY_DISORDER")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_UTI", "visible", "true");


			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY", "visible", "true");


			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONE", "visible", "true");


			medpropobj.setStyle("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS", "visible", "true");

			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
			medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_UTI", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_UTI", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_STONE", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONE", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");

			//clearValue("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_UTI':'','Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY':'','Q_MED_INFO_PROP_HISTORY_OF_STONE':'','Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_UTI") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_STONE") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_UTI")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_UTI").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_STONE")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_UTI").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");

			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_UTI").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_UTI");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_KIDNEY_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_KIDNEY_OTHER_DETAILS");
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_NEUROLOGICAL_PROBLEM")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_NEUROLOGICAL_DETAILS':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_MUSCULAR_JOINT_DISORDERS")) {

		if (value.equalsIgnoreCase( "Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");


			medpropobj.setStyle("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");


			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");


			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");


			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");


			medpropobj.setStyle("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");

			//clearValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");

			//clearValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC':'','Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY':'','Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE':'','Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS':'','Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE':'','Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS':''}",false);
			

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS")|| controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_SUGGESTED_PHYSIOTHERAPY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_HAIRLINE_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_OSTEOARTHRITIS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ANY_FRACTURE");
					medpropobj.setMandatory("Q_MED_INFO_PROP_MUSCULAR_JOINT_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BACK_PAIN_SLIP_DISC");
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_HOSPITALIZATION")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");

			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");

			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");

			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");

			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_COLD", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");

			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
		} else {

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_COLD", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_COLD", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");

			//clearValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER':'','Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING':'','Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT':'','Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION':'','Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA':'','Q_MED_INFO_PROP_HISTORY_OF_COLD':'','Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS':''}",false);
			

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_COLD") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS")) {

		if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS").equalsIgnoreCase("")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT")) {

			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION")) {

			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_COLD")) {
			if (value.equalsIgnoreCase("true")) {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS")) {
			if (value != "") {
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_COLD").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OTHER_DETAILS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_OF_POISONING");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_ACCIDENT");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_CSECTION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZED_FOR_MALARIA");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_COLD");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HOSPITALIZATION_FOR_FEVER");
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_ADVISED_TESTS_XRAY_SURGERY")) {

		if (value.equalsIgnoreCase( "Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");

			medpropobj.setStyle("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");

			medpropobj.setStyle("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");

			medpropobj.setStyle("Q_MED_INFO_PROP_SURGERY_FOR_DNS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");

			medpropobj.setStyle("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");

			medpropobj.setStyle("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");

			medpropobj.setStyle("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");

			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");

			medpropobj.setStyle("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
		} else {

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");

			//clearValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");

			//clearValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");

			//clearValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_SURGERY_FOR_DNS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");

			//clearValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");

			//clearValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");

			//clearValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");

			//clearValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");

			//clearValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");

			//clearValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			
			medpropobj.setValues("{'Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY':'','Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY':'','Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY':'','Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY':'','Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS':'','Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK':'','Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY':'','Q_MED_INFO_PROP_SURGERY_FOR_DNS':'','Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK':'','Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL':'','Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS':'','Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY':'','Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION':'','Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY':''}",false);

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_SURGERY_FOR_DNS") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY") || controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION") || controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY")) {

		if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_SURGERY_FOR_DNS")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
;					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION")) {
			if (value.equalsIgnoreCase("true")) {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY") == "") {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		} else if (controlName.equalsIgnoreCase( "Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY")) {
			if (value != "") {

				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
				medpropobj.setnonMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
			} else {
				if (medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_SURGERY_FOR_DNS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY").equalsIgnoreCase("false")&& medpropobj.getValue("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION").equalsIgnoreCase("false")) {
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_APPENDIX_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_PILES_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_STONE_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_INSERTION_RODS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SIGHT_CORRECTION_LASIK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_CATARACT_SURGERY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_SURGERY_FOR_DNS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_MRI_FOR_BACK");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HEALTH_CHECK_UP_NORMAL");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_INVESTIGATIONS");
					medpropobj.setMandatory("Q_MED_INFO_PROP_BLOOD_TEST_USG_DURING_PREGNANCY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_TEST_BLOOD_DONATION");
					medpropobj.setMandatory("Q_MED_INFO_PROP_ANY_OTHER_PLEASE_SPECIFY");
					medpropobj.setMandatory("Q_MED_INFO_PROP_HISTORY_OF_ACCIDENT_SURGERY");
				}
			}
		}

		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS");
			

		}
		
	} else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HAD_GENETIC_TESTING")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_GENETIC_TESTING_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_GENETIC_TESTING_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_GENETIC_TESTING_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_GENETIC_TESTING_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_GENETIC_TESTING_DETAILS");

		}
		
	}//HEALTH
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_CANCER_INVEST")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CANCER_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CANCER_DETAILS");
			

		}
                
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_CANC_PARENT")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS");
			

		}
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_HEPATITIS_B_C")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS");
			

		}
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_RECURR_COUGH")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS");
			

		}
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_MEDICAL_ULTRASOUND")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_ULTRASOUND_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ULTRASOUND_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_ULTRASOUND_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_ULTRASOUND_DETAILS");
			

		}
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_MEDICAL_ALCOHOL")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_ALCOHOL_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_ALCOHOL_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_ALCOHOL_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_ALCOHOL_DETAILS");
			

		}
		
	}
        else if (controlName.equalsIgnoreCase("Q_MED_INFO_PROP_DIAGNOSED_CONGENITAL_ANOMALY")) {

		if (value.equalsIgnoreCase("Y")) {
			medpropobj.setStyle("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", "visible", "true");
			medpropobj.setMandatory("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS");

		} else {

			//clearValue("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", false);
			medpropobj.setStyle("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS", "visible", "false");
			medpropobj.setnonMandatory("Q_MED_INFO_PROP_CONGENITAL_ANOMALY_DETAILS");
			

		}
		
	}
                
            }
            catch (Exception e) 
            {
                System.out.println("Error in MED PROP details-controlName" + controlName + " " + e.toString());
        
            }
                 
       
    }
    public void L2BI_section_load(String controlName, String stringData, IFormReference iFormRef) {
        BusinessRules prop = new BusinessRules(iFormRef);
        String id = controlName;
        System.out.println(id);
        String value = stringData;
        System.out.println(value);
        try {
            if (id.equalsIgnoreCase("Q_L2BI_DETAILS_CLIENT_ID")) {
                iFormRef.setValue(
                        "L2BI_CLIENT_ID", value);
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_TITLE")) {
               
                if ((!(iFormRef.getActivityName().equalsIgnoreCase("Manual_UW")))  &&(! (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") )) &&(! (iFormRef.getActivityName().equalsIgnoreCase("UW_HOD") )) &&(! (iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor")))&& (!(iFormRef.getActivityName().equalsIgnoreCase("CMO"))) && (!(iFormRef.getActivityName().equalsIgnoreCase("URMU"))) && (!(iFormRef.getActivityName().equalsIgnoreCase("URMU_MANAGER")))) {
                      iFormRef.setStyle("Q_L2BI_DETAILS.MARITAL_STATUS", "disable", "false");
                    if (value.equalsIgnoreCase("Others")) {
                        iFormRef.setStyle("Q_L2BI_DETAILS_SPECIFY_TITLE", "visible", "true");
                        prop.setMandatory("Q_L2BI_DETAILS_SPECIFY_TITLE");
                        prop.setMandatory("Q_L2BI_DETAILS_GENDER");
                    } else {
                        iFormRef.setValue("Q_L2BI_DETAILS_SPECIFY_TITLE", "");
                        iFormRef.setStyle("Q_L2BI_DETAILS_SPECIFY_TITLE", "visible", "false");
                        prop.setnonMandatory("Q_L2BI_DETAILS_SPECIFY_TITLE");
                        iFormRef.setStyle("Q_L2BI_DETAILS_GENDER_DUP", "disable", "true");
                        iFormRef.setStyle("Q_L2BI_DETAILS_GENDER_DUP", "disable", "true");
                    }
                    if (value.equalsIgnoreCase("Mr.")) {
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER", "M");
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER_DUP", "M");
                    } else if (value.equalsIgnoreCase("Mrs.") || value.equalsIgnoreCase("Ms.")) {
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER", "F");
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER_DUP", "F");
                    } else if (value.equalsIgnoreCase("Mx.")) {
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER", "T");
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS_GENDER_DUP", "T");
                        iFormRef.setValue(
                                "Q_L2BI_DETAILS.MARITAL_STATUS", "SNG");
                        iFormRef.setStyle("Q_L2BI_DETAILS.MARITAL_STATUS", "disable", "true");
                    } else if (value.equalsIgnoreCase("Others")) {
                        iFormRef.setStyle("Q_L2BI_DETAILS_GENDER", "disable", "false");
                        iFormRef.setStyle("Q_L2BI_DETAILS_GENDER_DUP", "disable", "false");
                        prop.setMandatory("Q_L2BI_DETAILS_GENDER");
                    }

                    prop.Proposer_Different_Insured_Validations();
                }
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_CITY_DISTRICT_DUP")) {
                iFormRef.setValue(
                        "Q_L2BI_DETAILS_CITY_DISTRICT", value);
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_STATE_UT_DUP")) {
                iFormRef.setValue(
                        "Q_L2BI_DETAILS_STATE_UT", value);
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_PERM_CITY_DISTRICT_DUP")) {
                iFormRef.setValue(
                        "Q_L2BI_DETAILS_PERM_CITY_DISTRICT", value);
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_PERM_STATE_UT_DUP")) {
                iFormRef.setValue(
                        "Q_L2BI_DETAILS_PERM_STATE_UT", value);
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_GENDER")) { 
                  
                  String plantype = (String) iFormRef.getControlValue("PLAN_TYPE");
            	String planN = (String) iFormRef.getControlValue("PLAN_NAME");
            	String chnl = (String) iFormRef.getControlValue("CHANNEL");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                String IS_POS="";
                	  List queryResult_POS = (List) iFormRef.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }

//changes made by amulya
                if (iFormRef.getValue("Q_L2BI_DETAILS_GENDER").toString().equalsIgnoreCase("F") && iFormRef.getValue("Q_L2BI_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") 
                        && Integer.parseInt(iFormRef.getValue("INSURED_AGE").toString()) > 18 &&    (!(IS_POS.equalsIgnoreCase("Y"))) ) {
                    iFormRef.setStyle("t4s2", "visible", "true");
                    iFormRef.setStyle("t4s10", "visible", "true");
                    //executeServerEvent("", "ShowSection", "t4s2", true);
                    //executeServerEvent("", "ShowSection", "t4s10", true);
                } else {
                    iFormRef.setStyle("t4s2", "visible", "false");
                    iFormRef.setStyle("t4s10", "visible", "false");
                    //executeServerEvent("", "HideSection", "t4s2", true);
                    //executeServerEvent("", "HideSection", "t4s10", true);
                }
                if (iFormRef.getValue("PLAN_TYPE").toString().equalsIgnoreCase("JOINT"))
		{
			
                        if (iFormRef.getValue("Q_PROPOSER_DETAILS_GENDER").toString().equalsIgnoreCase("F") && iFormRef.getValue("Q_PROPOSER_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(iFormRef.getValue("PROPOSER_AGE").toString()) > 18 &&    (!(IS_POS.equalsIgnoreCase("Y"))) ) {

				iFormRef.setStyle("t10s14", "visible", "true");
				//setStyle("t10s15", "visible", "true");
			} 
			else {
				iFormRef.setStyle("t10s14", "visible", "false");
				//setStyle("t10s15", "visible", "false");
			}
			 if (iFormRef.getValue("Q_L2BI_DETAILS_GENDER").toString().equalsIgnoreCase("F") && iFormRef.getValue("Q_L2BI_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(iFormRef.getValue("INSURED_AGE").toString()) > 18 &&    (!(IS_POS.equalsIgnoreCase("Y"))) ) {

				//setStyle("t10s14", "visible", "true");
				iFormRef.setStyle("t10s15", "visible", "true");
			} 
			else {
				//setStyle("t10s14", "visible", "false")
				iFormRef.setStyle("t10s15", "visible", "false");
			}
			
                      iFormRef.setStyle("t4s2", "visible", "false");
			
		}
                
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_MARITAL_STATUS")) { 
                String plantype = (String) iFormRef.getControlValue("PLAN_TYPE");
            	String planN = (String) iFormRef.getControlValue("PLAN_NAME");
            	String chnl = (String) iFormRef.getControlValue("CHANNEL");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("HEALTH"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                String IS_POS="";
                	  List queryResult_POS = (List) iFormRef.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }

//changes made by amulya
                if (iFormRef.getValue("Q_L2BI_DETAILS_GENDER").toString().equalsIgnoreCase("F") && iFormRef.getValue("Q_L2BI_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(iFormRef.getValue("INSURED_AGE").toString()) > 18 &&    (!(IS_POS.equalsIgnoreCase("Y"))) ) {
                    iFormRef.setStyle("t4s2", "visible", "true");
                    iFormRef.setStyle("t4s10", "visible", "true");
                    //executeServerEvent("", "ShowSection", "t4s2", true);
                    //executeServerEvent("", "ShowSection", "t4s10", true);
                } else {
                    iFormRef.setStyle("t4s2", "visible", "false");
                    iFormRef.setStyle("t4s10", "visible", "false");
                    //executeServerEvent("", "HideSection", "t4s2", true);
                    //executeServerEvent("", "HideSection", "t4s10", true);
                }
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_OCCUPATION")) {

                if (iFormRef.getValue("Q_L2BI_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Salaried")) {
                    prop.setMandatory("textbox946");
                } else {
                    prop.setnonMandatory("textbox946");
                }

                int age = Integer.parseInt(iFormRef.getValue("INSURED_AGE").toString());

                if (age < 18 && iFormRef.getValue("Q_L2BI_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Studen")) {
                    if (iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString().equalsIgnoreCase("Proposer")) {
                        iFormRef.setStyle("t4s7", "visible", "true");
                        //executeServerEvent("", "ShowSection", "t4s7", true)
                    } else {
                        iFormRef.setStyle("t4s7", "visible", "false");
                        //executeServerEvent("", "HideSection", "t4s7", true)
                    }

                } else {
                    iFormRef.setStyle("t4s7", "visible", "false");
                    //executeServerEvent("", "HideSection", "t4s7", true)
                }
            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_INDUSTRY_TYPE")) {

                if (value.equalsIgnoreCase("AVN")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_NATURE_OF_DUTIES", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_NATURE_OF_DUTIES");
                } else {
                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_NATURE_OF_DUTIES", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_NATURE_OF_DUTIES");
                    iFormRef.setStyle("Q_L2BI_DETAILS_NATURE_OF_DUTIES", "visible", "false");

                    iFormRef.setValue("Q_L2BI_DETAILS_FLYING_ROLE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_FLYING_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_FLYING_ROLE");
                }

                if (value.equalsIgnoreCase("DFN")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_CURRENTLY_POSTED", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_CURRENTLY_POSTED");
                    iFormRef.setStyle("Q_L2BI_DETAILS_NATURE_OF_JOB", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_NATURE_OF_JOB");
                } else {
                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_CURRENTLY_POSTED", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_CURRENTLY_POSTED");
                    iFormRef.setStyle("Q_L2BI_DETAILS_CURRENTLY_POSTED", "visible", "false");

                    iFormRef.setValue("Q_L2BI_DETAILS_NATURE_OF_JOB", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_NATURE_OF_JOB", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_NATURE_OF_JOB");
                }

                if (value.equalsIgnoreCase("DIV")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_PROFESSIONAL_DIVER", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_PROFESSIONAL_DIVER");
                } else {
                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_PROFESSIONAL_DIVER", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_PROFESSIONAL_DIVER");
                    iFormRef.setStyle("Q_L2BI_DETAILS_PROFESSIONAL_DIVER", "visible", "false");

                    iFormRef.setValue("Q_L2BI_DETAILS_DIVE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_DIVE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_DIVE");

                }

                if (value.equalsIgnoreCase("MEM")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_OF_VESSEL", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_TYPE_OF_VESSEL");
                } else {
                    iFormRef.setValue("Q_L2BI_DETAILS_TYPE_OF_VESSEL", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_TYPE_OF_VESSEL");
                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_OF_VESSEL", "visible", "false");
                }

                if (value.equalsIgnoreCase("MIN")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_ROLE_INVOLVE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_ROLE_INVOLVE");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ILLNESS_OCCUPATION", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_ILLNESS_OCCUPATION");
                } else {
                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_ROLE_INVOLVE", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ROLE_INVOLVE");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ROLE_INVOLVE", "visible", "false");

                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_ILLNESS_OCCUPATION", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ILLNESS_OCCUPATION", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ILLNESS_OCCUPATION");

                }

                if (value.equalsIgnoreCase("ONG")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_OFFSHORE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_OFFSHORE");
                } else {
                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_OFFSHORE", "");
                    prop.setnonMandatory("Q_L2BI_DETAILS_OFFSHORE");
                    iFormRef.setStyle("Q_L2BI_DETAILS_OFFSHORE", "visible", "false");
                }

            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_NATURE_OF_DUTIES")) {
                if (value.equalsIgnoreCase("FR")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_FLYING_ROLE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_FLYING_ROLE");

                } else {
                    iFormRef.setValue("Q_L2BI_DETAILS_FLYING_ROLE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_FLYING_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_FLYING_ROLE");
                }

            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_PROFESSIONAL_DIVER")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_DIVE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_DIVE");

                } else {
                    iFormRef.setValue("Q_L2BI_DETAILS_DIVE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_DIVE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_DIVE");
                }

            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_INCOME_SOURCE")) {

                if (value.equalsIgnoreCase("7")) { //others
                    iFormRef.setStyle("Q_L2BI_DETAILS_SPECIFY_INC_SRC", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_SPECIFY_INC_SRC");
                } else {
                    //clearValue("Q_L2BI_DETAILS_SPECIFY_OCCUPATION", true);
                    iFormRef.setStyle("Q_L2BI_DETAILS_SPECIFY_INC_SRC", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_SPECIFY_INC_SRC");

                }

            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_NATIONALITY")) {

                if (!(value.equalsIgnoreCase("I"))) {
                    iFormRef.setStyle("Q_L2BI_DETAILS_BUSINESS_SOURCE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_BUSINESS_SOURCE");

                    iFormRef.setStyle("Q_L2BI_DETAILS_PASSPORT_NO", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_PASSPORT_NO");

                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_OF_VISA", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_TYPE_OF_VISA");

                    iFormRef.setStyle("Q_L2BI_DETAILS_VISA_VALID_TILL", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_VISA_VALID_TILL");

                    iFormRef.setStyle("Q__LIST_PASSPORT_COUNTRIES_L2BI", "visible", "true");
                    prop.setMandatory("Q__LIST_PASSPORT_COUNTRIES_L2BI");

                    iFormRef.setStyle("Q_L2BI_DETAILS_PASSPORT_EXP_DATE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_PASSPORT_EXP_DATE");

                    iFormRef.setStyle("Q_LIST_COUNTRY_OF_RESIDENCE_L2BI", "visible", "true");
                    prop.setMandatory("Q_LIST_COUNTRY_OF_RESIDENCE_L2BI");

                    iFormRef.setStyle("Q_L2BI_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA");

                    iFormRef.setStyle("Q_LIST_COUNTRIES_FREQ_VISITED_L2BI", "visible", "true");
                    prop.setMandatory("Q_LIST_COUNTRIES_FREQ_VISITED_L2BI");

                    iFormRef.setStyle("Q_L2BI_DETAILS_COUNTRY_OF_RESIDENCE", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_COUNTRY_OF_RESIDENCE");

                    iFormRef.setStyle("Q_L2BI_DETAILS_BIRTH_COUNTRY", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_BIRTH_COUNTRY");

                    iFormRef.setStyle("Q_L2BI_DETAILS_FTIN_PRESENT", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_FTIN_PRESENT");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ISSUING_COUNTRY");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ID_NUMBER");

                } else {
                    iFormRef.setValue("Q_L2BI_DETAILS_PASSPORT_NO", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_PASSPORT_NO", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_PASSPORT_NO");

                    iFormRef.setValue("Q_L2BI_DETAILS_BUSINESS_SOURCE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_BUSINESS_SOURCE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_BUSINESS_SOURCE");

                    iFormRef.setValue("Q_L2BI_DETAILS_TYPE_OF_VISA", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_OF_VISA", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_TYPE_OF_VISA");

                    iFormRef.setValue("Q_L2BI_DETAILS_VISA_VALID_TILL", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_VISA_VALID_TILL", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_VISA_VALID_TILL");

                    //iFormRef.setValue("Q__LIST_PASSPORT_COUNTRIES_L2BI", "");
                    iFormRef.setStyle("Q__LIST_PASSPORT_COUNTRIES_L2BI", "visible", "false");
                    prop.setnonMandatory("Q__LIST_PASSPORT_COUNTRIES_L2BI");

                    iFormRef.setValue("Q_L2BI_DETAILS_PASSPORT_EXP_DATE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_PASSPORT_EXP_DATE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_PASSPORT_EXP_DATE");

                    //iFormRef.setValue("Q_LIST_COUNTRY_OF_RESIDENCE_L2BI", "");
                    iFormRef.setStyle("Q_LIST_COUNTRY_OF_RESIDENCE_L2BI", "visible", "false");
                    prop.setnonMandatory("Q_LIST_COUNTRY_OF_RESIDENCE_L2BI");

                    iFormRef.setValue("Q_L2BI_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA");

                    //iFormRef.setValue("Q_LIST_COUNTRIES_FREQ_VISITED_L2BI", "");
                    iFormRef.setStyle("Q_LIST_COUNTRIES_FREQ_VISITED_L2BI", "visible", "false");
                    prop.setnonMandatory("Q_LIST_COUNTRIES_FREQ_VISITED_L2BI");

                    iFormRef.setValue("Q_L2BI_DETAILS_COUNTRY_OF_RESIDENCE", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_COUNTRY_OF_RESIDENCE", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_COUNTRY_OF_RESIDENCE");

                    iFormRef.setValue("Q_L2BI_DETAILS_BIRTH_COUNTRY", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_BIRTH_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_BIRTH_COUNTRY");

                    iFormRef.setValue(
                            "Q_L2BI_DETAILS_FTIN_PRESENT", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_FTIN_PRESENT", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_FTIN_PRESENT");

                    //table38 is ftin details table	
                    //iFormRef.setValue("table45", "");
                    iFormRef.clearTable("table45");
                    iFormRef.setStyle("table45", "visible", "false");
                    prop.setnonMandatory("table45");

                    iFormRef.setValue("Q_L2BI_DETAILS_TYPE_FOREIGN_ID", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_FOREIGN_ID", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_TYPE_FOREIGN_ID");

                    iFormRef.setValue("Q_L2BI_DETAILS_ID_NUMBER", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ID_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ID_NUMBER");

                    iFormRef.setValue("Q_L2BI_DETAILS_ISSUING_COUNTRY", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ISSUING_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ISSUING_COUNTRY");

                }

            } else if (id.equalsIgnoreCase("Q_L2BI_DETAILS_FTIN_PRESENT")) {
                if (value.equalsIgnoreCase("Y")) {

                    iFormRef.setStyle("table45", "visible", "true");
                    prop.setMandatory("table45");

                    iFormRef.setValue("Q_L2BI_DETAILS_TYPE_FOREIGN_ID", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_FOREIGN_ID", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_TYPE_FOREIGN_ID");

                    iFormRef.setValue("Q_L2BI_DETAILS_ID_NUMBER", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ID_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ID_NUMBER");

                    iFormRef.setValue("Q_L2BI_DETAILS_ISSUING_COUNTRY", "");
                    iFormRef.setStyle("Q_L2BI_DETAILS_ISSUING_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ISSUING_COUNTRY");
                } else if (value.equalsIgnoreCase("N")) {

                    iFormRef.setStyle("Q_L2BI_DETAILS_TYPE_FOREIGN_ID", "visible", "true");
                    prop.setMandatory("Q_L2BI_DETAILS_TYPE_FOREIGN_ID");

                    iFormRef.setStyle("Q_L2BI_DETAILS_ID_NUMBER", "visible", "true");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ID_NUMBER");

                    iFormRef.setStyle("Q_L2BI_DETAILS_ISSUING_COUNTRY", "visible", "true");
                    prop.setnonMandatory("Q_L2BI_DETAILS_ISSUING_COUNTRY");

                    //iFormRef.setValue("table45", "");
                    iFormRef.clearTable("table45");
                    iFormRef.setStyle("table45", "visible", "false");
                    prop.setnonMandatory("table45");
                }

            }
        } catch (Exception e) {
            System.out.println("Error in L2BI details-controlName" + controlName + " " + e.toString());
        }
    }

    public void proposer_section_load(String controlName, String stringData, IFormReference iFormRef) {
        BusinessRules prop = new BusinessRules(iFormRef);
        String id = controlName;
        System.out.println(id);
        String value = stringData;
        System.out.println(value);
        String plan = iFormRef.getValue("PLAN_NAME").toString();

        try {
            if (plan.equalsIgnoreCase("UPPRPF") || plan.equalsIgnoreCase("UPPSPF") || plan.equalsIgnoreCase("UPPSCF")) {
                iFormRef.setStyle("Q_PROPOSER_DETAILS_ANNUITY_OPTION", "visible", "true");
                prop.setMandatory("Q_PROPOSER_DETAILS_ANNUITY_OPTION");
            } else {
                iFormRef.setStyle("Q_PROPOSER_DETAILS_ANNUITY_OPTION", "visible", "false");
            }
            if (plan.equalsIgnoreCase("EFGEP8") || plan.equalsIgnoreCase("EFGEPL") || plan.equalsIgnoreCase("U2ESF5") || plan.equalsIgnoreCase("U2ESFV")) { //shiksha plus plan and future genius plan
                //executeServerEvent("", "ShowSection", "t2s5", true) //child details
                iFormRef.setStyle("t2s5", "visible", "true");

            } else {
                //executeServerEvent("", "HideSection", "t2s5", true)
                iFormRef.setStyle("t2s5", "visible", "false");
            }
            if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_GENDER") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_MARITAL_STATUS") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_OCCUPATION") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_GENDER") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_MARITAL_STATUS") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_OCCUPATION")) {
                if (iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString().equalsIgnoreCase("ProposerInsured")) {
                    prop.Proposer_Equals_Insured_Validations();
                }
                if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_OCCUPATION")) {
                    if (iFormRef.getValue("Q_PROPOSER_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Salaried")) {
                        prop.setMandatory("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY");
                    } else {
                        prop.setnonMandatory("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY");
                    }
                    if (iFormRef.getValue("Q_PROPOSER_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Agricult")) {  //aanchal
                        prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    } else {
                        prop.setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    }
                }
            }
            if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_EXACT_INCOME")) {
                int x = (int) iFormRef.getValue("Q_PROPOSER_DETAILS_EXACT_INCOME");
                String y = iFormRef.getValue("Q_PROPOSER_DETAILS_STATE_UT").toString();
                if (x > 250000) {
                    if (y.equalsIgnoreCase("ARUNACHAL PRADESH") || y.equalsIgnoreCase("SIKKIM") || y.equalsIgnoreCase("NAGALAND") || y.equalsIgnoreCase("LADAKH") || y.equalsIgnoreCase("MIZORAM") || y.equalsIgnoreCase("MANIPUR") || y.equalsIgnoreCase("TRIPURA")) {
                        prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");

                    } else {
                        prop.setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    }

                }
            }
            if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_CLIENT_ID")) {
                iFormRef.setValue("PROPOSER_CLIENT_ID", value);

                if ((!(iFormRef.getValue("Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP").toString().equalsIgnoreCase("Y")))) {
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_CLIENT_ID", iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_ID").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_TITLE", iFormRef.getValue("Q_PROPOSER_DETAILS_TITLE").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE", iFormRef.getValue("Q_PROPOSER_DETAILS_SPECIFY_TITLE").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_FIRST_NAME", iFormRef.getValue("Q_PROPOSER_DETAILS_FIRST_NAME").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_MIDDLE_NAME", iFormRef.getValue("Q_PROPOSER_DETAILS_MIDDLE_NAME").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_LAST_NAME", iFormRef.getValue("Q_PROPOSER_DETAILS_LAST_NAME").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_DATE_OF_BIRTH", iFormRef.getValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_GENDER", iFormRef.getValue("Q_PROPOSER_DETAILS_GENDER").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_PAN_NUMBER", iFormRef.getValue("Q_PROPOSER_DETAILS_PAN_NUMBER").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_APPLIED_FOR_PAN", iFormRef.getValue("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_DATE_OF_APPLICATION", iFormRef.getValue("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_APP_ACK_NO", iFormRef.getValue("Q_PROPOSER_DETAILS_PAN_ACK_NO").toString());
                    iFormRef.setValue("Q_PAYOR_PAN_DETAILS_BANK_ACC_NO", iFormRef.getValue("Q_NEFT_DETAILS_ACC_NO_NEFT").toString());

                }
            } else if (controlName.equalsIgnoreCase("Q_PROPOSER_DETAILS_CLIENT_TYPE")) {

                if (value.equalsIgnoreCase("ProposerInsured")) {

                    //setValues({"Q_PAYOR_PAN_DETAILS_CLIENT_ID":getValue("Q_PROPOSER_DETAILS_CLIENT_ID")},true);
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_HAZARDOUS_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_CONVICTED_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_INVOLVED_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_CONVICT_DETAILS_INSUR", "visible", "false");
                    
                    
                  iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_DRUGS_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_DRUGS_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_SELECT_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_SELECT_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_QUANTITY_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_QUANTITY_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_NOYEAR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_NOYEAR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_SELECT_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_SELECT_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_QUANTITY_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_QUANTITY_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_NOYEAR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR_NOYEAR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_NOYEAR_POS","visible","false");
				iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR_NOYEAR_POS","visible","false");


                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_INSUR_POLICY_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_TRAVEL_INFO_TRAVEL_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_LIST_COUNTRY_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_TOTAL_SUM_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_OFFERED_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_ISSUED_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_LIFE_TOTAL_SUM_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_TOTAL_SUM_INSUR", "visible", "false");

                    iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR", "visible", "false");
                    iFormRef.setStyle("Q_HABIT_QUESTIONS_DRUGS_INSUR", "visible", "false");
                    iFormRef.setStyle("label104", "visible", "false");
                    iFormRef.setStyle("label145", "visible", "false");

                    prop.Proposer_Equals_Insured_Validations();

                    //hiding juvenille info as proposer age cannot be less than 18
                    iFormRef.setStyle("t4s7", "visible", "false");
                    iFormRef.setStyle("t6s2", "visible", "false");  //dr-14620 mansi
                    iFormRef.setStyle("t0s2", "visible", "false");
                    iFormRef.setStyle("t4s6", "visible", "false");
                    iFormRef.setStyle("t2s3", "visible", "true");
                    iFormRef.setStyle("t2s2", "visible", "false");
                    //executeServerEvent("", "HideSection", "t4s7", true)

                    //hiding l2bi sections
                    //executeServerEvent("", "HideSection", "t2s2", true)
                    //executeServerEvent("", "HideSection", "t0s2", true)
                    //executeServerEvent("", "HideSection", "t4s6", true);
                    //executeServerEvent("", "ShowSection", "t2s3", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATIONALITY", "visible", "true");

                    iFormRef.setStyle("t2s3", "sectionstate", "expanded");
                    iFormRef.setStyle("t2s3", "sectionstate", "collapsed");

                    iFormRef.setStyle("label110", "visible", "false");
                    iFormRef.setStyle("L2BINAME", "visible", "false");
                    iFormRef.setStyle("label134", "visible", "false");
                    iFormRef.setStyle("label138", "visible", "false");
                    iFormRef.setStyle("INSURED_AGE", "visible", "false");
                    iFormRef.setStyle("INSURED_CLIENT_ID", "visible", "false");

                } else {
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_HAZARDOUS_INSUR", "visible", "true");
                    iFormRef.setStyle("Q_LIFE_STYLE_INFO_CONVICTED_INSUR", "visible", "true");
                    iFormRef.setStyle("Q_OTHER_POLICY_INFO_INSUR_POLICY_INSUR", "visible", "true");
                    iFormRef.setStyle("Q_TRAVEL_INFO_TRAVEL_INSUR", "visible", "true");
                    iFormRef.setStyle("t2s2", "visible", "true");
                    iFormRef.setStyle("t6s2", "visible", "true"); 
                    iFormRef.setStyle("t0s2", "visible", "true");
                    iFormRef.setStyle("t4s6", "visible", "true");
                    iFormRef.setStyle("t2s3", "visible", "false");

                    prop.Proposer_Different_Insured_Validations();
                  

                    //executeServerEvent("", "HideSection", "t2s4", true)
                    //setStyle("t4s6", "sectionstate", "expanded")
                    iFormRef.setStyle("label110", "visible", "true");
                    iFormRef.setStyle("L2BINAME", "visible", "true");
                    iFormRef.setStyle("label134", "visible", "true");
                    iFormRef.setStyle("label138", "visible", "true");
                    iFormRef.setStyle("INSURED_AGE", "visible", "true");
                    iFormRef.setStyle("INSURED_CLIENT_ID", "visible", "true");

                }

                if (value.equalsIgnoreCase("Company")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR");
                   // iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "visible", "true");
                    //prop.setMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP");

                    prop.setnonMandatory("Q_PROPOSER_DETAILS_MARITAL_STATUS");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_OCCUPATION");
                    //prop.setnonMandatory("Q_PROPOSER_DETAILS_INDUSTRY_TYPE");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EDUCATION");
                       prop.setnonMandatory("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY");
                    
                   // prop.setnonMandatory("Q_PROPOSER_DETAILS_NATIONALITY");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_MARITAL_STATUS", "visible", "false");  //ok
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME", "visible", "true");    //ok
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_OCCUPATION", "visible", "false");     //ok
                   // iFormRef.setStyle("Q_PROPOSER_DETAILS_INDUSTRY_TYPE", "visible", "false");  ----true
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EDUCATION", "visible", "false"); 
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY", "visible", "false"); //ok
                    //iFormRef.setStyle("Q_PROPOSER_DETAILS_NATIONALITY", "visible", "false");    ----true
                   // iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "visible", "false");
                  //  iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "visible", "false");
                    //prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH");
                    //prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP");
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "");
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "");
                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", true);
                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COMPANY_TYPE", "visible", "true");  //ok
                    prop.setMandatory("Q_PROPOSER_DETAILS_COMPANY_TYPE");
                    
                    
                      iFormRef.setStyle("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP", "visible", "true");
                iFormRef.setStyle("label178", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_NAME_COMPANY", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_SOURCE_FUND", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_CERTI_INCORPORATION", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_REG_CERTI", "visible", "true");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_PREFERRED_LANGUAGE", "visible", "false");
                 iFormRef.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "false");
                
                  prop.setMandatory("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP");
                  prop.setMandatory("Q_PROPOSER_DETAILS_NAME_COMPANY");
                  prop.setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY");
                  prop.setMandatory("Q_PROPOSER_DETAILS_SOURCE_FUND");
                  prop.setMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY");
                  //prop.setMandatory("Q_PROPOSER_DETAILS_CERTI_INCORPORATION");
                  //prop.setMandatory("Q_PROPOSER_DETAILS_REG_CERTI");
                  
                  	iFormRef.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "visible", "true");
			iFormRef.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "disable", "true");
			prop.setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
			iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER", "visible", "true");
			iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "visible", "false");
			iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_ACK_NO", "visible", "false");
			prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION");
			prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_ACK_NO");
                        iFormRef.setValue("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "Y");
                        
                        
                    iFormRef.setStyle("t4s5", "visible", "false");
                        
                } else {
                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR", true);
                   // iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR");
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "");
                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_COMPANY_TYPE");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_MARITAL_STATUS", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_OCCUPATION", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_INDUSTRY_TYPE", "visible", "true");
                     String plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                     if(plan_type.equalsIgnoreCase("HEALTH"))
                     {
                         iFormRef.setStyle("Q_PROPOSER_DETAILS_INDUSTRY_TYPE", "disable", "true");
                     }
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EDUCATION", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATIONALITY", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COMPANY_TYPE", "visible", "false");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "visible", "true");
                    
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_PREFERRED_LANGUAGE", "visible", "true");
                 iFormRef.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "true");

                    prop.setMandatory("Q_PROPOSER_DETAILS_MARITAL_STATUS");
                    prop.setMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME");
                    prop.setMandatory("Q_PROPOSER_DETAILS_OCCUPATION");
                    prop.setMandatory("Q_PROPOSER_DETAILS_INDUSTRY_TYPE");
                    prop.setMandatory("Q_PROPOSER_DETAILS_EDUCATION");
                    prop.setMandatory("Q_PROPOSER_DETAILS_NATIONALITY");
                    prop.setMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH");
                    
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP", "visible", "false");
                iFormRef.setStyle("label178", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_NAME_COMPANY", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_SOURCE_FUND", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_CERTI_INCORPORATION", "visible", "false");
                iFormRef.setStyle("Q_PROPOSER_DETAILS_REG_CERTI", "visible", "false");
                
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_NAME_COMPANY");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_SOURCE_FUND");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_CERTI_INCORPORATION");
                  prop.setnonMandatory("Q_PROPOSER_DETAILS_REG_CERTI");
                  
                   iFormRef.setStyle("t4s5", "visible", "true");
                }

                if (value.equalsIgnoreCase("Proposer")) {

                    String age = iFormRef.getValue("INSURED_AGE").toString();
                    if (Integer.parseInt(age) < 18 && iFormRef.getValue("Q_L2BI_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Studen")) {
                        iFormRef.setStyle("t4s7", "visible", "true");
                    } else {
                        iFormRef.setStyle("t4s7", "visible", "false");
                    }

                    iFormRef.setStyle("Q_HABIT_QUESTIONS_TOBACCO_INSUR", "visible", "true");
                    iFormRef.setStyle("Q_HABIT_QUESTIONS_ALCOHOL_INSUR", "visible", "true");
                    iFormRef.setStyle("Q_HABIT_QUESTIONS_DRUGS_INSUR", "visible", "true");
                    iFormRef.setStyle("label104", "visible", "true");
                    iFormRef.setStyle("label145", "visible", "true");
                        //Modified by aanchal  Dr-6986
                    //clearValue("Q_OTHER_POLICY_INFO_INSUR_POLICY_INSUR")  //aanchal
                    //iFormRef.setValue("Q_LIFE_STYLE_INFO_HAZARDOUS_INSUR", "");
                    //iFormRef.setValue("Q_LIFE_STYLE_INFO_CONVICTED_INSUR", "");
                    //iFormRef.setValue("Q_LIFE_STYLE_INFO_INVOLVED_INSUR", "");
                    //iFormRef.setValue("Q_LIFE_STYLE_INFO_CONVICT_DETAILS_INSUR", "");
                    //iFormRef.setValue("Q_TRAVEL_INFO_TRAVEL_INSUR", "");
                    //iFormRef.setValue("Q_LIST_COUNTRY_INSUR","");
                   // iFormRef.setValue("Q_HABIT_QUESTIONS_ALCOHOL_INSUR", "");
                   // iFormRef.setValue("Q_HABIT_QUESTIONS_DRUGS_INSUR", "");
                   // iFormRef.setValue("Q_HABIT_QUESTIONS_TOBACCO_INSUR", "");
                       //Dr-6986 
                } else {
                    iFormRef.setStyle("t4s7", "visible", "false");
                    //executeServerEvent("", "HideSection", "t4s7", true)
                }

            }
            if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PAN_APPLIED_FOR")) {

                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_ACK_NO", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PAN_ACK_NO");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER", "disable", "true");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_PAN_NUMBER", "");
                    //clearValue("Q_PROPOSER_DETAILS_PAN_NUMBER", true);
                } else if (value.equalsIgnoreCase("N")) {
                    iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_PAN_ACK_NO", "");
                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", true);
                    //clearValue("Q_PROPOSER_DETAILS_PAN_ACK_NO", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "visible", "false");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_ACK_NO", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_ACK_NO");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER", "disable", "false");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION") || id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PAN_ACK_NO")) {
                iFormRef.setValue("Q_PAYOR_PAN_DETAILS_DATE_OF_APPLICATION", iFormRef.getValue("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION").toString());
                iFormRef.setValue("Q_PAYOR_PAN_DETAILS_APP_ACK_NO", iFormRef.getValue("Q_PROPOSER_DETAILS_PAN_ACK_NO").toString());

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_DO_YOU_HAVE_CKYC")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CKYC_NO", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_CKYC_NO");
                } else {
                    //clearValue("Q_PROPOSER_DETAILS_CKYC_NO", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_CKYC_NO", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CKYC_NO", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_CKYC_NO");
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_TITLE")) {
                iFormRef.setStyle("Q_PROPOSER_DETAILS.MARITAL_STATUS", "disable", "false");
                if (value.equalsIgnoreCase("Others")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_SPECIFY_TITLE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_SPECIFY_TITLE");
                    prop.setMandatory("Q_PROPOSER_DETAILS_GENDER");
                } else {
                    iFormRef.setValue("Q_PROPOSER_DETAILS_SPECIFY_TITLE", "");
                    //clearValue("Q_PROPOSER_DETAILS_SPECIFY_TITLE", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_SPECIFY_TITLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_SPECIFY_TITLE");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_GENDER", "disable", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_GENDER_DUP", "disable", "true");
                }
                if ((!iFormRef.getActivityName().equalsIgnoreCase("Manual_UW"))  && (!(iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") )) && (!(iFormRef.getActivityName().equalsIgnoreCase("UW_HOD") )) && (!(iFormRef.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor")) )&& (!(iFormRef.getActivityName().equalsIgnoreCase("CMO"))) && (!(iFormRef.getActivityName().equalsIgnoreCase("URMU"))) && (!(iFormRef.getActivityName().equalsIgnoreCase("URMU_MANAGER")))) {
                    if (value.equalsIgnoreCase("Mr.")) {
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER", "M");
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "M");

                    } else if (value.equalsIgnoreCase("Mrs.") || value.equalsIgnoreCase("Ms.")) {
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER", "F");
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "F");

                    } else if (value.equalsIgnoreCase("Mx.")) {
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER", "T");
                        iFormRef.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "T");
                        iFormRef.setValue("Q_PROPOSER_DETAILS.MARITAL_STATUS", "SNG");
                        iFormRef.setStyle("Q_PROPOSER_DETAILS.MARITAL_STATUS", "disable", "true");

                    } else if (value.equalsIgnoreCase("Others")) {
                        iFormRef.setStyle("Q_PROPOSER_DETAILS_GENDER", "disable", "false");
                        iFormRef.setStyle("Q_PROPOSER_DETAILS_GENDER_DUP", "disable", "false");
                        prop.setMandatory("Q_PROPOSER_DETAILS_GENDER");

                    }
                }
                if (iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString().equalsIgnoreCase("ProposerInsured")) {
                    prop.Proposer_Equals_Insured_Validations();
                } else {
                    prop.Proposer_Different_Insured_Validations();
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_NATIONALITY")) {

                //setHeaderDetails(controlId);
                if (value.equalsIgnoreCase("I")) {
                    System.out.print("Indian2");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "disable", "false");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", "");
                    //clearValue("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", "visible", "false");
                    prop.setMandatory("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "");
                    System.out.println("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE");
                    ///clearValue("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_PASSPORT_NO", "");
                    //clearValue("Q_PROPOSER_DETAILS_PASSPORT_NO", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PASSPORT_NO", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PASSPORT_NO");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_BUSINESS_SOURCE", "");
                    //clearValue("Q_PROPOSER_DETAILS_BUSINESS_SOURCE", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_BUSINESS_SOURCE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_BUSINESS_SOURCE");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_BUSINESS_SOURCE", "");
                    //clearValue("Q_PROPOSER_DETAILS_TYPE_OF_VISA", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_TYPE_OF_VISA", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_OF_VISA", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_TYPE_OF_VISA");

                    //clearValue("Q_PROPOSER_DETAILS_VISA_VALID_TILL", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_VISA_VALID_TILL", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_VISA_VALID_TILL", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_VISA_VALID_TILL");

                    //clearValue("Q_LIST_PASSPORT_COUNTRIES_PROP", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_VISA_VALID_TILL", "");
                    iFormRef.setStyle("Q_LIST_PASSPORT_COUNTRIES_PROP", "visible", "false");
                    prop.setnonMandatory("Q_LIST_PASSPORT_COUNTRIES_PROP");

                    //clearValue("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE", true);
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE");

                    //clearValue("Q_PROPOSER_DETAILS_COUNTRY_RESIDING_IN", true);
                    //iFormRef.setValue("Q_PROPOSER_DETAILS.COUNTRY_RESIDING_IN", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS.COUNTRY_RESIDING_IN", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS.COUNTRY_RESIDING_IN");

                    //clearValue("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA");

                    //clearValue("Q_LIST_COUNTRIES_FREQ_VISITED_PROP", true);
                    //iFormRef.setValue("Q_LIST_COUNTRIES_FREQ_VISITED_PROP","");
                    iFormRef.setStyle("Q_LIST_COUNTRIES_FREQ_VISITED_PROP", "visible", "false");
                    prop.setnonMandatory("Q_LIST_COUNTRIES_FREQ_VISITED_PROP");

                    //clearValue("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", "");
                    iFormRef.setStyle("Q_LIST_COUNTRY_OF_RESIDENCE_PROP", "visible", "false");
                    prop.setnonMandatory("Q_LIST_COUNTRY_OF_RESIDENCE_PROP");

                    //clearValue("Q_PROPOSER_DETAILS_BIRTH_COUNTRY", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_BIRTH_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_BIRTH_COUNTRY");

                    iFormRef.setValue("Q_PROPOSER_DETAILS_FTIN_PRESENT", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_FTIN_PRESENT", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_FTIN_PRESENT");

                    //table38 is ftin details table	
                    //clearValue("table38", true);
                    iFormRef.setStyle("table38", "visible", "false");
                    prop.setnonMandatory("table38");

                    //clearValue("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID");

                    //clearValue("Q_PROPOSER_DETAILS_ID_NUMBER", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_ID_NUMBER", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ID_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ID_NUMBER");

                    //clearValue("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", true);
                    iFormRef.setValue("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ISSUING_COUNTRY");
                    
                    //DR-31433 MANSI
                    iFormRef.setStyle("Q_LIST_CITIZENSHIP_PROP", "visible", "false");
                    prop.setnonMandatory("Q_LIST_CITIZENSHIP_PROP");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CITY_OF_BIRTH", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_CITY_OF_BIRTH"); 


                } else {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_BUSINESS_SOURCE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_BUSINESS_SOURCE");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PASSPORT_NO", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PASSPORT_NO");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_OF_VISA", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_TYPE_OF_VISA");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_VISA_VALID_TILL", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_VISA_VALID_TILL");
                    //visa valid till date should be future dated, it should not accept current date

                    iFormRef.setStyle("Q_LIST_PASSPORT_COUNTRIES_PROP", "visible", "true");
                    prop.setMandatory("Q_LIST_PASSPORT_COUNTRIES_PROP");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PASSPORT_EXP_DATE");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COUNTRY_RESIDING_IN", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_COUNTRY_RESIDING_IN");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_DATE_OF_LATEST_ENTRY_TO_INDIA");

                    iFormRef.setStyle("Q_LIST_COUNTRIES_FREQ_VISITED_PROP", "visible", "true");
                    prop.setMandatory("Q_LIST_COUNTRIES_FREQ_VISITED_PROP");

                    iFormRef.setStyle("Q_LIST_COUNTRY_OF_RESIDENCE_PROP", "visible", "true");
                    prop.setMandatory("Q_LIST_COUNTRY_OF_RESIDENCE_PROP");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_BIRTH_COUNTRY", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_BIRTH_COUNTRY");

                    if (iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString().equalsIgnoreCase("ProposerInsured") || iFormRef.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString().equalsIgnoreCase("Proposer"))
                    {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS");
                    }

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_COUNTRY_OF_RESIDENCE");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_FTIN_PRESENT", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_FTIN_PRESENT");
                    //setValues({"Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN":"NA"},true);      ///aanchal//30sept
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION");
                    //setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                    //clearValue("Q_PROPOSER_DETAILS_PAN_NUMBER_DUP", "false");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PAN_ACK_NO", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PAN_ACK_NO");
                    //setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER_DUP", "visible", "false");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "disable", "true");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ISSUING_COUNTRY");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ID_NUMBER");
                    
                    //dr-31433 mansi
                    if(value.equalsIgnoreCase("NRI") || value.equalsIgnoreCase("PIO") || value.equalsIgnoreCase("FN")){
                        iFormRef.setStyle("Q_LIST_CITIZENSHIP_PROP", "visible", "true");
                        prop.setMandatory("Q_LIST_CITIZENSHIP_PROP");

                        iFormRef.setStyle("Q_PROPOSER_DETAILS_CITY_OF_BIRTH", "visible", "true");
                        prop.setMandatory("Q_PROPOSER_DETAILS_CITY_OF_BIRTH"); 
                    }
                          
                }
              } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_FTIN_PRESENT")) {
                if (value.equalsIgnoreCase("Y")) {

                    iFormRef.setStyle("table38", "visible", "true");
                    prop.setMandatory("table38");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", "");
                    //clearValue("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_ID_NUMBER", "");
                    //clearValue("Q_PROPOSER_DETAILS_ID_NUMBER", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ID_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ID_NUMBER");
                    iFormRef.setValue("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", "");
                    //clearValue("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", true);
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ISSUING_COUNTRY");
                } else if (value.equalsIgnoreCase("N")) {

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_TYPE_FOREIGN_ID");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ID_NUMBER", "visible", "true");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ID_NUMBER");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ISSUING_COUNTRY", "visible", "true");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ISSUING_COUNTRY");   //dr-7235
                    //clearValue("table38", true);
                    iFormRef.setStyle("table38", "visible", "false");
                    prop.setnonMandatory("table38");
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_OPT_FOR_POLICY")) {

                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE");
         
                    

                } else {

                  /////  iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE", "");
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_EIA_NUMBER", "");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_REPOSITORY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_REPOSITORY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_REPOSITORY");
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_NUMBER");

                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_EIA_NO_AVAILABLE")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_NUMBER", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_EIA_NUMBER");
                    
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME", "visible", "true");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME");
                    
                    
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME", "disable", "true");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_REPOSITORY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_REPOSITORY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_REPOSITORY");

                } else if (value.equalsIgnoreCase("N")) {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_EIA_NUMBER", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_NUMBER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_NUMBER");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_REPOSITORY", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_REPOSITORY");
                     iFormRef.setStyle("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_EIA_REPOSITORY_NAME");

                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_POLITICALLY_EXPOSED")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PERON_PEP", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PERON_PEP");

                    iFormRef.setStyle("label97", "visible", "true");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_POLITICAL_EXP", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_POLITICAL_EXP");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_AFFILIATION_POLITICAL_PARTY", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_AFFILIATION_POLITICAL_PARTY");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PORTFLIO_HANDLED", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PORTFLIO_HANDLED");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PARTY_IN_POWER", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PARTY_IN_POWER");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_POSTED", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PEP_POSTED");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_INCOME_SOURCES", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PEP_INCOME_SOURCES");

                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_CONVICTED", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PEP_CONVICTED");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_PERON_PEP", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PERON_PEP", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PERON_PEP");

                    iFormRef.setStyle("label97", "visible", "false");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_POLITICAL_EXP", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_POLITICAL_EXP", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_POLITICAL_EXP");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_AFFILIATION_POLITICAL_PARTY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_AFFILIATION_POLITICAL_PARTY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_AFFILIATION_POLITICAL_PARTY");

                   // iFormRef.setValue("Q_PROPOSER_DETAILS_PORTFLIO_HANDLED", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PORTFLIO_HANDLED", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PORTFLIO_HANDLED");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY");

                   // iFormRef.setValue("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE");

                   // iFormRef.setValue(
                     //       "Q_PROPOSER_DETAILS_PARTY_IN_POWER", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PARTY_IN_POWER", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PARTY_IN_POWER");

                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_PEP_POSTED", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_POSTED", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_POSTED");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE");

                    iFormRef.setValue("Q_PROPOSER_DETAILS_PEP_INCOME_SOURCES", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_INCOME_SOURCES", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_INCOME_SOURCES");

                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_PEP_CONVICTED", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_CONVICTED", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_CONVICTED");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_CONVICTION_DETAILS", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CONVICTION_DETAILS", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_CONVICTION_DETAILS");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PERON_PEP")) {
                if (iFormRef.getValue("Q_PROPOSER_DETAILS_PERON_PEP").toString().equalsIgnoreCase("FM")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_SPECIFY", "visible", "true");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_SPECIFY");
                } else {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_SPECIFY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_SPECIFY");
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_ROLE_POLITICAL_PARTY")) {
                if (value.equalsIgnoreCase("OTH")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_SPECIFY_POLITICAL_ROLE");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PEP_POSTED")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PEP_SPECIFY_OFFICE");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PEP_CONVICTED")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CONVICTION_DETAILS", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_CONVICTION_DETAILS");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_CONVICTION_DETAILS", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CONVICTION_DETAILS", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_CONVICTION_DETAILS");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_COUNTRY")) {
                if (value.equalsIgnoreCase("Other")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COUNTRY_SPECIFY", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_COUNTRY_SPECIFY");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_COUNTRY_SPECIFY", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_COUNTRY_SPECIFY", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_COUNTRY_SPECIFY");
                }
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_CITY_DISTRICT_DUP")) {
                iFormRef.setValue(
                        "Q_PROPOSER_DETAILS_CITY_DISTRICT", iFormRef.getValue("Q_PROPOSER_DETAILS_CITY_DISTRICT_DUP").toString());
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_STATE_UT_DUP")) {
                iFormRef.setValue(
                        "Q_PROPOSER_DETAILS_STATE_UT", iFormRef.getValue("Q_PROPOSER_DETAILS_STATE_UT_DUP").toString());
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PERM_CITY_DISTRICT_DUP")) {
                iFormRef.setValue(
                        "Q_PROPOSER_DETAILS_PERM_CITY_DISTRICT", iFormRef.getValue("Q_PROPOSER_DETAILS_PERM_CITY_DISTRICT_DUP").toString());
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PERM_STATE_UT_DUP")) {
                iFormRef.setValue(
                        "Q_PROPOSER_DETAILS_PERM_STATE_UT", iFormRef.getValue("Q_PROPOSER_DETAILS_PERM_STATE_UT_DUP").toString());
            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_INDUSTRY_TYPE")) {

                if (value.equalsIgnoreCase("AVN")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATURE_OF_DUTIES", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_NATURE_OF_DUTIES");
                } else {
                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_NATURE_OF_DUTIES", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_NATURE_OF_DUTIES");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATURE_OF_DUTIES", "visible", "false");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_FLYING_ROLE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_FLYING_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_FLYING_ROLE");
                }

                if (value.equalsIgnoreCase("DFN")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CURRENTLY_POSTED", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATURE_OF_JOB", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_CURRENTLY_POSTED");
                    prop.setMandatory("Q_PROPOSER_DETAILS_NATURE_OF_JOB");
                } else {
                   // iFormRef.setValue(
                     //       "Q_PROPOSER_DETAILS_CURRENTLY_POSTED", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_CURRENTLY_POSTED");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_CURRENTLY_POSTED", "visible", "false");

                    //iFormRef.setValue("Q_PROPOSER_DETAILS_NATURE_OF_JOB", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_NATURE_OF_JOB", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_NATURE_OF_JOB");
                }

                if (value.equalsIgnoreCase("DIV")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER");
                } else {
                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER", "visible", "false");

                    iFormRef.setValue("Q_PROPOSER_DETAILS_DIVE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DIVE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DIVE");

                }

                if (value.equalsIgnoreCase("MEM")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_OF_VESSEL", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_TYPE_OF_VESSEL");
                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_TYPE_OF_VESSEL", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_TYPE_OF_VESSEL");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_TYPE_OF_VESSEL", "visible", "false");
                }

                if (value.equalsIgnoreCase("MIN")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ILLNESS_OCCUPATION", "visible", "true");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ROLE_INVOLVE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_ROLE_INVOLVE");
                    prop.setMandatory("Q_PROPOSER_DETAILS_ILLNESS_OCCUPATION");
                } else {
                   // iFormRef.setValue(
                     //       "Q_PROPOSER_DETAILS_ROLE_INVOLVE", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ROLE_INVOLVE");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ROLE_INVOLVE", "visible", "false");

                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_ILLNESS_OCCUPATION", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_ILLNESS_OCCUPATION", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_ILLNESS_OCCUPATION");

                }

                if (value.equalsIgnoreCase("ONG")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_OFFSHORE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_OFFSHORE");
                } else {
                    //iFormRef.setValue(
                      //      "Q_PROPOSER_DETAILS_OFFSHORE", "");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_OFFSHORE");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_OFFSHORE", "visible", "false");

                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_NATURE_OF_DUTIES")) {
                if (value.equalsIgnoreCase("FR")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_FLYING_ROLE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_FLYING_ROLE");

                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_FLYING_ROLE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_FLYING_ROLE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_FLYING_ROLE");
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_PROFESSIONAL_DIVER")) {
                if (value.equalsIgnoreCase("Y")) {
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DIVE", "visible", "true");
                    prop.setMandatory("Q_PROPOSER_DETAILS_DIVE");

                } else {
                    //iFormRef.setValue("Q_PROPOSER_DETAILS_DIVE", "");
                    iFormRef.setStyle("Q_PROPOSER_DETAILS_DIVE", "visible", "false");
                    prop.setnonMandatory("Q_PROPOSER_DETAILS_DIVE");
                }

            } else if (id.equalsIgnoreCase("Q_PROPOSER_DETAILS_MARITAL_STATUS")) {
                String life_stage = iFormRef.getValue("Q_POLICY_DETAILS_LIFE_STAGE").toString();//SNG MRD                                                                                                                                                 	
                String marital_status = value;
                if (marital_status.equalsIgnoreCase("SNG") && value.equalsIgnoreCase("MRD")) {
                    if (life_stage.equalsIgnoreCase("Single")) {
                        iFormRef.setValue(
                                "Q_POLICY_DETAILS_LIFE_STAGE", "Married with no children");

                    }
                    if (life_stage.equalsIgnoreCase("Married with no children")) {

                    }
                    if (life_stage.equalsIgnoreCase("Single with children")) {
                        iFormRef.setValue(
                                "Q_POLICY_DETAILS_LIFE_STAGE", "Married with children");

                    }
                    if (life_stage.equalsIgnoreCase("Married with children")) {

                    }
                }

                if (marital_status.equalsIgnoreCase("MRD") && value.equalsIgnoreCase("SNG")) {
                    if (life_stage.equalsIgnoreCase("Single")) {

                    }
                    if (life_stage.equalsIgnoreCase("Married with no children")) {
                        iFormRef.setValue(
                                "Q_POLICY_DETAILS_LIFE_STAGE", "Single");

                    }
                    if (life_stage.equalsIgnoreCase("Single with children")) {

                    }
                    if (life_stage.equalsIgnoreCase("Married with children")) {
                        iFormRef.setValue(
                                "Q_POLICY_DETAILS_LIFE_STAGE", "Single with children");

                    }
                }

            }
        } catch (Exception e) {
            System.out.println("Error in ProposerDetails - " + controlName + " " + e.toString());
        }

    }

    private String uploadDocToOD(String winame, String proposalNumber, String base64String, IFormReference iFormRef, String sessionId) {
        String docIndex = "", opXML_OD = "";
//        String query = "SELECT itemindex FROM NG_NB_EXT_TABLE(nolock) WHERE WI_NAME = '" + winame + "' ";
        //List dbData = iFormRef.getDataFromDB(query);

//        if (!dbData.isEmpty()) {
//            String itemindex = "";
//            for (int i = 0; i < dbData.size(); i++) {
//                itemindex = (String) ((List) dbData.get(i)).get(0);
//            }
//        }
        String url = "http://127.0.0.1:8080/MaxlifeService/rest/Services/addDocument";
        String method = "POST";
        String inputXML = "";
        String WFUploadWorkItem_XML = "";
        HashMap< String, String> hm = new HashMap<>();
        hm.put("Content-Type", "application/json");
        WFUploadWorkItem_XML = "{\n"
                + "	\"ProposalNumber\":\"" + proposalNumber + "\",\n"
                + "	\"SessionID\":\"" + sessionId + "\",\n"
                + "	\"Documents\":[{\n"
                + "					\"DocumentName\":\"Gtration.pdf\",	\n"
                + "					\"DocumentCategory\":\"Illustrations\",\n"
                + "					\"DocumentDataBase64\":\"" + base64String + "\"\n"
                + "				}]\n"
                + "	\n"
                + "}";
        String docAddResultJSON = callRestAPI(url, method, WFUploadWorkItem_XML, hm);

        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(docAddResultJSON);

            String soapenvEnvelope = json.get("soapenv:Envelope").toString();
            JSONObject json2 = (JSONObject) jsonParser.parse(soapenvEnvelope);

            String soapenvBody = json2.get("soapenv:Body").toString();
            JSONObject json3 = (JSONObject) jsonParser.parse(soapenvBody);

            String ns1NGOAddDocumentResponseBDO = json3.get("ns1:NGOAddDocumentResponseBDO").toString();
            JSONObject json4 = (JSONObject) jsonParser.parse(ns1NGOAddDocumentResponseBDO);

            String ns1NGOGetDocListDocDataBDO = json4.get("ns1:NGOGetDocListDocDataBDO").toString();
            JSONObject json5 = (JSONObject) jsonParser.parse(ns1NGOGetDocListDocDataBDO);

            docIndex = json5.get("documentIndex").toString();

            //creating OD op XML        
            opXML_OD = createODxml(json5);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return docIndex + "~~" + opXML_OD;
    }

    private String uploadDocToOD2(String filePath, String sessionId, String folderIndex, IFormReference iFormRef, String volId) throws IOException {
        String docIndex = "", opXML_OD = "";
        String cabName = iFormRef.getCabinetName();

        UploadToOmniDocs utOD = new UploadToOmniDocs();
        String docAddResultJSON = utOD.UploadToOmniDocsRest(cabName, folderIndex, filePath, sessionId, volId);
        try {
            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(docAddResultJSON);
            String soapenvEnvelope = json.get("NGOAddDocumentResponseBDO").toString();
            JSONObject json2 = (JSONObject) jsonParser.parse(soapenvEnvelope);
            String soapenvBody = json2.get("NGOGetDocListDocDataBDO").toString();
            JSONObject json3 = (JSONObject) jsonParser.parse(soapenvBody);
//            String ns1NGOAddDocumentResponseBDO = json3.get("ns1:NGOAddDocumentResponseBDO").toString();	
//            JSONObject json4 = (JSONObject) jsonParser.parse(ns1NGOAddDocumentResponseBDO);	
//	
//            String ns1NGOGetDocListDocDataBDO = json4.get("ns1:NGOGetDocListDocDataBDO").toString();	
//            JSONObject json5 = (JSONObject) jsonParser.parse(ns1NGOGetDocListDocDataBDO);	
            docIndex = json3.get("documentIndex").toString();

            //creating OD op XML        	
            opXML_OD = createODxml(json3);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return docIndex + "~~" + opXML_OD;
    }

    public String callRestAPI(String url, String method, String WFUploadWorkItem_XML, HashMap< String, String> request) {
        URL urlForGetRequest;
        //String data = "";
        String readLine = null;
        String returnJSON = "", returnVal = null;
        HttpURLConnection conection;
        try {
            urlForGetRequest = new URL(url);
            conection = (HttpURLConnection) urlForGetRequest.openConnection();
            conection.setRequestMethod(method);

            //System.out.println(url);
            //System.out.println(method);
            for (String i : request.keySet()) {
                conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
            }
            //conection.setRequestProperty("Authorization", "Basic YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp"); // set userId its a sample here
            //conection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); // set userId its a sample here

            conection.setDoOutput(true);

            if (method.equalsIgnoreCase("POST")) {

                String data = WFUploadWorkItem_XML;
                OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
                obj.write(data);
                obj.close();

            }
            /*else if(method.equalsIgnoreCase("GET"))
             {
             apiCount++;
             logger.info("API Count " + apiCount);
             }*/

            int responseCode = conection.getResponseCode();
            System.out.println(responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(conection.getInputStream()));
                StringBuffer response = new StringBuffer();
                while ((readLine = in.readLine()) != null) {
                    response.append(readLine);
                }
                in.close();

                returnJSON = response.toString();
                //System.out.println("JSON String Result " + response.toString());
                returnVal = returnJSON;
            } else {

                //Ariba disconnectUser = new Ariba();
                //disconnectUser.disconnectUser();
                returnVal = "ERROR";
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return returnVal;
    }
    

    /*@Override
    public String generateHTML(EControl ec) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
*/
    @Override
    public String introduceWorkItemInWorkFlow(IFormReference ifr, HttpServletRequest hsr, HttpServletResponse hsr1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String introduceWorkItemInWorkFlow(IFormReference ifr, HttpServletRequest hsr, HttpServletResponse hsr1, WorkdeskModel wm) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateDataInWidget(IFormReference ifr, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
/*
    @Override
    public String validateDocumentConfiguration(String string, String string1, File file, Locale locale) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
*/
    @Override
    public void postHookOnDocumentUpload(IFormReference ifr, String string, String string1, File file, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean introduceWorkItemInSpecificProcess(IFormReference ifr, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String onChangeEventServerSide(IFormReference ifr, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     private String getLableNamefromId(String labelValue, String masterTableName, String col_lab, String col_val,IFormReference ifr) {
        String labelName = "";
        if (!labelValue.equalsIgnoreCase("")) {
            String query = "SELECT " + col_lab + " FROM " + masterTableName + " (NOLOCK) WHERE " + col_val + " = '" + labelValue + "'";
            List queryResult = (List) ifr.getDataFromDB(query);;
            if (queryResult != null) {
                labelName = (String) ((List) queryResult.get(0)).get(0);
            }
        }
        return labelName;
    }

    @Override
    public String getWidgetNameToBeShown(IFormReference ifr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String generateHTML(IFormReference ifr, EControl ec) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String postHookExportToPDF(IFormReference ifr, File file) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String validateDocumentConfiguration(IFormReference ifr, String string, String string1, File file, Locale locale) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void postHookOnDocumentOperations(IFormReference ifr, String string, String string1, int i, String string2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  

}
