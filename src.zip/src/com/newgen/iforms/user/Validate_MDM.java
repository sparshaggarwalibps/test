/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import static com.newgen.iforms.user.DolphinUtil.CalculateYears;
import static com.newgen.iforms.user.DolphinUtil.getProductdating;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;



/**
 *
 * @author prakhar.saxena
 */
public class Validate_MDM {   

    String objVal;
    String objID;
    String planCode, Channel, subChannel,secPlanCode,productSolution;
    IFormReference ifr;
    String changeVal;
    String whereClause;
    DecimalFormat df = new DecimalFormat("#");

    //Constructors
    public Validate_MDM(String objID, String objVal, IFormReference iFormRef, String planCode, String Channel, String subChannel,String secPlanCode, String productSolution) {
        this.objVal = objVal;
        this.objID = objID;
        this.ifr = iFormRef;
        this.planCode = planCode;
        this.Channel = Channel;
        this.secPlanCode=secPlanCode;
        this.productSolution=productSolution;
        
        if(subChannel.equalsIgnoreCase("Y") && Channel.equals("A"))
            this.subChannel = "Defence";
      else if (Channel.equalsIgnoreCase("BY") && subChannel.equalsIgnoreCase("Y"))
        {
            this.subChannel = "TeleSale";
        }
        else
            this.subChannel = getChannelDescFromVal(Channel);
        
        //this.subChannel="Agency";
    }

    public Validate_MDM(IFormReference iFormRef, String planCode, String Channel, String subChannel,String secPlanCode, String Product_Solution) {
        this.ifr = iFormRef;
        this.planCode = planCode;
        this.Channel = Channel;
         this.secPlanCode = secPlanCode;
        this.productSolution = Product_Solution;
       if(subChannel.equalsIgnoreCase("Y") && Channel.equalsIgnoreCase("A"))
            this.subChannel = "Defence";
      else if (Channel.equalsIgnoreCase("BY") && subChannel.equalsIgnoreCase("Y"))
        {
            this.subChannel = "TeleSale";
        }
        else
            this.subChannel = getChannelDescFromVal(Channel);
        //this.subChannel="Agency";
    }
    
    public Validate_MDM(IFormReference iFormRef, String changeVal){
        this.ifr = iFormRef;
        this.changeVal = changeVal;
    }

    private Validate_MDM() {
    
    }

    //Methods
    
    public void setObjValue(String val){
        this.objVal = val;
    }
    String getErrorMessage(String controlID) throws ParseException {
        String message = "";
        if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_EFFECTIVE_DATE") || controlID.equalsIgnoreCase("Q_CUSTOMER_INFORMATION_CUSTOMER_SIGN_DATE")
                || controlID.equalsIgnoreCase("Q_DECISION_SECTION_UW_EDC")) {
            message = validate_EffectiveDate(controlID);
        } else if (controlID.equalsIgnoreCase("Q_L2BI_DETAILS_DOB") || controlID.equalsIgnoreCase("Q_PROPOSER_DETAILS_DATE_OF_BIRTH")
                || controlID.equalsIgnoreCase("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP")|| controlID.equalsIgnoreCase("Q_L2BI_DETAILS_DOB_DUP")) {
            message = validate_IssueAge("");
            message="";
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_SUM_ASSURED")) {
            message = validate_SumAssured();
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_SUM_ASSURED_UW")) {
            message = validate_SumAssured_UW();
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_COVERAGE_TERM")) {
            message = validate_CoverageTerm();
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_MODAL_PREMIUM")) {
            message = validate_ModalPremium();
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_MODAL_PREMIUM_UW")) {
            message = validate_ModalPremium_UW();
        } else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM")) {
            message = validate_PremiumPayment();
        }
        else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_Premium_Break_1")) {
            message = validate_PremiumBreak1();
        }
        else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_Premium_Break_2")) {
            message = validate_PremiumBreak2();
        }
        else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_MATURITY_AGE")) {
            message = validate_MaturtityAGE();
        }
        else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_DEATH_BENEFIT_MULTIPLE")) {
            message = validate_DeathBenefitMultiple();
        }
        else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_INCOME_PERIOD")) {
            message = validate_IncomePeriod();
        }
         else if (controlID.equalsIgnoreCase("Q_COVERAGE_DETAILS_INCOME_PERIOD_PPT")) {
            message = validate_IncomePeriodPPT();
        }
        return message;
    }
    
    public String getAllErrorMessagesJSON() throws ParseException{
        JSONObject responseJSON = new JSONObject();
        //validating effective/customer date
        String productDating = getProductdating(ifr);
        if(productDating.equals("CD")){
             this.objVal = (String) ifr.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
             responseJSON.put("effectiveDateMsg", validate_EffectiveDate("Q_CUSTOMER_INFORMATION_CUSTOMER_SIGN_DATE"));
        }
        else//ED
        {
            this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
            responseJSON.put("effectiveDateMsg", validate_EffectiveDate("Q_COVERAGE_DETAILS_EFFECTIVE_DATE"));
        }
        //for proposer/insured DOB
        //form 1 case
        if(ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")){
            this.objVal = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
            responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        }
        else if(ifr.getControlValue("PLAN_TYPE").toString().equals("JOINT"))
        {
        	   this.objVal = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                 responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        }
        else if(ifr.getControlValue("PLAN_TYPE").toString().equals("ANNUITY"))
        {
        	   this.objVal = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                 responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        }
        else
        	
        {
            this.objVal = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
            responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        }
        this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MATURITY_AGE");
        responseJSON.put("MaturityAge", validate_MaturtityAGE());
        this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SUM_ASSURED");
        responseJSON.put("sumAssuredMsg", validate_SumAssured());
        this.objVal =(String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
        responseJSON.put("coverageTermMsg", validate_CoverageTerm());
        //this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
        //responseJSON.put("sumAssuredMsg", validate_ModalPremium());
        this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
        responseJSON.put("premiumPaymentTermMsg", validate_PremiumPayment());
         this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.Premium_Break_1");
        responseJSON.put("PremiumBreakOption1", validate_PremiumBreak1()); //added by aaanchal
         this.objVal = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.Premium_Break_2");
        responseJSON.put("PremiumBreakOption2", validate_PremiumBreak2());
          
        return responseJSON.toJSONString();
    }

    public String getAllErrorMessagesJSON_UW() throws ParseException{
        JSONObject responseJSON = new JSONObject();
        
        JSONArray coverageDetailsArray = new JSONArray();
        coverageDetailsArray = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");
        
        //getting fist row values only
        if (coverageDetailsArray.size() > 0) {
            JSONObject jsonObj = new JSONObject();
            jsonObj = (JSONObject) coverageDetailsArray.get(0);

            this.objVal = (String) jsonObj.getOrDefault("Revised Coverage Term", "");
            responseJSON.put("coverageTermMsg", validate_CoverageTerm());

            this.objVal = (String) jsonObj.getOrDefault("Revised Premium Payment Term", "");
            responseJSON.put("premiumPaymentTermMsg", validate_PremiumPayment());
            
            this.objVal = (String) jsonObj.getOrDefault("Approved Sum Assured", "");
            responseJSON.put("sumAssuredMsg", validate_SumAssured_UW());
            
            responseJSON.put("coverageMultipleMsg", "");

        }
        return responseJSON.toJSONString();
    }

    
    private String validate_EffectiveDate(String controlId) throws ParseException {
        String result = "";

        String effectiveDate = objVal;
        String planEffectiveDate = null, channelEffectiveDate = null, planExpiryDate = null;
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
          query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' ;";
		  }		  
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
			 query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' ;";  
		  }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
			 query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' ;";  
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
			 query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' ;";  
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
                             secPlanCode= (String) ifr.getControlValue("PLAN_NAME_COMBO");
                             productSolution=(String) ifr.getControlValue("PRODUCT_SOLUTION");
        			 query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"' ;";  
        		  }
        List dateFromMDM = getValFromQuery(query);
        if (dateFromMDM != null) {
            planEffectiveDate = (String) ((List) dateFromMDM.get(0)).get(0);
            channelEffectiveDate = (String) ((List) dateFromMDM.get(0)).get(1);
            planExpiryDate = (String) ((List) dateFromMDM.get(0)).get(2);
            Date effectiveDateObj=null;
            try{
            effectiveDateObj = new SimpleDateFormat("dd/MM/yyyy").parse(effectiveDate);
            }catch(Exception Ex){
                effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
            }
            Date planEffectiveDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(planEffectiveDate);
            Date channelEffectiveDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(channelEffectiveDate);
            Date planExpiryDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(planExpiryDate);

            if (effectiveDateObj.before(planEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
                result = "Effective/Customer Date Should lie between Plan Effective Date: " + planEffectiveDate + " and Plan Expiry Date: " + planExpiryDate + " Please Correct!";
                if(controlId.equals("Q_COVERAGE_DETAILS_EFFECTIVE_DATE"))
                    ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
                else 
                    if(controlId.equals("Q_DECISION_SECTION_UW_EDC"))
                        ifr.setValue("Q_DECISION_SECTION.UW_EDC", "");
                else
                    ifr.setValue("Q_CUSTOMER_INFORMATIONCUSTOMER_SIGN_DATE", "");
            }
            if (effectiveDateObj.before(channelEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
                result = "Effective/Customer Date Should lie between Channel Effective Date: " + channelEffectiveDate + " and Plan Expiry Date: " + planExpiryDate + " Please Correct!";
                if(controlId.equals("Q_COVERAGE_DETAILS_EFFECTIVE_DATE"))
                    ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
                else
                    ifr.setValue("Q_CUSTOMER_INFORMATIONCUSTOMER_SIGN_DATE", "");
            }
        }
        //Rider Validation
        /*String defenceChannel = (String) ifr.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
        String productType = (String) ifr.getControlValue("PLAN_TYPE");
        RiderBenefit riderObj = new RiderBenefit(ifr, planCode, Channel, defenceChannel, productType);
        result+=riderObj.validateEffectiveDate();*/
		
        return result;
    }

    private String validate_IssueAge(String type) throws ParseException {
        String result = "";
        String ageOfInsured = objVal;
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        String minimunIssueAge = "", maximumIssueAge = "", ageOfInsuredInDays="";//DR-24067 sparsh
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
         query = "SELECT Min_Issue_Age,Max_Issue_Age,Min_Expiry_Age,Max_Expiry_Age FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
			  query = "SELECT Min_Issue_Age,Max_Issue_Age,Min_Expiry_Age,Max_Expiry_Age FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
			  query = "SELECT Min_Issue_Age,Max_Issue_Age,Min_Expiry_Age,Max_Expiry_Age FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
			  query = "SELECT Min_Issue_Age,Max_Issue_Age,Min_Expiry_Age,Max_Expiry_Age FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
        			  query = "SELECT Min_Issue_Age,Max_Issue_Age,ISNULL(Maximum_Term,0),ISNULL(Minimum_Expiry_Age,0),ISNULL(Maximum_Expiry_Age,0)FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		  }
		  
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            minimunIssueAge = (String) ((List) queryResult.get(0)).get(0);
            maximumIssueAge = (String) ((List) queryResult.get(0)).get(1);
            // DR-23153 sparsh
            
            if(minimunIssueAge.contains(".")) {
           try{
          	  String b[]=minimunIssueAge.split("[.]");
          	  minimunIssueAge=b[1];  //91
          	  
          	String eff_date = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
         	 
          	 LocalDate curDate = LocalDate.parse(eff_date); 
          	 // get dob
          	 String dob = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
          	 
          	 LocalDate a=LocalDate.parse(dob);  // insured dob
          	 long abc=ChronoUnit.DAYS.between(a,curDate);  // insured age in days
          	 ageOfInsuredInDays= abc + "";
            
          	if (Integer.parseInt(ageOfInsuredInDays) < Integer.parseInt(minimunIssueAge) || Integer.parseInt(ageOfInsured) > Integer.parseInt(maximumIssueAge)) {
                result = "Age must lie between " + minimunIssueAge + " days and " + maximumIssueAge + ". Please correct!";
          	} 
            }catch(Exception ee) {
            	ee.printStackTrace();
            }
        }
         else if (Integer.parseInt(ageOfInsured) < Integer.parseInt(minimunIssueAge) || Integer.parseInt(ageOfInsured) > Integer.parseInt(maximumIssueAge)) {
                result = "Age must lie between " + minimunIssueAge + " and " + maximumIssueAge + ". Please correct!";
                
//                if(type.equals("getAll")){
//                    if(ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")){
//                        ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH", "");
//                        ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH_DUP", "");
//                    }                        
//                    else{
//                        ifr.setValue("Q_L2BI_DETAILS.DOB", "");
//                        ifr.setValue("Q_L2BI_DETAILS.DOB_DUP", "");
//                    }
//                }
                //return result;
            }
            
            //Coverage term to auto populate when term calc code is B.
            String termCalCode="",planAgeExpiry="";
			 plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String coverageQuery ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
             coverageQuery = "SELECT Plan_Age_Expiry, Term_CalC_Code FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
             coverageQuery = "SELECT Plan_Age_Expiry, Term_CalC_Code FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
             coverageQuery = "SELECT Plan_Age_Expiry, Term_CalC_Code FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
             coverageQuery = "SELECT Plan_Age_Expiry, Term_CalC_Code FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
                     coverageQuery = "SELECT Plan_Age_Expiry, Term_CalC_Code FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		  }
            List coverageQueryResult = getValFromQuery(coverageQuery);
            if (coverageQueryResult != null) {
                planAgeExpiry = (String) ((List) coverageQueryResult.get(0)).get(0);
                termCalCode = (String) ((List) coverageQueryResult.get(0)).get(1);
                if(termCalCode.equalsIgnoreCase("B")){
                    String cTerm="";
                    if (!planAgeExpiry.equalsIgnoreCase("") && !ageOfInsured.equalsIgnoreCase("")) {
                            cTerm =String.valueOf(Integer.parseInt(planAgeExpiry) - Integer.parseInt(ageOfInsured));
                            ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", cTerm);
                    }
                }
            }
            /*
            //Expiry Age check
            String Min_Expiry_Age = "", Max_Expiry_Age = "";
            Min_Expiry_Age = (String) ((List) queryResult.get(0)).get(2);
            Max_Expiry_Age = (String) ((List) queryResult.get(0)).get(3);
            if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("") && !Max_Expiry_Age.equalsIgnoreCase("")) {
                if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer.parseInt(Min_Expiry_Age)
                        || Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer.parseInt(Max_Expiry_Age)) {
                    result = result+"|"+" Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age + ". Please correct!";
//                    if(type.equals("getAll")){
//                        if(ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")){
//                            ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH", "");
//                            ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH_DUP", "");
//                        }                        
//                        else{
//                            ifr.setValue("Q_L2BI_DETAILS.DOB", "");
//                            ifr.setValue("Q_L2BI_DETAILS.DOB_DUP", "");
//                        }
//                    }
                    //return result;
                }
            }
            */
        }
        return result;
    }

    private String validate_SumAssured() {
        String result = "";
        String sumAssured = objVal;
        String minIssueAmount = "", maxIssueAmount = "",interval="";
        double intervalDouble=0;
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
			query = "SELECT Min_Issue_Amount,Max_Issue_Amount,interval FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
			 query = "SELECT Min_Issue_Amount,Max_Issue_Amount,interval FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		  }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
			 query = "SELECT Min_Issue_Amount,Max_Issue_Amount,interval FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
			 query = "SELECT Min_Issue_Amount,Max_Issue_Amount,interval FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
        			 query = "SELECT Min_Issue_Amount,Max_Issue_Amount,interval FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; "; 
        		  }
	if(!(plan_type.equalsIgnoreCase("ANNUITY")))
        {
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            minIssueAmount = (String) ((List) queryResult.get(0)).get(0);
            maxIssueAmount = (String) ((List) queryResult.get(0)).get(1);
        }
        //modified by Aanchal for 28april21
            String ppt=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
	    String coverageTerm=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
            if(plan_type.equalsIgnoreCase("TRAD"))
            {
                query = "SELECT ISNULL(Min_Issue_Amount,0.00),ISNULL(Max_Issue_Amount,0.00) FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "' AND Term = '"+coverageTerm+"' and Premium_Payment_Term='"+ppt+"'; ";
            }
		  
            List queryResult1 = getValFromQuery(query);
     
            if (queryResult1 != null)
            {
            String minSA = (String) ((List) queryResult1.get(0)).get(0);
          String maxSA = (String) ((List) queryResult1.get(0)).get(1);
            if(!(minSA.equalsIgnoreCase("0.00") && maxSA.equalsIgnoreCase("0.00")))
            {
                minIssueAmount=minSA;
		maxIssueAmount=maxSA;
            }
            }
                    //modified by Aanchal for 28april21
        
        //check sum assured interval logic
        interval = (String) ((List) queryResult.get(0)).get(2);
        if(!interval.equals("")){
        intervalDouble = Double.parseDouble(interval);
        }
        
        if (!sumAssured.equalsIgnoreCase("") && !minIssueAmount.equalsIgnoreCase("") && !maxIssueAmount.equalsIgnoreCase("")) {
            if (Double.parseDouble(sumAssured) < Double.parseDouble(minIssueAmount) || Double.parseDouble(sumAssured) > Double.parseDouble(maxIssueAmount)) {
                result = "Sum Insured must lie beween " + df.format(Double.parseDouble(minIssueAmount)) + " and " + df.format(Double.parseDouble(maxIssueAmount)) + ". Please correct!";
                if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.SUM_ASSURED", "");
                return result;
            }
        }
        
        if(intervalDouble!=0 && interval!=null && !interval.equals("") && !sumAssured.equals("")){
            if(!(Double.parseDouble(sumAssured)%intervalDouble==0)){
                result = "Sum assured must be the multiple of "+intervalDouble+". Please correct!";
                 if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.SUM_ASSURED", "");
            }
        }
        }
        return result;
        
    }
    private String validate_SumAssured_UW() {
        String result = "";
        String sumAssured = objVal;
        String minIssueAmount = "", maxIssueAmount = "",interval="";
        double intervalDouble=0;
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
         query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0),ISNULL(interval,0) FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
			query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0),ISNULL(interval,0) FROM NG_NB_MS_JOINT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";  
		  }
                   else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
			query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0),ISNULL(interval,0) FROM NG_NB_MS_ANNUITANT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";  
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
			query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0),ISNULL(interval,0) FROM NG_NB_MS_HEALTH(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";  
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
        			query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0),ISNULL(interval,0) FROM NG_NB_MS_COMBO(NOLOCK) "
                        + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";  
        		  }
        if(!(plan_type.equalsIgnoreCase("ANNUITY"))) 
        {
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            minIssueAmount = (String) ((List) queryResult.get(0)).get(0);
            maxIssueAmount = (String) ((List) queryResult.get(0)).get(1);
        }
         //modified by Aanchal for 28april21
         String coverageTerm="";
         String ppt="";
           {
                JSONArray coverageDetailsArray = new JSONArray();
                coverageDetailsArray = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");

               //getting fist row values only
               if (coverageDetailsArray.size() > 0) {
                   JSONObject jsonObj = new JSONObject();
                   jsonObj = (JSONObject) coverageDetailsArray.get(0);

                    coverageTerm = (String) jsonObj.getOrDefault("Revised Coverage Term", coverageTerm);
                    ppt=(String) jsonObj.getOrDefault("Revised Premium Payment Term", ppt);
               }
          }
            
	   
            if(plan_type.equalsIgnoreCase("TRAD"))
            {
                query = "SELECT ISNULL(UW_Minimum_Issue_Amount,0.00),ISNULL(UW_Maximum_Issue_Amount,0.00) FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "' AND Term = '"+coverageTerm+"' and Premium_Payment_Term='"+ppt+"'; ";
            }
		  
            List queryResult1 = getValFromQuery(query);
     
            if (queryResult1 != null)
            {
            String minSA = (String) ((List) queryResult1.get(0)).get(0);
            String maxSA = (String) ((List) queryResult1.get(0)).get(1);
            if(!(minSA.equalsIgnoreCase("0.00") && maxSA.equalsIgnoreCase("0.00")))
            {
                minIssueAmount=minSA;
		maxIssueAmount=maxSA;
            }
            }
                    //modified by Aanchal for 28april21
        if (!sumAssured.equalsIgnoreCase("") && !minIssueAmount.equalsIgnoreCase("") && !maxIssueAmount.equalsIgnoreCase("")) {
            if (Double.parseDouble(sumAssured) < Double.parseDouble(minIssueAmount) || Double.parseDouble(sumAssured) > Double.parseDouble(maxIssueAmount)) {
                result = "Sum Insured must lie beween " + df.format(Double.parseDouble(minIssueAmount)) + " and " + df.format(Double.parseDouble(maxIssueAmount)) + ". Please correct!";
                 if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.SUM_ASSURED", "");
                return result;
            }
        }
        
        //check sum assured interval logic
        interval = (String) ((List) queryResult.get(0)).get(2);
        if(!interval.equals("")){
        intervalDouble = Double.parseDouble(interval);
        }
        
        if(intervalDouble!=0 && interval!=null && !interval.equals("") && !sumAssured.equals("")){
            if(!(Double.parseDouble(sumAssured)%intervalDouble==0)){
                result = "Sum assured must be the multiple of "+intervalDouble+". Please correct!";
                  if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.SUM_ASSURED", "");
            }
        }
        }
        return result;
    }

    private String validate_CoverageTerm() throws ParseException {
        String result = "";
        String coverageTerm = objVal;
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        if(ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        
       
        if(plan_type.equalsIgnoreCase("JOINT"))  ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
         if(plan_type.equalsIgnoreCase("ANNUITY"))  ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        
        
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        String termCalCode = "", minTerm = "", maxTerm = "", planAgeExpiry = "";
		
		
    	 String query ="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
         query = "SELECT ISNULL(Plan_Age_Expiry,0), Term_CalC_Code, ISNULL(Min_Term,'0'), ISNULL(Max_Term,0),ISNULL(Min_Expiry_Age,0),ISNULL(Max_Expiry_Age,0) "
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  else if(plan_type.equalsIgnoreCase("JOINT"))
		  {
			  query = "SELECT ISNULL(Plan_Age_Expiry,0), Term_CalC_Code, ISNULL(Min_Term,'0'), ISNULL(Max_Term,0),ISNULL(Min_Expiry_Age,0),ISNULL(Max_Expiry_Age,0) "
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   else if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
			  query = "SELECT ISNULL(Plan_Age_Expiry,0), Term_CalC_Code, ISNULL(Min_Term,'0'), ISNULL(Max_Term,0),ISNULL(Min_Expiry_Age,0),ISNULL(Max_Expiry_Age,0),deferment_period_app "
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
			  query = "SELECT ISNULL(Plan_Age_Expiry,0), Term_CalC_Code, ISNULL(Min_Term,'0'), ISNULL(Max_Term,0),ISNULL(Min_Expiry_Age,0),ISNULL(Max_Expiry_Age,0) "
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
        			secPlanCode= (String) ifr.getControlValue("PLAN_NAME_COMBO");
                             productSolution=(String) ifr.getControlValue("PRODUCT_SOLUTION");
                              query = "SELECT ISNULL(Plan_Age_Expiry,0), Term_CalC_Code, ISNULL(Minimum_Term,'0'), ISNULL(Maximum_Term,0),ISNULL(Minimum_Expiry_Age,0),ISNULL(Maximum_Expiry_Age,0) "
                        + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		  }
        List queryResult = getValFromQuery(query);
         String DEFER="";
        String term_calc_desc=(String) ((List) queryResult.get(0)).get(2); //comma separated values
        if (queryResult != null) {
            planAgeExpiry = (String) ((List) queryResult.get(0)).get(0);
            termCalCode = (String) ((List) queryResult.get(0)).get(1);
            minTerm = (String) ((List) queryResult.get(0)).get(2);
            maxTerm = (String) ((List) queryResult.get(0)).get(3);
            if(plan_type.equalsIgnoreCase("ANNUITY"))
                 DEFER=(String) ((List) queryResult.get(0)).get(4);
            else
                DEFER="Y";
            
            if(DEFER.equalsIgnoreCase("Y"))
            {
            if (termCalCode.equalsIgnoreCase("A")) {
                if (!coverageTerm.equalsIgnoreCase("") && !minTerm.equalsIgnoreCase("") && !maxTerm.equalsIgnoreCase("")) {
                    if (Integer.parseInt(coverageTerm) < Integer.parseInt(minTerm) || Integer.parseInt(coverageTerm) > Integer.parseInt(maxTerm)) {
                        
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "Deferment Period must lie between " + minTerm + " and " + maxTerm + ". Please correct!";
                         }
                         else
                        result = "Coverage Term must lie between " + minTerm + " and " + maxTerm + ". Please correct!";
                         if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                            ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
                        return result;
                    }
                }
            } 
            else 
            if(termCalCode.equalsIgnoreCase("B")){
                String cTerm="";
                if (!coverageTerm.equalsIgnoreCase("") && !planAgeExpiry.equalsIgnoreCase("") && !ageOfInsured.equalsIgnoreCase("")) {
                    if (Integer.parseInt(coverageTerm) != Integer.parseInt(planAgeExpiry) - Integer.parseInt(ageOfInsured)) {
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "Deferment Period must be equal to " + (Integer.parseInt(planAgeExpiry) - Integer.parseInt(ageOfInsured));
                         }
                         else
                            result = "Coverage Term must be equal to " + (Integer.parseInt(planAgeExpiry) - Integer.parseInt(ageOfInsured));
                       if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                            ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
                        cTerm =String.valueOf(Integer.parseInt(planAgeExpiry) - Integer.parseInt(ageOfInsured));
                            ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", cTerm);
                        return result;
                    }
                }
            }
            else
            if(termCalCode.equalsIgnoreCase("C")){
                boolean matched = false;
                String[]  term_calc_descArr = term_calc_desc.split(",");
                if(term_calc_descArr.length!=0){
                    for(String code:term_calc_descArr){
                        code = code.trim();
                        if(coverageTerm.equals(code))
                            matched = true;
                    }
                }
                if(!matched)
                {
                      if(plan_type.equalsIgnoreCase("ANNUITY"))
                      {
                          result = "Please enter the valid Deferment Period!: "+term_calc_desc;
                      }
                      else
                        result = "Please enter the valid coverage term!: "+term_calc_desc;
                       if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
                    return result;
                }
            }
            String Min_Expiry_Age = "", Max_Expiry_Age = "";
            String ppt=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
            Min_Expiry_Age = (String) ((List) queryResult.get(0)).get(4);
            Max_Expiry_Age = (String) ((List) queryResult.get(0)).get(5);
            //added By Aanchal for 28April21
            query ="";
            if(plan_type.equalsIgnoreCase("TRAD"))
            {
                query = "SELECT ISNULL(Min_Expiry_Age,0),ISNULL(Max_Expiry_Age,0) FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "' AND Term = '"+coverageTerm+"' and Premium_Payment_Term='"+ppt+"'; ";
            }
		  
            List queryResult1 = getValFromQuery(query);
     
            if (queryResult1 != null)
            {
            String minEA = (String) ((List) queryResult1.get(0)).get(0);
            String maxEA = (String) ((List) queryResult1.get(0)).get(1);
            if(!(minEA.equalsIgnoreCase("0") && maxEA.equalsIgnoreCase("0")))
            {
                Min_Expiry_Age=minEA;
		Max_Expiry_Age=maxEA;
            }
            }
             //added By Aanchal for 28April21
            if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("") && !ageOfInsured.equalsIgnoreCase("") && !Max_Expiry_Age.equalsIgnoreCase("")) {
                if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer.parseInt(Min_Expiry_Age)
                        || Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer.parseInt(Max_Expiry_Age)) {
                    result = result + "|" +"Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age + ". Please correct!";
                     if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
                    return result;
                }
            }

        }
        }
        return result;
    }

    private String validate_ModalPremium() {
        String result = "";
        String ModeofPayment = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");
        String ModalPremium = objVal;
        String query = "";
        List queryResult = null;
        if (ModeofPayment.equalsIgnoreCase("01")) {
					//monthly
			String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
            query = "SELECT Min_Monthly_Premium,Max_Monthly_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Min_Monthly_Premium,Max_Monthly_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Min_Monthly_Premium,Max_Monthly_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Min_Monthly_Premium,Max_Monthly_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT Min_Monthly_Premium,Max_Monthly_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
		
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Monthly_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Monthly_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Monthly_Premium.equalsIgnoreCase("") && !Max_Monthly_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Monthly_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Monthly_Premium)) {
                        
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium)) + " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
                         }
                         else
                            result = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium)) + " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("03")) { //quarterly
			String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
            query = "SELECT Min_Quarterly_Premium,Max_Quarterly_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Min_Quarterly_Premium,Max_Quarterly_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Min_Quarterly_Premium,Max_Quarterly_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Min_Quarterly_Premium,Max_Quarterly_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		if(plan_type.equalsIgnoreCase("COMBO"))
		  {
          query = "SELECT Min_Quarterly_Premium,Max_Quarterly_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                  + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
		  }
            
                  
            
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Quarterly_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Quarterly_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Quarterly_Premium.equalsIgnoreCase("") && !Max_Quarterly_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Quarterly_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Quarterly_Premium)) {
                          if(plan_type.equalsIgnoreCase("ANNUITY"))
                          {
                               result = "Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and " + df.format(Double.parseDouble(Max_Quarterly_Premium));
                          }
                          else
                        result = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and " + df.format(Double.parseDouble(Max_Quarterly_Premium));
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("06")) { //semi annual
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT Min_Semi_Annual_Premium,Max_Semi_Annual_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Min_Semi_Annual_Premium,Max_Semi_Annual_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Min_Semi_Annual_Premium,Max_Semi_Annual_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Min_Semi_Annual_Premium,Max_Semi_Annual_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT Min_Semi_Annual_Premium,Max_Semi_Annual_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
                    
            
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Semi_Annual_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Semi_Annual_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Semi_Annual_Premium.equalsIgnoreCase("") && !Max_Semi_Annual_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Semi_Annual_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Semi_Annual_Premium)) {
                        
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Semi_Annual_Premium));
                       
                         }
                         else
                            result = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Semi_Annual_Premium));
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("12")) { //annual
		
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT Min_Annual_Premium,Max_Annual_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Min_Annual_Premium,Max_Annual_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Min_Annual_Premium,Max_Annual_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Min_Annual_Premium,Max_Annual_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT Min_Annual_Premium,Max_Annual_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
            
            
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Annual_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Annual_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Annual_Premium.equalsIgnoreCase("") && !Max_Annual_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Annual_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Annual_Premium)) {
                        
                        if(plan_type.equalsIgnoreCase("ANNUITY"))
                        {
                             result = "Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Annual_Premium));
                        }
                        else
                        result = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Annual_Premium));
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        }
        return result;
    }

    private String validate_ModalPremium_UW() {
        String result = "";
        String ModeofPayment = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");
        String ModalPremium = objVal;
        String query = "";
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        List queryResult = null;
        if (ModeofPayment.equalsIgnoreCase("01")) { //monthly
		plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
             query = "SELECT UW_Minimum_Monthly_Premium,UW_Maximum_Monthly_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
              query = "SELECT UW_Minimum_Monthly_Premium,UW_Maximum_Monthly_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
              query = "SELECT UW_Minimum_Monthly_Premium,UW_Maximum_Monthly_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  if(plan_type.equalsIgnoreCase("COMBO"))
        		  {
                      query = "SELECT UW_Minimum_Monthly_Premium,UW_Maximum_Monthly_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                            + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		  }
          
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Monthly_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Monthly_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Monthly_Premium.equalsIgnoreCase("") && !Max_Monthly_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Monthly_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Monthly_Premium)) {
                        
                        if(plan_type.equalsIgnoreCase("ANNUITY"))
                        {
                            result = "UW Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium)) + " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
                        }
                        else
                            result = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium)) + " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
                         if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("03")) { //quarterly
			 if(plan_type.equalsIgnoreCase("TRAD"))
		  {
            query = "SELECT UW_Minimum_Quarterly_Premium,UW_Maximum_Quarterly_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
              query = "SELECT UW_Minimum_Quarterly_Premium,UW_Maximum_Quarterly_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
              query = "SELECT UW_Minimum_Quarterly_Premium,UW_Maximum_Quarterly_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
              query = "SELECT UW_Minimum_Quarterly_Premium,UW_Maximum_Quarterly_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                        query = "SELECT UW_Minimum_Quarterly_Premium,UW_Maximum_Quarterly_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
            
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Quarterly_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Quarterly_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Quarterly_Premium.equalsIgnoreCase("") && !Max_Quarterly_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Quarterly_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Quarterly_Premium)) {
                           if(plan_type.equalsIgnoreCase("ANNUITY"))
                           {
                               result = "UW Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and " + df.format(Double.parseDouble(Max_Quarterly_Premium));
                           }
                           else
                            result = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and " + df.format(Double.parseDouble(Max_Quarterly_Premium));
                         if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("06")) { //semi annual
			if(plan_type.equalsIgnoreCase("TRAD"))
		  {
             query = "SELECT UW_Minimum_Semi_Annual_Premium,UW_Maximum_Semi_Annual_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
                query = "SELECT UW_Minimum_Semi_Annual_Premium,UW_Maximum_Semi_Annual_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
                query = "SELECT UW_Minimum_Semi_Annual_Premium,UW_Maximum_Semi_Annual_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
                query = "SELECT UW_Minimum_Semi_Annual_Premium,UW_Maximum_Semi_Annual_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                          query = "SELECT UW_Minimum_Semi_Annual_Premium,UW_Maximum_Semi_Annual_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
            
          
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Semi_Annual_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Semi_Annual_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Semi_Annual_Premium.equalsIgnoreCase("") && !Max_Semi_Annual_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Semi_Annual_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Semi_Annual_Premium)) {
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "UW Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Semi_Annual_Premium));
                       
                         }
                         else
                            result = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Semi_Annual_Premium));
                        if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        } else if (ModeofPayment.equalsIgnoreCase("12")) { //annual
			if(plan_type.equalsIgnoreCase("TRAD"))
		  {
            query = "SELECT UW_Minimum_Annual_Premium,UW_Maximum_Annual_Premium FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
                query = "SELECT UW_Minimum_Annual_Premium,UW_Maximum_Annual_Premium FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
                query = "SELECT UW_Minimum_Annual_Premium,UW_Maximum_Annual_Premium FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
                query = "SELECT UW_Minimum_Annual_Premium,UW_Maximum_Annual_Premium FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                          query = "SELECT UW_Minimum_Annual_Premium,UW_Maximum_Annual_Premium FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                              + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
            
            queryResult = getValFromQuery(query);
            if (queryResult != null) {
                String Min_Annual_Premium = (String) ((List) queryResult.get(0)).get(0);
                String Max_Annual_Premium = (String) ((List) queryResult.get(0)).get(1);

                if (!ModalPremium.equalsIgnoreCase("") && !Min_Annual_Premium.equalsIgnoreCase("") && !Max_Annual_Premium.equalsIgnoreCase("")) {
                    if (Double.parseDouble(ModalPremium) < Double.parseDouble(Min_Annual_Premium) || Double.parseDouble(ModalPremium) > Double.parseDouble(Max_Annual_Premium)) {
                        
                         if(plan_type.equalsIgnoreCase("ANNUITY"))
                         {
                             result = "UW Purchase Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Annual_Premium));
                         }
                         else
                            result = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium)) + " and " + df.format(Double.parseDouble(Max_Annual_Premium));
                        if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
                    }
                }
            }
        }
        return result;
    }
    private String validate_PremiumBreak1() throws ParseException   //added by Aanchal for PremiumBreak
    {
         String result = "",PremiumBreak="",PremiumBreak1="";
      
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");	
        String PremiumBreakOption1 = objVal;	
    	String query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_JOINT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_ANNUITANT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_HEALTH(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_COMBO(NOLOCK) "
                          + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                          + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
           List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            PremiumBreak = (String) ((List) queryResult.get(0)).get(0);
            PremiumBreak1 = (String) ((List) queryResult.get(0)).get(1);
        }
        if(PremiumBreak.equals("Y"))
        {
            int numericCT,numerciPB1,numerciPB_1;
        numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
        numerciPB1=PremiumBreak1.isEmpty()?0:Integer.parseInt(PremiumBreak1);
        numerciPB_1=PremiumBreakOption1.isEmpty()?0:Integer.parseInt(PremiumBreakOption1);
           if(numerciPB_1<numerciPB1 || numerciPB_1>numericCT ) 
           {
               result="1st Premium Break Option must lie between "+numerciPB1+" and"+ numericCT;
               ifr.setValue("Q_COVERAGE_DETAILS_Premium_Break_1","");
           }
        }
        return result;
    }
    
    
    
             private String validate_MaturtityAGE() throws ParseException
    {
         String result = ""; 
         int coverageterm=0;
         String Maturityage = objVal;
      
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        if(ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        
       
        if(plan_type.equalsIgnoreCase("JOINT"))  ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
         if(plan_type.equalsIgnoreCase("ANNUITY"))  ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        
        
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        
          if(plan_type.equalsIgnoreCase("HEALTH"))
          {
              coverageterm=Integer.parseInt(Maturityage)-Integer.parseInt(ageOfInsured);
              ifr.setValue("Q_COVERAGE_DETAILS_COVERAGE_TERM",String.valueOf(coverageterm));
               ifr.setValue("Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM",String.valueOf(coverageterm));
          }
       
        return result;
    }
    
      private String validate_PremiumBreak2() throws ParseException
    {
         String result = "",PremiumBreak="",PremiumBreak2="";
      
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");	
        String PremiumBreakOption2 = objVal;	
    	String query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_JOINT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_ANNUITANT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_HEALTH(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_COMBO(NOLOCK) "
                          + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                          + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
           List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            PremiumBreak = (String) ((List) queryResult.get(0)).get(0);
            PremiumBreak2 = (String) ((List) queryResult.get(0)).get(1);
        }
        if(PremiumBreak.equals("Y"))
        {
            int numericCT,numerciPB2,numerciPB_2;
        numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
        numerciPB2=PremiumBreak2.isEmpty()?0:Integer.parseInt(PremiumBreak2);
        numerciPB_2=PremiumBreakOption2.isEmpty()?0:Integer.parseInt(PremiumBreakOption2);
           if(numerciPB_2<numerciPB2 || numerciPB_2>numericCT ) 
           {
               result="2nd Premium Break Option must lie between "+numerciPB2+" and"+ numericCT;
               ifr.setValue("Q_COVERAGE_DETAILS_Premium_Break_2","");
           }
        }
        return result;
    }
      private String  validate_DeathBenefitMultiple() throws ParseException 
     {
         String result = "";
        String Death_Benefit_Multiple = "";
        String DBM = objVal;
        String ageOfInsured="";
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if(!ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
        
        String query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT Death_Benefit_Multiple FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  
                    List queryResult = getValFromQuery(query);   
                     if (queryResult != null)
                     {
                         
                     
                    Death_Benefit_Multiple = (String) ((List) queryResult.get(0)).get(0);
                    
                     String[] Death_Benefit_MultipleArr = Death_Benefit_Multiple.split(",");
                Boolean match = false;
                for (int i = 0; i < Death_Benefit_MultipleArr.length; i++) {
                    if (DBM.equalsIgnoreCase(Death_Benefit_MultipleArr[i])) {
                        match = true;
                    }
                }
                  if (!match) {
                    result = "Death Benefit Multiple is not valid. Please check.";
                     if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.DEATH_BENEFIT_MULTIPLE", "");
                }
              }
            return result;
     }
     private String  validate_IncomePeriod() throws ParseException 
     {
         String result = "";
        String Income_Period = "";
        String IncomePeriodV = objVal;
        String ageOfInsured="";
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if(!ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        String PremiumPaymentTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
        
        String query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT  INCOME_PERIOD_CD, INCOME_PERIOD_VL FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                  
                  String INCOME_PERIOD_CD="";
                  String INCOME_PERIOD_VL="";
                  
                    List queryResult = getValFromQuery(query);   
                     if (queryResult != null)
                     {
                         
                     INCOME_PERIOD_CD = (String) ((List) queryResult.get(0)).get(0);
                      INCOME_PERIOD_VL = (String) ((List) queryResult.get(0)).get(1);
            
                    
                      if(INCOME_PERIOD_CD.equalsIgnoreCase("A"))
                      {
                          String[] INCOME_PERIOD_VLArr = INCOME_PERIOD_VL.split(",");
                          Boolean match = false;
                          for (int i = 0; i < INCOME_PERIOD_VLArr.length; i++) {
                            if (IncomePeriodV.equalsIgnoreCase(INCOME_PERIOD_VLArr[i])) {
                                match = true;
                            }
                         }
                          if (!match) {
                            result = "Income Period Multiple is not valid. Please check.";
                             if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                            ifr.setValue("Q_COVERAGE_DETAILS.INCOME_PERIOD", "");
                        }
                      }
                      if(INCOME_PERIOD_CD.equalsIgnoreCase("B"))
                      {
                          
                          String INCOME_PERIOD_value = String.valueOf(100-Integer.parseInt(PremiumPaymentTerm) - Integer.parseInt(ageOfInsured));
                         
                          
                             if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                            ifr.setValue("Q_COVERAGE_DETAILS.INCOME_PERIOD", INCOME_PERIOD_value);
                        
                      }
                      
                     
                  
              }
            return result;
     }
    private String  validate_IncomePeriodPPT() throws ParseException 
     {
         String result = "";
        
        String ageOfInsured="";
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if(!ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        String PremiumPaymentTerm = objVal;
        
                     
                      {
                          
                          String INCOME_PERIOD_value = String.valueOf(100-Integer.parseInt(PremiumPaymentTerm) - Integer.parseInt(ageOfInsured));
                         
                          
                             if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                            ifr.setValue("Q_COVERAGE_DETAILS.INCOME_PERIOD", INCOME_PERIOD_value);
                        
                      }
                      
                     
                  
            
            return result;
     }
    
    private String validate_PremiumPayment() throws ParseException {
        String result = "";
        String PPT_Cal_Logic_code = "", Payment_Term = "", Calculation_Value = "",planPayOptionCode="";
        String premiumPayment = objVal;
        String ageOfInsured="";
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-28538 sparsh
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if(!ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured"))
            ageOfInsured = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
        
        if(ifr.getActivityName().equalsIgnoreCase("MANUAL_UW") || ifr.getActivityName().equalsIgnoreCase("Manual_UW_Vendor") || ifr.getActivityName().equalsIgnoreCase("Manual_UW_Supervisor") || ifr.getActivityName().equalsIgnoreCase("UW_HOD") )
        {
         JSONArray coverageDetailsArray = new JSONArray();
        coverageDetailsArray = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");

        //getting fist row values only
        if (coverageDetailsArray.size() > 0) {
            JSONObject jsonObj = new JSONObject();
            jsonObj = (JSONObject) coverageDetailsArray.get(0);

             coverageTerm = (String) jsonObj.getOrDefault("Revised Coverage Term", coverageTerm);
        }
        }

        if(plan_type.equalsIgnoreCase("JOINT") || JointLife.equalsIgnoreCase("Y")) //DR-28538 sparsh   ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if(plan_type.equalsIgnoreCase("ANNUITY"))  ///if plan type JOINT validations to work for prop
            ageOfInsured = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        
        
        if (!ageOfInsured.equalsIgnoreCase("")) {
            ageOfInsured = CalculateYears(ageOfInsured,ifr);
        }
        int numericCT,numerciPPT;
        numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
        numerciPPT=premiumPayment.isEmpty()?0:Integer.parseInt(premiumPayment);
		
    	String query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           query = "SELECT PPT_Cal_Logic_code,Payment_Term,ISNULL(Calculation_Value,0), ISNULL(Plan_Pay_Option_Code,'') FROM NG_NB_MS_TRAD(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            query = "SELECT PPT_Cal_Logic_code,Payment_Term,ISNULL(Calculation_Value,0), ISNULL(Plan_Pay_Option_Code,'') FROM NG_NB_MS_JOINT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            query = "SELECT PPT_Cal_Logic_code,Payment_Term,ISNULL(Calculation_Value,0), ISNULL(Plan_Pay_Option_Code,'') FROM NG_NB_MS_ANNUITANT(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            query = "SELECT PPT_Cal_Logic_code,Payment_Term,ISNULL(Calculation_Value,0), ISNULL(Plan_Pay_Option_Code,'') FROM NG_NB_MS_HEALTH(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  }
                    if(plan_type.equalsIgnoreCase("COMBO"))
          		  {
                      query = "SELECT PPT_Cal_Logic_code,Payment_Term,ISNULL(Calculation_Value,0), ISNULL(Plan_Pay_Option_Code_Desc,'') FROM NG_NB_MS_COMBO(NOLOCK) "
                          + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                          + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
          		  }
        
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            PPT_Cal_Logic_code = (String) ((List) queryResult.get(0)).get(0);
            Payment_Term = (String) ((List) queryResult.get(0)).get(1);
            Calculation_Value = (String) ((List) queryResult.get(0)).get(2);
            planPayOptionCode= (String) ((List) queryResult.get(0)).get(3);
            if (PPT_Cal_Logic_code.equalsIgnoreCase("A")) {
                String[] Payment_TermArr = Payment_Term.split(",");
                Boolean match = false;
                for (int i = 0; i < Payment_TermArr.length; i++) {
                    if (premiumPayment.equalsIgnoreCase(Payment_TermArr[i])) {
                        match = true;
                    }
                }
                if (!match) {
                    result = "Premium Payment Term is not valid. Please check.";
                     if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("B")) {
                if (!premiumPayment.isEmpty() && !ageOfInsured.isEmpty()) {
                    if (Integer.parseInt(premiumPayment) != Integer.parseInt(Calculation_Value) - Integer.parseInt(ageOfInsured)) {
                        result = "Premium Payment Term is not valid. Please check.";
                         if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                    }
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("C")) {
                if (!coverageTerm.equalsIgnoreCase(premiumPayment)) {
                    result = "Premium Payment Term is not valid. Please check.";
                    if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("D")) {
                if (!premiumPayment.equalsIgnoreCase("1")) {
                    result = "Premium Payment Term is not valid. Please check.";
                    if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("E")) {
                if (!premiumPayment.isEmpty() && !coverageTerm.isEmpty() && !Calculation_Value.isEmpty()) {
                    if (Integer.parseInt(premiumPayment) != Integer.parseInt(coverageTerm) - Integer.parseInt(Calculation_Value)) {
                        result = "Premium Payment Term is not valid. Please check.";
                        if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                    }
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("F")) {
				 plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	String ppt_query="";
		  if(plan_type.equalsIgnoreCase("TRAD"))
		  {
           ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' AND Term = "+coverageTerm;
		  }
		  if(plan_type.equalsIgnoreCase("JOINT"))
		  {
            ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' AND Term = "+coverageTerm;
		  }
                   if(plan_type.equalsIgnoreCase("ANNUITY"))
		  {
            ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' AND Term = "+coverageTerm;
		  }
                   if(plan_type.equalsIgnoreCase("HEALTH"))
		  {
            ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "' AND Term = "+coverageTerm;
		  }
                   if(plan_type.equalsIgnoreCase("COMBO"))
         		  {
                     ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                         + " AND Sub_Channel='" + subChannel + "' AND Term = "+coverageTerm;
         		  }
                   
                
                List ppt_queryResult = getValFromQuery(ppt_query);
                boolean matched = false;
                if(ppt_queryResult!=null){
                    for(int i=0;i<ppt_queryResult.size(); i++){
                        if(premiumPayment.equals((String) ((List) ppt_queryResult.get(i)).get(0)))
                            matched = true;
                    }
                }
                if(!matched){
                    result = "Premium Payment Term is not valid. Please check.";
                      if(!ifr.getActivityName().equals("Manual_UW") && !ifr.getActivityName().equals("Manual_UW_Vendor") && !ifr.getActivityName().equals("Manual_UW_Supervisor") && !ifr.getActivityName().equals("UW_HOD"))
                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            }
            
			//Premium Payment Term should not be greater than Coverage Term if Plan_Pay_Option_Code is selected as LTD in MDM. 
            if(!(plan_type.equalsIgnoreCase("ANNUITY")))
            {
            if((planPayOptionCode.equalsIgnoreCase("LTD") || planPayOptionCode.equalsIgnoreCase("PAY60")) && numerciPPT>numericCT){
                result+="-----Premium Payment Term should not be greater than Coverage Term";
            }
            }
            if((plan_type.equalsIgnoreCase("ANNUITY")))
            {
            if((planPayOptionCode.equalsIgnoreCase("LTD") || planPayOptionCode.equalsIgnoreCase("PAY60")) && numericCT<numerciPPT)
            {
               
                query = "SELECT deferment_period_app "
    	                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; "; 
                
                 List queryR1 = getValFromQuery(query);
                 String DEFER = (String) ((List) queryR1.get(0)).get(0);
                  if ((DEFER.equals("Y") && !planCode.equalsIgnoreCase("TIRS") && !planCode.equalsIgnoreCase("TIRJ") && !planCode.equalsIgnoreCase("TDRS") && !planCode.equalsIgnoreCase("TDRJ")
                		 && !planCode.equalsIgnoreCase("TIRSR") && !planCode.equalsIgnoreCase("TIRJR") && !planCode.equalsIgnoreCase("TDRSR") && !planCode.equalsIgnoreCase("TDRJR") && !planCode.equalsIgnoreCase("TIRSMR")
                		 && !planCode.equalsIgnoreCase("TIRSIR") && !planCode.equalsIgnoreCase("TIRSRP") && !planCode.equalsIgnoreCase("TIRJRP") && !planCode.equalsIgnoreCase("TIRSRF") && !planCode.equalsIgnoreCase("TIRJRF")
                		 && !planCode.equalsIgnoreCase("TDRSN") && !planCode.equalsIgnoreCase("TDRJN") && !planCode.equalsIgnoreCase("TDRSNR") && !planCode.equalsIgnoreCase("TDRJNR") && !planCode.equalsIgnoreCase("TIRJF")
                		 && !planCode.equalsIgnoreCase("TIRJFR") && !planCode.equalsIgnoreCase("TIRSG") && !planCode.equalsIgnoreCase("TIRSBR") && !planCode.equalsIgnoreCase("TIGRS") && !planCode.equalsIgnoreCase("TIGRJ")
                                 && !planCode.equalsIgnoreCase("TDGRS") && !planCode.equalsIgnoreCase("TDGRJ") && !planCode.equalsIgnoreCase("TIGRSR") && !planCode.equalsIgnoreCase("TIGRJR") && !planCode.equalsIgnoreCase("TDGRSR")
                                 && !planCode.equalsIgnoreCase("TDGRJR") && !planCode.equalsIgnoreCase("TIGSMR") && !planCode.equalsIgnoreCase("TIGSIR"))) {
                      result+="-----Deferment Period should not be less than Premium Payment Term";
                 }
               
            }
            } //Dr17035
        }
        return result;
    }

    public void populateCombos() {
    	 String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
    	 if(plan_type.equalsIgnoreCase("TRAD"))
    	 {
       query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
               + "Company_Entity,income_frequency, discount,maturity_Age,DEFER_PERIOD,INCOME_STARTYR,PAYOUT_PERIOD,PROPOSITION_OF_ROP,SURVIVAL_BENEFIT_PERIOD"
               + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
               + " AND Sub_Channel='" + subChannel + "'; ";//sparsh DR-28244 26june
    	 }
    	 else if(plan_type.equalsIgnoreCase("JOINT"))
    	 {
    		 query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
    	                + "Company_Entity,income_frequency, discount,maturity_Age,DEFER_PERIOD,INCOME_STARTYR,PAYOUT_PERIOD,PROPOSITION_OF_ROP,SURVIVAL_BENEFIT_PERIOD"
    	                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan //sparsh DR-28244 26june
    	 }
          else if(plan_type.equalsIgnoreCase("ANNUITY"))
    	 {
    		 query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
    	                + "Company_Entity,income_frequency, discount,maturity_Age,DEFER_PERIOD,INCOME_STARTYR,PAYOUT_PERIOD,PROPOSITION_OF_ROP,SURVIVAL_BENEFIT_PERIOD"
    	                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan //sparsh DR-28244 26june
    	 }
         else if(plan_type.equalsIgnoreCase("HEALTH"))
    	 {
    		 query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
    	                + "Company_Entity,income_frequency, discount,Maturity_Age,DEFER_PERIOD,INCOME_STARTYR,PAYOUT_PERIOD,PROPOSITION_OF_ROP,SURVIVAL_BENEFIT_PERIOD"
    	                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan//sparsh DR-28244 26june
    	 }
        else if(plan_type.equalsIgnoreCase("COMBO"))
    	 {
    		 query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Desc,Death_Benefit_Option_Name,Product_Solution,"
    	                + "Company_Entity,income_frequency, discount,maturity_Age,DEFER_PERIOD,INCOME_STARTYR,PAYOUT_PERIOD,PROPOSITION_OF_ROP,SURVIVAL_BENEFIT_PERIOD"
    	                + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";   //aanchal //14jan //sparsh DR-28244 26june
    	 }
      
         
        List queryResult = getValFromQuery(query);
        //String Bonus_Option_Code_Form = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.BONUS_OPTION");
       // if (queryResult != null) {
            //Bonus Option
            populateComboValues(queryResult, 0, "Q_COVERAGE_DETAILS.BONUS_OPTION", "NG_NB_MS_BONUS_OPT", "BONUS_LABEL", "BONUS_VALUE");
            
            //NonForfeitureOption
            populateComboValues(queryResult, 1, "Q_COVERAGE_DETAILS.NON_FORFEITURE", "NG_NB_MS_NON_FORFEITURE", "FORF_LABEL", "FORF_VALUE");

            //Renewal Premium
            populateComboValues(queryResult, 2, "Q_RENEWAL_PREMIUM_DETAILS.RENEWAL_PREM_METHOD", "NG_NB_MS_BILL_TYPE_CODE_DESC", "BILL_TYPE_DESC", "BILL_TYPE_CODE");

            //Billing Mode (Mode of Payment)
            populateComboValues(queryResult, 3, "Q_COVERAGE_DETAILS.MODE_OF_PAY", "NG_NB_MS_MODE_OF_PAYMENT", "LABEL", "VALUE");

            //Death Benefit 
            populateComboValues(queryResult, 4, "Q_COVERAGE_DETAILS.DEATH_BENEFIT", "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_LABEL", "BENEFIT_VALUE");

            //Product Solution
            populateComboValues(queryResult, 5, "Q_POLICY_DETAILS.PRODUCT_SOLUTION", "NG_NB_MS_PRODUCT_SOLUTION", "SOLUTION_LABEL", "SOLUTION_VALUE");

            //Client Type
            populateComboValues(queryResult, 6, "Q_PROPOSER_DETAILS.CLIENT_TYPE", "NG_NB_MS_CLIENT_TYPE", "TYPE_LABEL", "TYPE_VALUE");
            
            //Income Frequency
            populateComboValues(queryResult, 7, "Q_COVERAGE_DETAILS.INCOME_FREQUENCY", "NG_NB_MS_MODE_OF_PAYMENT", "LABEL", "VALUE");
            
            //Discount
            populateComboValues(queryResult, 8, "Q_COVERAGE_DETAILS.EMP_DISCOUNT", "NG_NB_MS_DISCOUNT_OPTION_CODE_DESC", "Discount_Option_Desc", "Discount_Option_Code");
            populateComboValues(queryResult, 8, "Q_DECISION_SECTION_UW_DISCOUNT_ANY", "NG_NB_MS_DISCOUNT_OPTION_CODE_DESC", "Discount_Option_Desc", "Discount_Option_Code");
            
            if(plan_type.equalsIgnoreCase("HEALTH"))
            {
                populateComboValues(queryResult, 9, "Q_COVERAGE_DETAILS.MATURITY_AGE", "NG_NB_MS_MATURITYAGE", "AGE", "AGE");
            }
            
            populateComboValues(queryResult, 10, "Q_COVERAGE_DETAILS.DEFER_PERIOD", "NG_NB_MS_DEFERPERIOD", "PERIOD", "PERIOD");
            
            
             populateComboValues(queryResult, 11, "Q_COVERAGE_DETAILS.INCOME_STARTYEAR", "NG_NB_MS_INCOMESTARTYEAR", "VALUE", "VALUE");
                
            //payout period
            populateComboValues(queryResult, 12, "Q_COVERAGE_DETAILS.PAYOUT_PERIOD", "NG_NB_MS_PAYOUT_PERIOD", "VALUE", "VALUE"); //DR-28244 sparsh 26June
            
            //Proposition Of ROP
            populateComboValues(queryResult, 13, "Q_COVERAGE_DETAILS.PROPOSITION_OF_ROP", "NG_NB_MS_PROPOSITION_OF_ROP", "LABEL", "VALUE"); 
            
            //Survival Benefit Period
            populateComboValues(queryResult, 14, "Q_COVERAGE_DETAILS.SURVIVAL_BENEFIT_PERIOD", "NG_NB_MS_SURVIVAL_BENEFIT_PERIOD", "VALUE", "VALUE"); //DR-40123 Nikita
         
           
            String q1="SELECT ',' + CODE FROM NG_NB_MS_VARIANT where PLAN_NAME='"+planCode+"' ORDER BY (LABEL) FOR XML PATH('')";
              List queryResult1 = getValFromQuery(q1);
            populateComboValues(queryResult1, 0, "Q_COVERAGE_DETAILS.VARIANT", "NG_NB_MS_VARIANT", "LABEL", "CODE");
        //}
    }

    public void hideFields() {
    	 String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
    	 if(plan_type.equalsIgnoreCase("TRAD"))
    	 {
       query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit, uw_edc, MATURITY_AGE,Premium_break,Death_Benefit_Option_Code,discount,Income_Frequency,Death_Benefit_Multiple,DEFER_PERIOD,INCOME_PERIOD_CD,INCOME_STARTYR,DESIRE_DATE,PREM_OFFSET,SMOKER_CLASS_INSURED,ACCRUAL_OPTION,ISNULL(PAYOUT_PERIOD,''),WELLNESS_DISCOUNT, ISNULL(PROPOSITION_OF_ROP,''),ISNULL(EARLY_ROP,''),ISNULL(EARLY_ROP_MILESTONE,''),ISNULL(GUARANTEED_ANNUITY_PERIOD,''),ISNULL(INC_ANNUITY_PERCENTAGE,''),ISNULL(PROPOSITION_OF_ANNUITY,''),ISNULL(DEFERMENT_PERIOD,''),FAMILY_INCOME_OPTION,QROPS,ISNULL(SURVIVAL_BENEFIT_PERIOD,'')"
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
    	 }
    	 else if(plan_type.equalsIgnoreCase("JOINT"))
    	 {
    		 query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit, uw_edc, MATURITY_AGE,premium_break,Death_Benefit_Option_Code,discount,Income_Frequency,Death_Benefit_Multiple,DEFER_PERIOD,INCOME_PERIOD_CD,INCOME_STARTYR,DESIRE_DATE,PREM_OFFSET,SMOKER_CLASS_INSURED,ACCRUAL_OPTION,ISNULL(PAYOUT_PERIOD,''),WELLNESS_DISCOUNT, ISNULL(PROPOSITION_OF_ROP,''),ISNULL(EARLY_ROP,''),ISNULL(EARLY_ROP_MILESTONE,''),ISNULL(GUARANTEED_ANNUITY_PERIOD,''),ISNULL(INC_ANNUITY_PERCENTAGE,''),ISNULL(PROPOSITION_OF_ANNUITY,''),ISNULL(DEFERMENT_PERIOD,''),FAMILY_INCOME_OPTION,QROPS,ISNULL(SURVIVAL_BENEFIT_PERIOD,'')"
    	                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan
    	 }
         else if(plan_type.equalsIgnoreCase("ANNUITY"))
    	 {
    		 query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit, uw_edc, MATURITY_AGE,premium_break,Death_Benefit_Option_Code,discount,Income_Frequency,deferment_period_app,Death_Benefit_Multiple,DEFER_PERIOD,INCOME_PERIOD_CD,INCOME_STARTYR,DESIRE_DATE,PREM_OFFSET,SMOKER_CLASS_INSURED,ACCRUAL_OPTION,ISNULL(PAYOUT_PERIOD,''),WELLNESS_DISCOUNT, ISNULL(PROPOSITION_OF_ROP,''),ISNULL(EARLY_ROP,''),ISNULL(EARLY_ROP_MILESTONE,''),ISNULL(GUARANTEED_ANNUITY_PERIOD,''),ISNULL(INC_ANNUITY_PERCENTAGE,''),ISNULL(PROPOSITION_OF_ANNUITY,''),ISNULL(DEFERMENT_PERIOD,''),FAMILY_INCOME_OPTION,QROPS,ISNULL(SURVIVAL_BENEFIT_PERIOD,'')"
    	                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan
    	 }
         else if(plan_type.equalsIgnoreCase("HEALTH"))
    	 {
    		 query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit, uw_edc, MATURITY_AGE,premium_break,Death_Benefit_Option_Code,discount,Income_Frequency,isnull(Maturity_age,'') as MA,DEFER_PERIOD,INCOME_PERIOD_CD,INCOME_STARTYR,DESIRE_DATE,PREM_OFFSET,SMOKER_CLASS_INSURED,ACCRUAL_OPTION,ISNULL(PAYOUT_PERIOD,''),WELLNESS_DISCOUNT,ISNULL(PROPOSITION_OF_ROP,''),ISNULL(EARLY_ROP,''),ISNULL(EARLY_ROP_MILESTONE,''),ISNULL(GUARANTEED_ANNUITY_PERIOD,''),ISNULL(INC_ANNUITY_PERCENTAGE,''),ISNULL(PROPOSITION_OF_ANNUITY,''),ISNULL(DEFERMENT_PERIOD,''),FAMILY_INCOME_OPTION,QROPS,ISNULL(SURVIVAL_BENEFIT_PERIOD,'')"
    	                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "'; ";   //aanchal //14jan
    	 }
         else if(plan_type.equalsIgnoreCase("COMBO"))
    	 {
    		 query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit, uw_edc, MATURITY_AGE,premium_break,Death_Benefit_Option_Name,discount,Income_Frequency,DEFER_PERIOD,INCOME_PERIOD_CD,INCOME_STARTYR,DESIRE_DATE,PREM_OFFSET,SMOKER_CLASS_INSURED,ACCRUAL_OPTION,ISNULL(PAYOUT_PERIOD,''),WELLNESS_DISCOUNT, ISNULL(PROPOSITION_OF_ROP,''),ISNULL(EARLY_ROP,''),ISNULL(EARLY_ROP_MILESTONE,''),ISNULL(GUARANTEED_ANNUITY_PERIOD,''),ISNULL(INC_ANNUITY_PERCENTAGE,''),ISNULL(PROPOSITION_OF_ANNUITY,''),ISNULL(DEFERMENT_PERIOD,''),FAMILY_INCOME_OPTION,QROPS,ISNULL(SURVIVAL_BENEFIT_PERIOD,'')"
    	                + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
    	                + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";   //aanchal //14jan
    	 }
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            String Vesting_Age = (String) ((List) queryResult.get(0)).get(0);
            if (Vesting_Age.equals("N")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_VESTING_AGE", "visible", "false");
            }
            String Save_More_Tomorrow = (String) ((List) queryResult.get(0)).get(1);
            if (Save_More_Tomorrow.equals("N")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW", "visible", "false");
            }
            String Smoker_Class = (String) ((List) queryResult.get(0)).get(2);
            if (Smoker_Class.equals("N")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMOKER_CLASS", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", "visible", "false");
            }
            else
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMOKER_CLASS", "visible", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", "visible", "true"); //7554
                ifr.setStyle("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", "mandatory", "true");  //DR_7215
            }
            String Life_Event = (String) ((List) queryResult.get(0)).get(3);
            if (Life_Event.equals("N")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_LIFE_EVENT", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW_LIFE_STAGE_REV", "visible", "false");
            }
            //changed by Prakhar
            String Income = (String) ((List) queryResult.get(0)).get(4);
            if (Income.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_INCOME", "visible", "true");
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_INCOME", "visible", "false");
            
            String Guaranteed_Death_Benefit = (String) ((List) queryResult.get(0)).get(5);
            if (Guaranteed_Death_Benefit.equals("N")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEE_DEATH_BENEFIT", "visible", "false");
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEE_DEATH_BENEFIT", "visible", "true");
            
            String uw_edc = (String) ((List) queryResult.get(0)).get(6);
            if (uw_edc.equals("N")) {
                ifr.setStyle("Q_DECISION_SECTION_UW_EDC", "visible", "false");
            }
            else
                ifr.setStyle("Q_DECISION_SECTION_UW_EDC", "visible", "true");
            
            String maturityAge = (String) ((List) queryResult.get(0)).get(7);
            if (maturityAge.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_MATURITY_AGE", "visible", "true");  //7553
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_MATURITY_AGE", "visible", "false");
             String premiumbreak = (String) ((List) queryResult.get(0)).get(8);
            if (premiumbreak.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_PREMIUM_BREAK", "visible", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_PREMIUM_BREAK", "visible", "true");
                ifr.setStyle("Q_COVERAGE_DETAILS_PREMIUM_BREAK", "mandatory", "true");  //DR-7399
                ifr.setStyle("Q_DECISION_SECTION_UW_PREMIUM_BREAK", "mandatory", "true"); //DR-7399
                
               String WorkItemName = (String) ifr.getControlValue("WorkItemName");
                 query ="Select premium_break from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME='"+WorkItemName+"' ";
		List queryResult1 = getValFromQuery(query);
                String PB = (String) ((List) queryResult1.get(0)).get(0);
                if (PB.equals("Y")) 
                {
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "true"); 
                }
                else
                {
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_2", "visible", "false"); 
                }
                
                
            }
            else
            {   ifr.setStyle("Q_COVERAGE_DETAILS_PREMIUM_BREAK", "visible", "false");  //aanchal //16MARCH
                ifr.setStyle("Q_DECISION_SECTION_UW_PREMIUM_BREAK", "visible", "false");
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_2", "visible", "false"); 
            }
             String deathBenefit = (String) ((List) queryResult.get(0)).get(9);
            if (deathBenefit.equals("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_DEATH_BENEFIT", "visible", "false");  //7553
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_DEATH_BENEFIT", "visible", "true"); 
             String discount = (String) ((List) queryResult.get(0)).get(10);
            if (discount.equals("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_EMP_DISCOUNT", "visible", "false");  //7553
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_EMP_DISCOUNT", "visible", "true"); 
            
            
            String INCOMEFRE = (String) ((List) queryResult.get(0)).get(11);
            if (INCOMEFRE.equals("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_FREQUENCY", "visible", "false");  //7553
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_FREQUENCY", "visible", "true"); 
            if(plan_type.equalsIgnoreCase("ANNUITY"))
            {
              String DEFER = (String) ((List) queryResult.get(0)).get(12);
            if (DEFER.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_COVERAGE_TERM", "visible", "true");  //7553
            }
            else
                ifr.setStyle("Q_COVERAGE_DETAILS_COVERAGE_TERM", "visible", "false"); 
            
            //DR-33955 Nikita
            String PropositionOfROP = (String) ((List) queryResult.get(0)).get(23);
            if (!PropositionOfROP.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ROP", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ROP", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ROP", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ROP", "mandatory", "false");
            }
            String EarlyROP = (String) ((List) queryResult.get(0)).get(24);
            if (!EarlyROP.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP", "mandatory", "false");
            }
            String EarlyROPMilestone = (String) ((List) queryResult.get(0)).get(25);
            if (!EarlyROPMilestone.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP_MILESTONE", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP_MILESTONE", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP_MILESTONE", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_EARLY_ROP_MILESTONE", "mandatory", "false");
            }
            String GuaranteedAnnuityPeriod = (String) ((List) queryResult.get(0)).get(26);
            if (!GuaranteedAnnuityPeriod.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEED_ANNUITY_PERIOD", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEED_ANNUITY_PERIOD", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEED_ANNUITY_PERIOD", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_GUARANTEED_ANNUITY_PERIOD", "mandatory", "false");
            }
            String IncreasingAnnuityPercentage = (String) ((List) queryResult.get(0)).get(27);
            if (!IncreasingAnnuityPercentage.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_INC_ANNUITY_PERCENTAGE", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_INC_ANNUITY_PERCENTAGE", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_INC_ANNUITY_PERCENTAGE", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_INC_ANNUITY_PERCENTAGE", "mandatory", "false");
            }
            String PropositionOfAnnuity = (String) ((List) queryResult.get(0)).get(28);
            if (!PropositionOfAnnuity.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ANNUITY", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ANNUITY", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ANNUITY", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_PROPOSITION_OF_ANNUITY", "mandatory", "false");
            }
            String DefermentPeriod = (String) ((List) queryResult.get(0)).get(29);
            if (!DefermentPeriod.equalsIgnoreCase("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_DEFERMENT_PERIOD", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_DEFERMENT_PERIOD", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_DEFERMENT_PERIOD", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_DEFERMENT_PERIOD", "mandatory", "false");
            }
            String QROPS = (String) ((List) queryResult.get(0)).get(31);
            if (QROPS.equals("Y")) {
                ifr.setStyle("Q_POLICY_DETAILS_QROPS", "visible", "true");  
                ifr.setStyle("Q_POLICY_DETAILS_QROPS", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_POLICY_DETAILS_QROPS", "visible", "false"); 
              ifr.setStyle("Q_POLICY_DETAILS_QROPS", "mandatory", "false");
            }
            String FamilyIncomeOption = (String) ((List) queryResult.get(0)).get(30);
            if (FamilyIncomeOption.equals("Y")) {
                ifr.setStyle("Q_POLICY_DETAILS_FAMILY_INCOME_OPTION", "visible", "true");  
                ifr.setStyle("Q_POLICY_DETAILS_FAMILY_INCOME_OPTION", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_POLICY_DETAILS_FAMILY_INCOME_OPTION", "visible", "false"); 
              ifr.setStyle("Q_POLICY_DETAILS_FAMILY_INCOME_OPTION", "mandatory", "false");
            }

        
       
            }
            if(plan_type.equalsIgnoreCase("HEALTH"))
            {
              String MA = (String) ((List) queryResult.get(0)).get(12);
            if (MA.equals("")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_MATURITY_AGE", "visible", "false");  //7553
                ifr.setStyle("Q_COVERAGE_DETAILS_COVERAGE_TERM", "disable", "false"); 
            }
            else
            { ifr.setStyle("Q_COVERAGE_DETAILS_MATURITY_AGE", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_COVERAGE_TERM", "disable", "true"); 
            }
            }
            
            if(plan_type.equalsIgnoreCase("TRAD"))
            {
                String DeathBnefitMultiple = (String) ((List) queryResult.get(0)).get(12);
              if (DeathBnefitMultiple.equals("")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_DEATH_BENEFIT_MULTIPLE", "visible", "false");  //7553

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_DEATH_BENEFIT_MULTIPLE", "visible", "true"); 

              }

               String DeferPeriod = (String) ((List) queryResult.get(0)).get(13);
              if (DeferPeriod.equals("")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_DEFER_PERIOD", "visible", "false");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_DEFER_PERIOD", "mandatory", "false");

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_DEFER_PERIOD", "visible", "true"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_DEFER_PERIOD", "mandatory", "true");

              }

              String IncomePEriod = (String) ((List) queryResult.get(0)).get(14);
              if (IncomePEriod.equals("")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_PERIOD", "visible", "false");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_PERIOD", "mandatory", "false");

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_PERIOD", "visible", "true"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_PERIOD", "mandatory", "true");

              }

              String IncomeSY = (String) ((List) queryResult.get(0)).get(15);
              if (IncomeSY.equals("")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_STARTYEAR", "visible", "false");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_STARTYEAR", "mandatory", "false");

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_STARTYEAR", "visible", "true"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_STARTYEAR", "mandatory", "true");

              }
              
              String DesireDate = (String) ((List) queryResult.get(0)).get(16);
              if (DesireDate.equals("Y")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_DESIRE_INCOMEPAYOUT", "visible", "true");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_DESIRE_INCOMEPAYOUT", "mandatory", "true");
                   
                   String WorkItemName = (String) ifr.getControlValue("WorkItemName");
                 query ="Select DESIRE_INCOMEPAYOUT from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME='"+WorkItemName+"' ";
		List queryResult1 = getValFromQuery(query);
                String PB = (String) ((List) queryResult1.get(0)).get(0);
                if (PB.equals("Y")) 
                {
                    ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "visible", "true");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "mandatory", "true");
                }
                else
                {
                    ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "visible", "false");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "mandatory", "false");
                }

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_DESIRE_INCOMEPAYOUT", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_DESIRE_INCOMEPAYOUT", "mandatory", "false");
              ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "visible", "false");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOMEPAYOUT_DATE", "mandatory", "false");

              }
              
              String PremOffset = (String) ((List) queryResult.get(0)).get(17);
              if (PremOffset.equals("Y")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_OFFSET", "visible", "true");  //7553
                   ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_OFFSET", "mandatory", "true");
                   
                    ifr.setStyle("Q_DECISION_SECTION_UW_INCOME_OFFSET", "visible", "true");  //7553
                   ifr.setStyle("Q_DECISION_SECTION_UW_INCOME_OFFSET", "mandatory", "true");

              }
              else
              { ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_OFFSET", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_INCOME_OFFSET", "mandatory", "false");
              
              ifr.setStyle("Q_DECISION_SECTION_UW_INCOME_OFFSET", "visible", "false"); 
              ifr.setStyle("Q_DECISION_SECTION_UW_INCOME_OFFSET", "mandatory", "false");

			  ifr.setValue("Q_DECISION_SECTION_UW.PREM_OFFSET_VAL", "NA");
              }
              
              //PAYOUT_PERIOD
              String PayoutPeriod = (String) ((List) queryResult.get(0)).get(20);
              String WorkItemName = (String) ifr.getControlValue("WorkItemName");
              //fetch edc
              query ="SELECT EFFECTIVE_DATE FROM NG_NB_COVERAGE_DETAILS(NOLOCK) WHERE WI_NAME='"+WorkItemName+"' ";
              List queryResult1 = getValFromQuery(query);
              String edc = (String) ((List) queryResult1.get(0)).get(0);
 
              //fetch date from MDM
              query ="Select date from NG_NB_MS_SWP_DATE(NOLOCK)";
              queryResult1 = getValFromQuery(query);
              String MDMdate = (String) ((List) queryResult1.get(0)).get(0);
 
              if(edc.compareTo(MDMdate)>=0 && !PayoutPeriod.equalsIgnoreCase("")) {
            	  ifr.setStyle("Q_COVERAGE_DETAILS_PAYOUT_PERIOD", "visible", "true");  
                  ifr.setStyle("Q_COVERAGE_DETAILS_PAYOUT_PERIOD", "mandatory", "true");
              }
              else
              { 
            	  ifr.setStyle("Q_COVERAGE_DETAILS_PAYOUT_PERIOD", "visible", "false"); 
            	  ifr.setStyle("Q_COVERAGE_DETAILS_PAYOUT_PERIOD", "mandatory", "false");
              }
              String SurvivalBenefitPeriod = (String) ((List) queryResult.get(0)).get(31);
              if (!SurvivalBenefitPeriod.equalsIgnoreCase("")) {
                  ifr.setStyle("Q_COVERAGE_DETAILS_SURVIVAL_BENEFIT_PERIOD", "visible", "true");  
                  ifr.setStyle("Q_COVERAGE_DETAILS_SURVIVAL_BENEFIT_PERIOD", "mandatory", "true");
              }
              else
              {
                 ifr.setStyle("Q_COVERAGE_DETAILS_SURVIVAL_BENEFIT_PERIOD", "visible", "false"); 
                 ifr.setStyle("Q_COVERAGE_DETAILS_SURVIVAL_BENEFIT_PERIOD", "mandatory", "false");
              }
            }
           
            String Smoker_Class_Insured = (String) ((List) queryResult.get(0)).get(18);
            if (Smoker_Class_Insured.equals("Y")){
                ifr.setStyle("Q_COVERAGE_DETAILS_SMOKER_CLASS_INSURED", "visible", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_SMOKER_CLASS_INSURED", "visible", "true"); 
                ifr.setStyle("Q_DECISION_SECTION_UW_SMOKER_CLASS_INSURED", "mandatory", "true");
            }
            else
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMOKER_CLASS_INSURED", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW_SMOKER_CLASS_INSURED", "visible", "false"); 
                ifr.setStyle("Q_DECISION_SECTION_UW_SMOKER_CLASS_INSURED", "mandatory", "false");  
            }
      //  }
      //DR-24153 sparsh
            String AccrualOption = (String) ((List) queryResult.get(0)).get(19);
            if (AccrualOption.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_ACCRUAL_OPTION", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_ACCRUAL_OPTION", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_ACCRUAL_OPTION", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_ACCRUAL_OPTION", "mandatory", "false");
            }
            
      //DR-31327 Nikita
            String WellnessDiscount = (String) ((List) queryResult.get(0)).get(21);
            if (WellnessDiscount.equals("Y")) {
                ifr.setStyle("Q_COVERAGE_DETAILS_WELLNESS_DISCOUNT", "visible", "true");  
                ifr.setStyle("Q_COVERAGE_DETAILS_WELLNESS_DISCOUNT", "mandatory", "true");
              }
            else
            {
              ifr.setStyle("Q_COVERAGE_DETAILS_WELLNESS_DISCOUNT", "visible", "false"); 
              ifr.setStyle("Q_COVERAGE_DETAILS_WELLNESS_DISCOUNT", "mandatory", "false");
            }
        }
        //comma separated values present in columns db will be hidden
        //discount
        //hideCommaSeparatedValuesFromMDM();

    }

    public void clearFields() {
        String[] fields = {"Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "Q_COVERAGE_DETAILS.SUM_ASSURED", "Q_COVERAGE_DETAILS.COVERAGE_TERM",
            "Q_COVERAGE_DETAILS.MODAL_PREMIUM", "Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM","Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE",
            "Q_COVERAGE_DETAILS.REQ_MODAL_PREMIUM","Q_COVERAGE_DETAILS.TOTAL_REQ_PREMIUM","AFYP","Q_COVERAGE_DETAILS.GST","Q_COVERAGE_DETAILS.GUARANTEE_DEATH_BENEFIT","label123","Q_COVERAGE_DETAILS_PREMIUM_BREAK"};
        for (int i = 0; i < fields.length; i++) {
            ifr.setValue(fields[i], "");
        }
    }
    
    String isEDCVisible() {
		 String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
         query = "SELECT  uw_edc "
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			query = "SELECT  uw_edc "
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			query = "SELECT  uw_edc "
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			query = "SELECT  uw_edc "
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
         		 {
         			query = "SELECT  uw_edc "
                         + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                         + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; "; 
         		 }
        List queryResult = getValFromQuery(query);
        String uw_edc = (String) ((List) queryResult.get(0)).get(0);
            if (uw_edc.equals("N")) 
                return "false";
        return "true";
    }

    private void hideCommaSeparatedValuesFromMDM() {
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
         query = "SELECT Discount"
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			 query = "SELECT Discount"
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			 query = "SELECT Discount"
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			 query = "SELECT Discount"
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; "; 
		 }
                 else if(plan_type.equalsIgnoreCase("COMBO"))
        		 {
        			 query = "SELECT Discount"
                        + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; "; 
        		 }
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            String Discount = (String) ((List) queryResult.get(0)).get(0);
            String[] DiscountArr = Discount.split(",");
            ifr.setStyle("Q_COVERAGE_DETAILS.EMP_DISCOUNT", "visible", "false");
            ifr.setStyle("Q_COVERAGE_DETAILS.EXISTING_CUST_DISCOUNT", "visible", "false");
            for (int i = 0; i < DiscountArr.length; i++) {
                if (DiscountArr[i].equalsIgnoreCase("ED")) {
                    ifr.setStyle("Q_COVERAGE_DETAILS.EMP_DISCOUNT", "visible", "true");
                    ifr.setStyle("Q_DECISION_SECTION_UW_DISCOUNT_ANY", "visible", "true");
                }

                if (DiscountArr[i].equalsIgnoreCase("EC")) {
                    ifr.setStyle("Q_COVERAGE_DETAILS.EXISTING_CUST_DISCOUNT", "visible", "true");
                    ifr.setStyle("Q_DECISION_SECTION_UW_DISCOUNT_ANY", "visible", "true");  //AANCHAL16MARCH
                }
            }
        }
    }
    
    String getHiddenColumns() {
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
         query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code,Deferment_Period_App "
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
         		 {
         			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Name "
                         + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                         + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
         		 }
        List queryResult = getValFromQuery(query);
        
        String hiddenColumns="",appliedTable="",revisedTable=""; //appliedTableIndex;revisedTableIndex
        //applied table indices to hide:
        //income
        String Income = (String) ((List) queryResult.get(0)).get(4);
        if (!Income.equals("Y")) {
            appliedTable=appliedTable+"4,";
        }
        String defer="";
        if(plan_type.equalsIgnoreCase("ANNUITY"))
        {
            defer = (String) ((List) queryResult.get(0)).get(7);
        if (!defer.equals("Y")) {
            appliedTable=appliedTable+"8,";
        }
        }
        
        
        //GdB  AANCHAL
        String GDB = (String) ((List) queryResult.get(0)).get(5);
        if (!GDB.equals("Y")) {
            appliedTable=appliedTable+"11,";
        }
        //GDB AANCHAL
        //ATP
        appliedTable=appliedTable+"6,";
        //death benefit
        //populateComboValues(queryResult, 4, "Q_COVERAGE_DETAILS.DEATH_BENEFIT", "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_LABEL", "BENEFIT_VALUE");
        if(queryResult!=null){
        String Option_Code = (String) ((List) queryResult.get(0)).get(6);    
        if(Option_Code.equalsIgnoreCase("")){
                appliedTable=appliedTable+"1,";
            }
       }
        //cover Multiple
        appliedTable=appliedTable+"10";
        
        //======================================================================
        //revised table indices to hide:
        //income
        Income = (String) ((List) queryResult.get(0)).get(4);
        if (!Income.equals("Y")) {
            revisedTable=revisedTable+"3,";
        }
        //GDB
         GDB = (String) ((List) queryResult.get(0)).get(5);
        if (!GDB.equals("Y")) {
        	revisedTable=revisedTable+"15,";
        }
        //GDB
        //ATP
        revisedTable=revisedTable+"13,";
        
        //Death benefit
        if(queryResult!=null){
        String Option_Code = (String) ((List) queryResult.get(0)).get(6);    
        if(Option_Code.equalsIgnoreCase("")){
                revisedTable=revisedTable+"8,";
            }
//        else{
//            //ifr.clearTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 7);
//            String[] Option_Code_Arr = Option_Code.split(",");
//            for (int i = 0; i < Option_Code_Arr.length; i++) {
//                if(!Option_Code_Arr[0].equalsIgnoreCase(""))
//                ifr.addItemInTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 7, getLableNamefromId(Option_Code_Arr[i].trim(), "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_LABEL", "BENEFIT_VALUE"),
//                        Option_Code_Arr[i].trim());
//            }
//        }
       }
        //cover Multiple
        revisedTable=revisedTable+"14";

        if(appliedTable.endsWith(","))
            appliedTable=appliedTable.substring(0, appliedTable.length()-1);
        
        if(revisedTable.endsWith(","))
            revisedTable=revisedTable.substring(0, revisedTable.length()-1);
        
        hiddenColumns=appliedTable+";"+revisedTable;
        return hiddenColumns;
    }
    
    public void addMandatoryRiders() throws org.json.simple.parser.ParseException {
        //clearing table
        ifr.clearTable("table37");
        String insuredFirstName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
        String baseCoverage = "";
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
          query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory"
                + "riders11,Is_Rider11_Mandatory,riders12,Is_Rider12_Mandatory,riders13,Is_Rider13_Mandatory"  //DR-49496 Nikita
                + "riders14,Is_Rider14_Mandatory,riders15,Is_Rider15_Mandatory,riders16,Is_Rider16_Mandatory"
                + "riders17,Is_Rider17_Mandatory,riders18,Is_Rider18_Mandatory,riders19,Is_Rider19_Mandatory"
                + "riders20,Is_Rider20_Mandatory FROM NG_NB_MS_TRAD(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			  query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_JOINT(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			  query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_ANNUITANT(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			  query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_HEALTH(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("COMBO"))
        		 {
        			  query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                        + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                        + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_COMBO(NOLOCK)"
                        + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		 }
        List queryResult = getValFromQuery(query);
        JSONArray jsonArray = new JSONArray();
        if (queryResult != null) {
            String rider, isMandatory;
            for (int i = 0, j = 1; i < 20; i++, j++) {
                rider = (String) ((List) queryResult.get(0)).get(i++);
                isMandatory = (String) ((List) queryResult.get(0)).get(j++);

                if (!rider.equalsIgnoreCase("") && !isMandatory.equalsIgnoreCase("")) {
                    if (isMandatory.equalsIgnoreCase("Y")) {
                        //JSONParser jsonParser = new JSONParser();
                        //[{"col1":"val1","col2":"val2"},{row2 data}]
                        //String data = "{\"data\":[{\"Rider Type\":\"" + rider + "\",\"Rider Insured Details\" : \"" + insuredFirstName + "\"}]}";
                        JSONObject rowObj = new JSONObject();
                        rowObj.put("Rider Type", rider);
                        rowObj.put("Rider Insured Details", insuredFirstName);      
                        rowObj.put("RiderBenefit", "R");   
                        //JSONArray jsonArray = new JSONArray();
                        //jsonArray = (JSONArray) json.get("data");
                        jsonArray.add(rowObj); 
                    }
                }
            }
            ifr.addDataToGrid("table37", jsonArray);
        }
    }

    public String getRiders() {
        String riders = "";
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
            query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory "
                + "riders11,Is_Rider11_Mandatory,riders12,Is_Rider12_Mandatory,riders13,Is_Rider13_Mandatory"  //DR-49496 Nikita
                + "riders14,Is_Rider14_Mandatory,riders15,Is_Rider15_Mandatory,riders16,Is_Rider16_Mandatory"
                + "riders17,Is_Rider17_Mandatory,riders18,Is_Rider18_Mandatory,riders19,Is_Rider19_Mandatory"
                + "riders20,Is_Rider20_Mandatory FROM NG_NB_MS_TRAD(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			     query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_JOINT(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			     query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_ANNUITANT(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			     query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_HEALTH(NOLOCK)"
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("COMBO"))
        		 {
        			     query = "SELECT riders1,Is_Rider1_Mandatory,riders2,Is_Rider2_Mandatory,riders3,Is_Rider3_Mandatory,"
                        + "riders4,Is_Rider4_Mandatory,riders5,Is_Rider5_Mandatory,riders6,Is_Rider6_Mandatory,riders7,Is_Rider7_Mandatory,"
                        + "riders8,Is_Rider8_Mandatory,riders9,Is_Rider9_Mandatory, riders10,Is_Rider10_Mandatory FROM NG_NB_MS_COMBO(NOLOCK)"
                        + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                        + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
        		 }
      
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            String rider, isMandatory;
            for (int i = 0, j = 1; i < 20; i++, j++) {
                rider = (String) ((List) queryResult.get(0)).get(i++);
                isMandatory = (String) ((List) queryResult.get(0)).get(j++);

                if (!rider.equalsIgnoreCase("") && !isMandatory.equalsIgnoreCase("")) {
                    if (isMandatory.equalsIgnoreCase("N")) {
                        riders = riders + "," + rider;
                    }
                }
            }
        }
        if (riders.contains(",")) {
            riders = riders.substring(1); //removing first comma
        }
        return riders;
    }

    public String getActiveRiders() throws ParseException {
        String activeRiders = "";
        Date effectiveDateObj = new Date(), expiryDateObj = new Date();
        String effectiveDate = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
            query = "SELECT \n" +
                        "riders1,Is_Active_Rider1,Rider1_Expiry_Plan,Is_Rider1_Mandatory,\n" +
                        "riders2,Is_Active_Rider2,Rider2_Expiry_Plan,Is_Rider2_Mandatory,\n" +
                        "riders3,Is_Active_Rider3,Rider3_Expiry_Plan,Is_Rider3_Mandatory,\n" +
                        "riders4,Is_Active_Rider4,Rider4_Expiry_Plan,Is_Rider4_Mandatory,\n" +
                        "riders5,Is_Active_Rider5,Rider5_Expiry_Plan,Is_Rider5_Mandatory,\n" +
                        "riders6,Is_Active_Rider6,Rider6_Expiry_Plan,Is_Rider6_Mandatory,\n" +
                        "riders7,Is_Active_Rider7,Rider7_Expiry_Plan,Is_Rider7_Mandatory,\n" +
                        "riders8,Is_Active_Rider8,Rider8_Expiry_Plan,Is_Rider8_Mandatory,\n" +
                        "riders9,Is_Active_Rider9,Rider9_Expiry_Plan,Is_Rider9_Mandatory,\n" +
                        "riders10,Is_Active_Rider10,Rider10_Expiry_Plan,Is_Rider10_Mandatory, \n" +
                        "riders11,Is_Active_Rider11,Rider11_Expiry_Plan,Is_Rider11_Mandatory, \n" + //DR-49496 Nikita
                        "riders12,Is_Active_Rider12,Rider12_Expiry_Plan,Is_Rider12_Mandatory, \n" +
                        "riders13,Is_Active_Rider13,Rider13_Expiry_Plan,Is_Rider13_Mandatory, \n" +
                        "riders14,Is_Active_Rider14,Rider14_Expiry_Plan,Is_Rider14_Mandatory, \n" +
                        "riders15,Is_Active_Rider15,Rider15_Expiry_Plan,Is_Rider15_Mandatory, \n" +
                        "riders16,Is_Active_Rider16,Rider16_Expiry_Plan,Is_Rider16_Mandatory, \n" +
                        "riders17,Is_Active_Rider17,Rider17_Expiry_Plan,Is_Rider17_Mandatory, \n" +
                        "riders18,Is_Active_Rider18,Rider18_Expiry_Plan,Is_Rider18_Mandatory, \n" +
                        "riders19,Is_Active_Rider19,Rider19_Expiry_Plan,Is_Rider19_Mandatory, \n" +
                        "riders20,Is_Active_Rider20,Rider20_Expiry_Plan,Is_Rider20_Mandatory, \n" +
                        "FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='\" + planCode + \"' AND Channel='\" + Channel + \"'  AND Sub_Channel='\" + subChannel + \"'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			     query = "SELECT \n" +
                        "riders1,Is_Active_Rider1,Rider1_Expiry_Plan,Is_Rider1_Mandatory,\n" +
                        "riders2,Is_Active_Rider2,Rider2_Expiry_Plan,Is_Rider2_Mandatory,\n" +
                        "riders3,Is_Active_Rider3,Rider3_Expiry_Plan,Is_Rider3_Mandatory,\n" +
                        "riders4,Is_Active_Rider4,Rider4_Expiry_Plan,Is_Rider4_Mandatory,\n" +
                        "riders5,Is_Active_Rider5,Rider5_Expiry_Plan,Is_Rider5_Mandatory,\n" +
                        "riders6,Is_Active_Rider6,Rider6_Expiry_Plan,Is_Rider6_Mandatory,\n" +
                        "riders7,Is_Active_Rider7,Rider7_Expiry_Plan,Is_Rider7_Mandatory,\n" +
                        "riders8,Is_Active_Rider8,Rider8_Expiry_Plan,Is_Rider8_Mandatory,\n" +
                        "riders9,Is_Active_Rider9,Rider9_Expiry_Plan,Is_Rider9_Mandatory,\n" +
                        "riders10,Is_Active_Rider10,Rider10_Expiry_Plan,Is_Rider10_Mandatory, \n" +
                        "FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='\" + planCode + \"' AND Channel='\" + Channel + \"'  AND Sub_Channel='\" + subChannel + \"'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			     query = "SELECT \n" +
                        "riders1,Is_Active_Rider1,Rider1_Expiry_Plan,Is_Rider1_Mandatory,\n" +
                        "riders2,Is_Active_Rider2,Rider2_Expiry_Plan,Is_Rider2_Mandatory,\n" +
                        "riders3,Is_Active_Rider3,Rider3_Expiry_Plan,Is_Rider3_Mandatory,\n" +
                        "riders4,Is_Active_Rider4,Rider4_Expiry_Plan,Is_Rider4_Mandatory,\n" +
                        "riders5,Is_Active_Rider5,Rider5_Expiry_Plan,Is_Rider5_Mandatory,\n" +
                        "riders6,Is_Active_Rider6,Rider6_Expiry_Plan,Is_Rider6_Mandatory,\n" +
                        "riders7,Is_Active_Rider7,Rider7_Expiry_Plan,Is_Rider7_Mandatory,\n" +
                        "riders8,Is_Active_Rider8,Rider8_Expiry_Plan,Is_Rider8_Mandatory,\n" +
                        "riders9,Is_Active_Rider9,Rider9_Expiry_Plan,Is_Rider9_Mandatory,\n" +
                        "riders10,Is_Active_Rider10,Rider10_Expiry_Plan,Is_Rider10_Mandatory, \n" +
                        "FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='\" + planCode + \"' AND Channel='\" + Channel + \"'  AND Sub_Channel='\" + subChannel + \"'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			     query = "SELECT \n" +
                        "riders1,Is_Active_Rider1,Rider1_Expiry_Plan,Is_Rider1_Mandatory,\n" +
                        "riders2,Is_Active_Rider2,Rider2_Expiry_Plan,Is_Rider2_Mandatory,\n" +
                        "riders3,Is_Active_Rider3,Rider3_Expiry_Plan,Is_Rider3_Mandatory,\n" +
                        "riders4,Is_Active_Rider4,Rider4_Expiry_Plan,Is_Rider4_Mandatory,\n" +
                        "riders5,Is_Active_Rider5,Rider5_Expiry_Plan,Is_Rider5_Mandatory,\n" +
                        "riders6,Is_Active_Rider6,Rider6_Expiry_Plan,Is_Rider6_Mandatory,\n" +
                        "riders7,Is_Active_Rider7,Rider7_Expiry_Plan,Is_Rider7_Mandatory,\n" +
                        "riders8,Is_Active_Rider8,Rider8_Expiry_Plan,Is_Rider8_Mandatory,\n" +
                        "riders9,Is_Active_Rider9,Rider9_Expiry_Plan,Is_Rider9_Mandatory,\n" +
                        "riders10,Is_Active_Rider10,Rider10_Expiry_Plan,Is_Rider10_Mandatory, \n" +
                        "FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='\" + planCode + \"' AND Channel='\" + Channel + \"'  AND Sub_Channel='\" + subChannel + \"'; ";
		 }
      
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            String rider, isActive, expiryDate, isMandatory;
            for (int i = 0; i < 40; i+=4) {
                rider = (String) ((List) queryResult.get(0)).get(i);                
                isActive = (String) ((List) queryResult.get(0)).get(i+1);                
                expiryDate = (String) ((List) queryResult.get(0)).get(i+2);
                isMandatory = (String) ((List) queryResult.get(0)).get(i+3);

                if (isActive.equalsIgnoreCase("Y") && !isMandatory.equalsIgnoreCase("Y")) {
                    activeRiders = activeRiders + "," + rider;
                } else if (!expiryDate.equalsIgnoreCase("") && !effectiveDate.equalsIgnoreCase("")) {
                    effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
                    expiryDateObj = new SimpleDateFormat("dd/MMM/yyyy").parse(expiryDate);
                    if (expiryDateObj.before(effectiveDateObj)) {
                        activeRiders = activeRiders + "," + rider;
                    }
                }

            }
        }
        if (activeRiders.contains(",")) {
            activeRiders = activeRiders.substring(1); //removing first comma
        }
        return activeRiders;
    }

    public String getComboValues(){
        String keyVal = "";
        planCode = objVal;
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
   	 String query ="";
		if(plan_type.equalsIgnoreCase("TRAD"))
		 {
            query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
                + "Company_Entity, discount,Income_Frequency, Maturity_age,DEFER_PERIOD,INCOME_STARTYR"
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			  query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
                + "Company_Entity, discount,Income_Frequency,Maturity_age,DEFER_PERIOD,INCOME_STARTYR"
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			  query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
                + "Company_Entity, discount,Income_Frequency,Maturity_age,DEFER_PERIOD,INCOME_STARTYR"
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			  query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Code,Death_Benefit_Option_Code,Product_Solution,"
                + "Company_Entity, discount,Income_Frequency, Maturity_age,DEFER_PERIOD,INCOME_STARTYR"
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                else if(plan_type.equalsIgnoreCase("COMBO"))
       		 {
       			  query = "SELECT Bonus_Option_Code,NFO_Option_Code,Billing_Type_Code,Billing_Mode_Desc,Death_Benefit_Option_Name,Product_Solution,"
                       + "Company_Entity, discount,Income_Frequency, Maturity_age,DEFER_PERIOD,INCOME_STARTYR"
                       + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                       + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
       		 }
        
        List queryResult = getValFromQuery(query);
        String BonusComboValues=" ",NonForfeitureValues=" ",RenewalPremiumMethodValues=" ",ModeOfPaymentValues=" ",DeathBenefitValues=" ",ProductSolutionValues=" ",
                ClientTypeValues=" ", Discount=" ",incomeFreq="", maturityage="", deferPeriod="", incomeStartYear="";
        
        BonusComboValues = getKeyValCombo(queryResult, 0, "", "NG_NB_MS_BONUS_OPT", "BONUS_LABEL", "BONUS_VALUE");
        NonForfeitureValues = getKeyValCombo(queryResult, 1, "", "NG_NB_MS_NON_FORFEITURE", "FORF_LABEL", "FORF_VALUE");
        RenewalPremiumMethodValues = getKeyValCombo(queryResult, 2, "", "NG_NB_MS_BILL_TYPE_CODE_DESC", "BILL_TYPE_DESC", "BILL_TYPE_CODE");
        ModeOfPaymentValues = getKeyValCombo(queryResult, 3, "",  "NG_NB_MS_MODE_OF_PAYMENT", "LABEL", "VALUE");
        DeathBenefitValues = getKeyValCombo(queryResult, 4, "","NG_NB_MS_DEATH_BENEFIT", "BENEFIT_LABEL", "BENEFIT_VALUE");
        ProductSolutionValues = getKeyValCombo(queryResult, 5, "", "NG_NB_MS_PRODUCT_SOLUTION", "SOLUTION_LABEL", "SOLUTION_VALUE");
        ClientTypeValues = getKeyValCombo(queryResult, 6, "", "NG_NB_MS_CLIENT_TYPE", "TYPE_LABEL", "TYPE_VALUE");
        Discount = getKeyValCombo(queryResult, 7, "", "NG_NB_MS_DISCOUNT_OPTION_CODE_DESC", "Discount_Option_Desc", "Discount_Option_Code"); //DR 13APril
          incomeFreq = getKeyValCombo(queryResult, 8, "", "NG_NB_MS_MODE_OF_PAYMENT", "LABEL", "VALUE");
              maturityage = getKeyValCombo(queryResult, 9, "", "NG_NB_MS_MATURITYAGE", "AGE", "AGE");
              deferPeriod=getKeyValCombo(queryResult, 10, "", "NG_NB_MS_DEFERPERIOD", "PERIOD", "PERIOD");
                incomeStartYear=getKeyValCombo(queryResult, 11, "", "NG_NB_MS_INCOMESTARTYEAR", "VALUE", "VALUE");
            
        
        keyVal = BonusComboValues + "##" + NonForfeitureValues + "##"  + RenewalPremiumMethodValues + "##"  + ModeOfPaymentValues + "##"  + DeathBenefitValues
                 + "##" + ProductSolutionValues + "##" + ClientTypeValues + "##" + Discount+ "##" +incomeFreq +"##" +maturityage +"##" +deferPeriod  +"##" + incomeStartYear;
        
        return keyVal;
    }
    
    /*
    public String getProductNameComboValues(){
        String labelVal = "",query="";
        String productFamily = changeVal;
        if(productFamily.equalsIgnoreCase("TRAD")){
            query = "SELECT PCM.PLANS, PCM.PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK) PCM, NG_NB_MS_TRAD MDM WHERE PCM.PRODUCT_TYPE='"+productFamily+"' AND PCM.plan_code = MDM.Plan_Code";
        }
        else
            query = "SELECT PLANS, PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK)";
        
        List queryResult = getValFromQuery(query);
        if(queryResult!=null){
            for(int i=0;i<queryResult.size();i++){
                String label="",val="";
                label = (String)((List)queryResult.get(i)).get(0);
                val = (String)((List)queryResult.get(i)).get(1);
                if(!label.equalsIgnoreCase("") && !val.equalsIgnoreCase("")){
                    labelVal = labelVal + "," + label + "~~"+val;
                }
            }
        }
        if(labelVal.charAt(0) == ','){
            labelVal = labelVal.substring(1);
        }
        return labelVal;
    }
    */
    public void populateProductNamesCombo (){
        String query = "";
        String prodFamily = (String) ifr.getControlValue("Q_POLICY_DETAILS.PRODUCT_NAME");
        if(!ifr.getActivityName().equalsIgnoreCase("Source")){
            if(prodFamily.equalsIgnoreCase("TRAD")){
                query = "SELECT PCM.PLANS, PCM.PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK) PCM, NG_NB_MS_TRAD(NOLOCK) MDM WHERE PCM.PRODUCT_TYPE='"+prodFamily+"' AND PCM.plan_code = MDM.Plan_Code";
            }
            else  if(prodFamily.equalsIgnoreCase("JOINT")){
                query = "SELECT PCM.PLANS, PCM.PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK) PCM, NG_NB_MS_JOINT(NOLOCK) MDM WHERE PCM.PRODUCT_TYPE='"+prodFamily+"' AND PCM.plan_code = MDM.Plan_Code";
            }  //aaanchal //14jan
             else  if(prodFamily.equalsIgnoreCase("ANNUITY")){
                query = "SELECT PCM.PLANS, PCM.PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK) PCM, NG_NB_MS_ANNUITANT(NOLOCK) MDM WHERE PCM.PRODUCT_TYPE='"+prodFamily+"' AND PCM.plan_code = MDM.Plan_Code";
            } 
             else  if(prodFamily.equalsIgnoreCase("HEALTH")){
                query = "SELECT PCM.PLANS, PCM.PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK) PCM, NG_NB_MS_HEALTH(NOLOCK) MDM WHERE PCM.PRODUCT_TYPE='"+prodFamily+"' AND PCM.plan_code = MDM.Plan_Code";
            } 
            else
                query = "SELECT PLANS, PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK)";

             List queryResult = getValFromQuery(query);
            if(queryResult!=null){
                for(int i=0;i<queryResult.size();i++){
                    String label="",val="";
                    label = (String)((List)queryResult.get(i)).get(0);
                    val = (String)((List)queryResult.get(i)).get(1);
                    if(!label.equalsIgnoreCase("") && !val.equalsIgnoreCase("")){
                       ifr.addItemInCombo("PLAN_NAME",
                        label, val);
                    }
                }
            }
        }
 }
    
    //utility methods for this class Only
    private String getLableNamefromId(String labelValue, String masterTableName, String col_lab, String col_val) {
        String labelName = "";
        if (!labelValue.equalsIgnoreCase("")) {
            String query = "SELECT " + col_lab + " FROM " + masterTableName + " (NOLOCK) WHERE " + col_val + " = '" + labelValue + "'";
            List queryResult = getValFromQuery(query);
            if (queryResult != null) {
                labelName = (String) ((List) queryResult.get(0)).get(0);
            }
        }
        return labelName;
    }

    private void populateComboValues(List queryResult, int pos, String comboID, String masterTabelName, String label, String value) {
       // ifr.clearCombo(comboID);
       String Option_Code="";
       //for TRAD Cases
       if(queryResult!=null){
        Option_Code = (String) ((List) queryResult.get(0)).get(pos);    
        if(Option_Code.equalsIgnoreCase("")){
                ifr.setStyle(comboID, "visible", "false");
                return;
            }else{
            ifr.setStyle(comboID, "visible", "true");
        }
       }
        
        //in case of ulip cases populating all the values
        String prodFamily = (String) ifr.getControlValue("PLAN_TYPE");
        if(prodFamily.equalsIgnoreCase("ULIP")){  //joint//ulip
            String query="";
            List masterValueResult = null;
            if(masterTabelName.equalsIgnoreCase("NG_NB_MS_BONUS_OPT")){
                Option_Code = "";
                query = "SELECT ',' + BONUS_VALUE FROM NG_NB_MS_BONUS_OPT ORDER BY LEN(BONUS_VALUE) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_NON_FORFEITURE")){
                Option_Code = "";
                query = "SELECT ',' + FORF_VALUE FROM NG_NB_MS_NON_FORFEITURE ORDER BY (FORF_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_BILL_TYPE_CODE_DESC")){
                Option_Code = "";
                query = "SELECT ',' + BILL_TYPE_CODE FROM NG_NB_MS_BILL_TYPE_CODE_DESC ORDER BY (BILL_TYPE_DESC) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_MODE_OF_PAYMENT")){
                Option_Code = "";
                query = "SELECT ',' + VALUE FROM NG_NB_MS_MODE_OF_PAYMENT ORDER BY (VALUE) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_DEATH_BENEFIT")){
                Option_Code = "";
                query = "SELECT ',' + BENEFIT_VALUE FROM NG_NB_MS_DEATH_BENEFIT ORDER BY (BENEFIT_LABEL) FOR XML PATH('')  ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_PRODUCT_SOLUTION")){
                Option_Code = "";
                query = "SELECT ',' + SOLUTION_VALUE FROM NG_NB_MS_PRODUCT_SOLUTION ORDER BY (SOLUTION_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_CLIENT_TYPE")){
                Option_Code = "";
                query = "SELECT ',' + TYPE_VALUE FROM NG_NB_MS_CLIENT_TYPE ORDER BY (TYPE_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            }
            else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_VARIANT")){
                Option_Code = "";
                query = "SELECT ',' + CODE FROM NG_NB_MS_VARIANT ORDER BY (LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            }
            if(Option_Code.charAt(0) == ',')
                Option_Code = Option_Code.substring(1);
        }
        
        String[] Option_Code_Arr = Option_Code.split(",");
        /*
        try{
         if(Option_Code_Arr[0].equalsIgnoreCase(""))            //to hide those combos who have no value in dropdown
             ifr.setStyle("Q_COVERAGE_DETAILS.VESTING_AGE", "visible", "false");
             }
        catch(Exception ex){}
        */
        for (int i = 0; i < Option_Code_Arr.length; i++) {
            if(!Option_Code_Arr[0].equalsIgnoreCase(""))
            ifr.addItemInCombo(comboID,
                    getLableNamefromId(Option_Code_Arr[i].trim(), masterTabelName, label, value), Option_Code_Arr[i].trim());
        }
    }
    
    private String getKeyValCombo(List queryResult, int pos, String comboID, String masterTabelName, String label, String value){
        //will return combo label and values as label1~~val1,lab2~~val2.....
        // ifr.clearCombo(comboID);
        String keyVal="";
        String Option_Code="";
        
        if(queryResult!=null)
        Option_Code = (String) ((List) queryResult.get(0)).get(pos);
        
        //in case of non-trad cases populating all the values
        String prodFamily = (String) ifr.getControlValue("PLAN_TYPE");
        if(prodFamily.equalsIgnoreCase("ULIP")){  //JOINT//14jan
            String query="";
            List masterValueResult = null;
            if(masterTabelName.equalsIgnoreCase("NG_NB_MS_BONUS_OPT")){
                Option_Code = "";
                query = "SELECT ',' + BONUS_VALUE FROM NG_NB_MS_BONUS_OPT ORDER BY LEN(BONUS_VALUE) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_NON_FORFEITURE")){
                Option_Code = "";
                query = "SELECT ',' + FORF_VALUE FROM NG_NB_MS_NON_FORFEITURE ORDER BY (FORF_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_BILL_TYPE_CODE_DESC")){
                Option_Code = "";
                query = "SELECT ',' + BILL_TYPE_CODE FROM NG_NB_MS_BILL_TYPE_CODE_DESC ORDER BY (BILL_TYPE_DESC) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_MODE_OF_PAYMENT")){
                Option_Code = "";
                query = "SELECT ',' + VALUE FROM NG_NB_MS_MODE_OF_PAYMENT ORDER BY (VALUE) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_DEATH_BENEFIT")){
                Option_Code = "";
                query = "SELECT ',' + BENEFIT_VALUE FROM NG_NB_MS_DEATH_BENEFIT ORDER BY (BENEFIT_LABEL) FOR XML PATH('')  ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_PRODUCT_SOLUTION")){
                Option_Code = "";
                query = "SELECT ',' + SOLUTION_VALUE FROM NG_NB_MS_PRODUCT_SOLUTION ORDER BY (SOLUTION_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            } else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_CLIENT_TYPE")){
                Option_Code = "";
                query = "SELECT ',' + TYPE_VALUE FROM NG_NB_MS_CLIENT_TYPE ORDER BY (TYPE_LABEL) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            }
            else if(masterTabelName.equalsIgnoreCase("NG_NB_MS_DISCOUNT_OPTION_CODE_DESC")){
                Option_Code = "";
                query = "SELECT ',' + Discount_Option_Desc FROM NG_NB_MS_DISCOUNT_OPTION_CODE_DESC ORDER BY (Discount_Option_Code) FOR XML PATH('') ";
                masterValueResult = getValFromQuery(query);
                if(masterValueResult!=null){
                    Option_Code = (String) ((List) masterValueResult.get(0)).get(0);
                }
            }
            
            if(Option_Code.charAt(0) == ',')
                Option_Code = Option_Code.substring(1);
        }
        String[] Option_Code_Arr = Option_Code.split(",");

        for (int i = 0; i < Option_Code_Arr.length; i++) {
            keyVal = keyVal + " , " + getLableNamefromId(Option_Code_Arr[i].trim(), masterTabelName, label, value) + " ~~ " + Option_Code_Arr[i].trim();
                   // getLableNamefromId(Option_Code_Arr[i].trim(), masterTabelName, label, value), Option_Code_Arr[i].trim());
        }  
         if (keyVal.contains(" , ")) {
            keyVal = keyVal.substring(2); //removing first comma
        }
        return keyVal;
    }

    List getValFromQuery(String query) {
        String queryResult = "";
        List queryResultList = (List) ifr.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
    }

    

    private String getChannelDescFromVal(String Channel) {
        String channelDesc="";
        String query = "SELECT TOP(1) CHANNEL_DESC FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE = '"+Channel+"' ";
        List queryResult = getValFromQuery(query);
        if(queryResult!=null){
            channelDesc = (String) ((List) queryResult.get(0)).get(0);
        }
        return channelDesc;
    }

    boolean isPlanValid() {
        String count = "0";
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
          query = "SELECT COUNT(*) AS TOTAL_COUNT "
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			  query = "SELECT COUNT(*) AS TOTAL_COUNT "
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'";
		 }
                 else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			  query = "SELECT COUNT(*) AS TOTAL_COUNT "
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'";
		 }
                 else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			  query = "SELECT COUNT(*) AS TOTAL_COUNT "
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'";
		 }
        
        List queryResult = getValFromQuery(query);
        if(queryResult!=null){
            count = (String) ((List) queryResult.get(0)).get(0);
        }
        if(count.equals("")) count = "0";
        if(Integer.parseInt(count)>0)
            return true;
        else 
            return false;
    }

    void populateComboCoverageRevised() {
		String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
    	 String query ="";
		 if(plan_type.equalsIgnoreCase("TRAD"))
		 {
          query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
		 else if(plan_type.equalsIgnoreCase("JOINT"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code,SMOKER_CLASS_INSURED "
                + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("ANNUITY"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("HEALTH"))
		 {
			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		 }
                  else if(plan_type.equalsIgnoreCase("COMBO"))
         		 {
         			  query = "SELECT Vesting_Age,Save_More_Tomorrow,Smoker_Class,Life_Event, Income, Guaranteed_Death_Benefit,Death_Benefit_Option_Code "
                         + " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                         + " AND Sub_Channel='" + subChannel + "' AND combo_plan_code='"+secPlanCode+"' and product_Solution='"+productSolution+"'; ";
         		 }
                 
                 
        
        List queryResult = getValFromQuery(query);
        if(queryResult!=null){
            String Option_Code = (String) ((List) queryResult.get(0)).get(6); 
            if(!Option_Code.equalsIgnoreCase("")){
                String[] Option_Code_Arr = Option_Code.split(",");
                for (int i = 0; i < Option_Code_Arr.length; i++) {
                    if(!Option_Code_Arr[0].equalsIgnoreCase(""))
                        ifr.addItemInTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 7, getLableNamefromId(Option_Code_Arr[i].trim(), "NG_NB_MS_DEATH_BENEFIT", 
                            "BENEFIT_LABEL", "BENEFIT_VALUE"),Option_Code_Arr[i].trim());
                }
            }
        }        
    }

    

    

}
