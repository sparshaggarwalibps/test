/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
        
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author pranav-gupta
 */
public class RiderBenefit {

    IFormReference ifr;
    String planCode, Channel, subChannel, productType,edc, secondaryplancode ;

    //Constructor
    public RiderBenefit(IFormReference iFormRef, String planCode, String Channel, String SubChannelCase, String productType) {
        this.ifr = iFormRef;
        this.planCode = planCode;
        this.Channel = Channel;
        this.productType = productType;
        if (Channel.equalsIgnoreCase("A") && SubChannelCase.equalsIgnoreCase("Y")) {
            this.subChannel = "Defence";
        }
        else if (Channel.equalsIgnoreCase("BY") && SubChannelCase.equalsIgnoreCase("Y"))
        {
            this.subChannel = "TeleSale";
        }
        else {
            this.subChannel = getSubChannel(Channel);
        }
        //this.subChannel="Agency";
    }

    //Validate the Client Type of all the rider/benefit
    /*public String validateClientType() {
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", validationResult;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();

                validationResult = clientTypeLogic(riderName);

                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }*/
    //Validate issue amount of Benefit 1 and 2
    public String validateSumAssuredOfBenefit() {
        String ATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP");
        
        String coverMultiple = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE");
        
        String PLANTYPE=(String) ifr.getControlValue("PLAN_TYPE");
        if(PLANTYPE.equalsIgnoreCase("COMBO"))
        {
            ATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP_COMBO");
            coverMultiple = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE_COMBO");
        }
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", benefitFlag, benefit = "#", validationResult, riderCode;
        double sumAssured = 0.0;

        if (ATP.equalsIgnoreCase("")) {
            ATP = "0";
        }
        if (coverMultiple.equalsIgnoreCase("")) {
            coverMultiple = "0";
        }

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderCode = obj.get("Rider").toString();//returns rider code
                riderName = obj.get("Rider Type").toString();//returns rider desc
                benefitFlag = obj.get("RiderBenefit").toString();

                if (benefitFlag.equalsIgnoreCase("B1") || benefitFlag.equalsIgnoreCase("B2")) {
                    if (benefitFlag.equalsIgnoreCase("B1")) {
                        sumAssured = Double.parseDouble(ATP);
                    } else if (benefitFlag.equalsIgnoreCase("B2")) {
                        sumAssured = Double.parseDouble(ATP) * Double.parseDouble(coverMultiple);
                    }

                    validationResult = sumAssuredLogic(riderName, sumAssured, "CoverageDetails", riderCode);

                    if (!validationResult.equalsIgnoreCase("")) {
                        errorMsg += validationResult;
                        benefit += benefitFlag + "^";
                    }
                }
            }
        }

        errorMsg += benefit;
        return errorMsg;
    }

    //Validate modal premium of riders when modeOfPayment changes
    /*public String validateModalPremium() {

        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", riderModalPremium, validationResult;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();
                riderModalPremium = obj.get("Modal Premium(INR)").toString();

                validationResult = modalPremiumLogic(riderName, riderModalPremium, "CoverageDetails");
                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }*/
    //Validate sum assured of riders when modeOfPayment changes
    public String validateSumAssured() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", riderSumAssured, validationResult, riderCode;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderCode = obj.get("Rider").toString();//returns rider code
                riderName = obj.get("Rider Type").toString();
                riderSumAssured = obj.get("Sum Assured").toString();
                if (riderSumAssured.equalsIgnoreCase("")) {
                    riderSumAssured = "0";
                }
                validationResult = sumAssuredLogic(riderName, Double.parseDouble(riderSumAssured), "CoverageDetails", riderCode);
                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }

    //To validate Insured Age and expiry Age when effecive of DOB changes
    /*public String validateInsuredAge() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", coverTerm, validationResult;
        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();
                coverTerm = obj.get("Coverage term").toString();

                validationResult = insuredAgeLogic(riderName, coverTerm);

                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }*/
    //To validate Effective/Customer date of Rider
    /*public String validateEffectiveDate() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", validationResult;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();
                validationResult = effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate");
                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }*/
    //To validate Coverage Term of riders/benefits
    /*public String validateCoverageTerm() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", riderCoverTerm, validationResult;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();
                riderCoverTerm = obj.get("Coverage term").toString();
                validationResult = coverageTermLogic(riderName, riderCoverTerm);
                if (!validationResult.equalsIgnoreCase("")) {
                    errorMsg += validationResult;
                }
            }
        }
        return errorMsg;
    }*/
    //When User clicks on Save Changes or Save and Next Button
    public String RiderOnSaveModal() {
        String riderName = (String) ifr.getValue("table37_RIDER_DESC");
        String coverTerm = (String) ifr.getValue("table37_COVERAGE_TERM");
        String sumAssured = (String) ifr.getValue("table37_SUM_ASSURED");
        String ppt = (String) ifr.getValue("table37_PPT");
        String riderClass = (String) ifr.getValue("table37_RIDER_CLASS");
        String riderCode = (String) ifr.getValue("table37_RIDER_TYPE");//returns rider code
        String planname=(String) ifr.getValue("PLAN_NAME");
        String errorMsg = "";

        sumAssured = sumAssured.isEmpty() ? "0" : sumAssured;

        errorMsg += clientTypeLogic(riderName, riderCode);
        errorMsg += sumAssuredLogic(riderName, Double.parseDouble(sumAssured), "CoverageDetails", riderCode);
        errorMsg += coverageTermLogic(riderName, coverTerm, riderCode);
        errorMsg += premiumPaymentTermLogic(riderName, ppt, coverTerm, "CoverageDetails", riderCode);
        errorMsg += riderFamilyLogic(riderName, riderClass);
        return errorMsg;
    }

    public String onLoadCoverageDetails() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
           if (productType.equalsIgnoreCase("ULIP") || productType.equalsIgnoreCase("COMBO")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
        String riderName, termCalcCode = "", pptCalcCode = "", pptApplicable = "", riderClass = "", query, planPayOptionCode, baseCT, riderDescription = "";
        int rowCounter = 0;
        List queryList;
        try {
            if (riderDetailsTable.size() > 0) {
                for (Object i : riderDetailsTable) {
                    obj = (JSONObject) i;
                    riderName = obj.get("Rider").toString();
                    termCalcCode = "";
                    pptCalcCode = "";
                    pptApplicable = "";
                    riderClass = "";
                    riderDescription = "";

                    query = "SELECT ISNULL(S.Term_Calc_Cd,''), ISNULL(S.PPT_Calc_Cd,''), ISNULL(S.PPT_APPLICABLE,''), ISNULL(R.Rider_Type,''), ISNULL(R.Rider_Desc,'') "
                            + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                            + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                            + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderName + "' and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";

                    queryList = getValFromQuery(query);
                    if (queryList != null) {
                        termCalcCode = (String) ((List) queryList.get(0)).get(0);
                        pptCalcCode = (String) ((List) queryList.get(0)).get(1);
                        pptApplicable = (String) ((List) queryList.get(0)).get(2);
                        riderClass = (String) ((List) queryList.get(0)).get(3);
                        riderDescription = (String) ((List) queryList.get(0)).get(4);

                    }

                    ifr.setTableCellValue("table37", rowCounter, 0, riderDescription);
                    ifr.setTableCellValue("table37", rowCounter, 8, termCalcCode);
                    ifr.setTableCellValue("table37", rowCounter, 10, pptApplicable);
                    ifr.setTableCellValue("table37", rowCounter, 11, pptCalcCode);
                    ifr.setTableCellValue("table37", rowCounter, 12, riderClass);

                    rowCounter++;
                }
            }

            planPayOptionCode = getPlanPayOptionCode();

            //If Plan_Pay_Option_Code is selected as RGLR in MDM then Premium payment term should be in freedzed mode having same value as Coverage Term.
            if (planPayOptionCode.equalsIgnoreCase("RGLR")) {
                baseCT = (String) ifr.getValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
                ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", baseCT);
                ifr.setStyle("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "disable", "true");
            }
        } catch (Exception e) {
            planPayOptionCode = "";
        }
        return planPayOptionCode;
    }

    public String uwSumAssuredChange(String rowIndex) {
        String errorMsg = "", riderSA, riderName, riderCode;
        double riderSumAssured;
        try {
            int rownum = Integer.parseInt(rowIndex);

            riderCode = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 0);
            riderName = getRiderBenefitDesc(riderCode);
            riderSA = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 1);
            riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);

            errorMsg = sumAssuredLogic(riderName, riderSumAssured, "UW", riderCode);
        } catch (Exception e) {
            errorMsg = "Error Occured in uwSumAssuredChange method " + e.toString();
        }
        return errorMsg;
    }

    public String uwCTChange(String rowIndex) {
        String errorMsg = "", riderCoverTerm, riderName, riderCode;
        try {
            int rownum = Integer.parseInt(rowIndex);

            riderCode = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 0);
            riderName = getRiderBenefitDesc(riderCode);
            riderCoverTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 6); //ok

            errorMsg = coverageTermLogic(riderName, riderCoverTerm, riderCode);
        } catch (Exception e) {
            errorMsg = "Error Occured in uwCTChange method " + e.toString();
        }
        return errorMsg;
    }

    public String uwPPTChange(String rowIndex) {
        String errorMsg = "", riderCoverTerm, riderName, ppt, riderCode;
        try {
            int rownum = Integer.parseInt(rowIndex);

            riderCode = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 0);
            riderName = getRiderBenefitDesc(riderCode);
            riderCoverTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 6);  //ok
            ppt = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", rownum, 7);  //ok

            errorMsg = premiumPaymentTermLogic(riderName, ppt, riderCoverTerm, "UW", riderCode);
        } catch (Exception e) {
            errorMsg = "Error Occured in uwCTChange method " + e.toString();
        }
        return errorMsg;
    }

    //On Clicking UW Review Calculate button
    public String uwReviewPreCalculateClick() {
        JSONArray riderDetailsTable;
        String uwDecision = (String) ifr.getControlValue("Decision");
        String plantype=(String) ifr.getControlValue("PLAN_TYPE");
        JSONObject obj;
        int size;
        double riderSumAssured = 0;
        String riderName, errorMsg = "", riderCoverTerm, riderCoverTermAsPerTermCalc, riderPPT, riderSA, riderCode;

        if (uwDecision.equalsIgnoreCase("Counter Offer") || uwDecision.equalsIgnoreCase("Counter Offer Accept")|| uwDecision.equalsIgnoreCase("CO Reconsider")) {
            riderDetailsTable = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");//Coverage Details Revised Table
            size = riderDetailsTable.size();
            if (size > 0) {
                if(plantype.equalsIgnoreCase("COMBO"))
                {
                    for (int i = 2; i < size; i++) {
                    obj = (JSONObject) riderDetailsTable.get(i);
                    riderCode = obj.get("Base Coverage (Plan Name)").toString();
                    riderName = getRiderBenefitDesc(riderCode);
                    riderSA = obj.get("Approved Sum Assured").toString();
                    riderCoverTerm = obj.get("Revised Coverage Term").toString();
                    riderPPT = obj.get("Revised Premium Payment Term").toString();

                    riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);

                    //riderCoverTerm = getRiderCT(riderName, "UW", riderCode);
                    riderCoverTermAsPerTermCalc = getRiderCT(riderName, "UW", riderCode);
                    if (!riderCoverTermAsPerTermCalc.isEmpty()) {
                        riderCoverTerm = riderCoverTermAsPerTermCalc;
                        ifr.setTableCellValue("COVERAGE_DETAILS_REVISED", i, 6, riderCoverTerm);  //ok
                    }

                    riderPPT = getRiderPPT(riderName, "UW", riderCode);
                    if (!riderPPT.equalsIgnoreCase("0")) {
                        ifr.setTableCellValue("COVERAGE_DETAILS_REVISED", i, 7, riderPPT);  //ok
                    }

                    errorMsg += insuredAgeLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += coverageTermLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += clientTypeLogic(riderName, riderCode);
                    errorMsg += effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate", riderCode);
                    errorMsg += sumAssuredLogic(riderName, riderSumAssured, "UW", riderCode);
                    errorMsg += premiumPaymentTermLogic(riderName, riderPPT, riderCoverTerm, "UW", riderCode);
                }
                }
                else
                {
                for (int i = 1; i < size; i++) {
                    obj = (JSONObject) riderDetailsTable.get(i);
                    riderCode = obj.get("Base Coverage (Plan Name)").toString();
                    riderName = getRiderBenefitDesc(riderCode);
                    riderSA = obj.get("Approved Sum Assured").toString();
                    riderCoverTerm = obj.get("Revised Coverage Term").toString();
                    riderPPT = obj.get("Revised Premium Payment Term").toString();

                    riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);

                    //riderCoverTerm = getRiderCT(riderName, "UW", riderCode);
                    riderCoverTermAsPerTermCalc = getRiderCT(riderName, "UW", riderCode);
                    if (!riderCoverTermAsPerTermCalc.isEmpty()) {
                        riderCoverTerm = riderCoverTermAsPerTermCalc;
                        ifr.setTableCellValue("COVERAGE_DETAILS_REVISED", i, 6, riderCoverTerm);  //ok
                    }

                    riderPPT = getRiderPPT(riderName, "UW", riderCode);
                    if (!riderPPT.equalsIgnoreCase("0")) {
                        ifr.setTableCellValue("COVERAGE_DETAILS_REVISED", i, 7, riderPPT);  //ok
                    }

                    errorMsg += insuredAgeLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += coverageTermLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += clientTypeLogic(riderName, riderCode);
                    errorMsg += effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate", riderCode);
                    errorMsg += sumAssuredLogic(riderName, riderSumAssured, "UW", riderCode);
                    errorMsg += premiumPaymentTermLogic(riderName, riderPPT, riderCoverTerm, "UW", riderCode);
                }
               }
            }
        } else {
            riderDetailsTable = ifr.getDataFromGrid("COVERAGE_DETAILS_APPLIED");//Coverage Details Applied Table
            size = riderDetailsTable.size();
            if (size > 0) {
                 if(plantype.equalsIgnoreCase("COMBO"))
                 {
                     for (int i = 2; i < size; i++) {
                    obj = (JSONObject) riderDetailsTable.get(i);
                    riderCode = obj.get("Base Coverage (Plan Name)").toString();
                    riderName = getRiderBenefitDesc(riderCode);
                    riderSA = obj.get("Applied Sum Assured").toString();
                    riderCoverTerm = obj.get("Coverage Term").toString();
                    riderPPT = obj.get("Premium Payment Term").toString();

                    riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);
                    
                    riderCoverTermAsPerTermCalc = getRiderCT(riderName, "UW_Applied", riderCode);
                    
                    if (!riderCoverTermAsPerTermCalc.isEmpty()) {
                        riderCoverTerm = riderCoverTermAsPerTermCalc;
                        ifr.setTableCellValue("COVERAGE_DETAILS_APPLIED", i, 8, riderCoverTerm);
                    }

                    riderPPT = getRiderPPT(riderName, "UW_Applied", riderCode);
                    if (!riderPPT.equalsIgnoreCase("0")) {
                        ifr.setTableCellValue("COVERAGE_DETAILS_APPLIED", i, 9, riderPPT);
                    }

                    errorMsg += insuredAgeLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += coverageTermLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += clientTypeLogic(riderName, riderCode);
                    errorMsg += effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate", riderCode);
                    errorMsg += sumAssuredLogic(riderName, riderSumAssured, "UW_Applied", riderCode);
                    errorMsg += premiumPaymentTermLogic(riderName, riderPPT, riderCoverTerm, "UW_Applied", riderCode);
                }
                 }
                 else
                 {
                for (int i = 1; i < size; i++) {
                    obj = (JSONObject) riderDetailsTable.get(i);
                    riderCode = obj.get("Base Coverage (Plan Name)").toString();
                    riderName = getRiderBenefitDesc(riderCode);
                    riderSA = obj.get("Applied Sum Assured").toString();
                    riderCoverTerm = obj.get("Coverage Term").toString();
                    riderPPT = obj.get("Premium Payment Term").toString();

                    riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);
                    
                    riderCoverTermAsPerTermCalc = getRiderCT(riderName, "UW_Applied", riderCode);
                    
                    if (!riderCoverTermAsPerTermCalc.isEmpty()) {
                        riderCoverTerm = riderCoverTermAsPerTermCalc;
                        ifr.setTableCellValue("COVERAGE_DETAILS_APPLIED", i, 8, riderCoverTerm);
                    }

                    riderPPT = getRiderPPT(riderName, "UW_Applied", riderCode);
                    if (!riderPPT.equalsIgnoreCase("0")) {
                        ifr.setTableCellValue("COVERAGE_DETAILS_APPLIED", i, 9, riderPPT);
                    }

                    errorMsg += insuredAgeLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += coverageTermLogic(riderName, riderCoverTerm, riderCode);
                    errorMsg += clientTypeLogic(riderName, riderCode);
                    errorMsg += effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate", riderCode);
                    errorMsg += sumAssuredLogic(riderName, riderSumAssured, "UW_Applied", riderCode);
                    errorMsg += premiumPaymentTermLogic(riderName, riderPPT, riderCoverTerm, "UW_Applied", riderCode);
                }
                 }
            }
        }
        return errorMsg;
    }

    public String uwReviewPostCalculateClick() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");//Coverage Details Revised Table
        String uwDecision = (String) ifr.getControlValue("Decision");
        JSONObject obj;
        int size = riderDetailsTable.size();
        String riderName, errorMsg = "", riderClass, wopSA, riderModalPrem, riderCode, riderPPT, riderCT;
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-23942 sparsh

        if (uwDecision.equalsIgnoreCase("Counter Offer") || uwDecision.equalsIgnoreCase("Counter Offer Accept")) {
            if (size > 0) {
                for (int i = 1; i < size; i++) {
                    obj = (JSONObject) riderDetailsTable.get(i);
                    riderCode = obj.get("Base Coverage (Plan Name)").toString();
                    riderName = getRiderBenefitDesc(riderCode);
                    riderModalPrem = obj.get("Revised Modal Premium").toString();
                    riderClass = getRiderFamily(riderName, riderCode);
                    riderPPT = obj.get("Revised Premium Payment Term").toString();
                    riderCT = obj.get("Revised Coverage Term").toString();
                    
                    if (riderClass.equalsIgnoreCase("WOP") || (riderClass.equalsIgnoreCase("WOP_Mandatory_Joint") && JointLife.equalsIgnoreCase("Y"))) { // Dr-23942 sparsh
                        wopSA = String.valueOf(getWOPSumAssured("UW"));
                        ifr.setTableCellValue("COVERAGE_DETAILS_REVISED", i, 1, wopSA);
                    }
                    
                    errorMsg += modalPremiumLogic(riderName, riderModalPrem, "UW", riderCode);
                    errorMsg += PPTLogic(riderCode, riderPPT, riderCT); // added by sparsh DR-50232
             
                }
            }
        }

        return errorMsg;
    }

    //On Clicking Calculate Button
    public String CalculateBtnClick() {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String riderName, errorMsg = "", riderCoverTerm, riderCoverTermAsPerTermCalc, riderPPT, riderSA, riderCode;
        double riderSumAssured = 0;

        int rowCounter = 0;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderCode = obj.get("Rider").toString();//returns rider code
                riderName = obj.get("Rider Type").toString();
                riderCoverTerm = obj.get("Coverage term").toString();
                riderPPT = obj.get("PPT").toString();
                //pptApplicable = obj.get("PPT_APPLICABLE").toString();
                riderSA = obj.get("Sum Assured").toString();
                //termCalcCode = obj.get("TermCalcCode").toString();
                //pptCalcCode = obj.get("PPT_CALC_CD").toString();

                riderCoverTermAsPerTermCalc = getRiderCT(riderName, "CoverageDetails", riderCode);
                //riderCoverTerm = getRiderCT(riderName, "CoverageDetails", riderCode);
                if (!riderCoverTermAsPerTermCalc.isEmpty()) {
                    riderCoverTerm = riderCoverTermAsPerTermCalc;
                    ifr.setTableCellValue("table37", rowCounter, 2, riderCoverTerm);
                }

                 String planCode = (String) ifr.getControlValue("PLAN_NAME");
                if((!(planCode.equalsIgnoreCase("UFISFL"))) && (!(planCode.equalsIgnoreCase("UFISFR"))) && (!(planCode.equalsIgnoreCase("UFINFL"))) && (!(planCode.equalsIgnoreCase("UFINFR"))))
                {
                    riderPPT = getRiderPPT(riderName, "CoverageDetails", riderCode);
                if (riderPPT.equalsIgnoreCase("0")) {
                    riderPPT = "";
                }
                
                ifr.setTableCellValue("table37", rowCounter, 9, riderPPT);
                }
                riderSumAssured = riderSA.isEmpty() ? 0 : Double.parseDouble(riderSA);

                errorMsg += insuredAgeLogic(riderName, riderCoverTerm, riderCode);
                errorMsg += coverageTermLogic(riderName, riderCoverTerm, riderCode);
                errorMsg += clientTypeLogic(riderName, riderCode);
                errorMsg += effectiveExpiryPlanLogic(riderName, "effectiveExpiryValidate", riderCode);
                errorMsg += sumAssuredLogic(riderName, riderSumAssured, "CoverageDetails", riderCode);
                errorMsg += premiumPaymentTermLogic(riderName, riderPPT, riderCoverTerm, "CoverageDetails", riderCode);

                rowCounter++;
            }
        }

        //errorMsg = validateInsuredAge();//Issue age and Expiry Age
        //errorMsg += validateCoverageTerm();//Coverage Term
        //errorMsg += validateClientType();//Client Type
        //errorMsg += validateEffectiveDate();//Effective and Expiry Date
        return errorMsg;
    }

    //Post Clicking Calculate Button
    public String PostCalculateBtnClick() {
        String riderName, errorMsg = "", riderModalPremium, riderClass, wopSA, riderCode, riderBenefitFlag,riderPPT,riderCT; //added by sparsh DR-50232
        //errorMsg = validateSumAssured();
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        int rowCounter = 0;
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-23942 sparsh
        //ifr.setTableCellValue("table37", 0, 4, "test");
        //ifr.setTableCellValue("table37", 0, 5, "test");

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderCode = obj.get("Rider").toString();//returns rider code
                riderName = obj.get("Rider Type").toString();
                riderModalPremium = obj.get("Modal Premium(INR)").toString();
                riderBenefitFlag = obj.get("RiderBenefit").toString();
                riderClass = getRiderFamily(riderName, riderCode);
                riderPPT = obj.get("PPT").toString();
                riderCT = obj.get("Coverage term").toString();

                if (riderClass.equalsIgnoreCase("WOP")) {
                    //wopSA = String.valueOf(getWOPSumAssured("CoverageDetails"));
                    Double SA=getWOPSumAssured("CoverageDetails");
                    SA=Math.round(SA*100.0)/100.0;
                    wopSA=String.valueOf(SA);  ///dR-7386
                    ifr.setTableCellValue("table37", rowCounter, 3, wopSA);
                }

                if (riderBenefitFlag.equalsIgnoreCase("R")) {
                	if(JointLife.equalsIgnoreCase("Y")) {
                		if(riderClass.equalsIgnoreCase("WOP_Mandatory_Joint")) {
                		  Double SA=getWOPSumAssured("CoverageDetails");
                          SA=Math.round(SA*100.0)/100.0;
                          wopSA=String.valueOf(SA);  ///dR-7386
                          ifr.setTableCellValue("table37", rowCounter, 3, wopSA);
                		} 
                	}
                	else
                       ifr.setTableCellValue("table37", rowCounter, 3, getMandatoryRiderSumAssured());
                }

                errorMsg += modalPremiumLogic(riderName, riderModalPremium, "CoverageDetails", riderCode);
                errorMsg += PPTLogic(riderCode, riderPPT, riderCT); // added by sparsh DR-50232
             
                rowCounter++;
            }

        }
        return errorMsg;
    }

    //When user selects new Rider from UI
    public void onRiderChangeFromModal() {
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String riderType = (String) ifr.getValue("table37_RIDER_TYPE");//returns riderCode
        String riderName = (String) ifr.getValue("table37_RIDER_DESC");
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE");
        String query, termCalcCode = "", pptCalcCode = "",
                riderCoverageTerm = "", riderPPT = "", disableCovTerm = "true",
                disablePPT = "true", pptApplicable = "", riderVisible = "false",
                riderClass = "", disableSumAssured = "false", baseATP, insuredFirstName, proposerFirstName;
        List queryList;
        double wopSumAssured = 0;

        if (clientType.equalsIgnoreCase("ProposerInsured")) {
            insuredFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
            proposerFirstName = insuredFirstName;
        } else {
            insuredFirstName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
            proposerFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
        }
           if (productType.equalsIgnoreCase("ULIP") || productType.equalsIgnoreCase("COMBO")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
        query = "SELECT ISNULL(S.Term_Calc_Cd,''), ISNULL(S.PPT_Calc_Cd,''), ISNULL(S.PPT_APPLICABLE,''), ISNULL(R.Rider_Type,'') "
                + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderType + "' and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            termCalcCode = (String) ((List) queryList.get(0)).get(0);
            pptCalcCode = (String) ((List) queryList.get(0)).get(1);
            pptApplicable = (String) ((List) queryList.get(0)).get(2);
            riderClass = (String) ((List) queryList.get(0)).get(3);

            riderCoverageTerm = getRiderCT(riderName, "CoverageDetails", riderType);
            ifr.setValue("table37_INSURED_DETAILS", insuredFirstName);

            if (pptApplicable.equalsIgnoreCase("Y")) {
                riderPPT = getRiderPPT(riderName, "CoverageDetails", riderType);
                riderVisible = "true";
                if (pptCalcCode.equalsIgnoreCase("RAN")) {
                    disablePPT = "false";
                }
            }

            if (termCalcCode.equalsIgnoreCase("RAN")) {
                disableCovTerm = "false";
            }
            if (riderClass.equalsIgnoreCase("WOP") || riderClass.equalsIgnoreCase("SUPR_WOP")) {
                if(riderClass.equalsIgnoreCase("WOP")){
                wopSumAssured = getWOPSumAssured("CoverageDetails");
                wopSumAssured = Math.round(wopSumAssured*100.0)/100.0; // added by lovnish 25 AUg23
                }
                ifr.setValue("table37_SUM_ASSURED", String.valueOf(wopSumAssured));
                ifr.setValue("table37_INSURED_DETAILS", proposerFirstName);
                //DR-23942 sparsh
                if(JointLife.equalsIgnoreCase("Y") && clientType.equalsIgnoreCase("Proposer") && (riderType.equalsIgnoreCase("VN06") || riderType.equalsIgnoreCase("VN07"))) {
                	 ifr.setValue("table37_INSURED_DETAILS", insuredFirstName);
                }
                disableSumAssured = "true";
            } else if (riderClass.equalsIgnoreCase("PARTNERCARE")) {
                baseATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP");
                String PLANTYPE=(String) ifr.getControlValue("PLAN_TYPE");
        if(PLANTYPE.equalsIgnoreCase("COMBO"))
        {
            baseATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP_COMBO");
            
        }
                ifr.setValue("table37_SUM_ASSURED", baseATP);
                disableSumAssured = "true";
            }
            else if (riderClass.equalsIgnoreCase("WOP_BENEFIT")) {
                baseATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP");
                 String PLANTYPE=(String) ifr.getControlValue("PLAN_TYPE");
        if(PLANTYPE.equalsIgnoreCase("COMBO"))
        {
            baseATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP_COMBO");
            
        }
                ifr.setValue("table37_SUM_ASSURED", baseATP);
                ifr.setValue("table37_INSURED_DETAILS", proposerFirstName);  //Dr 10585
                disableSumAssured = "true";
            }
            
          //DR-23942 sparsh
            if(JointLife.equalsIgnoreCase("Y") && !riderClass.equalsIgnoreCase("MANDATORY_JOINT") ) {
            	 ifr.setValue("table37_INSURED_DETAILS", proposerFirstName); 
            }
        }

        ifr.setValue("table37_COVERAGE_TERM", riderCoverageTerm);
        ifr.setValue("table37_TermCalcCode", termCalcCode);
        ifr.setStyle("table37_COVERAGE_TERM", "disable", disableCovTerm);

        ifr.setStyle("table37_PPT", "visible", riderVisible);
        ifr.setValue("table37_PPT", riderPPT);
        ifr.setStyle("table37_PPT", "disable", disablePPT);

        ifr.setValue("table37_PPT_APPLICABLE", pptApplicable);
        ifr.setValue("table37_PPT_CALC_CD", pptCalcCode);
        ifr.setValue("table37_RIDER_CLASS", riderClass);

        ifr.setStyle("table37_SUM_ASSURED", "disable", disableSumAssured);
        ifr.setStyle("table37_INSURED_DETAILS", "disable", "true");

        ifr.setValue("table37_MODAL_PREMIUM", "0");
        ifr.setValue("table37_GST", "0");

    }

    public String getValidRiders() {
        return effectiveExpiryPlanLogic("", "getAllRiders", "");
    }

    public void addInbuildRiderBenefit() {
    	String winame = (String) ifr.getControlValue("WorkItemName");
        ifr.clearTable("table37");
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String insuredFirstName, tableName = "NG_NB_MS_TRAD", query = "", benefit1,
                benefit2, termCalcCode = "", riderFromTable, riderMandatory, riderDesc = "",
                pptCalcCode = "", pptApplicable = "", riderClass = "", proposerFirstName=""; //DR-23942 sparsh
        
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-23942 sparsh
        
        if( ((String) ifr.getControlValue("PLAN_TYPE")).equalsIgnoreCase("JOINT"))
        {
        	tableName = "NG_NB_MS_JOINT";
        }
         if( ((String) ifr.getControlValue("PLAN_TYPE")).equalsIgnoreCase("ANNUITY"))
        {
        	tableName = "NG_NB_MS_ANNUITANT";
        }
         if( ((String) ifr.getControlValue("PLAN_TYPE")).equalsIgnoreCase("HEALTH"))
        {
        	tableName = "NG_NB_MS_HEALTH";
        }
        List queryList, descriptionList;
        JSONArray jsonArray = new JSONArray();

        if (clientType.equalsIgnoreCase("ProposerInsured")) {
            insuredFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
            proposerFirstName = insuredFirstName;  //DR-23942 sparsh
        } else {
            insuredFirstName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
            proposerFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME"); //DR-23942 sparsh
        }
          if (productType.equalsIgnoreCase("ULIP") || productType.equalsIgnoreCase("COMBO")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
        if (productType.equalsIgnoreCase("ULIP") ) {
            tableName = "NG_NB_MS_ULIP";
            query = "SELECT isnull(Benefit1,'') FROM NG_NB_MS_ULIP(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + "AND Sub_Channel='" + subChannel + "' AND Is_Active_Benefit1='Y' AND Is_Benefit1_Mandatory='Y'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                benefit1 = (String) ((List) queryList.get(0)).get(0);
                if (!benefit1.equalsIgnoreCase("")) {

                    query = "SELECT ISNULL(S.Term_Calc_Cd,''), ISNULL(S.PPT_Calc_Cd,''), ISNULL(S.PPT_APPLICABLE,''), ISNULL(R.Rider_Type,'') "
                            + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                            + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                            + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + benefit1 + "'and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";
                    queryList = getValFromQuery(query);
                    if (queryList != null) {
                        termCalcCode = (String) ((List) queryList.get(0)).get(0);
                        pptCalcCode = (String) ((List) queryList.get(0)).get(1);
                        pptApplicable = (String) ((List) queryList.get(0)).get(2);
                        riderClass = (String) ((List) queryList.get(0)).get(3);
                    }

                    //termCalcCode = getRiderTermCalcCode(benefit1);
                    riderDesc = getRiderBenefitDesc(benefit1);
                    JSONObject jsonObj = new JSONObject();
                    jsonObj.put("Rider Type", riderDesc);
                    jsonObj.put("Coverage term", "0");
                    jsonObj.put("Sum Assured", "0");
                    jsonObj.put("Modal Premium(INR)", "0");
                    jsonObj.put("GST", "0");
                    jsonObj.put("Rider Insured Details", insuredFirstName);
                    jsonObj.put("RiderBenefit", "B1");
                    jsonObj.put("TermCalcCode", termCalcCode);
                    jsonObj.put("Rider", benefit1);
                    jsonObj.put("PPT", "0");
                    jsonObj.put("PPT_APPLICABLE", pptApplicable);
                    jsonObj.put("PPT_CALC_CD", pptCalcCode);
                    jsonObj.put("RIDER_CLASS", riderClass);

                    jsonArray.add(jsonObj);
                    
                    
//debug 1 start              
                    
                String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                             + "VALUES('" + winame + "',GETDATE(),'" + benefit1 + "','CODE_INSERT_1_addInbuildRiderBenefit()')";
                             ifr.getDataFromDB(query1);
//debug 1 end 
                    
                }
//debug 2 start              
                
                String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                         + "VALUES('" + winame + "',GETDATE(),'" + jsonArray + "','array_CODE_INSERT_2_addInbuildRiderBenefit()')";
                         ifr.getDataFromDB(query1);
//debug 2 end                  
            }
              if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
            query = "SELECT isnull(Benefit2,'') FROM NG_NB_MS_ULIP(nolock) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                    + "AND Sub_Channel='" + subChannel + "' AND Is_Active_Benefit2='Y' AND Is_Benefit2_Mandatory='Y'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                benefit2 = (String) ((List) queryList.get(0)).get(0);
                if (!benefit2.equalsIgnoreCase("")) {
                    query = "SELECT ISNULL(S.Term_Calc_Cd,''), ISNULL(S.PPT_Calc_Cd,''), ISNULL(S.PPT_APPLICABLE,''), ISNULL(R.Rider_Type,'') "
                            + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                            + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                            + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + benefit2 + "' and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";
                    queryList = getValFromQuery(query);
                    if (queryList != null) {
                        termCalcCode = (String) ((List) queryList.get(0)).get(0);
                        pptCalcCode = (String) ((List) queryList.get(0)).get(1);
                        pptApplicable = (String) ((List) queryList.get(0)).get(2);
                        riderClass = (String) ((List) queryList.get(0)).get(3);
                    } else {
                        termCalcCode = "";
                        pptCalcCode = "";
                        pptApplicable = "";
                        riderClass = "";
                    }

                    //termCalcCode = getRiderTermCalcCode(benefit2);
                    riderDesc = getRiderBenefitDesc(benefit2);
                    JSONObject jsonObj = new JSONObject();
                    jsonObj.put("Rider Type", riderDesc);
                    jsonObj.put("Coverage term", "0");
                    jsonObj.put("Sum Assured", "0");
                    jsonObj.put("Modal Premium(INR)", "0");
                    jsonObj.put("GST", "0");
                    jsonObj.put("Rider Insured Details", insuredFirstName);
                    jsonObj.put("RiderBenefit", "B2");
                    jsonObj.put("TermCalcCode", termCalcCode);
                    jsonObj.put("Rider", benefit2);
                    jsonObj.put("PPT", "0");
                    jsonObj.put("PPT_APPLICABLE", pptApplicable);
                    jsonObj.put("PPT_CALC_CD", pptCalcCode);
                    jsonObj.put("RIDER_CLASS", riderClass);
                    jsonArray.add(jsonObj);
//debug 3 start              
                    
                String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                             + "VALUES('" + winame + "',GETDATE(),'" + benefit2 + "','CODE_INSERT_3_addInbuildRiderBenefit()')";
                             ifr.getDataFromDB(query1);
//debug 3 end
                }
//debug 4 start              
                
                String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                         + "VALUES('" + winame + "',GETDATE(),'" + jsonArray + "','array_CODE_INSERT_4_addInbuildRiderBenefit()')";
                         ifr.getDataFromDB(query1);
//debug 4 end                        
            }
        }
        query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
        //DR-49496 Nikita
        if (productType.equalsIgnoreCase("TRAD"))
        {
             query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101),\n"
                + "ISNULL(Riders11,''),ISNULL(Is_Active_Rider11,''),ISNULL(Is_Rider11_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider11_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider11_Effective_Plan,''),101),\n"
                + "ISNULL(Riders12,''),ISNULL(Is_Active_Rider12,''),ISNULL(Is_Rider12_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider12_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider12_Effective_Plan,''),101),\n"
                + "ISNULL(Riders13,''),ISNULL(Is_Active_Rider13,''),ISNULL(Is_Rider13_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider13_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider13_Effective_Plan,''),101),\n"
                + "ISNULL(Riders14,''),ISNULL(Is_Active_Rider14,''),ISNULL(Is_Rider14_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider14_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider14_Effective_Plan,''),101),\n"
                + "ISNULL(Riders15,''),ISNULL(Is_Active_Rider15,''),ISNULL(Is_Rider15_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider15_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider15_Effective_Plan,''),101),\n"
                + "ISNULL(Riders16,''),ISNULL(Is_Active_Rider16,''),ISNULL(Is_Rider16_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider16_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider16_Effective_Plan,''),101),\n"
                + "ISNULL(Riders17,''),ISNULL(Is_Active_Rider17,''),ISNULL(Is_Rider17_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider17_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider17_Effective_Plan,''),101),\n"
                + "ISNULL(Riders18,''),ISNULL(Is_Active_Rider18,''),ISNULL(Is_Rider18_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider18_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider18_Effective_Plan,''),101),\n"
                + "ISNULL(Riders19,''),ISNULL(Is_Active_Rider19,''),ISNULL(Is_Rider19_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider19_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider19_Effective_Plan,''),101),\n"
                + "ISNULL(Riders20,''),ISNULL(Is_Active_Rider20,''),ISNULL(Is_Rider20_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider20_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider20_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
        }
        
        if (productType.equalsIgnoreCase("ULIP"))
        {
             query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101),\n"
                + "ISNULL(Riders11,''),ISNULL(Is_Active_Rider11,''),ISNULL(Is_Rider11_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider11_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider11_Effective_Plan,''),101),\n"
                + "ISNULL(Riders12,''),ISNULL(Is_Active_Rider12,''),ISNULL(Is_Rider12_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider12_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider12_Effective_Plan,''),101),\n"
                + "ISNULL(Riders13,''),ISNULL(Is_Active_Rider13,''),ISNULL(Is_Rider13_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider13_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider13_Effective_Plan,''),101),\n"
                + "ISNULL(Riders14,''),ISNULL(Is_Active_Rider14,''),ISNULL(Is_Rider14_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider14_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider14_Effective_Plan,''),101),\n"
                + "ISNULL(Riders15,''),ISNULL(Is_Active_Rider15,''),ISNULL(Is_Rider15_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider15_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider15_Effective_Plan,''),101),\n"
                + "ISNULL(Riders16,''),ISNULL(Is_Active_Rider16,''),ISNULL(Is_Rider16_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider16_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider16_Effective_Plan,''),101),\n"
                + "ISNULL(Riders17,''),ISNULL(Is_Active_Rider17,''),ISNULL(Is_Rider17_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider17_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider17_Effective_Plan,''),101),\n"
                + "ISNULL(Riders18,''),ISNULL(Is_Active_Rider18,''),ISNULL(Is_Rider18_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider18_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider18_Effective_Plan,''),101),\n"
                + "ISNULL(Riders19,''),ISNULL(Is_Active_Rider19,''),ISNULL(Is_Rider19_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider19_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider19_Effective_Plan,''),101),\n"
                + "ISNULL(Riders20,''),ISNULL(Is_Active_Rider20,''),ISNULL(Is_Rider20_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider20_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider20_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
        }
         int limit=50;
           if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                 limit=100;
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
           
        queryList = getValFromQuery(query);
        if (queryList != null) {
            for (int j = 0; j < limit; j += 5) {
                riderFromTable = (String) ((List) queryList.get(0)).get(j);
                riderMandatory = (String) ((List) queryList.get(0)).get(j + 2);
                if (riderMandatory.equalsIgnoreCase("Y")) {
                    query = "SELECT ISNULL(S.Term_Calc_Cd,''), ISNULL(S.PPT_Calc_Cd,''), ISNULL(S.PPT_APPLICABLE,''), ISNULL(R.Rider_Type,'') "
                            + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                            + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                            + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderFromTable + "' and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";
                    descriptionList = getValFromQuery(query);
                    if (descriptionList != null) {
                        termCalcCode = (String) ((List) descriptionList.get(0)).get(0);
                        pptCalcCode = (String) ((List) descriptionList.get(0)).get(1);
                        pptApplicable = (String) ((List) descriptionList.get(0)).get(2);
                        riderClass = (String) ((List) descriptionList.get(0)).get(3);
                    } else {
                        termCalcCode = "";
                        pptCalcCode = "";
                        pptApplicable = "";
                        riderClass = "";
                    }
                  
                    //termCalcCode = getRiderTermCalcCode(riderFromTable);
                    riderDesc = getRiderBenefitDesc(riderFromTable);
                    JSONObject jsonObj = new JSONObject();
                    jsonObj.put("Rider Type", riderDesc);
                    jsonObj.put("Coverage term", "0");
                    jsonObj.put("Sum Assured", "0");
                    jsonObj.put("Modal Premium(INR)", "0");
                    jsonObj.put("GST", "0");
                   // DR-23942 sparsh
                    if(JointLife.equalsIgnoreCase("Y") && !riderClass.equalsIgnoreCase("MANDATORY_JOINT")){
                    	jsonObj.put("Rider Insured Details", proposerFirstName);
                    }else {
                    	jsonObj.put("Rider Insured Details", insuredFirstName);
                    }
                    jsonObj.put("RiderBenefit", "R");
                    jsonObj.put("TermCalcCode", termCalcCode);
                    jsonObj.put("Rider", riderFromTable);
                    jsonObj.put("PPT", "0");
                    jsonObj.put("PPT_APPLICABLE", pptApplicable);
                    jsonObj.put("PPT_CALC_CD", pptCalcCode);
                    jsonObj.put("RIDER_CLASS", riderClass);
                    jsonArray.add(jsonObj);
// debug 5 start             
                    
                 String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                             + "VALUES('" + winame + "',GETDATE(),'" + riderFromTable + "','INSERT_5_addInbuildRiderBenefit()')";
                             ifr.getDataFromDB(query1);
// debug 5 end                
                    
                }
                
// ---debug 6 start
                
                
                String query1 = "INSERT INTO NG_NB_RIDER_DEBUG_28APR(WI_NAME,ENTRY_DATE_TIME,RIDERS_DETAILS,INSERTCOMMENT)\n"
                         + "VALUES('" + winame + "',GETDATE(),'" + jsonArray + "','array_INSERT_6_addInbuildRiderBenefit()')";
                         ifr.getDataFromDB(query1);   
                       
//----debug 6  end
            }
        }

        ifr.addDataToGrid("table37", jsonArray);
        
       

    }

    //Returns SumAssured of WOP Rider
    private double getWOPSumAssured(String section) {
        JSONArray riderDetailsTable = new JSONArray();
        JSONObject obj;
        String riderClass, modalPremium, riderName, baseModalPremium = "0", riderType = "", modalPrem = "", riderCodeKey = "", riderCode;
        double basePremium = 0, riderModalPremium = 0, returnVal = 0,totalriderpremium=0;
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-23942 sparsh
        int rowCounter = 1;
        try {
            if (section.equalsIgnoreCase("CoverageDetails")) {
                baseModalPremium = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
                riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
                riderType = "Rider Type";
                modalPrem = "Modal Premium(INR)";
                riderCodeKey = "Rider";
            } else if (section.equalsIgnoreCase("UW")) {
                baseModalPremium = ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 4);  //ok
                riderDetailsTable = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");//Rider Details Table
                riderType = "Base Coverage (Plan Name)";
                modalPrem = "Revised Modal Premium";
                riderCodeKey = riderType;
            }
             basePremium = baseModalPremium.isEmpty() ? 0 : Double.parseDouble(baseModalPremium); //DR-7404
            if (riderDetailsTable.size() > 0) {
               

                for (Object i : riderDetailsTable) {
                    obj = (JSONObject) i;
                    riderCode = obj.get(riderCodeKey).toString();
                    riderName = obj.get(riderType).toString();
                    modalPremium = obj.get(modalPrem).toString();
                    if (section.equalsIgnoreCase("UW")) {
                        if (rowCounter == 1) {
                            rowCounter++;
                            continue;
                        }
                        riderName = getRiderBenefitDesc(riderName);
                    }
                    riderClass = getRiderFamily(riderName, riderCode);
                    if(JointLife.equalsIgnoreCase("Y") && !riderClass.equalsIgnoreCase("WOP") && !riderClass.equalsIgnoreCase("WOP_Mandatory_Joint")) {
                    	riderModalPremium += modalPremium.isEmpty() ? 0 : Double.parseDouble(modalPremium);
                    }
                    else if (!riderClass.equalsIgnoreCase("COVID") && !riderClass.equalsIgnoreCase("WOP")) {
                        riderModalPremium += modalPremium.isEmpty() ? 0 : Double.parseDouble(modalPremium);
                    }
                    rowCounter++;
                }
                
            }
            returnVal = basePremium + riderModalPremium;
        } catch (Exception e) {
            returnVal = 0;
        }

        return returnVal;
    }

    private String getMandatoryRiderSumAssured() {
        String baseModalPremium = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM");
        String ATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP");
         String PLANTYPE=(String) ifr.getControlValue("PLAN_TYPE");
        if(PLANTYPE.equalsIgnoreCase("COMBO"))
        {
            ATP = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP_COMBO");
            
        }

        if (productType.equalsIgnoreCase("ULIP") || productType.equalsIgnoreCase("COMBO")) {
            return ATP;
        } else {
            return baseModalPremium;
        }

    }

//Get CT of rider based of CTCalc Code
    private String getRiderCT(String riderName, String section, String riderCode) {
        String query, riderCoverageTerm = "", mimterm = "", maxterm = "", termLogicCode = "", maxExpiry = "0", termCalcCode = "",
                baseCoverageTerm = "0", basePPT = "0";
        List queryList;
        int intBasePPT, intBaseCT, insuredAge, riderMaxTerm = 0, intMaxExpiry = 0;
        String PLANTYPE = (String) ifr.getControlValue("PLAN_TYPE");
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE");  //DR-28247 sparsh

        try {
            if (section.equalsIgnoreCase("CoverageDetails")) {
                if(PLANTYPE.equalsIgnoreCase("COMBO"))
                {
                     baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
                     basePPT = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_PPT");
                }
                else
                {
                baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
                basePPT = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
                }
            } else if (section.equalsIgnoreCase("UW")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 6);
                basePPT = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 7);
            } else if (section.equalsIgnoreCase("UW_Applied")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 8);
                basePPT = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 9);       //ok
            }
               if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
            query = "SELECT ISNULL(S.Term_Calc_Cd,''),ISNULL(S.Minimum_Term,'0'), ISNULL(S.Maximum_Term,0), ISNULL(S.Term_CalC_Code,''),ISNULL(S.Maximum_Expiry_Age,0) "
                    + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between"
                            + " rider_effective_Date and rider_expiry_Date ";

            queryList = getValFromQuery(query);
            if (queryList != null) {
                termCalcCode = (String) ((List) queryList.get(0)).get(0);
                mimterm = (String) ((List) queryList.get(0)).get(1);
                maxterm = (String) ((List) queryList.get(0)).get(2);
                termLogicCode = (String) ((List) queryList.get(0)).get(3);
                maxExpiry = (String) ((List) queryList.get(0)).get(4);

                if (termCalcCode.equalsIgnoreCase("CT")) {
                    riderCoverageTerm = baseCoverageTerm;
                } else if (termCalcCode.equalsIgnoreCase("PPT")) {
                    riderCoverageTerm = basePPT;
                } else if (termCalcCode.equalsIgnoreCase("RAN")) {
                    riderCoverageTerm = "";
                } else if (termCalcCode.equalsIgnoreCase("CALC")) {
                    intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
                    intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
                    insuredAge = calculateInsuredAge();
                    
                    if (termLogicCode.equalsIgnoreCase("A")) {
                        riderMaxTerm = maxterm.isEmpty() ? 0 : Integer.parseInt(maxterm);
                    } else if (termLogicCode.equalsIgnoreCase("C")) {
                        String[] multipleTerm = mimterm.split(",", -1);
                        int ctVal = 0;
                        for (String CT : multipleTerm) {
                            ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
                            if (ctVal > riderMaxTerm) {
                                riderMaxTerm = ctVal;
                            }
                        }
                    }
                    
                     intMaxExpiry = maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
                    //riderCoverageTerm = String.valueOf(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - insuredAge));   //EXPIRY- CHANGES BY AANCHAL for 7404
                   //DR-28247 sparsh
                     if(JointLife.equalsIgnoreCase("Y")) {
                    	insuredAge = calculateProposerAge();
                     }
                     riderCoverageTerm = String.valueOf(Math.min(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - insuredAge),riderMaxTerm));
                } 
                else if (termCalcCode.equalsIgnoreCase("PCALC")) {
                    intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
                    intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
                    insuredAge = calculateProposerAge();
                    
                    if (termLogicCode.equalsIgnoreCase("A")) {
                        riderMaxTerm = maxterm.isEmpty() ? 0 : Integer.parseInt(maxterm);
                    } else if (termLogicCode.equalsIgnoreCase("C")) {
                        String[] multipleTerm = mimterm.split(",", -1);
                        int ctVal = 0;
                        for (String CT : multipleTerm) {
                            ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
                            if (ctVal > riderMaxTerm) {
                                riderMaxTerm = ctVal;
                            }
                        }
                    }
                    
                     intMaxExpiry = maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
                    //riderCoverageTerm = String.valueOf(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - insuredAge));   //EXPIRY- CHANGES BY AANCHAL for 7404
                    riderCoverageTerm = String.valueOf(Math.min(Math.min(Math.min(intBasePPT, intBaseCT), intMaxExpiry - insuredAge),riderMaxTerm));
                } 
                else if (termCalcCode.equalsIgnoreCase("CTCALC")) {
                    intBaseCT = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
                    intMaxExpiry = maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
                    insuredAge = calculateInsuredAge();

                    if (termLogicCode.equalsIgnoreCase("A")) {
                        riderMaxTerm = maxterm.isEmpty() ? 0 : Integer.parseInt(maxterm);
                    } else if (termLogicCode.equalsIgnoreCase("C")) {
                        String[] multipleTerm = mimterm.split(",", -1);
                        int ctVal = 0;
                        for (String CT : multipleTerm) {
                            ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
                            if (ctVal > riderMaxTerm) {
                                riderMaxTerm = ctVal;
                            }
                        }
                    }
                    //DR-28247 sparsh
                    if(JointLife.equalsIgnoreCase("Y")){
                    	 insuredAge = calculateProposerAge();
                    }
                    	 riderCoverageTerm = String.valueOf(Math.min(Math.min(intBaseCT, riderMaxTerm), intMaxExpiry - insuredAge));
               }
            }
        } catch (Exception e) {
            riderCoverageTerm = "0";
        }
        return riderCoverageTerm;
    }

    //Get CT of rider based of CTCalc Code
    private String getRiderPPT(String riderName, String section, String riderCode) {
        String query, riderPPT = "0", mimterm = "", maxterm = "", termLogicCode = "", maxExpiry = "0",
                pptCalcCode = "", pptApplicable = "", baseCoverageTerm = "0", basePPT = "0";
        List queryList;
        int intBasePPT, insuredAge, riderMaxTerm = 0, intMaxExpiry = 0;
        String PLANTYPE = (String) ifr.getControlValue("PLAN_TYPE");
        try {

            if (section.equalsIgnoreCase("CoverageDetails")) {
                if(PLANTYPE.equalsIgnoreCase("COMBO"))
                {
                    baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
                    basePPT = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_PPT");
                }
               else
                {
                baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
                basePPT = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
                }
            } else if (section.equalsIgnoreCase("UW")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 6);
                basePPT = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 7);
            } else if (section.equalsIgnoreCase("UW_Applied")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 8);
                basePPT = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 9);
            }
               if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }

            query = "SELECT ISNULL(S.PPT_Calc_Cd,''),ISNULL(S.Minimum_PPT,'0'), ISNULL(S.Maximum_PPT,0), ISNULL(S.PPT_Cal_Logic_Code,''),ISNULL(S.Maximum_Expiry_Age,0),ISNULL(S.PPT_APPLICABLE,'') "
                    + "FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between " 
                    + " rider_effective_Date and rider_expiry_Date ";

            queryList = getValFromQuery(query);
            if (queryList != null) {
                pptCalcCode = (String) ((List) queryList.get(0)).get(0);
                mimterm = (String) ((List) queryList.get(0)).get(1);
                maxterm = (String) ((List) queryList.get(0)).get(2);
                termLogicCode = (String) ((List) queryList.get(0)).get(3);
                maxExpiry = (String) ((List) queryList.get(0)).get(4);
                pptApplicable = (String) ((List) queryList.get(0)).get(5);

                if (pptApplicable.equalsIgnoreCase("Y")) {
                    if (pptCalcCode.equalsIgnoreCase("CT")) {
                        riderPPT = baseCoverageTerm;
                    } else if (pptCalcCode.equalsIgnoreCase("PPT")) {
                        riderPPT = basePPT;
                    } else if (pptCalcCode.equalsIgnoreCase("RAN")) {
                        riderPPT = "";
                    } else if (pptCalcCode.equalsIgnoreCase("CTCALC")) {
                        intBasePPT = basePPT.isEmpty() ? 0 : Integer.parseInt(basePPT);
                        intMaxExpiry = maxExpiry.isEmpty() ? 0 : Integer.parseInt(maxExpiry);
                        insuredAge = calculateInsuredAge();

                        if (termLogicCode.equalsIgnoreCase("A")) {
                            String[] multipleTerm = mimterm.split(",", -1);
                            int ctVal = 0;
                            for (String CT : multipleTerm) {
                                ctVal = CT.isEmpty() ? 0 : Integer.parseInt(CT);
                                if (ctVal > riderMaxTerm) {
                                    riderMaxTerm = ctVal;
                                }
                            }
                        } else if (termLogicCode.equalsIgnoreCase("G")) {
                            riderMaxTerm = maxterm.isEmpty() ? 0 : Integer.parseInt(maxterm);
                        }

                        riderPPT = String.valueOf(Math.min(intBasePPT, Math.min(intMaxExpiry - insuredAge, riderMaxTerm)));
                    }
                }

            }
        } catch (Exception e) {
            riderPPT = "0";
        }
        return riderPPT;
    }

    //Logic to check Two riders of same family type cannot be added in one policy
    private String riderFamilyLogic(String currRiderName, String riderClass) {
        JSONArray riderDetailsTable = ifr.getDataFromGrid("table37");//Rider Details Table
        JSONObject obj;
        String errorMsg = "", riderFamily, riderName;

        if (riderDetailsTable.size() > 0) {
            for (Object i : riderDetailsTable) {
                obj = (JSONObject) i;
                riderName = obj.get("Rider Type").toString();
                riderFamily = obj.get("RIDER_CLASS").toString();
                if (riderFamily.equalsIgnoreCase(riderClass) && !currRiderName.equalsIgnoreCase(riderName) && !riderFamily.equalsIgnoreCase("")) {
                    errorMsg = "Two riders of same rider type should not be selected in one policy!";
                    break;
                }
            }
        }
        return errorMsg;
    }

    //Business Logic for Client Type
    private String clientTypeLogic(String riderName, String riderCode) {
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String JointLife = (String) ifr.getControlValue("IS_JOINTLIFE"); //DR-23942 sparsh
        String query, riderClientType, matchFlag = "N", errorMsg = "";
           if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
        List ClientTypeList;
        try {
            query = "SELECT ISNULL(S.Client_Type,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)"
                    + " INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between" 
                                              + " rider_effective_Date and rider_expiry_Date ";

            ClientTypeList = getValFromQuery(query);
            if (ClientTypeList != null) {
                riderClientType = (String) ((List) ClientTypeList.get(0)).get(0);
                String[] clientTypeArr = riderClientType.split(",");

                for (String client : clientTypeArr) { // DR-23942 sparsh
                    if ((clientType.equalsIgnoreCase(client.trim())) || (JointLife.equalsIgnoreCase("Y") && clientType.equalsIgnoreCase("Proposer") && (riderCode.equalsIgnoreCase("VN06") || riderCode.equalsIgnoreCase("VN07")))) {
                        matchFlag = "Y";
                    }
                 }
                if (matchFlag.equalsIgnoreCase("N")) {
                    errorMsg = riderName + " - Applicable Client Type is/are " + riderClientType + "!";
                }
            }
        } catch (Exception e) {
            errorMsg = "Error in clientTypeLogic Method " + e.toString();
        }
        return errorMsg;
    }

    //Business Logic for valdating Sum
    private String sumAssuredLogic(String riderName, double sumAssured, String section, String riderCode) {
        String query;
        List sumAssuredList;
        String minIssueAmount, maxIssueAmount, returnMessage = "", interval, querySelector = "", riderClass, baseSumAssured = "0";
        double minimumIssueAmount, maximumIssueAmount, intervalValue, baseSA = 0;
        String newlogic="";
        double maxSA=0.0;
        
        String exactIncome=(String) ifr.getControlValue("Q_PROPOSER_DETAILS.EXACT_INCOME");

        try {
            if (section.equalsIgnoreCase("CoverageDetails")) {
                baseSumAssured = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SUM_ASSURED");
                querySelector = "ISNULL(S.Min_Issue_Amount,0),ISNULL(S.Max_Issue_Amount,0)";
            } else if (section.equalsIgnoreCase("UW")) {
                baseSumAssured = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 1);
                querySelector = "ISNULL(S.UW_Minimum_Issue_Amount,0),ISNULL(S.UW_Maximum_Issue_Amount,0)";
            } else if (section.equalsIgnoreCase("UW_Applied")) {
                baseSumAssured = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 2);
                querySelector = "ISNULL(S.UW_Minimum_Issue_Amount,0),ISNULL(S.UW_Maximum_Issue_Amount,0)";
            }
                
              if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
              String query1="";
              if (productType.equalsIgnoreCase("ULIP"))
              {
                   query1 = "select RIDER_MAX_SA_LOGIC from NG_NB_MS_ULIP(nolock) WHere Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "' AND PLAN_CODE='" + planCode + "' ";

                   Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, query1, query1);
                     List RiderMaxlogic= getValFromQuery(query1);
                     
                     if (RiderMaxlogic != null)
                     {
                       String  riderLogic = (String) ((List) RiderMaxlogic.get(0)).get(0);
                         //aaan1234 
                         String[] riderLogicArr = riderLogic.split(",");
                        for (String term : riderLogicArr) 
                        {
                            if (term.equalsIgnoreCase(riderCode)) {
                                
                                String query2 = "SELECT ISNULL(S.RIDER_MAX_SA_LOGIC_CODE,0),ISNULL(S.RIDER_MAX_SA_FORMULA_VALUES,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";
                             List RiderMaxlogic1 = getValFromQuery(query2);
                             
                              Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, query2, query2);
                                  if (RiderMaxlogic1 != null) {
                                      
                                       String RIDER_MAX_SA_LOGIC_CODE = (String) ((List) RiderMaxlogic1.get(0)).get(0);
                                      String RIDER_MAX_SA_FORMULA_VALUES = (String) ((List) RiderMaxlogic1.get(0)).get(1);
                                          Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, RIDER_MAX_SA_LOGIC_CODE, RIDER_MAX_SA_LOGIC_CODE);
                                      
                                      if (RIDER_MAX_SA_LOGIC_CODE.equalsIgnoreCase("LEIBSA")) {
                                          newlogic="Y";
                                           String[] riderLogicVALUES = RIDER_MAX_SA_FORMULA_VALUES.split(",");
                                          
                                           String firstValue= riderLogicVALUES[0];
                                           String secondValue= riderLogicVALUES[1];
                                           
                                           double FV = Double.parseDouble(firstValue);
                                           double SV = Double.parseDouble(secondValue);
                                           double EI=Double.parseDouble(exactIncome);
                                           
                                            baseSA = baseSumAssured.isEmpty() ? 0 : Double.parseDouble(baseSumAssured);
                                             baseSA = SV * baseSA / 100;
                                             
                                             EI=FV * EI;
                                                     Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE,String.valueOf("aan122"), String.valueOf("aan122"));
                                              Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE,String.valueOf(EI), String.valueOf(EI));
                                                   Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE,String.valueOf(baseSA), String.valueOf(baseSA));
                                             Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE,String.valueOf(SV), String.valueOf(SV));
                                             
                                             maxSA=Math.min(baseSA, EI); 
                                      }
                                      
                                      
                                  }



                            }
                        }
                     }
              }
            query = "SELECT " + querySelector + ",ISNULL(S.Interval,0),ISNULL(R.Rider_Type,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";
            sumAssuredList = getValFromQuery(query);

            if (sumAssuredList != null) {
                minIssueAmount = (String) ((List) sumAssuredList.get(0)).get(0);
                maxIssueAmount = (String) ((List) sumAssuredList.get(0)).get(1);
                interval = (String) ((List) sumAssuredList.get(0)).get(2);
                riderClass = (String) ((List) sumAssuredList.get(0)).get(3);

                minimumIssueAmount = Double.parseDouble(minIssueAmount);
                maximumIssueAmount = Double.parseDouble(maxIssueAmount);
                intervalValue = Double.parseDouble(interval);

                if (riderClass.equalsIgnoreCase("CI")) {
                    baseSA = baseSumAssured.isEmpty() ? 0 : Double.parseDouble(baseSumAssured);
                    baseSA = 50 * baseSA / 100;
                    maximumIssueAmount = Math.min(baseSA, maximumIssueAmount);  //modified by aanchal for 1077272
                    
                      
                }
                if (newlogic.equalsIgnoreCase("Y")) {
                          maximumIssueAmount=maxSA;
                          
                      }
                
                if(maximumIssueAmount == 0 ||  maximumIssueAmount == 0.0)
                {
                    returnMessage="Max Issue is 0"; 
                    return returnMessage;
                }
                if (sumAssured < minimumIssueAmount || sumAssured > maximumIssueAmount) {
                    returnMessage = riderName + " - Issue amount should be between " + minIssueAmount + " and " + String.format("%.2f",maximumIssueAmount) + "!";
                }
                
                if (intervalValue != 0) {
                    if (sumAssured % intervalValue != 0) {
                        returnMessage += riderName + " - Issue amount should be multiple of " + interval + "!";
                    }
                }
            }
        } catch (Exception e) {
            returnMessage = "Error Occured in sumAssuredLogic method " + e.toString();
        }
        return returnMessage;
    }

    //Business Logic for Modal Premium
    private String modalPremiumLogic(String riderName, String riderModalPremium, String section, String riderCode) {
        String query = "", fromClause, minVal, maxVal, querySelector = "", errorMsg = "";
        double riderModalValue, minimumValue, maximumValue;
        List modalList;

        try {
            riderModalPremium = riderModalPremium.isEmpty() ? "0" : riderModalPremium;

            String modeofPayment = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");

            riderModalValue = Double.parseDouble(riderModalPremium);
            
              if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }

            fromClause = " FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";

            switch (section + modeofPayment) {
                case "CoverageDetails12":
                    querySelector = "SELECT ISNULL(S.Minimum_Annual_Premium,0), ISNULL(S.Maximum_Annual_Premium,0)";
                    break;
                case "CoverageDetails06":
                    querySelector = "SELECT ISNULL(S.Minimum_Semi_Annual_Premium,0), ISNULL(S.Maximum_Semi_Annual_Premium,0)";
                    break;
                case "CoverageDetails03":
                    querySelector = "SELECT ISNULL(S.Minimum_Quarterly_Premium,0), ISNULL(S.Maximum_Quarterly_Premium,0)";
                    break;
                case "CoverageDetails01":
                    querySelector = "SELECT ISNULL(S.Minimum_Monthly_Premium,0), ISNULL(S.Maximum_Monthly_Premium,0)";
                    break;
                case "UW12":
                    querySelector = "SELECT ISNULL(S.UW_Minimum_Annual_Premium,0), ISNULL(S.UW_Maximum_Annual_Premium,0)";
                    break;
                case "UW06":
                    querySelector = "SELECT ISNULL(S.UW_Minimum_Semi_Annual_Premium,0), ISNULL(S.UW_Maximum_Semi_Annual_Premium,0)";
                    break;
                case "UW03":
                    querySelector = "SELECT ISNULL(S.UW_Minimum_Quarterly_Premium,0), ISNULL(S.UW_Maximum_Quarterly_Premium,0)";
                    break;
                case "UW01":
                    querySelector = "SELECT ISNULL(S.UW_Minimum_Monthly_Premium,0), ISNULL(S.UW_Maximum_Monthly_Premium,0)";
                    break;
            }
            query = querySelector + fromClause;
            modalList = getValFromQuery(query);
            if (modalList != null) {
                minVal = (String) ((List) modalList.get(0)).get(0);
                maxVal = (String) ((List) modalList.get(0)).get(1);
                minimumValue = Double.parseDouble(minVal);
                maximumValue = Double.parseDouble(maxVal);

                if (riderModalValue < minimumValue || riderModalValue > maximumValue) {
                    errorMsg = riderName + " -Modal Premium should be between " + minVal + " and " + maxVal + "!";
                }
            }
        } catch (Exception e) {
            errorMsg = "Error Occured in modalPremiumLogic " + e.toString();
        }
        return errorMsg;
    }

    //Business Logic for Insured/Expiry Age
    private String insuredAgeLogic(String riderName, String riderCoverageTerm, String riderCode) {
        String query, minIssueAge, maxIssueAge, minExpiryAge, maxExpiryAge, returnMessage = "";
        int minimumIssueAge, maximumIssueAge, minimumExpiryAge, maximumExpiryAge, expiryAge, insuredAge;
        List queryList;

        try {
            riderCoverageTerm = riderCoverageTerm.isEmpty() ? "0" : riderCoverageTerm;

            insuredAge = calculateInsuredAge();
              if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
            query = "SELECT ISNULL(S.Min_Issue_Age,0),ISNULL(S.Max_Issue_Age,0),ISNULL(S.Minimum_Expiry_Age,0),ISNULL(S.Maximum_Expiry_Age,0),ISNULL(Term_Calc_Cd,'') AS 'Term_Calc_Cd' FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";

            expiryAge = insuredAge + Integer.parseInt(riderCoverageTerm);

            queryList = getValFromQuery(query);
            if (queryList != null) {
                minIssueAge = (String) ((List) queryList.get(0)).get(0);
                maxIssueAge = (String) ((List) queryList.get(0)).get(1);
                minExpiryAge = (String) ((List) queryList.get(0)).get(2);
                maxExpiryAge = (String) ((List) queryList.get(0)).get(3);
                String termclacd=(String) ((List) queryList.get(0)).get(4);

                minimumIssueAge = Integer.parseInt(minIssueAge);
                maximumIssueAge = Integer.parseInt(maxIssueAge);
                minimumExpiryAge = Integer.parseInt(minExpiryAge);
                maximumExpiryAge = Integer.parseInt(maxExpiryAge);
                
                if(termclacd.equalsIgnoreCase("PCALC"))
                {
                    insuredAge=calculateProposerAge();
                    expiryAge = insuredAge + Integer.parseInt(riderCoverageTerm);
                }

                if (insuredAge < minimumIssueAge || insuredAge > maximumIssueAge) {
                    returnMessage = riderName + " - Issue Age should be between " + minIssueAge + " and " + maxIssueAge + " !";
                }
                if (expiryAge < minimumExpiryAge || expiryAge > maximumExpiryAge) {
                    returnMessage += riderName + " - Expiry Age should be between " + minExpiryAge + " and " + maxExpiryAge + " !";
                }
            } else {
                returnMessage = riderName + " - Min/Max Issue/Expiry age not found in DB!";
            }
        } catch (Exception e) {
            returnMessage = "Error Occured in insuredAgeLogic Method " + e.toString();
        }
        return returnMessage;
    }

    //Business Logic for Effective/Expiry Age
    private String effectiveExpiryPlanLogic(String riderName, String caseFlag, String riderCode) {
        String query, tableName = "NG_NB_MS_TRAD", riderFromTable, Rider_Expiry_Plan, Rider1_Effective_Plan, returnMessage = "", productDating = "";
        Date riderExpiry, riderEffective;
        List queryList, riderCodeList;
        Date customerSign, effectiveDate;
        

        try {

            String effectiveDateOfCoverage = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
            String customerSigndate = (String) ifr.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");

            if (productType.equalsIgnoreCase("ULIP")) {
                tableName = "NG_NB_MS_ULIP";
            }
            if (productType.equalsIgnoreCase("JOINT")) {
                tableName = "NG_NB_MS_JOINT";
            }
            if (productType.equalsIgnoreCase("ANNUITY")) {
                tableName = "NG_NB_MS_ANNUITANT";
            }
           if (productType.equalsIgnoreCase("HEALTH")) 
        {
        	tableName = "NG_NB_MS_HEALTH";
        }if (productType.equalsIgnoreCase("COMBO")) 
        {
        	tableName = "NG_NB_MS_COMBO";
        }

            try {
                customerSign = new SimpleDateFormat("yyyy-MM-dd").parse(customerSigndate);
            } catch (ParseException ex) {
                Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
                customerSign = new Date();
            }

            productDating = getProductDating();
            if (productDating.equalsIgnoreCase("")) {
                returnMessage = "Please update Product Dating corresponding to this Product! ";
            }

            if (productDating.equalsIgnoreCase("CD")) {
                effectiveDate = new Date();
            } else {
                try {
                    effectiveDate = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDateOfCoverage);
                } catch (ParseException ex) {
                    Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
                    effectiveDate = new Date();
                }
            }

            query = "SELECT \n"
                    + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                    + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101)\n"
                    + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                    + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
         int limit=50; 
        //DR-49496 Nikita
        if (productType.equalsIgnoreCase("TRAD"))
        {
             query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101),\n"
                + "ISNULL(Riders11,''),ISNULL(Is_Active_Rider11,''),ISNULL(Is_Rider11_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider11_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider11_Effective_Plan,''),101),\n"
                + "ISNULL(Riders12,''),ISNULL(Is_Active_Rider12,''),ISNULL(Is_Rider12_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider12_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider12_Effective_Plan,''),101),\n"
                + "ISNULL(Riders13,''),ISNULL(Is_Active_Rider13,''),ISNULL(Is_Rider13_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider13_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider13_Effective_Plan,''),101),\n"
                + "ISNULL(Riders14,''),ISNULL(Is_Active_Rider14,''),ISNULL(Is_Rider14_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider14_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider14_Effective_Plan,''),101),\n"
                + "ISNULL(Riders15,''),ISNULL(Is_Active_Rider15,''),ISNULL(Is_Rider15_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider15_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider15_Effective_Plan,''),101),\n"
                + "ISNULL(Riders16,''),ISNULL(Is_Active_Rider16,''),ISNULL(Is_Rider16_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider16_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider16_Effective_Plan,''),101),\n"
                + "ISNULL(Riders17,''),ISNULL(Is_Active_Rider17,''),ISNULL(Is_Rider17_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider17_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider17_Effective_Plan,''),101),\n"
                + "ISNULL(Riders18,''),ISNULL(Is_Active_Rider18,''),ISNULL(Is_Rider18_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider18_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider18_Effective_Plan,''),101),\n"
                + "ISNULL(Riders19,''),ISNULL(Is_Active_Rider19,''),ISNULL(Is_Rider19_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider19_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider19_Effective_Plan,''),101),\n"
                + "ISNULL(Riders20,''),ISNULL(Is_Active_Rider20,''),ISNULL(Is_Rider20_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider20_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider20_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
             limit=100;
        }
        if (productType.equalsIgnoreCase("ULIP"))
        {
             query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101),\n"
                + "ISNULL(Riders11,''),ISNULL(Is_Active_Rider11,''),ISNULL(Is_Rider11_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider11_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider11_Effective_Plan,''),101),\n"
                + "ISNULL(Riders12,''),ISNULL(Is_Active_Rider12,''),ISNULL(Is_Rider12_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider12_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider12_Effective_Plan,''),101),\n"
                + "ISNULL(Riders13,''),ISNULL(Is_Active_Rider13,''),ISNULL(Is_Rider13_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider13_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider13_Effective_Plan,''),101),\n"
                + "ISNULL(Riders14,''),ISNULL(Is_Active_Rider14,''),ISNULL(Is_Rider14_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider14_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider14_Effective_Plan,''),101),\n"
                + "ISNULL(Riders15,''),ISNULL(Is_Active_Rider15,''),ISNULL(Is_Rider15_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider15_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider15_Effective_Plan,''),101),\n"
                + "ISNULL(Riders16,''),ISNULL(Is_Active_Rider16,''),ISNULL(Is_Rider16_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider16_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider16_Effective_Plan,''),101),\n"
                + "ISNULL(Riders17,''),ISNULL(Is_Active_Rider17,''),ISNULL(Is_Rider17_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider17_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider17_Effective_Plan,''),101),\n"
                + "ISNULL(Riders18,''),ISNULL(Is_Active_Rider18,''),ISNULL(Is_Rider18_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider18_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider18_Effective_Plan,''),101),\n"
                + "ISNULL(Riders19,''),ISNULL(Is_Active_Rider19,''),ISNULL(Is_Rider19_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider19_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider19_Effective_Plan,''),101),\n"
                + "ISNULL(Riders20,''),ISNULL(Is_Active_Rider20,''),ISNULL(Is_Rider20_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider20_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider20_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
             limit=100;
        }
        String secplanCode = (String) ifr.getControlValue("PLAN_NAME_COMBO");
            String Product_Solution = (String) ifr.getControlValue("PRODUCT_SOLUTION");
        if (productType.equalsIgnoreCase("COMBO"))
        {
             query = "SELECT \n"
                + "ISNULL(Riders1,''),ISNULL(Is_Active_Rider1,''),ISNULL(Is_Rider1_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider1_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider1_Effective_Plan,''),101),\n"
                + "ISNULL(Riders2,''),ISNULL(Is_Active_Rider2,''),ISNULL(Is_Rider2_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider2_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider2_Effective_Plan,''),101),\n"
                + "ISNULL(Riders3,''),ISNULL(Is_Active_Rider3,''),ISNULL(Is_Rider3_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider3_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider3_Effective_Plan,''),101),\n"
                + "ISNULL(Riders4,''),ISNULL(Is_Active_Rider4,''),ISNULL(Is_Rider4_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider4_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider4_Effective_Plan,''),101),\n"
                + "ISNULL(Riders5,''),ISNULL(Is_Active_Rider5,''),ISNULL(Is_Rider5_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider5_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider5_Effective_Plan,''),101),\n"
                + "ISNULL(Riders6,''),ISNULL(Is_Active_Rider6,''),ISNULL(Is_Rider6_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider6_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider6_Effective_Plan,''),101),\n"
                + "ISNULL(Riders7,''),ISNULL(Is_Active_Rider7,''),ISNULL(Is_Rider7_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider7_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider7_Effective_Plan,''),101),\n"
                + "ISNULL(Riders8,''),ISNULL(Is_Active_Rider8,''),ISNULL(Is_Rider8_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider8_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider8_Effective_Plan,''),101),\n"
                + "ISNULL(Riders9,''),ISNULL(Is_Active_Rider9,''),ISNULL(Is_Rider9_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider9_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider9_Effective_Plan,''),101),\n"
                + "ISNULL(Riders10,''),ISNULL(Is_Active_Rider10,''),ISNULL(Is_Rider10_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider10_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider10_Effective_Plan,''),101),\n"
                + "ISNULL(Riders11,''),ISNULL(Is_Active_Rider11,''),ISNULL(Is_Rider11_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider11_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider11_Effective_Plan,''),101),\n"
                + "ISNULL(Riders12,''),ISNULL(Is_Active_Rider12,''),ISNULL(Is_Rider12_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider12_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider12_Effective_Plan,''),101),\n"
                + "ISNULL(Riders13,''),ISNULL(Is_Active_Rider13,''),ISNULL(Is_Rider13_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider13_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider13_Effective_Plan,''),101),\n"
                + "ISNULL(Riders14,''),ISNULL(Is_Active_Rider14,''),ISNULL(Is_Rider14_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider14_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider14_Effective_Plan,''),101),\n"
                + "ISNULL(Riders15,''),ISNULL(Is_Active_Rider15,''),ISNULL(Is_Rider15_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider15_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider15_Effective_Plan,''),101),\n"
                + "ISNULL(Riders16,''),ISNULL(Is_Active_Rider16,''),ISNULL(Is_Rider16_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider16_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider16_Effective_Plan,''),101),\n"
                + "ISNULL(Riders17,''),ISNULL(Is_Active_Rider17,''),ISNULL(Is_Rider17_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider17_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider17_Effective_Plan,''),101),\n"
                + "ISNULL(Riders18,''),ISNULL(Is_Active_Rider18,''),ISNULL(Is_Rider18_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider18_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider18_Effective_Plan,''),101),\n"
                + "ISNULL(Riders19,''),ISNULL(Is_Active_Rider19,''),ISNULL(Is_Rider19_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider19_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider19_Effective_Plan,''),101),\n"
                + "ISNULL(Riders20,''),ISNULL(Is_Active_Rider20,''),ISNULL(Is_Rider20_Mandatory,''),CONVERT(VARCHAR,ISNULL(Rider20_Expiry_Plan,''),101),CONVERT(VARCHAR,ISNULL(Rider20_Effective_Plan,''),101)\n"
                + "FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND   combo_plan_code='"+secplanCode+"' and product_Solution='"+Product_Solution+"' AND  \n"
                + "Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
             limit=100;
        }
         

            queryList = getValFromQuery(query);

            if (caseFlag.equalsIgnoreCase("effectiveExpiryValidate")) {
                //query = "SELECT ISNULL(Rider_Code,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC(NOLOCK) WHERE Rider_Desc='" + riderName + "'";
                //riderCodeList = getValFromQuery(query);

                if (queryList != null) {
                    for (int j = 0; j < limit; j += 5) {
                        riderFromTable = (String) ((List) queryList.get(0)).get(j);

                        if (riderCode.equalsIgnoreCase(riderFromTable) && !riderFromTable.equalsIgnoreCase("")) {
                            Rider_Expiry_Plan = (String) ((List) queryList.get(0)).get(j + 3);
                            Rider1_Effective_Plan = (String) ((List) queryList.get(0)).get(j + 4);
                            try {
                                riderExpiry = new SimpleDateFormat("MM/dd/yyyy").parse(Rider_Expiry_Plan);
                                riderEffective = new SimpleDateFormat("MM/dd/yyyy").parse(Rider1_Effective_Plan);
                            } catch (ParseException ex) {
                                Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
                                riderExpiry = new Date();
                                riderEffective = new Date();
                            }
                            if (productDating.equalsIgnoreCase("ED")) {
                                if (effectiveDate.before(riderEffective) || effectiveDate.after(riderExpiry)) {
                                    returnMessage += riderName + " - effective Date should be between " + Rider1_Effective_Plan + " and " + Rider_Expiry_Plan + " (ED)!";
                                }

                            } else if (effectiveDate.before(riderEffective) || customerSign.after(riderExpiry)) {
                                returnMessage += riderName + " - efeective Date/Customer Sign date should be between" + Rider1_Effective_Plan + " and " + Rider_Expiry_Plan + " (CD)!";
                            }
                            break;
                        }
                    }
                } else {
                    returnMessage += riderName + " - Rider is not present in Rider Setup Master!";
                }

            } else if (caseFlag.equalsIgnoreCase("getAllRiders")) {
                ArrayList<String> riderArr = new ArrayList<String>();
                if (queryList != null) {
                    String Is_Active_Rider, Is_Rider_Mandatory;
                    for (int j = 0; j < limit; j += 5) {
                        riderFromTable = (String) ((List) queryList.get(0)).get(j);
                        if (!riderFromTable.equalsIgnoreCase("")) {
                            Is_Active_Rider = (String) ((List) queryList.get(0)).get(j + 1);
                            Is_Rider_Mandatory = (String) ((List) queryList.get(0)).get(j + 2);
                            Rider_Expiry_Plan = (String) ((List) queryList.get(0)).get(j + 3);
                            Rider1_Effective_Plan = (String) ((List) queryList.get(0)).get(j + 4);
                            try {
                                riderExpiry = new SimpleDateFormat("MM/dd/yyyy").parse(Rider_Expiry_Plan);
                                riderEffective = new SimpleDateFormat("MM/dd/yyyy").parse(Rider1_Effective_Plan);
                            } catch (ParseException ex) {
                                Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
                                riderExpiry = new Date();
                                riderEffective = new Date();
                            }

                            if (Is_Rider_Mandatory.equalsIgnoreCase("N") && Is_Active_Rider.equalsIgnoreCase("Y")) {
                                if (productDating.equalsIgnoreCase("ED")) {
                                    if (effectiveDate.after(riderEffective) || effectiveDate.before(riderExpiry)) {
                                        riderArr.add(riderFromTable);
                                    }
                                } else if (effectiveDate.after(riderEffective) || customerSign.before(riderExpiry)) {
                                    riderArr.add(riderFromTable);
                                }
                            }
                        }
                    }
                    for (String validRider : riderArr) {
                        query = "SELECT ISNULL(Rider_Desc,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC(NOLOCK) WHERE Rider_Code='" + validRider + "'";
                        queryList = getValFromQuery(query);
                        if (queryList != null) {
                            returnMessage += (String) ((List) queryList.get(0)).get(0) + "~~" + validRider + "^";
                        }
                    }
                    if (returnMessage.indexOf("^") > 0) {
                        returnMessage = returnMessage.substring(0, returnMessage.length() - 1);
                    }
                }
            }
        } catch (Exception e) {

            returnMessage = "Error Occured in effectiveExpiryPlanLogic method" + e.toString();
        }
        return returnMessage;
    }

    //Business Logic for Coverage Term
    private String coverageTermLogic(String riderName, String riderCoverTerm, String riderCode) {
        String query, matchFlag = "N", calcCode, minTerm, maxTerm, planAgeExpiry, returnMessage = "";
        List queryList;
        int riderCoverageTerm, minCoverTerm, maxCoverTerm, planAgeExpiryNumeric, insuredAge;

        try {
            riderCoverTerm = riderCoverTerm.isEmpty() ? "0" : riderCoverTerm;

            insuredAge = calculateInsuredAge();
              if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }
            query = "SELECT ISNULL(S.Term_CalC_Code,''), ISNULL(S.Minimum_Term,'0'),ISNULL(s.Maximum_Term,0),ISNULL(Plan_Age_Expiry,0) FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";

            queryList = getValFromQuery(query);
            if (queryList != null) {
                calcCode = (String) ((List) queryList.get(0)).get(0);
                minTerm = (String) ((List) queryList.get(0)).get(1);
                maxTerm = (String) ((List) queryList.get(0)).get(2);
                planAgeExpiry = (String) ((List) queryList.get(0)).get(3);

                riderCoverageTerm = Integer.parseInt(riderCoverTerm);
                planAgeExpiryNumeric = Integer.parseInt(planAgeExpiry);
                if (calcCode.equalsIgnoreCase("A")) {
                    minCoverTerm = Integer.parseInt(minTerm);
                    maxCoverTerm = Integer.parseInt(maxTerm);
                    if (riderCoverageTerm < minCoverTerm || riderCoverageTerm > maxCoverTerm) {
                        returnMessage += riderName + " - Coverage term should be between " + minTerm + " and " + maxTerm + "!";
                    }
                } else if (calcCode.equalsIgnoreCase("B")) {
                    if (riderCoverageTerm != (planAgeExpiryNumeric - insuredAge)) {
                        returnMessage += riderName + " - Coverage term should be equal to " + (planAgeExpiryNumeric - insuredAge) + "!";
                    }
                } else if (calcCode.equalsIgnoreCase("C")) {
                    String[] minTermArr = minTerm.split(",");
                    for (String term : minTermArr) {
                        if (term.equalsIgnoreCase(riderCoverTerm)) {
                            matchFlag = "Y";
                        }
                    }
                    if (matchFlag.equalsIgnoreCase("N")) {
                        returnMessage += riderName + " - Valid values for Coverage Term are " + minTerm + "!";
                    }
                }
            }
        } catch (Exception e) {
            returnMessage = "Error Occured in coverageTermLogic Method" + e.toString();
        }
        return returnMessage;
    }

    //Business Logic for PPT
    private String premiumPaymentTermLogic(String riderName, String ppt, String riderCoverTerm, String section, String riderCode) {
        String query, matchFlag = "N", pptCode, minTerm, maxTerm, pptApplicable, returnMessage = "", calculation, baseCoverageTerm = "0";
        List queryList;
        int insuredAge = 0, calculationValue = 0, pptVal, logicalValue, baseCoverageTermVal, minPremiumTerm, maxPremiumTerm, numericCT;
  String PLANTYPE = (String) ifr.getControlValue("PLAN_TYPE");
        try {
            if (section.equalsIgnoreCase("CoverageDetails")) {
                if(PLANTYPE.equalsIgnoreCase("COMBO"))
                {
                   baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM"); 
                }
                else
                {
                baseCoverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
                }
            } else if (section.equalsIgnoreCase("UW")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_REVISED", 0, 6); //ok
            } else if (section.equalsIgnoreCase("UW_Applied")) {
                baseCoverageTerm = (String) ifr.getTableCellValue("COVERAGE_DETAILS_APPLIED", 0, 8);  //ok
            }

            pptVal = ppt.isEmpty() ? 0 : Integer.parseInt(ppt);
            baseCoverageTermVal = baseCoverageTerm.isEmpty() ? 0 : Integer.parseInt(baseCoverageTerm);
             if (productType.equalsIgnoreCase("ULIP")) {
                 Date d1=new Date();
                 edc=new SimpleDateFormat("yyyy-MM-dd").format(d1);
                
             }
             else
             {
            edc=(String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
             }

            query = "SELECT ISNULL(S.PPT_APPLICABLE,''),ISNULL(S.PPT_Cal_Logic_Code,''),ISNULL(S.Minimum_PPT,'0'),ISNULL(S.Maximum_PPT,''),ISNULL(S.Calculation,0) FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC R(NOLOCK)\n"
                    + "INNER JOIN NG_NB_MS_RIDER_BENEFIT_SET_UP S(NOLOCK) ON R.Rider_Code=S.Plan_Code "
                    + "AND S.Channel='" + Channel + "' AND S.Sub_Channel='" + subChannel + "' AND R.Rider_Code='" + riderCode + "' and '"+edc+"' between  rider_effective_Date and rider_expiry_Date ";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                pptApplicable = (String) ((List) queryList.get(0)).get(0);
                pptCode = (String) ((List) queryList.get(0)).get(1);
                minTerm = (String) ((List) queryList.get(0)).get(2);
                maxTerm = (String) ((List) queryList.get(0)).get(3);
                calculation = (String) ((List) queryList.get(0)).get(4);
                calculationValue = Integer.parseInt(calculation);

                if (pptApplicable.equalsIgnoreCase("Y")) {
                    if (pptCode.equalsIgnoreCase("A")) {
                        String[] minTermArr = minTerm.split(",");
                        for (String term : minTermArr) {
                            if (term.equalsIgnoreCase(ppt.trim())) {
                                matchFlag = "Y";
                            }
                        }
                        if (matchFlag.equalsIgnoreCase("N")) {
                            returnMessage += riderName + " - Valid values for Premium Payment Term are " + minTerm + "!";
                        }
                    } else if (pptCode.equalsIgnoreCase("B")) {
                        insuredAge = calculateInsuredAge();
                        logicalValue = calculationValue - insuredAge;
                        if (logicalValue != pptVal) {
                            returnMessage += riderName + " - Value for Premium Payment Term should be " + logicalValue + "!";
                        }
                    } else if (pptCode.equalsIgnoreCase("C") && pptVal != baseCoverageTermVal) {
                        returnMessage += riderName + " - Premium Payment Term should be " + baseCoverageTermVal + "!";
                    } else if (pptCode.equalsIgnoreCase("D") && pptVal != 1) {
                        returnMessage += riderName + " - Premium Payment Term should be 1 !";
                    } else if (pptCode.equalsIgnoreCase("E")) {
                        logicalValue = baseCoverageTermVal - calculationValue;
                        if (logicalValue != pptVal) {
                            returnMessage += riderName + " - Value for Premium Payment Term should be " + logicalValue + "!";
                        }
                    } else if (pptCode.equalsIgnoreCase("G")) {
                        minPremiumTerm = Integer.parseInt(minTerm);
                        maxPremiumTerm = Integer.parseInt(maxTerm);
                        if (pptVal < minPremiumTerm || pptVal > maxPremiumTerm) {
                            returnMessage += riderName + " - Premium term should be between " + minTerm + " and " + maxTerm + "!";
                        }
                    }

                    numericCT = riderCoverTerm.isEmpty() ? 0 : Integer.parseInt(riderCoverTerm);
                    if (pptVal > numericCT) {
                        returnMessage += riderName + "- PPT can not greater than rider CT ! ";
                    }

                }

            }
        } catch (Exception e) {
            returnMessage = "Error occured in premiumPaymentTermLogic method " + e.toString();
        }
        return returnMessage;
    }

    public String uinLogic() {
        String ActtivityName = "", query, tableName = "NG_NB_MS_TRAD", uwEDC, version1 = "", version2 = "",
                whereCondition = "WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'", errorMsg = "";
        ActtivityName = ifr.getActivityName();
        String effectiveDateOfCoverage = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
        String customerSigndate = (String) ifr.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
        String BINGENDATE = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.BI_GEN_DATE");
        
        if(!(BINGENDATE.equalsIgnoreCase("")))
        {
            customerSigndate=BINGENDATE;
        }
        List queryList;

        if (productType.equalsIgnoreCase("ULIP")) {
            tableName = "NG_NB_MS_ULIP";
        }
        if (productType.equalsIgnoreCase("JOINT")) {
            tableName = "NG_NB_MS_JOINT";
        }
        if (productType.equalsIgnoreCase("ANNUITY")) {
            tableName = "NG_NB_MS_ANNUITANT";
        }
        if (productType.equalsIgnoreCase("HEALTH")) {
            tableName = "NG_NB_MS_HEALTH";
        }
        if (ActtivityName.equalsIgnoreCase("MANUAL_UW") || ActtivityName.equalsIgnoreCase("Manual_UW_Vendor") || ActtivityName.equalsIgnoreCase("Manual_UW_Supervisor") || ActtivityName.equalsIgnoreCase("UW_HOD")) {
            query = "SELECT ISNULL(UW_EDC,'') FROM " + tableName + "(NOLOCK) " + whereCondition;
            queryList = getValFromQuery(query);

            if (queryList != null) {
                uwEDC = (String) ((List) queryList.get(0)).get(0);
                if (uwEDC.equalsIgnoreCase("Y")) {
                    String uwdecision=(String) ifr.getControlValue("Decision");
                    if(uwdecision.equalsIgnoreCase("Counter Offer")  || uwdecision.equalsIgnoreCase("CO Reconsider" ) || uwdecision.equalsIgnoreCase("Accept"))   ///DR_7417
                        effectiveDateOfCoverage = (String) ifr.getControlValue("Q_DECISION_SECTION_UW.EDC");
                }
            }

        }

        query = "SELECT ISNULL(UIN_NM,'') FROM NG_NB_MS_UIN_LOGIC(NOLOCK) " + whereCondition
                + " AND  '" + effectiveDateOfCoverage + "' BETWEEN UIN_EFFECTIVE_DT AND UIN_EXPIRY_DT AND Is_Active_Ind='Y'";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            version1 = (String) ((List) queryList.get(0)).get(0);
        }

        query = "SELECT ISNULL(UIN_NM,'') FROM NG_NB_MS_UIN_LOGIC(NOLOCK) " + whereCondition
                + " AND  '" + customerSigndate + "' BETWEEN UIN_EFFECTIVE_DT AND UIN_EXPIRY_DT AND Is_Active_Ind='Y'";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            version2 = (String) ((List) queryList.get(0)).get(0);
        }

        if (!version1.equalsIgnoreCase(version2)) {
            errorMsg = "UIN Number Mismatch!";
        }

        return errorMsg;
    }

    private int calculateInsuredAge() {
        String insuredDOB;
        int insuredAge;
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String effectiveDateOfCoverage = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
        insuredDOB = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        if (clientType.equalsIgnoreCase("ProposerInsured")) {
            insuredDOB = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        }
        insuredAge = calculateAge(insuredDOB, effectiveDateOfCoverage);
        return insuredAge;
    }
    private int calculateProposerAge() {
        String propDOB;
        int propAge;
        String clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String effectiveDateOfCoverage = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
        propDOB = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
       
        propAge = calculateAge(propDOB, effectiveDateOfCoverage);
        return propAge;
    }

    //To Calculate Age based on product dating of the product
    private int calculateAge(String insuredDOB, String effectiveDate) {
        String years = "", productDating = "";

        productDating = getProductDating();

        Date inDate = null;
        Date currentDate = new Date();

        if (productDating.equalsIgnoreCase("ED")) {
            try {
                currentDate = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
            } catch (ParseException ex) {
                Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
                currentDate = new Date();
            }
        }

        try {
            inDate = new SimpleDateFormat("yyyy-MM-dd").parse(insuredDOB);
        } catch (ParseException ex) {
            Logger.getLogger(RiderBenefit.class.getName()).log(Level.SEVERE, null, ex);
            inDate = new Date();
        }

        LocalDate fromDate = inDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate toDate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        int diffYears = Period.between(fromDate, toDate).getYears();
        years = String.valueOf(diffYears);
        return diffYears;
    }

    //To get the product Dating of current product
    private String getProductDating() {
        String tableName = "NG_NB_MS_TRAD", query, productDating = "";
        List queryList;

        if (productType.equalsIgnoreCase("ULIP")) {
            tableName = "NG_NB_MS_ULIP";
        }
        if (productType.equalsIgnoreCase("JOINT")) {
            tableName = "NG_NB_MS_JOINT";
        }
        if (productType.equalsIgnoreCase("ANNUITY")) {
            tableName = "NG_NB_MS_ANNUITANT";
        }
        if (productType.equalsIgnoreCase("HEALTH")) {
            tableName = "NG_NB_MS_HEALTH";
        }
        query = "SELECT ISNULL(Product_Dating,'') FROM " + tableName + "(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' AND Sub_Channel='" + subChannel + "'";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            productDating = (String) ((List) queryList.get(0)).get(0);
        }

        return productDating;
    }

    public String getPlanPayOptionCode() {
        String query, planPayOptionCode = "", selector = "Plan_Pay_Option_Code", tableName = "NG_NB_MS_TRAD";
        List queryList;
        if (productType.equalsIgnoreCase("ULIP")) {
            tableName = "NG_NB_MS_ULIP";
            selector = "Plan_Pay_Option_Code_Desc";

        }
        if (productType.equalsIgnoreCase("JOINT")) {
            tableName = "NG_NB_MS_JOINT";
          

        }
        if (productType.equalsIgnoreCase("ANNUITY")) {
            tableName = "NG_NB_MS_ANNUITANT";
          

        }
        if (productType.equalsIgnoreCase("HEALTH")) {
            tableName = "NG_NB_MS_HEALTH";
          

        }
        if (productType.equalsIgnoreCase("COMBO")) {
            tableName = "NG_NB_MS_COMBO";
            selector = "Plan_Pay_Option_Code_Desc";

        }

        
        String secplanCode = (String) ifr.getControlValue("PLAN_NAME_COMBO");
            String Product_Solution = (String) ifr.getControlValue("PRODUCT_SOLUTION");
	
        query = "SELECT ISNULL(" + selector + ",'') FROM " + tableName + "(NOLOCK ) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + "AND Sub_Channel='" + subChannel + "'";
        
        if (productType.equalsIgnoreCase("COMBO")) {
             query = "SELECT ISNULL(" + selector + ",'') FROM " + tableName + "(NOLOCK ) WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + "AND Sub_Channel='" + subChannel + "' AND  combo_plan_code='"+secplanCode+"' and product_Solution='"+Product_Solution+"'";
        }
        queryList = getValFromQuery(query);
        if (queryList != null) {
            planPayOptionCode = (String) ((List) queryList.get(0)).get(0);
        }
        return planPayOptionCode;
    }

    private String getRiderBenefitDesc(String riderCode) {
        String query, riderDesc = "";
        List queryList;
        query = "SELECT ISNULL(Rider_Desc,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC WHERE Rider_Code='" + riderCode + "'";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            riderDesc = (String) ((List) queryList.get(0)).get(0);
        }
        return riderDesc;
    }

    private String getRiderFamily(String riderName, String riderCode) {
        String query, riderFamily = "";
        List queryList;
        query = "SELECT ISNULL(Rider_Type,'') FROM NG_NB_MS_RIDER_BENEFIT_CODE_DESC WHERE Rider_Code='" + riderCode + "'";
        queryList = getValFromQuery(query);
        if (queryList != null) {
            riderFamily = (String) ((List) queryList.get(0)).get(0);
        }
        return riderFamily;
    }

    //To get SubChannel
    private String getSubChannel(String Channel) {
        String subChannel = "";
        String query = "SELECT SUB_CHANNEL FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE='" + Channel + "' AND SUB_CHANNEL!='Defence' AND SUB_CHANNEL!='TeleSale'";
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            subChannel = (String) ((List) queryResult.get(0)).get(0);
        }
        return subChannel;
    }

    //Get List from Query
    List getValFromQuery(String query) {
        String queryResult = "";
        List queryResultList = (List) ifr.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
    }
    
    // added by Sparsh DR-50232
    //Business Logic for PPT and CT for CI Rider
    private String PPTLogic(String riderCode, String ppt, String riderCoverTerm) {
        String returnMessage = "";
        
        try {
               //added by sparsh DR-50232
                if((riderCode.equalsIgnoreCase("TCIGPR") || riderCode.equalsIgnoreCase("TCIGR") ||
                   riderCode.equalsIgnoreCase("TCIPDR") || riderCode.equalsIgnoreCase("TCIPPR") || 
                   riderCode.equalsIgnoreCase("TCIPR")) && !ppt.equalsIgnoreCase(riderCoverTerm)){
                    
                    returnMessage += "For opted Max Life Critical Illness and Disability Rider Coverage term and PPT should be same!";
                }
                else if((riderCode.equalsIgnoreCase("TCIGL") || riderCode.equalsIgnoreCase("TCIGPL") ||
                   riderCode.equalsIgnoreCase("TCIPDL") || riderCode.equalsIgnoreCase("TCIPL") || 
                   riderCode.equalsIgnoreCase("TCIPPL")) && ppt.equalsIgnoreCase(riderCoverTerm)){
                    
                    returnMessage += "For opted Max Life Critical Illness and Disability Rider Coverage term and PPT should be different!";
                }
                
        
        } catch (Exception e) {
            returnMessage = "Error occured in PPTLogic method " + e.toString();
        }
        return returnMessage;
    }


}
