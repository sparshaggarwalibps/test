package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import static com.newgen.iforms.user.DolphinUtil.CalculateYears;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class BusinessRules {

    IFormReference ifr;

    public BusinessRules(IFormReference iFormRef) {
        this.ifr = iFormRef;
    }

    public String validateCaseUserLevel() {
        String userLevel = "", caseLevel = "", query, errorMsg = "";

        try {
            String PLANTYPE=(String) ifr.getControlValue("PLAN_TYPE");
            String MSA="";
            String SUC="";
            if(PLANTYPE.equalsIgnoreCase("JOINT") || PLANTYPE.equalsIgnoreCase("ANNUITY"))
            {
                 MSA = (String) ifr.getControlValue("Q_SUC_PARAMETERES_PROP.MSA");
                 SUC = (String) ifr.getControlValue("Q_SUC_PARAMETERES_PROP.SUM_UNDER_CONSIDERATION");
            }
            else
            {
                MSA = (String) ifr.getControlValue("Q_SUC_PARAMETERES.MSA");
                SUC = (String) ifr.getControlValue("Q_SUC_PARAMETERES.SUM_UNDER_CONSIDERATION");
            }
           String FACFLAG=(String) ifr.getControlValue("FACULTATIVE_FLAG");
            String Decision = (String) ifr.getControlValue("Decision");
            if (MSA.equalsIgnoreCase("")) {
                MSA = "0";
            }

            if (SUC.equalsIgnoreCase("")) {
                SUC = "0";
            }

            String category = (String) ifr.getValue("MED_NON_MED");
            List queryList;

            userLevel = getUserLevel();
            if (!userLevel.equalsIgnoreCase("")) {
                query = "SELECT TOP 1 LEVEL FROM NG_NB_UW_ALLOCATION L(NOLOCK) WHERE (convert(float,round('" + SUC + "',0,0)) BETWEEN SUC_FROM AND SUC_TO) AND FAC_TAG='" + FACFLAG + "' AND Category='" + category + "' ";
                System.out.println("Error in validateCaseUserLevel " +query );
                queryList = getValFromQuery(query);
                System.out.println("Error in validateCaseUserLevel " +queryList );
                if (queryList != null) {
                    caseLevel = (String) ((List) queryList.get(0)).get(0);
                    userLevel = userLevel.substring(2, 3);
                    caseLevel = caseLevel.substring(2, 3);

                    if (Integer.parseInt(userLevel) >= Integer.parseInt(caseLevel)) {
                        if ((Decision.equalsIgnoreCase("Counter Offer") || Decision.equalsIgnoreCase("Decline") || Decision.equalsIgnoreCase("Postpone")) && userLevel.equalsIgnoreCase("1")) {
                            errorMsg = "Level 1 underwriter is not allowed " + Decision;
                        }
                        //errorMsg = "";
                    } else {
                        errorMsg = "User Level is lower than Case Level!";
                    }

                } else {
                    errorMsg = "Case Level not found!";
                }

            } else {
                errorMsg = "Update user level in the Master";
            }
        } catch (Exception e) {
            System.out.println("Error in validateCaseUserLevel " + e.toString());
        }
        return errorMsg;
    }

    public String validateAddInfoLevel() {
        String Decision = (String) ifr.getControlValue("Decision");
        String referTo = (String) ifr.getControlValue("REFER_TO");
        String userLevel = "", erroMsg = "";

        userLevel = getUserLevel();
        if (!userLevel.equalsIgnoreCase("")) {
            userLevel = userLevel.substring(2, 3);
            if (Integer.parseInt(userLevel) < 4) {
                if (Decision.equalsIgnoreCase("Add Info")) {
                    erroMsg = "Medical Add info can only be marked by Level 4 and above Underwriters!";
                } else if (Decision.equalsIgnoreCase("Medical Discrepancy")) {
                    erroMsg = "Medical discrepancy can only be marked by Level 4 and above Underwriters!";
                } else if (Decision.equalsIgnoreCase("Refer") && (referTo.equalsIgnoreCase("CMO") || referTo.equalsIgnoreCase("Reinsurer"))) {
                    erroMsg = "Level 1,2,3 can not refer the case to " + referTo;
                }
            }
        } else {
            erroMsg = "Level of user not found!";
        }
        return erroMsg;
    }

    public String getUserLevel() {
        String username = ifr.getUserName();
        String query = "SELECT ISNULL(LEVEL,'') FROM NG_NB_UW_USERS(NOLOCK) WHERE USERNAME='" + username + "'";
        String userLevel = "";
        List queryList;
        queryList = getValFromQuery(query);
        if (queryList != null) {
            userLevel = (String) ((List) queryList.get(0)).get(0);
        }
        return userLevel;
    }

    public String getCaseType() {
        String planCode = (String) ifr.getControlValue("PLAN_NAME");
        String query = "SELECT ISNULL(PROTECTION,'') FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE='" + planCode + "'";
        String caseType = "";
        List queryList;
        queryList = getValFromQuery(query);
        if (queryList != null) {
            caseType = (String) ((List) queryList.get(0)).get(0);
        }
        return caseType;

    }

    public String checkUserInUWGroups() {
        String username = ifr.getUserName();
        String query = "SELECT COUNT(*) FROM PDBGroup G(NOLOCK)\n"
                + "INNER JOIN PDBGroupMember GM(NOLOCK) ON G.GroupIndex=GM.GroupIndex AND G.GroupName IN ('Dolphin UW Med','Dolphin UW Non Med','Dolphin UW  L7 L8','Dolphin Datamatics UW L1A','Dolphin Bubble UW L1A',\n" +
" 'Dolphin Bubble UW L1A Supervisor','Dolphin Bubble UW L4A','Dolphin Bubble UW L4A Supervisor',\n" +
" 'Dolphin Datamatics UW L1A Supervisor','Dolphin Datamatics UW L4A','Dolphin Datamatics UW L4A Supervisor',\n" +
" 'Dolphin PNW UW  L1A Supervisor','Dolphin PNW UW L1A','Dolphin PNW UW L4A','Dolphin PNW UW L4A Supervisor','Dolphin UW Vendor Med','Dolphin UW Vendor Non Med','Dolphin UW Supervisor Med','Dolphin UW Supervisor Non Med')\n"
                + "INNER JOIN PDBUser P(NOLOCK) ON GM.UserIndex=P.UserIndex AND P.USERNAME='" + username + "'";
        String userCount = "";
        int count = 0;
        List queryList;
        queryList = getValFromQuery(query);
        if (queryList != null) {
            userCount = (String) ((List) queryList.get(0)).get(0);
        }
        return userCount;

    }

    public String userRole() {
        String username = ifr.getUserName();
        String query = "EXEC NG_SP_NB_USER_ROLE '" + username + "'";
        String userRole = "";
        List queryList;
        queryList = getValFromQuery(query);
        if (queryList != null) {
            userRole = (String) ((List) queryList.get(0)).get(0);  //1060409
        }
        return userRole;
    }

    List getValFromQuery(String query) {
        String queryResult = "";
        List queryResultList = (List) ifr.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
    }
    public void headerLoad()
    {
        String wiName = (String) ifr.getValue("WorkItemName");
        String controlValue, proposerDob = "", insuredDob = "", activityName, clientType = null, proposerFirstName = null,
                proposerMiddleName = null, proposerLastName = null, proposerFullName, insuredFirstName = null, insuredMiddleName = null, insuredLastName = null, insuredFullName, query, clientTypeDesc = "";
        int proposerAge, insuredAge;
        String proposalNo = "", objectiveOfInsur = "", productName = "", insuredNatioanality = "", afyp = "", atp = "",
                plan_type = "", sourcingSystem = "", exactIncome = "";

        List queryList;
        String getDataQuery = "EXEC NG_SP_NB_ONLOAD '"+wiName+"'";  //added by AANCHAL ON 30 MARCH
            queryList = getValFromQuery(getDataQuery);
            if (queryList != null) {
                clientType = (String) ((List) queryList.get(0)).get(0);
                proposerFirstName = (String) ((List) queryList.get(0)).get(1);
                proposerMiddleName = (String) ((List) queryList.get(0)).get(2);
                proposerLastName = (String) ((List) queryList.get(0)).get(3);

                insuredFirstName = (String) ((List) queryList.get(0)).get(4);
                insuredMiddleName = (String) ((List) queryList.get(0)).get(5);
                insuredLastName = (String) ((List) queryList.get(0)).get(6);

                proposalNo = (String) ((List) queryList.get(0)).get(7);
                objectiveOfInsur = (String) ((List) queryList.get(0)).get(8);
                productName = (String) ((List) queryList.get(0)).get(9);
                insuredNatioanality = (String) ((List) queryList.get(0)).get(10);
                afyp = (String) ((List) queryList.get(0)).get(11);
                atp = (String) ((List) queryList.get(0)).get(12);
                plan_type = (String) ((List) queryList.get(0)).get(13);
                sourcingSystem = (String) ((List) queryList.get(0)).get(14);
                exactIncome = (String) ((List) queryList.get(0)).get(15);
                //clientType = (String) ((List) queryList.get(0)).get(0);
            }
            
            
             if (!(productName.equalsIgnoreCase("UFIPFS") || productName.equalsIgnoreCase("UFIPFL") || productName.equalsIgnoreCase("UFIPFR")|| productName.equalsIgnoreCase("UFIPFW") || productName.equalsIgnoreCase("UIPWFS")
                    || productName.equalsIgnoreCase("UIPWF5") || productName.equalsIgnoreCase("UIPWFR")|| productName.equalsIgnoreCase("U2NIFS") || productName.equalsIgnoreCase("U2NF20") || productName.equalsIgnoreCase("U2NIF5")  || productName.equalsIgnoreCase("UFISFL")|| productName.equalsIgnoreCase("UFISFR") || productName.equalsIgnoreCase("UFINFL") || productName.equalsIgnoreCase("UFINFR") ))
             {
             
            if (plan_type.equalsIgnoreCase("ULIP")) {
                afyp = atp;
            }
             }

//            clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
//            proposerFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
//            proposerMiddleName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.MIDDLE_NAME");
//            proposerLastName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.LAST_NAME");
            proposerFullName = proposerFirstName + " " + proposerMiddleName + " " + proposerLastName;
//            insuredFirstName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
//            insuredMiddleName = (String) ifr.getControlValue("Q_L2BI_DETAILS.MIDDLE_NAME");
//            insuredLastName = (String) ifr.getControlValue("Q_L2BI_DETAILS.LAST_NAME");
            insuredFullName = insuredFirstName + " " + insuredMiddleName + " " + insuredLastName;

            //Set Header details
//            String proposalNo = (String) ifr.getControlValue("PROPOSAL_NUMBER");
//            String objectiveOfInsur = (String) ifr.getControlValue("OBJ_OF_INSURANCE");
//            String productName = (String) ifr.getControlValue("PLAN_NAME");
//            String insuredNatioanality = (String) ifr.getControlValue("Q_L2BI_DETAILS.NATIONALITY");
//            String afyp = (String) ifr.getControlValue("AFYP");
            query = "SELECT ISNULL(OBJ_INSURANCE_LABEL,'') FROM NG_NB_MS_OBJ_OF_INSURANCE(NOLOCK) WHERE OBJ_INSURANCE_VALUE='" + objectiveOfInsur + "'";

            queryList = getValFromQuery(query);
            if (queryList != null) {
                objectiveOfInsur = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(PLANS,'') FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE='" + productName + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                productName = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(LABEL,'') FROM NG_NB_MS_NATIONALITY(NOLOCK) WHERE VALUE='" + insuredNatioanality + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                insuredNatioanality = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(TYPE_LABEL,'') FROM NG_NB_MS_CLIENT_TYPE(NOLOCK) WHERE TYPE_VALUE='" + clientType + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                clientTypeDesc = (String) ((List) queryList.get(0)).get(0);
            }
            ifr.setValue("label112", proposalNo);
            ifr.setValue("PROPOSER_NAME", proposerFullName);
            ifr.setValue("L2BINAME", insuredFullName);
            ifr.setValue("label115", objectiveOfInsur);
            ifr.setValue("label121", productName);
            ifr.setValue("label122", insuredNatioanality);
            ifr.setValue("label123", clientTypeDesc);
            ifr.setValue("label120", afyp);
            ifr.setValue("textbox904", exactIncome);
    }
    //Dependency on Sections -Proposer details, L2BI details, NEFT details, Payor PAN details, Coverage details
    public void copyDataToQCSummary() {
        String wiName = (String) ifr.getValue("WorkItemName");
        String controlValue, proposerDob = "", insuredDob = "", activityName, clientType = null, proposerFirstName = null,
                proposerMiddleName = null, proposerLastName = null, proposerFullName, insuredFirstName = null, insuredMiddleName = null, insuredLastName = null, insuredFullName, query, clientTypeDesc = "";
        int proposerAge, insuredAge;
        String proposalNo = "", objectiveOfInsur = "", productName = "", insuredNatioanality = "", afyp = "", atp = "",
                plan_type = "", sourcingSystem = "", exactIncome = "";

        List queryList;
        try {
            activityName = ifr.getActivityName();

            //"SELECT Q_PROPOSER_DETAILS.CLIENT_TYPE,Q_PROPOSER_DETAILS.FIRST_NAME,Q_PROPOSER_DETAILS.MIDDLE_NAME,Q_PROPOSER_DETAILS.LAST_NAME,"
                  //  + " Q_L2BI_DETAILS.FIRST_NAME,Q_L2BI_DETAILS.MIDDLE_NAME,Q_L2BI_DETAILS.LAST_NAME, "
                    //+ " EXT.PROPOSAL_NUMBER,EXT.OBJ_OF_INSURANCE,EXT.PLAN_NAME,Q_PROPOSER_DETAILS.NATIONALITY,EXT.AFYP,Q_COVERAGE_DETAILS.ATP,EXT.PLAN_TYPE,EXT.SOURCING_SYSTEM,Q_PROPOSER_DETAILS.EXACT_INCOME "
                    //+ " FROM NG_NB_PROPOSER_DETAILS(NOLOCK) Q_PROPOSER_DETAILS, NG_NB_L2BI_DETAILS(NOLOCK) Q_L2BI_DETAILS, NG_NB_EXT_TABLE(NOLOCK) EXT, NG_NB_COVERAGE_DETAILS(NOLOCK) Q_COVERAGE_DETAILS"
                    //+ " WHERE Q_PROPOSER_DETAILS.WI_NAME='" + wiName + "' "
                    //+ " AND Q_L2BI_DETAILS.WI_NAME='" + wiName + "'"
                    //+ " AND EXT.WI_NAME='" + wiName + "'"
                    //+ " AND Q_COVERAGE_DETAILS.WI_NAME='" +  + "' ";
             String getDataQuery = "EXEC NG_SP_NB_ONLOAD '"+wiName+"'";  //added by AANCHAL ON 30 MARCH
            queryList = getValFromQuery(getDataQuery);
            if (queryList != null) {
                clientType = (String) ((List) queryList.get(0)).get(0);
                proposerFirstName = (String) ((List) queryList.get(0)).get(1);
                proposerMiddleName = (String) ((List) queryList.get(0)).get(2);
                proposerLastName = (String) ((List) queryList.get(0)).get(3);

                insuredFirstName = (String) ((List) queryList.get(0)).get(4);
                insuredMiddleName = (String) ((List) queryList.get(0)).get(5);
                insuredLastName = (String) ((List) queryList.get(0)).get(6);

                proposalNo = (String) ((List) queryList.get(0)).get(7);
                objectiveOfInsur = (String) ((List) queryList.get(0)).get(8);
                productName = (String) ((List) queryList.get(0)).get(9);
                insuredNatioanality = (String) ((List) queryList.get(0)).get(10);
                afyp = (String) ((List) queryList.get(0)).get(11);
                atp = (String) ((List) queryList.get(0)).get(12);
                plan_type = (String) ((List) queryList.get(0)).get(13);
                sourcingSystem = (String) ((List) queryList.get(0)).get(14);
                exactIncome = (String) ((List) queryList.get(0)).get(15);
                //clientType = (String) ((List) queryList.get(0)).get(0);
            }
            //joint //aanchal
          //  if (plan_type.equalsIgnoreCase("JOINT")) {
            	 ifr.setTabStyle("mytab", "3", "visible", "true");  //shhet10---sheet2 JOINT //IIB
            	 ifr.setStyle("t10s2", "visible", "false");
            	 ifr.setStyle("t10s3", "visible", "false");
            	 ifr.setStyle("t10s4", "visible", "false");
            	 ifr.setStyle("t10s5", "visible", "false");
            	 ifr.setStyle("t10s6", "visible", "false");
            	 ifr.setStyle("t10s8", "visible", "false");
            	 ifr.setStyle("t10s9", "visible", "false");
            	 ifr.setStyle("t10s10", "visible", "false");
            	 ifr.setStyle("t10s11", "visible", "false");
            	 ifr.setStyle("t10s12", "visible", "false");
           // }
           // else
           // {
            	ifr.setTabStyle("mytab", "11", "visible", "false");  //IIB
            //}
            //joint //aanchal
            if (clientType.equalsIgnoreCase("ProposerInsured")) {
                ifr.setStyle("t2s2", "visible", "false");
                ifr.setStyle("t0s2", "visible", "false");
                ifr.setStyle("t6s2", "visible", "false"); 
                ifr.setStyle("t2s13", "visible", "false");  //previous policy insured section
                 
            }
              

            if (sourcingSystem.equalsIgnoreCase("Online")) {
                ifr.setStyle("Q_NEFT_DETAILS_NAME_BRANCH_NEFT_DUP", "visible", "false");
                ifr.setStyle("Q_NEFT_DETAILS_ACC_NO_NEFT_DUP", "visible", "false");
                ifr.setStyle("Q_NEFT_DETAILS_IFSC_NEFT_DUP", "visible", "false");
                
                 wiName = (String) ifr.getValue("WorkItemName");
                  
                  String BNPL = "SELECT bnpl FROM NG_NB_PROPOSER_DETAILS(NOLOCK) WHERE WI_NAME='" + wiName + "' ";
                     List queryListbnpl = getValFromQuery(BNPL);
                        if (queryListbnpl != null) {
                            ifr.setValue("BNPL", (String) ((List) queryListbnpl.get(0)).get(0));
                        }
                
                
            } else {
                ifr.setStyle("checkbox239", "visible", "false");
                ifr.setStyle("checkbox240", "visible", "false");
                ifr.setStyle("BNPL", "visible", "false");

                ifr.setStyle("textbox542", "visible", "false");
                ifr.setStyle("ESTIMATED_INCOME_BAND", "visible", "false");
                ifr.setStyle("CRIF", "visible", "false");

                ifr.setStyle("CIBIL", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_CANCELLATION_TAG", "visible", "false");
                ifr.setStyle("checkbox242", "visible", "false");

                ifr.setStyle("button221", "visible", "false");
                ifr.setStyle("button222", "visible", "false");
            }

            String getPAyor = "SELECT payor_diff_prop FROM NG_NB_PAYOR_PAN_DETAILS(NOLOCK) WHERE WI_NAME='" + wiName + "' ";
            List queryList9 = getValFromQuery(getPAyor);
            if (queryList9 != null) {
                String Pdiff = (String) ((List) queryList9.get(0)).get(0);
                if (Pdiff.equalsIgnoreCase("N")) {
                    ifr.setStyle("t0s3", "visible", "false");
                    ifr.setStyle("t6s3", "visible", "false");   //dr-14620 mansi
                }
            }

            //added by Prakhar
             if (!(productName.equalsIgnoreCase("UFIPFS") || productName.equalsIgnoreCase("UFIPFL") || productName.equalsIgnoreCase("UFIPFR")|| productName.equalsIgnoreCase("UFIPFW") || productName.equalsIgnoreCase("UIPWFS")
                    || productName.equalsIgnoreCase("UIPWF5") || productName.equalsIgnoreCase("UIPWFR")|| productName.equalsIgnoreCase("U2NIFS") || productName.equalsIgnoreCase("U2NF20") || productName.equalsIgnoreCase("U2NIF5")  || productName.equalsIgnoreCase("UFISFL")|| productName.equalsIgnoreCase("UFISFR") || productName.equalsIgnoreCase("UFINFL") || productName.equalsIgnoreCase("UFINFR") ))
            {
            if (plan_type.equalsIgnoreCase("ULIP")) {
                afyp = atp;
            }
            }
             

//            clientType = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
//            proposerFirstName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
//            proposerMiddleName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.MIDDLE_NAME");
//            proposerLastName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.LAST_NAME");
            proposerFullName = proposerFirstName + " " + proposerMiddleName + " " + proposerLastName;
//            insuredFirstName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
//            insuredMiddleName = (String) ifr.getControlValue("Q_L2BI_DETAILS.MIDDLE_NAME");
//            insuredLastName = (String) ifr.getControlValue("Q_L2BI_DETAILS.LAST_NAME");
            insuredFullName = insuredFirstName + " " + insuredMiddleName + " " + insuredLastName;

            //Set Header details
//            String proposalNo = (String) ifr.getControlValue("PROPOSAL_NUMBER");
//            String objectiveOfInsur = (String) ifr.getControlValue("OBJ_OF_INSURANCE");
//            String productName = (String) ifr.getControlValue("PLAN_NAME");
//            String insuredNatioanality = (String) ifr.getControlValue("Q_L2BI_DETAILS.NATIONALITY");
//            String afyp = (String) ifr.getControlValue("AFYP");
            query = "SELECT ISNULL(OBJ_INSURANCE_LABEL,'') FROM NG_NB_MS_OBJ_OF_INSURANCE(NOLOCK) WHERE OBJ_INSURANCE_VALUE='" + objectiveOfInsur + "'";

            queryList = getValFromQuery(query);
            if (queryList != null) {
                objectiveOfInsur = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(PLANS,'') FROM NG_NB_MS_PLAN_CODE(NOLOCK) WHERE PLAN_CODE='" + productName + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                productName = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(LABEL,'') FROM NG_NB_MS_NATIONALITY(NOLOCK) WHERE VALUE='" + insuredNatioanality + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                insuredNatioanality = (String) ((List) queryList.get(0)).get(0);
            }

            query = "SELECT ISNULL(TYPE_LABEL,'') FROM NG_NB_MS_CLIENT_TYPE(NOLOCK) WHERE TYPE_VALUE='" + clientType + "'";
            queryList = getValFromQuery(query);
            if (queryList != null) {
                clientTypeDesc = (String) ((List) queryList.get(0)).get(0);
            }

            ifr.setValue("label112", proposalNo);
            ifr.setValue("PROPOSER_NAME", proposerFullName);
            ifr.setValue("L2BINAME", insuredFullName);
            ifr.setValue("label115", objectiveOfInsur);
            ifr.setValue("label121", productName);
            ifr.setValue("label122", insuredNatioanality);
            ifr.setValue("label123", clientTypeDesc);
            ifr.setValue("label120", afyp);
            ifr.setValue("textbox904", exactIncome);

            if (clientType.equalsIgnoreCase("ProposerInsured")) {
                ifr.setStyle("label110", "visible", "false");//L2BI Name Label
                ifr.setStyle("L2BINAME", "visible", "false");
                ifr.setStyle("label134", "visible", "false"); //Insured Client ID Label
                ifr.setStyle("label138", "visible", "false");//Insured Age Label
                ifr.setStyle("INSURED_AGE", "visible", "false");
                ifr.setStyle("INSURED_CLIENT_ID", "visible", "false");
            }
            /* if (clientType.equalsIgnoreCase("Company")) {
                ifr.setStyle("label122", "visible", "false");//L2BI Name Label
                ifr.setStyle("label118", "visible", "false");
                
            }*/
            //Header details End
            if((!(plan_type.equalsIgnoreCase("ANNUITY"))) && (!(clientType.equalsIgnoreCase("Company"))) && (!(ifr.getValue("IS_JOINTLIFE").toString().equalsIgnoreCase("Y")))) //DR-23942 mansi
                 ifr.setStyle("Q_L2BI_DETAILS_PAN_NUMBER_DUP", "visible", "false");
            List queryList1;
            if (!activityName.equalsIgnoreCase("Source")) {

                ifr.setStyle("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");
                ifr.setStyle("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");
                ifr.setStyle("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");

                String dataquery
                        = "SELECT Q_PROPOSER_DETAILS.SPECIFY_TITLE, Q_PROPOSER_DETAILS.TITLE, Q_PROPOSER_DETAILS.FIRST_NAME, Q_PROPOSER_DETAILS.MIDDLE_NAME, Q_PROPOSER_DETAILS.LAST_NAME,  Q_PROPOSER_DETAILS.DATE_OF_INCOR, Q_PROPOSER_DETAILS.GENDER, Q_PROPOSER_DETAILS.PIN_CODE, Q_PROPOSER_DETAILS.HOUSE_NO_APT_NAME, Q_PROPOSER_DETAILS.ROAD_AREA_SECTOR, Q_PROPOSER_DETAILS.LANDMARK, Q_PROPOSER_DETAILS.VILLAGE_TOWN, Q_PROPOSER_DETAILS.CITY_DISTRICT, Q_PROPOSER_DETAILS.STATE_UT, Q_PROPOSER_DETAILS.MOBILE_NO_2, Q_PROPOSER_DETAILS.LANDLINE_NO, Q_PROPOSER_DETAILS.STD, Q_PROPOSER_DETAILS.MOBILE_NO_1, Q_PROPOSER_DETAILS.EMAIL_ID, Q_PROPOSER_DETAILS.PAN_NUMBER, Q_PROPOSER_DETAILS.FATHER_HUSBAND_NAME, Q_PROPOSER_DETAILS.PERM_PIN_CODE, Q_PROPOSER_DETAILS.PERM_HOUSE_NO_APT_NAME, Q_PROPOSER_DETAILS.PERM_ROAD_AREA_SECTOR, Q_PROPOSER_DETAILS.PERM_LANDMARK, Q_PROPOSER_DETAILS.PERM_VILLAGE_TOWN, Q_PROPOSER_DETAILS.PERM_CITY_DISTRICT, Q_PROPOSER_DETAILS.PERM_STATE_UT, Q_PROPOSER_DETAILS.PERM_MOBILE_NO_1, Q_PROPOSER_DETAILS.PERM_MOBILE_NO_2, Q_PROPOSER_DETAILS.PERM_LANDLINE_NO, Q_PROPOSER_DETAILS.PERM_STD, Q_PROPOSER_DETAILS.COUNTRY, Q_PROPOSER_DETAILS.PERM_COUNTRY,Q_PROPOSER_DETAILS.Countrycode1,Q_PROPOSER_DETAILS.Countrycode2,Q_PROPOSER_DETAILS.PermCountrycode1,Q_PROPOSER_DETAILS.PermCountrycode2, Q_NEFT_DETAILS.NAME_BRANCH_NEFT, Q_NEFT_DETAILS.ACC_NO_NEFT, Q_NEFT_DETAILS.IFSC_NEFT, Q_L2BI_DETAILS.SPECIFY_TITLE, Q_L2BI_DETAILS.TITLE, Q_L2BI_DETAILS.FIRST_NAME, Q_L2BI_DETAILS.MIDDLE_NAME, Q_L2BI_DETAILS.LAST_NAME, Q_L2BI_DETAILS.GENDER, Q_L2BI_DETAILS.PIN_CODE, Q_L2BI_DETAILS.HOUSE_NO_APT_NAME, Q_L2BI_DETAILS.ROAD_AREA_SECTOR, Q_L2BI_DETAILS.LANDMARK, Q_L2BI_DETAILS.VILLAGE_TOWN, Q_L2BI_DETAILS.CITY_DISTRICT, Q_L2BI_DETAILS.STATE_UT, Q_L2BI_DETAILS.MOBILE_NO_2, Q_L2BI_DETAILS.LANDLINE_NO, Q_L2BI_DETAILS.STD, Q_L2BI_DETAILS.MOBILE_NO_1, Q_L2BI_DETAILS.PERM_PIN_CODE, Q_L2BI_DETAILS.PERM_HOUSE_NO_APT_NAME, Q_L2BI_DETAILS.PERM_ROAD_AREA_SECTOR, Q_L2BI_DETAILS.PERM_LANDMARK, Q_L2BI_DETAILS.PERM_VILLAGE_TOWN, Q_L2BI_DETAILS.PERM_CITY_DISTRICT, Q_L2BI_DETAILS.PERM_STATE_UT, Q_L2BI_DETAILS.PERM_MOBILE_NO_2, Q_L2BI_DETAILS.PERM_LANDLINE_NO, Q_L2BI_DETAILS.PERM_STD, Q_L2BI_DETAILS.PERM_MOBILE_NO_1, Q_L2BI_DETAILS.COUNTRY, Q_L2BI_DETAILS.PERM_COUNTRY,Q_L2BI_DETAILS.Countrycode1,Q_L2BI_DETAILS.Countrycode2,Q_L2BI_DETAILS.PermCountrycode1,Q_L2BI_DETAILS.PermCountrycode2, Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE, Q_PAYOR_PAN_DETAILS.TITLE, Q_PAYOR_PAN_DETAILS.FIRST_NAME, Q_PAYOR_PAN_DETAILS.MIDDLE_NAME, Q_PAYOR_PAN_DETAILS.LAST_NAME, Q_PAYOR_PAN_DETAILS.PAN_NUMBER, Q_PAYOR_PAN_DETAILS.GENDER, Q_PAYOR_PAN_DETAILS.BANK_NAME, Q_PAYOR_PAN_DETAILS.BANK_ACC_NO, Q_COVERAGE_DETAILS.SUM_ASSURED, EXT.AFYP,Q_L2BI_DETAILS.PAN_NUMBER FROM NG_NB_PROPOSER_DETAILS(NOLOCK) Q_PROPOSER_DETAILS, NG_NB_L2BI_DETAILS(NOLOCK) Q_L2BI_DETAILS, NG_NB_EXT_TABLE(NOLOCK) EXT,NG_NB_PAYOR_PAN_DETAILS(NOLOCK) Q_PAYOR_PAN_DETAILS, NG_NB_NEFT_DETAILS(NOLOCK) Q_NEFT_DETAILS , NG_NB_COVERAGE_DETAILS(NOLOCK) Q_COVERAGE_DETAILS WHERE Q_PROPOSER_DETAILS.WI_NAME='" + wiName + "' AND Q_L2BI_DETAILS.WI_NAME='" + wiName + "' AND EXT.WI_NAME='" + wiName + "' AND Q_PAYOR_PAN_DETAILS.WI_NAME='" + wiName + "' AND Q_NEFT_DETAILS.WI_NAME='" + wiName + "' AND Q_COVERAGE_DETAILS.WI_NAME='" + wiName + "'";

                String[] controlNameArr = {"Q_PROPOSER_DETAILS.SPECIFY_TITLE", "Q_PROPOSER_DETAILS.TITLE", "Q_PROPOSER_DETAILS.FIRST_NAME", "Q_PROPOSER_DETAILS.MIDDLE_NAME", "Q_PROPOSER_DETAILS.LAST_NAME", "Q_PROPOSER_DETAILS.DATE_OF_INCOR", "Q_PROPOSER_DETAILS.GENDER", "Q_PROPOSER_DETAILS.PIN_CODE", "Q_PROPOSER_DETAILS.HOUSE_NO_APT_NAME", "Q_PROPOSER_DETAILS.ROAD_AREA_SECTOR", "Q_PROPOSER_DETAILS.LANDMARK", "Q_PROPOSER_DETAILS.VILLAGE_TOWN", "Q_PROPOSER_DETAILS.CITY_DISTRICT", "Q_PROPOSER_DETAILS.STATE_UT", "Q_PROPOSER_DETAILS.MOBILE_NO_2", "Q_PROPOSER_DETAILS.LANDLINE_NO", "Q_PROPOSER_DETAILS.STD", "Q_PROPOSER_DETAILS.MOBILE_NO_1", "Q_PROPOSER_DETAILS.EMAIL_ID", "Q_PROPOSER_DETAILS.PAN_NUMBER", "Q_PROPOSER_DETAILS.FATHER_HUSBAND_NAME", "Q_PROPOSER_DETAILS.PERM_PIN_CODE", "Q_PROPOSER_DETAILS.PERM_HOUSE_NO_APT_NAME", "Q_PROPOSER_DETAILS.PERM_ROAD_AREA_SECTOR", "Q_PROPOSER_DETAILS.PERM_LANDMARK", "Q_PROPOSER_DETAILS.PERM_VILLAGE_TOWN", "Q_PROPOSER_DETAILS.PERM_CITY_DISTRICT", "Q_PROPOSER_DETAILS.PERM_STATE_UT", "Q_PROPOSER_DETAILS.PERM_MOBILE_NO_1", "Q_PROPOSER_DETAILS.PERM_MOBILE_NO_2", "Q_PROPOSER_DETAILS.PERM_LANDLINE_NO", "Q_PROPOSER_DETAILS.PERM_STD", "Q_PROPOSER_DETAILS.COUNTRY", "Q_PROPOSER_DETAILS.PERM_COUNTRY","Q_PROPOSER_DETAILS.Countrycode1","Q_PROPOSER_DETAILS.Countrycode2","Q_PROPOSER_DETAILS.PermCountrycode1","Q_PROPOSER_DETAILS.PermCountrycode2", "Q_NEFT_DETAILS.NAME_BRANCH_NEFT", "Q_NEFT_DETAILS.ACC_NO_NEFT", "Q_NEFT_DETAILS.IFSC_NEFT", "Q_L2BI_DETAILS.SPECIFY_TITLE", "Q_L2BI_DETAILS.TITLE", "Q_L2BI_DETAILS.FIRST_NAME", "Q_L2BI_DETAILS.MIDDLE_NAME", "Q_L2BI_DETAILS.LAST_NAME", "Q_L2BI_DETAILS.GENDER", "Q_L2BI_DETAILS.PIN_CODE", "Q_L2BI_DETAILS.HOUSE_NO_APT_NAME", "Q_L2BI_DETAILS.ROAD_AREA_SECTOR", "Q_L2BI_DETAILS.LANDMARK", "Q_L2BI_DETAILS.VILLAGE_TOWN", "Q_L2BI_DETAILS.CITY_DISTRICT", "Q_L2BI_DETAILS.STATE_UT", "Q_L2BI_DETAILS.MOBILE_NO_2", "Q_L2BI_DETAILS.LANDLINE_NO", "Q_L2BI_DETAILS.STD", "Q_L2BI_DETAILS.MOBILE_NO_1", "Q_L2BI_DETAILS.PERM_PIN_CODE", "Q_L2BI_DETAILS.PERM_HOUSE_NO_APT_NAME", "Q_L2BI_DETAILS.PERM_ROAD_AREA_SECTOR", "Q_L2BI_DETAILS.PERM_LANDMARK", "Q_L2BI_DETAILS.PERM_VILLAGE_TOWN", "Q_L2BI_DETAILS.PERM_CITY_DISTRICT", "Q_L2BI_DETAILS.PERM_STATE_UT", "Q_L2BI_DETAILS.PERM_MOBILE_NO_2", "Q_L2BI_DETAILS.PERM_LANDLINE_NO", "Q_L2BI_DETAILS.PERM_STD", "Q_L2BI_DETAILS.PERM_MOBILE_NO_1", "Q_L2BI_DETAILS.COUNTRY", "Q_L2BI_DETAILS.PERM_COUNTRY","Q_L2BI_DETAILS.Countrycode1","Q_L2BI_DETAILS.Countrycode2","Q_L2BI_DETAILS.PermCountrycode1","Q_L2BI_DETAILS.PermCountrycode2", "Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "Q_PAYOR_PAN_DETAILS.TITLE", "Q_PAYOR_PAN_DETAILS.FIRST_NAME", "Q_PAYOR_PAN_DETAILS.MIDDLE_NAME", "Q_PAYOR_PAN_DETAILS.LAST_NAME", "Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "Q_PAYOR_PAN_DETAILS.GENDER", "Q_PAYOR_PAN_DETAILS.BANK_NAME", "Q_PAYOR_PAN_DETAILS.BANK_ACC_NO", "Q_COVERAGE_DETAILS.SUM_ASSURED", "AFYP","Q_L2BI_DETAILS.PAN_NUMBER"};
                queryList1 = getValFromQuery(dataquery);
                String qcSummaryControlID = "";
                if (queryList1 != null) {
                    for (int i = 0; i < controlNameArr.length; i++) {
                        try {
                            controlValue = (String) ((List) queryList1.get(0)).get(i);
                            qcSummaryControlID = controlNameArr[i].replace(".", "_") + "_DUP";
                            ifr.setValue(qcSummaryControlID, controlValue);

                            if ((controlNameArr[i].equalsIgnoreCase("Q_PROPOSER_DETAILS.SPECIFY_TITLE")
                                    || controlNameArr[i].equalsIgnoreCase("Q_L2BI_DETAILS.SPECIFY_TITLE")
                                    || controlNameArr[i].equalsIgnoreCase("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE")) && controlValue.equalsIgnoreCase("Others")) {
                                ifr.setStyle(qcSummaryControlID, "visible", "true");
                            }

                        } catch (Exception e) {
                            System.out.println("Error in copyDataToQCSummary in Control " + controlNameArr[i] + " " + e.toString());
                        }
                    }
                }
                //Set Proposer and Insured Age
                //proposerDob = ifr.getValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH").toString();
                String getDOB = "SELECT Q_PROPOSER_DETAILS.DATE_OF_BIRTH FROM NG_NB_PROPOSER_DETAILS(NOLOCK) Q_PROPOSER_DETAILS WHERE Q_PROPOSER_DETAILS.WI_NAME='" + wiName + "' ";
                List queryList2 = getValFromQuery(getDOB);
                int PA = 0;
                if (queryList2 != null) {
                    proposerDob = (String) ((List) queryList2.get(0)).get(0);
                    System.out.println(proposerDob);
                    //proposerAge = calculateAge(proposerDob);
                    //PA = DolphinUtil.CalculateYears(proposerDob,ifr);
                    //PA = proposerAge;
                    ifr.setValue("PROPOSER_AGE", String.valueOf(DolphinUtil.CalculateYears(proposerDob, ifr)));
                    //SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");
                    // Date date1=formatter.parse(proposerDob);
                    //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/mm/yyyy");
                    String[] date1 = proposerDob.split("-");
                    String date2 = date1[2] + "/" + date1[1] + "/" + date1[0];

                    //String date2 = simpleDateFormat.format(date1);
                    System.out.println(date2);
                    ifr.setValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", date2);
                }

                String relationWithProposer = "";
                String getDOBINSUR = "SELECT ISNULL(DOB,''),RELATIONSHIP_WITH_PROPOSER FROM NG_NB_L2BI_DETAILS(NOLOCK) WHERE WI_NAME='" + wiName + "' ";
                List queryList3 = getValFromQuery(getDOBINSUR);
                int IA = 0;
                if (queryList3 != null) {
                    insuredDob = (String) ((List) queryList3.get(0)).get(0);
                    relationWithProposer = (String) ((List) queryList3.get(0)).get(1);
                    //insuredAge = calculateAge(insuredDob);
                    //IA = insuredAge;
                    ifr.setValue("INSURED_AGE", String.valueOf(DolphinUtil.CalculateYears(insuredDob, ifr)));
                    //SimpleDateFormat formatter = new SimpleDateFormat("YYYY-DD-MM");
                    // Date date1=formatter.parse(insuredDob);
                    //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/mm/yyyy");
                    String[] date1 = insuredDob.split("-");
                    String date2 = date1[2] + "/" + date1[1] + "/" + date1[0];
                    //String date2 = simpleDateFormat.format(date1);
                    ifr.setValue("Q_L2BI_DETAILS_DOB_DUP", date2);
                }

                //insuredDob = ifr.getValue("Q_L2BI_DETAILS.DOB").toString();
                String getDOBPAyor = "SELECT Q_PAYOR_PAN_DETAILS.DATE_OF_BIRTH FROM NG_NB_PAYOR_PAN_DETAILS(NOLOCK) Q_PAYOR_PAN_DETAILS WHERE Q_PAYOR_PAN_DETAILS.WI_NAME='" + wiName + "' ";
                List queryList8 = getValFromQuery(getDOBPAyor);

                if (queryList8 != null) {
                    String payorDob = (String) ((List) queryList8.get(0)).get(0);

                    // SimpleDateFormat formatter = new SimpleDateFormat("YYYY-DD-MM");
                    //Date date1=formatter.parse(payorDob);
                    //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/mm/yyyy");
                    String[] date1 = payorDob.split("-");
                    String date2 = date1[2] + "/" + date1[1] + "/" + date1[0];
                    //String date2 = simpleDateFormat.format(date1);
                    ifr.setValue("Q_PAYOR_PAN_DETAILS_DATE_OF_BIRTH_DUP", date2);
                }

                //Copy UW Summary
                ifr.setValue("textbox813", proposerFullName);

                if (!(activityName.equalsIgnoreCase("Manual_UW") || activityName.equalsIgnoreCase("Manual_UW_Vendor") || activityName.equalsIgnoreCase("Manual_UW_Supervisor") || activityName.equalsIgnoreCase("UW_HOD")  || activityName.equalsIgnoreCase("URMU") || activityName.equalsIgnoreCase("CMO"))) {

                    if (clientType.equalsIgnoreCase("ProposerInsured")) {
                        String getdata_PROP = "SELECT MARITAL_STATUS,INDUSTRY_TYPE,PIN_CODE,GENDER,OCCUPATION,NATIONALITY,EXACT_INCOME,CITY_DISTRICT FROM NG_NB_PROPOSER_DETAILS(NOLOCK) WHERE WI_NAME='" + wiName + "' ";
                        List queryList5 = getValFromQuery(getdata_PROP);
                        if (queryList5 != null) {
                            ifr.setValue("Q_L2BI_DETAILS_MARITAL_STATUS_UW_DUP", (String) ((List) queryList5.get(0)).get(0));
                            ifr.setValue("Q_L2BI_DETAILS_INDUSTRY_TYPE_UW_DUP", (String) ((List) queryList5.get(0)).get(1));
                            ifr.setValue("Q_L2BI_DETAILS_PIN_CODE_UW_DUP", (String) ((List) queryList5.get(0)).get(2));
                            ifr.setValue("Q_L2BI_DETAILS_GENDER_UW_DUP", (String) ((List) queryList5.get(0)).get(3));
                            ifr.setValue("Q_L2BI_DETAILS_OCCUPATION_UW_DUP", (String) ((List) queryList5.get(0)).get(4));
                            ifr.setValue("Q_L2BI_DETAILS_NATIONALITY_UW_DUP", (String) ((List) queryList5.get(0)).get(5));
                            ifr.setValue("Q_PROPOSER_DETAILS_EXACT_INCOME_UW_DUP", (String) ((List) queryList5.get(0)).get(6));
                            ifr.setValue("textbox814", (String) ((List) queryList5.get(0)).get(7));
                            ifr.setValue("Q_L2BI_DETAILS_AGE_UW_DUP", String.valueOf(DolphinUtil.CalculateYears(proposerDob, ifr)));
                            ifr.setValue("PERSONAL_DETAILS_UW_INSURED_NAME", proposerFullName);
                            ifr.setValue("Q_L2BI_DETAILS_RELATIONSHIP_WITH_PROPOSER_UW_DUP", "Self");
                        }
                    } else {
                        String getdata_INSUR = "SELECT MARITAL_STATUS,INDUSTRY_TYPE,PIN_CODE,GENDER,OCCUPATION,NATIONALITY,EXACT_INCOME,CITY_DISTRICT  FROM NG_NB_L2BI_DETAILS(NOLOCK) WHERE WI_NAME='" + wiName + "' ";
                        List queryList6 = getValFromQuery(getdata_INSUR);
                        if (queryList6 != null) {
                            ifr.setValue("Q_L2BI_DETAILS_MARITAL_STATUS_UW_DUP", (String) ((List) queryList6.get(0)).get(0));
                            ifr.setValue("Q_L2BI_DETAILS_INDUSTRY_TYPE_UW_DUP", (String) ((List) queryList6.get(0)).get(1));
                            ifr.setValue("Q_L2BI_DETAILS_PIN_CODE_UW_DUP", (String) ((List) queryList6.get(0)).get(2));
                            ifr.setValue("Q_L2BI_DETAILS_GENDER_UW_DUP", (String) ((List) queryList6.get(0)).get(3));
                            ifr.setValue("Q_L2BI_DETAILS_OCCUPATION_UW_DUP", (String) ((List) queryList6.get(0)).get(4));
                            ifr.setValue("Q_L2BI_DETAILS_NATIONALITY_UW_DUP", (String) ((List) queryList6.get(0)).get(5));
                            ifr.setValue("Q_PROPOSER_DETAILS_EXACT_INCOME_UW_DUP", (String) ((List) queryList6.get(0)).get(6));
                            ifr.setValue("textbox814", (String) ((List) queryList6.get(0)).get(7));
                            ifr.setValue("Q_L2BI_DETAILS_AGE_UW_DUP", String.valueOf(DolphinUtil.CalculateYears(insuredDob, ifr)));
                            ifr.setValue("PERSONAL_DETAILS_UW_INSURED_NAME", insuredFullName);
                            ifr.setValue("Q_L2BI_DETAILS_RELATIONSHIP_WITH_PROPOSER_UW_DUP", relationWithProposer);
                        }
                    }

                }

                String uwSumAssuredDetails = "SELECT ISNULL(INSUR_POLICY_PROP,''), ISNULL(INSUR_POLICY_INSUR,''), ISNULL(LIFE_TOTAL_SUM_PROP,''), ISNULL(LIFE_TOTAL_SUM_INSUR,''), ISNULL(TOTAL_SUM_PROP,''), ISNULL(TOTAL_SUM_INSUR,'') FROM NG_NB_OTHER_POLICY_INFO (NOLOCK) WHERE WI_NAME='" + wiName + "' ";
                List queryList7 = getValFromQuery(uwSumAssuredDetails);
                if (queryList7 != null) {
                    String otherPolicyProp, otherpolicyInsur, lifeSAProp, lifeSAInsur, totalSAProp, totalSAInsur;
                    otherPolicyProp = (String) ((List) queryList7.get(0)).get(0);
                    otherpolicyInsur = (String) ((List) queryList7.get(0)).get(1);
                    lifeSAProp = (String) ((List) queryList7.get(0)).get(2);
                    lifeSAInsur = (String) ((List) queryList7.get(0)).get(3);
                    totalSAProp = (String) ((List) queryList7.get(0)).get(4);
                    totalSAInsur = (String) ((List) queryList7.get(0)).get(5);

                    if (clientType.equalsIgnoreCase("ProposerInsured") && otherPolicyProp.equalsIgnoreCase("Y")) {
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_LIFE", lifeSAProp);
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_DDCI", totalSAProp);
                    } else if (otherpolicyInsur.equalsIgnoreCase("Y")) {
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_LIFE", lifeSAInsur);
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_DDCI", totalSAInsur);
                    }
                    //JOINT //AANCHAL //30JAN
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_LIFE_PROP", lifeSAProp);
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_DDCI_PROP", totalSAProp);
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_LIFE_INSUR", lifeSAInsur);
                        ifr.setValue("SUM_ASSURED_DETAILS_UW_TSA_DDCI_INSUR", totalSAInsur);
                    //JOINT //AANCHAL //30JAN
                }
            }

            if (activityName.equalsIgnoreCase("URMU") || activityName.equalsIgnoreCase("CMO") || activityName.equalsIgnoreCase("Reinsurance")) {

                ifr.setTabStyle("mytab", "0", "disable", "true");
                ifr.setTabStyle("mytab", "2", "disable", "true"); //IIB
                
            }
            //12APril
           /* String getDataQuery1 = "select CREDIT_SCORE,INCOME_ESTIMATED from NG_NB_LIST_CREDIT_SCORE(nolock) where WI_NAME = '"+wiName+"' and NAME_BUREAU='CIBIL'";  //added by AANCHAL ON 30 MARCH
             queryList = getValFromQuery(getDataQuery1);
            if (queryList != null) 
            {
                    String CIBIL_CC=(String) ((List) queryList.get(0)).get(0);
                    String CIBIL_IE=(String) ((List) queryList.get(0)).get(1);
                     ifr.setValue("CIBIL", CIBIL_CC);
                 ifr.setValue("ESTIMATED_INCOME_BAND", CIBIL_IE);
            }
 
            String getDataQuery2 = "select CREDIT_SCORE,INCOME_ESTIMATED from NG_NB_LIST_CREDIT_SCORE(nolock) where WI_NAME = '"+wiName+"' and NAME_BUREAU='CRIF'";  //added by AANCHAL ON 30 MARCH
            queryList = getValFromQuery(getDataQuery2);
            if (queryList != null) 
            {
                    String CRIF_CC=(String) ((List) queryList.get(0)).get(0);
                    String CRIF_IE=(String) ((List) queryList.get(0)).get(1);
                     ifr.setValue("textbox904", CRIF_IE);
                 ifr.setValue("CRIF", CRIF_CC);
            }*/
            //12April

        } catch (Exception e) {
            System.out.println("Error in copyDataToQCSummary of Business Rules class--" + e.toString());
        }
    }

    private int calculateAge(String DOB) {
        String years = "", productDating = "";

        Date inDate = null;
        Date currentDate = new Date();

        try {
            inDate = new SimpleDateFormat("YYYY-DD-MM").parse(DOB);
        } catch (ParseException ex) {
            inDate = new Date();
        }

        LocalDate fromDate = inDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate toDate = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        int diffYears = Period.between(fromDate, toDate).getYears();
        years = String.valueOf(diffYears);
        return diffYears;
    }

    public String receiveReqAtmPROCET() {
        String winame = (String) ifr.getControlValue("WorkItemName");
        String query = "EXEC NG_SP_NB_REQ_RECEIVE_AT_SUBMIT '" + winame + "'";
        String response = "";
        List queryList;
        queryList = getValFromQuery(query);
        if (queryList != null) {
            response = (String) ((List) queryList.get(0)).get(0);
        }
        return response;

    }

    public void medicalInfoProposer() {

        if (ifr.getValue("Q_MED_INFO_PROP_COVID_QUESTIONS").toString().equalsIgnoreCase("Y")) {
           // ifr.setStyle("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT");

            //ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR");

            //ifr.setStyle("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS");

            //ifr.setStyle("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED");

            //ifr.setStyle("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS", "visible", "true");
            //ifr.setStyle("label167", "visible", "true");
            //ifr.setStyle("label168", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS");

            //ifr.setStyle("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH");
        } else {
            //clearValue("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT", true);
            ifr.setValue("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT", "N");

            ifr.setStyle("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT");

            //clearValue("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR", true);
            ifr.setValue("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR", "N");

            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR");

            //clearValue("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS", true);
            ifr.setValue("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS", "N");

            ifr.setStyle("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS");

            //clearValue("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED", true);
            ifr.setValue("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED", "N");

            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED");

            //clearValue("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS", true);
            ifr.setValue("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS", "N");

            ifr.setStyle("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS", "visible", "false");
            ifr.setStyle("label167", "visible", "false");
            ifr.setStyle("label168", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS");

            //clearValue("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH", true);
            ifr.setValue("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH", "N");

            ifr.setStyle("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_CONTACT_WITH_SUSPECT").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_QUARANTINE_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_ADVISED_QUARANTINE_1");
        } else {
            //clearValue("Q_MED_INFO_PROP_ADVISED_QUARANTINE_1", true);

            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_QUARANTINE_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ADVISED_QUARANTINE_1");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_TRAVEL_ABROAD_1_YEAR").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_QUARANTINE_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_ADVISED_QUARANTINE_2");

            ifr.setStyle("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1");

            ifr.setStyle("Q_MED_INFO_PROP_DURATION_OF_STAY_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_DURATION_OF_STAY_1");

            ifr.setStyle("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1");
        } else {
            //clearValue("Q_MED_INFO_PROP_ADVISED_QUARANTINE_2", true);

            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_QUARANTINE_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ADVISED_QUARANTINE_2");

            //clearValue("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1", true);
            ifr.setValue("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1", "N");

            ifr.setStyle("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_1");

            //clearValue("Q_MED_INFO_PROP_DURATION_OF_STAY_1", true);
            //ifr.clearComboOptions("Q_MED_INFO_PROP_DURATION_OF_STAY_1");
            ifr.setStyle("Q_MED_INFO_PROP_DURATION_OF_STAY_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_DURATION_OF_STAY_1");

            //clearValue("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1", true);
            ifr.setValue("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1", "N");
            ifr.setStyle("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_1");
        }
        if (ifr.getValue("Q_MED_INFO_PROP_PLAN_TRAVEL_OVERSEAS").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_2");

            ifr.setStyle("Q_MED_INFO_PROP_DURATION_OF_STAY_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_DURATION_OF_STAY_2");

            ifr.setStyle("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_2");
        } else {
            //clearValue("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_SPECIFY_COUNTRIES_2");

            //clearValue("Q_MED_INFO_PROP_DURATION_OF_STAY_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_DURATION_OF_STAY_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_DURATION_OF_STAY_2");

            //clearValue("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_DATE_OF_RETURN_INDIA_2");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_ADVISED_TO_BE_TESTED").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_AWAITING_TEST_RESULT", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_AWAITING_TEST_RESULT");
        } else {
            //clearValue("Q_MED_INFO_PROP_AWAITING_TEST_RESULT", true);
            ifr.setValue("Q_MED_INFO_PROP_AWAITING_TEST_RESULT", "N");
            ifr.setStyle("Q_MED_INFO_PROP_AWAITING_TEST_RESULT", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_AWAITING_TEST_RESULT");
        }
        if (ifr.getValue("Q_MED_INFO_PROP_EXPERIENCED_SYMPTOMS").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_PERSISTENT_COUGH", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_PERSISTENT_COUGH");

            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE");
        } else {
            //clearValue("Q_MED_INFO_PROP_PERSISTENT_COUGH", true);
            ifr.setValue("Q_MED_INFO_PROP_PERSISTENT_COUGH", "N");
            ifr.setStyle("Q_MED_INFO_PROP_PERSISTENT_COUGH", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_PERSISTENT_COUGH");

            //clearValue("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE", true);
            ifr.setValue("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE", "N");

            ifr.setStyle("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_PERSISTENT_COUGH").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_CONSULT_DOCTOR_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_CONSULT_DOCTOR_1");

            ifr.setStyle("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_1");

            ifr.setStyle("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_1");

            ifr.setStyle("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_1", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_1");
        } else {
            //clearValue("Q_MED_INFO_PROP_CONSULT_DOCTOR_1", true);
            ifr.setValue("Q_MED_INFO_PROP_CONSULT_DOCTOR_1", "N");
            ifr.setStyle("Q_MED_INFO_PROP_CONSULT_DOCTOR_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CONSULT_DOCTOR_1");

            //clearValue("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_1", true);
            ifr.setStyle("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_1");

            //clearValue("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_1", true);
            ifr.setStyle("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_1");

            //clearValue("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_1", true);
            ifr.setStyle("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_1");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_ADVISED_SELF_ISOLATE").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_CONSULT_DOCTOR_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_CONSULT_DOCTOR_2");

            ifr.setStyle("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_2");

            ifr.setStyle("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_2");

            ifr.setStyle("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_2", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_2");
        } else {
            //clearValue("Q_MED_INFO_PROP_CONSULT_DOCTOR_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_CONSULT_DOCTOR_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CONSULT_DOCTOR_2");

            //clearValue("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ANY_TREATMENT_GIVEN_2");

            //clearValue("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_EXACT_DIAGNOSIS_2");

            //clearValue("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_2", true);
            ifr.setStyle("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_MADE_FULL_RECOVERY_2");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_CURRENTLY_GOOD_HEALTH").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_PROVIDE_DETAILS", "visible", "true");
            setMandatory("Q_MED_INFO_PROP_PROVIDE_DETAILS");
        } else {
            //clearValue("Q_MED_INFO_PROP_PROVIDE_DETAILS", true);
            ifr.setStyle("Q_MED_INFO_PROP_PROVIDE_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_PROVIDE_DETAILS");
        }

        //Plan Specific validation
        String plan = ifr.getValue("PLAN_TYPE").toString();
        if (plan.equalsIgnoreCase("HEALTH")) {

            ifr.setStyle("Q_MED_INFO_PROP_CANCER_INVEST", "visible", "true"); //added by abhishek 
            // ifr.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS","visible","true")
            ifr.setStyle("Q_MED_INFO_PROP_CANC_PARENT", "visible", "true");
            // ifr.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS","visible","true")
            ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C", "visible", "true");
            // ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS","visible","true")
            ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH", "visible", "true");
             ifr.setStyle("Q_MED_INFO_PROP_MEDICAL_ULTRASOUND", "visible", "true");
              ifr.setStyle("Q_MED_INFO_PROP_MEDICAL_ALCOHOL", "visible", "true");
            //ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS","visible","true")
        } else {
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_INVEST", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_CANC_PARENT", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "visible", "false");
             ifr.setStyle("Q_MED_INFO_PROP_MEDICAL_ULTRASOUND", "visible", "false");
              ifr.setStyle("Q_MED_INFO_PROP_MEDICAL_ALCOHOL", "visible", "false");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_CANCER_INVEST").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_PROVIDE_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_CANCER_DETAILS", true);
           // ifr.setValue("Q_MED_INFO_PROP_CANCER_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CANCER_DETAILS");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_CANC_PARENT").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", true);
            //ifr.setValue("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_CANCER_PARENT_DETAILS");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_HEPATITIS_B_C").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", true);
            //ifr.setValue("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_HEPATITIS_B_C_DETAILS");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_RECURR_COUGH").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", true);
            //ifr.setValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS");
        }
        if (ifr.getValue("Q_MED_INFO_PROP_MEDICAL_ULTRASOUND").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_ULTRASOUND_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", true);
            //ifr.setValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_ULTRASOUND_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ULTRASOUND_DETAILS");
        }
        if (ifr.getValue("Q_MED_INFO_PROP_MEDICAL_ALCOHOL").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_ALCOHOL_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", true);
            //ifr.setValue("Q_MED_INFO_PROP_RECURR_COUGH_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_ALCOHOL_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_ALCOHOL_DETAILS");
        }

       /* if (plan.equalsIgnoreCase("TGBP5") || plan.equalsIgnoreCase("TSWPVL") || plan.equalsIgnoreCase("TSWPVR")) //added by abhishek 
        {
            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE", "visible", "true");
            //ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS","visible","true")
            ifr.setStyle("Q_MED_INFO_PROP_FAMILY_HEART_SIXTY", "visible", "true");
            ifr.setStyle("Q_MED_INFO_PROP_AIDS_DISORDER", "visible", "true");
            ifr.setStyle("Q_MED_INFO_PROP_BIOSPIES_DISORDER", "visible", "true");
            ifr.setStyle("Q_MED_INFO_PROP_ATTACH_MEDICAL_REPORT", "visible", "true");
        } else*/ {
            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_FAMILY_HEART_SIXTY", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_AIDS_DISORDER", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_BIOSPIES_DISORDER", "visible", "false");
            ifr.setStyle("Q_MED_INFO_PROP_ATTACH_MEDICAL_REPORT", "visible", "false");
        }

        if (ifr.getValue("Q_MED_INFO_PROP_TRAVEL_OUTSIDE").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS", "visible", "true");
            //setMandatory("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS")
        } else {
            //clearValue("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS", true);
            ifr.setValue("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_PROP_TRAVEL_OUTSIDE_DETAILS");
        }

    }

    public void medicalInfoInsured() {
        if (ifr.getValue("Q_MED_INFO_INSUR_COVID_QUESTIONS").toString().equalsIgnoreCase("Y")) {
            //ifr.setStyle("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT");

            //ifr.setStyle("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR");

            //ifr.setStyle("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS");

            //ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED");

            //ifr.setStyle("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS", "visible", "true");
            //ifr.setStyle("label169", "visible", "true");
            //ifr.setStyle("label170", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS");

            //ifr.setStyle("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH", "visible", "true");
            //setMandatory("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT", "");
            ifr.setStyle("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT");

            ifr.setValue("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR", "");
            ifr.setStyle("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR");

            ifr.setValue("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS", "");
            ifr.setStyle("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS");

            ifr.setValue("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED");

            ifr.setValue("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS", "");
            ifr.setStyle("label169", "visible", "false");
            ifr.setStyle("label170", "visible", "false");
            ifr.setStyle("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS");

            ifr.setValue("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH", "");
            ifr.setStyle("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_CONTACT_WITH_SUSPECT").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_1");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_1");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_TRAVEL_ABROAD_1_YEAR").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_2");

            ifr.setStyle("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_1");

            ifr.setStyle("Q_MED_INFO_INSUR_DURATION_OF_STAY_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_DURATION_OF_STAY_1");

            ifr.setStyle("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_1");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ADVISED_QUARANTINE_2");

            ifr.setValue("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_1");
            ifr.setValue("Q_MED_INFO_INSUR_DURATION_OF_STAY_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_DURATION_OF_STAY_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_DURATION_OF_STAY_1");
            ifr.setValue("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_1");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_PLAN_TRAVEL_OVERSEAS").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_2");

            ifr.setStyle("Q_MED_INFO_INSUR_DURATION_OF_STAY_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_DURATION_OF_STAY_2");

            ifr.setStyle("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_2");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_SPECIFY_COUNTRIES_2");

            ifr.setValue("Q_MED_INFO_INSUR_DURATION_OF_STAY_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_DURATION_OF_STAY_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_DURATION_OF_STAY_2");

            ifr.setValue("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_DATE_OF_RETURN_INDIA_2");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_ADVISED_TO_BE_TESTED").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_AWAITING_TEST_RESULT", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_AWAITING_TEST_RESULT");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_AWAITING_TEST_RESULT", "");
            ifr.setStyle("Q_MED_INFO_INSUR_AWAITING_TEST_RESULT", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_AWAITING_TEST_RESULT");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_EXPERIENCED_SYMPTOMS").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_PERSISTENT_COUGH", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_PERSISTENT_COUGH");

            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_PERSISTENT_COUGH", "");
            ifr.setStyle("Q_MED_INFO_INSUR_PERSISTENT_COUGH", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_PERSISTENT_COUGH");

            ifr.setValue("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_PERSISTENT_COUGH").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_CONSULT_DOCTOR_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_CONSULT_DOCTOR_1");

            ifr.setStyle("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_1");

            ifr.setStyle("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_1");

            ifr.setStyle("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_1", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_1");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_CONSULT_DOCTOR_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_CONSULT_DOCTOR_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_CONSULT_DOCTOR_1");

            ifr.setValue("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_1");

            ifr.setValue("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_1");

            ifr.setValue("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_1", "");
            ifr.setStyle("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_1", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_1");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_ADVISED_SELF_ISOLATE").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_CONSULT_DOCTOR_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_CONSULT_DOCTOR_2");

            ifr.setStyle("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_2");

            ifr.setStyle("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_2");

            ifr.setStyle("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_2", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_2");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_CONSULT_DOCTOR_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_CONSULT_DOCTOR_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_CONSULT_DOCTOR_2");

            ifr.setValue("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_ANY_TREATMENT_GIVEN_2");

            ifr.setValue("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_EXACT_DIAGNOSIS_2");

            ifr.setValue("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_2", "");
            ifr.setStyle("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_2", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_MADE_FULL_RECOVERY_2");
        }

        if (ifr.getValue("Q_MED_INFO_INSUR_CURRENTLY_GOOD_HEALTH").toString().equalsIgnoreCase("Y")) {
            ifr.setStyle("Q_MED_INFO_INSUR_PROVIDE_DETAILS", "visible", "true");
            setMandatory("Q_MED_INFO_INSUR_PROVIDE_DETAILS");
        } else {
            ifr.setValue("Q_MED_INFO_INSUR_PROVIDE_DETAILS", "");
            ifr.setStyle("Q_MED_INFO_INSUR_PROVIDE_DETAILS", "visible", "false");
            setnonMandatory("Q_MED_INFO_INSUR_PROVIDE_DETAILS");
        }

    }

    public void setMandatory(String controlId) {
        ifr.setStyle(controlId, "mandatory", "true");
    }

    public void setnonMandatory(String controlId) {
        ifr.setStyle(controlId, "mandatory", "false");
    }

    public void Proposer_Equals_Insured_Validations() {
        String plantype = (String) ifr.getControlValue("PLAN_TYPE");
            	String planN = (String) ifr.getControlValue("PLAN_NAME");
            	String chnl = (String) ifr.getControlValue("CHANNEL");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                  else if(plantype.equalsIgnoreCase("HEALTH"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                String IS_POS="";
                	  List queryResult_POS = (List) ifr.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }
        if (ifr.getValue("Q_PROPOSER_DETAILS_GENDER").toString().equalsIgnoreCase("F") && ifr.getValue("Q_PROPOSER_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(ifr.getValue("PROPOSER_AGE").toString()) > 18 && (!(IS_POS.equalsIgnoreCase("Y"))) && (!(IS_POS.equalsIgnoreCase("FD")))) {
            ifr.setStyle("t4s2", "visible", "true");
            ifr.setStyle("t4s10", "visible", "true");

        } else {
            ifr.setStyle("t4s2", "visible", "false");
            ifr.setStyle("t4s10", "visible", "false");
        }
        ifr.setStyle("t4s7", "visible", "false");

    }

    public void Proposer_Different_Insured_Validations() {
         String plantype = (String) ifr.getControlValue("PLAN_TYPE");
            	String planN = (String) ifr.getControlValue("PLAN_NAME");
            	String chnl = (String) ifr.getControlValue("CHANNEL");
                //iFormRef.setValue("PARTIAL_EXACT_FLAG", "ND"); //Default if dedupe is done and no match
            	 // String PS = stringData;
            	//String SubChannel = (String) iFormRef.getControlValue("PLAN_TYPE");
           	 String query_POS ="";
       		 if(plantype.equalsIgnoreCase("TRAD"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' ";
       		 }
       		 else if(plantype.equalsIgnoreCase("JOINT"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "'"; 
       		 }
       		 else if(plantype.equalsIgnoreCase("ULIP"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("ANNUITY"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 else if(plantype.equalsIgnoreCase("HEALTH"))
       		 {
       			query_POS = "SELECT IS_POS"
                       + " FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='" + planN + "' AND Channel='" + chnl + "' "; 
       		 }
                 
                 
                String IS_POS="";
                	  List queryResult_POS = (List) ifr.getDataFromDB(query_POS);
                if (!queryResult_POS.isEmpty()) {
                    IS_POS = (String) ((List) queryResult_POS.get(0)).get(0);
                }
        String clientType = ifr.getValue("Q_PROPOSER_DETAILS_CLIENT_TYPE").toString();
            
		
        if (!(clientType.equalsIgnoreCase("ProposerInsured"))) {

            if (ifr.getValue("Q_L2BI_DETAILS_GENDER").toString().equalsIgnoreCase("F") && ifr.getValue("Q_L2BI_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(ifr.getValue("INSURED_AGE").toString()) > 18 && (!(IS_POS.equalsIgnoreCase("Y"))) && (!(IS_POS.equalsIgnoreCase("FD")))) {

                ifr.setStyle("t4s2", "visible", "true");
                ifr.setStyle("t4s10", "visible", "true");
            } else {
                ifr.setStyle("t4s2", "visible", "false");
                ifr.setStyle("t4s10", "visible", "false");
            }
            if (Integer.parseInt(ifr.getValue("INSURED_AGE").toString()) < 18 && ifr.getValue("Q_L2BI_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Studen")) {
                ifr.setStyle("t4s7", "visible", "true");
            } else {
                ifr.setStyle("t4s7", "visible", "false");
            }
        }
         if (ifr.getValue("PLAN_TYPE").toString().equalsIgnoreCase("JOINT"))
		{
			
                        if (ifr.getValue("Q_PROPOSER_DETAILS_GENDER").toString().equalsIgnoreCase("F") && ifr.getValue("Q_PROPOSER_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(ifr.getValue("PROPOSER_AGE").toString()) > 18 && (!(IS_POS.equalsIgnoreCase("Y"))) && (!(IS_POS.equalsIgnoreCase("FD")))) {

				ifr.setStyle("t10s14", "visible", "true");
				//setStyle("t10s15", "visible", "true");
			} 
			else {
				ifr.setStyle("t10s14", "visible", "false");
				//setStyle("t10s15", "visible", "false");
			}
			 if (ifr.getValue("Q_L2BI_DETAILS_GENDER").toString().equalsIgnoreCase("F") && ifr.getValue("Q_L2BI_DETAILS_MARITAL_STATUS").toString().equalsIgnoreCase("MRD") && Integer.parseInt(ifr.getValue("INSURED_AGE").toString()) > 18 && (!(IS_POS.equalsIgnoreCase("Y"))) && (!(IS_POS.equalsIgnoreCase("FD")))) {

				//setStyle("t10s14", "visible", "true");
				ifr.setStyle("t10s15", "visible", "true");
			} 
			else {
				//setStyle("t10s14", "visible", "false")
				ifr.setStyle("t10s15", "visible", "false");
			}
			
                      ifr.setStyle("t4s2", "visible", "false");
			
		}
         ifr.setStyle("t2s4", "visible", "false");
          if((ifr.getValue("PLAN_TYPE").toString()).equalsIgnoreCase("ANNUITY"))
                {
                            String proposerGender, proposerMaritalStatus, proposerDOB, nomineeDOB, isMinor = "N";
                        int proposerAge, nomineeAge;
                        JSONArray nomineeGrid;
                        JSONObject nomineeGridObj;
                        int nomineeGridSize;

                        nomineeGrid = ifr.getDataFromGrid("table40");
                        nomineeGridSize = nomineeGrid.size();
                        if (nomineeGridSize > 0) {
                            for (Object i : nomineeGrid) {
                                nomineeGridObj = (JSONObject) i;
                                nomineeDOB = nomineeGridObj.get("Date of Birth").toString();
                                try {
                                    nomineeAge = Integer.parseInt(DolphinUtil.CalculateYears(nomineeDOB, ifr));
                                } catch (Exception e) {
                                    System.out.println("Exception in formLoadLater method" + e.toString());
                                    nomineeAge = 0;
                                }

                                if (nomineeAge < 18) {
                                    isMinor = "Y";
                                    break;
                                }
                            }
                        }

                        if (isMinor.equalsIgnoreCase("Y")) {
                            ifr.setStyle("t2s4", "visible", "true");
                        } else {
                            ifr.setStyle("t2s4", "visible", "false");
                        }

                }
    }

    public void formLoadDolphinLater() {
        String activityName, username, channel, facultativeFlag, proposerClientId, insuredClientID,
                objOfInsurance, clientType, planCode, planType, userLevel, atp, gridOutput,gridOutputPROP,gridOutputINSUR;

        try {
            activityName = ifr.getActivityName();
            username = ifr.getUserName();

            channel = ifr.getValue("CHANNEL").toString();
            facultativeFlag = ifr.getValue("FACULTATIVE_FLAG").toString();
            proposerClientId = ifr.getValue("PROPOSER_CLIENT_ID").toString();
            insuredClientID = ifr.getValue("INSURED_CLIENT_ID").toString();
            objOfInsurance = ifr.getValue("OBJ_OF_INSURANCE").toString();
            clientType = ifr.getValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString();
            planCode = ifr.getValue("PLAN_NAME").toString();
            planType = ifr.getValue("PLAN_TYPE").toString();
            atp = ifr.getValue("Q_COVERAGE_DETAILS.ATP").toString();
            gridOutput = ifr.getValue("Q_BRMS_MED_GRID_OP_GRID_OUTPUT").toString();
            gridOutputPROP = ifr.getValue("Q_BRMS_MED_GRID_OP_PROP_GRID_OUTPUT").toString();
            gridOutputINSUR = ifr.getValue("Q_BRMS_MED_GRID_OP_INSUR_GRID_OUTPUT").toString();
            
         
            System.out.println("formLoadDolphinLater clientType=" + clientType);

            ifr.setValue("combo456", channel);
            ifr.setValue("textbox904", ifr.getValue("Q_PROPOSER_DETAILS.EXACT_INCOME").toString());
            ifr.setValue("Q_DECISION_SECTION_UW.FACULTATIVE", facultativeFlag);
            ifr.setValue("textbox872", gridOutput);
            ifr.setValue("PROP_MEDGRID", gridOutputPROP);   //to be deployed and check
            ifr.setValue("INSUR_MEDGRID", gridOutputINSUR);  //to be deployed and check
            ifr.setValue("Q_PROPOSER_DETAILS.CLIENT_ID", proposerClientId);
            ifr.setValue("Q_L2BI_DETAILS.CLIENT_ID", insuredClientID);
            
             ifr.setValue("MED_CAT", gridOutput);
            ifr.setValue("MED_CAT_PROP", gridOutputPROP);   //to be deployed and check
            ifr.setValue("MED_CAT_INSUR", gridOutputINSUR);
            
            ifr.setStyle("MED_CAT","visible","true");
            ifr.setStyle("MED_CAT_INSUR","visible","false");
            ifr.setStyle("MED_CAT_PROP","visible","false");

            ifr.setStyle("t1s5", "disable", "true");
            ifr.setStyle("t4s1", "visible", "false");
            ifr.setStyle("t3s9", "visible", "false");
            ifr.setStyle("t5s1", "disable", "true");
            ifr.setStyle("t5s2", "disable", "true");
            ifr.setStyle("t5s4", "disable", "true");
            ifr.setStyle("t5s10", "disable", "false");
            
            ifr.setColumnVisible("table48", "0", false); //OPTIMIzATION PHASE @
            //aanchal
            String PE = ifr.getValue("Q_PROPOSER_DETAILS.POLITICALLY_EXPOSED").toString();
            if (PE.equalsIgnoreCase("Y"))
                ifr.setValue("ISPOLITICALLYEXPOSEDFLAG", "Y");                             
            else
                ifr.setValue("ISPOLITICALLYEXPOSEDFLAG", "N");
            //aanchal
             // DR-11642 //sparsh
            String IsNPS = ifr.getValue("Q_PROPOSER_DETAILS_IS_NPS").toString();
            if (IsNPS.equalsIgnoreCase("Y")) {
            	 ifr.setStyle("Q_PROPOSER_DETAILS_PRAN_NUMBER","visible","true"); 
            	 setMandatory("Q_PROPOSER_DETAILS_PRAN_NUMBER");
            }else {
            	ifr.setStyle("Q_PROPOSER_DETAILS_PRAN_NUMBER","visible","false");
            	setnonMandatory("Q_PROPOSER_DETAILS_PRAN_NUMBER");
            }

			//if(actName == "CT")
			//setValues({"Decision":"YES"},true);
		
            //ifr.setStyle("t8s2", "disable", "true");
            //ifr.setStyle("t5s10", "disable", "true");
            ifr.setStyle("button124", "visible", "false");
            ifr.setStyle("table60", "visible", "false");
            ifr.setStyle("Q_NOTES_QC_REMARKS", "visible", "false");
            ifr.setStyle("Q_NOTES_CET_REMARKS", "visible", "false");
            ifr.setStyle("Q_NOTES_URMU_REMARKS", "visible", "false");
            ifr.setStyle("Q_NOTES_UW_REMARKS", "visible", "false");
            ifr.setStyle("Q_NOTES_CMO_REMARKS", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_BASE_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_APP_SUM_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_ADDITIONAL_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_SUBRACTION_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_REV_SUM_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_EXCESS_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_TERMS_OF_POLICY", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_EMR_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_SUM_ASSURED_INVISIBLE", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW_TOT_PRE_ANNUAL", "visible", "false");

            ifr.setStyle("t5s10", "disable", "false");
            ifr.setStyle("DocFlag", "disable", "false");
            ifr.setStyle("CC_Flag", "disable", "false");
            ifr.setStyle("Discrepancy_Flag", "disable", "false");
            ifr.setStyle("Auto_UW_Flag", "disable", "false");
            ifr.setStyle("Med_Kickout_Flag", "disable", "false");
            ifr.setStyle("Add_Info_Flag", "disable", "false");
            //ifr.setStyle("Req_in_flag", "disable", "false");
            ifr.setStyle("PI_ATTACHED", "disable", "false");
            ifr.setStyle("ULIP_CHECK", "disable", "false");

            if (channel.equalsIgnoreCase("A") || channel.equalsIgnoreCase("B9")) {
                ifr.setStyle("t1s4", "visible", "true");
            } else {
                ifr.setStyle("t1s4", "visible", "false");
            }
            if (!(objOfInsurance.equalsIgnoreCase("CEIP") || objOfInsurance.equalsIgnoreCase("CEIPE"))) {
                ifr.setStyle("t1s3", "visible", "false");
            } else {
                ifr.setStyle("t1s3", "visible", "true");
            }

            ifr.setStyle("UW_REQUIREMENTS", "disable", "true");
            ifr.setStyle("Q_LIST_REINSURER_REINSURER_REASON", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW.REF_NUM", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW.REINSURER_ref_Reason", "visible", "false");
            ifr.setStyle("Q_LIST_REINSURER_LIST", "visible", "false");
            ifr.setStyle("Q_DECISION_SECTION_UW.OPINION_RECEIVED_BY", "visible", "false");

            if (ifr.getValue("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN").toString().equalsIgnoreCase("Y")) {
                setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
            }

            if (ifr.getValue("Q_PROPOSER_DETAILS.OCCUPATION").toString().equalsIgnoreCase("Agricult")) {
                setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");//DR-6049
            }

            if (ifr.getValue("Q_PROPOSER_DETAILS.OCCUPATION").toString().equalsIgnoreCase("Salaried")) {
                setMandatory("Q_PROPOSER_DETAILS.OCCUPATION_SPECIFY");
            } else {
                setnonMandatory("Q_PROPOSER_DETAILS.OCCUPATION_SPECIFY");
            }

           // if (ifr.getValue("Q_DECISION_SECTION_UW.REVISED_OFFER").toString().equalsIgnoreCase("As is")) {
             //   ifr.setStyle("COVERAGE_DETAILS_REVISED", "disable", "true");
            //} else {
              //  ifr.setStyle("COVERAGE_DETAILS_REVISED", "disable", "false");
            //}

            //Form 1 Case
            if (clientType.equalsIgnoreCase("ProposerInsured")) {
                String proposerGender, proposerMaritalStatus, proposerDOB, nomineeDOB, isMinor = "N";
                int proposerAge, nomineeAge;
                JSONArray nomineeGrid;
                JSONObject nomineeGridObj;
                int nomineeGridSize;

                nomineeGrid = ifr.getDataFromGrid("table40");
                nomineeGridSize = nomineeGrid.size();
                if (nomineeGridSize > 0) {
                    for (Object i : nomineeGrid) {
                        nomineeGridObj = (JSONObject) i;
                        nomineeDOB = nomineeGridObj.get("Date of Birth").toString();
                        try {
                            nomineeAge = Integer.parseInt(DolphinUtil.CalculateYears(nomineeDOB, ifr));
                        } catch (Exception e) {
                            System.out.println("Exception in formLoadLater method" + e.toString());
                            nomineeAge = 0;
                        }

                        if (nomineeAge < 18) {
                            isMinor = "Y";
                            break;
                        }
                    }
                }

                if (isMinor.equalsIgnoreCase("Y")) {
                    ifr.setStyle("t2s4", "visible", "true");
                } else {
                    ifr.setStyle("t2s4", "visible", "false");
                }

                proposerGender = ifr.getValue("Q_PROPOSER_DETAILS.GENDER").toString();
                proposerMaritalStatus = ifr.getValue("Q_PROPOSER_DETAILS.MARITAL_STATUS").toString();
                proposerDOB = ifr.getValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH").toString();
                
                System.out.println("formLoadDolphinLater proposerGender=" + proposerGender);
                System.out.println("formLoadDolphinLater proposerMaritalStatus=" + proposerMaritalStatus);
                System.out.println("formLoadDolphinLater proposerDOB=" + proposerDOB);
                try {
                    proposerAge = Integer.parseInt(DolphinUtil.CalculateYears(proposerDOB, ifr));
                } catch (Exception e) {
                    System.out.println("Exception in formLoadLater method" + e.toString());
                    proposerAge = 0;
                }
                if (proposerGender.equalsIgnoreCase("F") && proposerMaritalStatus.equalsIgnoreCase("MRD") && proposerAge > 18) {
                    ifr.setStyle("t4s2", "visible", "true");
                    ifr.setStyle("t4s10", "visible", "true");
                } else {
                    ifr.setStyle("t4s2", "visible", "false");
                    ifr.setStyle("t4s10", "visible", "false");
                }

                ifr.setStyle("t0s2", "visible", "false");
                  ifr.setStyle("t6s2", "visible", "false");   //dr-14620 mansi
                ifr.setStyle("t2s2", "visible", "false");
                ifr.setStyle("t2s3", "visible", "true");
                ifr.setStyle("t4s6", "visible", "false");
                ifr.setStyle("t4s7", "visible", "false");

            } else {
                
               
                String insuredGender, insuredMaritalStatus, insuredDOB;
                int insuredAge;
                insuredGender = ifr.getValue("Q_L2BI_DETAILS.GENDER").toString();
                insuredMaritalStatus = ifr.getValue("Q_L2BI_DETAILS.MARITAL_STATUS").toString();
                insuredDOB = ifr.getValue("Q_L2BI_DETAILS.DOB").toString();
                try {
                    insuredAge = Integer.parseInt(DolphinUtil.CalculateYears(insuredDOB, ifr));
                } catch (Exception e) {
                    System.out.println("Exception in formLoadLater method" + e.toString());
                    insuredAge = 0;
                }

                if (insuredGender.equalsIgnoreCase("F") && insuredMaritalStatus.equalsIgnoreCase("MRD") && insuredAge > 18) {
                    ifr.setStyle("t4s2", "visible", "true");
                    ifr.setStyle("t4s10", "visible", "true");
                } else {
                    ifr.setStyle("t4s2", "visible", "false");
                    ifr.setStyle("t4s10", "visible", "false");
                }

                if (insuredAge < 18 && ifr.getValue("Q_L2BI_DETAILS_OCCUPATION").toString().equalsIgnoreCase("Studen")) {
                    ifr.setStyle("t4s7", "visible", "true");
                } else {
                    ifr.setStyle("t4s7", "visible", "false");
                }

                
             
                ifr.setStyle("t0s2", "visible", "true");
                  ifr.setStyle("t6s2", "visible", "true");  //dr-14620 mansi
                ifr.setStyle("t2s2", "visible", "true");
                ifr.setStyle("t2s3", "visible", "false");
                ifr.setStyle("t2s4", "visible", "false");
                ifr.setStyle("t4s6", "visible", "true");
                
                 if((ifr.getValue("PLAN_TYPE").toString()).equalsIgnoreCase("ANNUITY"))
                {
                            String proposerGender, proposerMaritalStatus, proposerDOB, nomineeDOB, isMinor = "N";
                        int proposerAge, nomineeAge;
                        JSONArray nomineeGrid;
                        JSONObject nomineeGridObj;
                        int nomineeGridSize;

                        nomineeGrid = ifr.getDataFromGrid("table40");
                        nomineeGridSize = nomineeGrid.size();
                        if (nomineeGridSize > 0) {
                            for (Object i : nomineeGrid) {
                                nomineeGridObj = (JSONObject) i;
                                nomineeDOB = nomineeGridObj.get("Date of Birth").toString();
                                try {
                                    nomineeAge = Integer.parseInt(DolphinUtil.CalculateYears(nomineeDOB, ifr));
                                } catch (Exception e) {
                                    System.out.println("Exception in formLoadLater method" + e.toString());
                                    nomineeAge = 0;
                                }

                                if (nomineeAge < 18) {
                                    isMinor = "Y";
                                    break;
                                }
                            }
                        }

                        if (isMinor.equalsIgnoreCase("Y")) {
                            ifr.setStyle("t2s4", "visible", "true");
                        } else {
                            ifr.setStyle("t2s4", "visible", "false");
                        }

                }

            }

            if (clientType.equalsIgnoreCase("Company")) {  //TBd WITH MAYANK
                ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "visible", "true");
               // ifr.setStyle("Q_PROPOSER_DETAILS.NATIONALITY", "visible", "false");
                //ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "visible", "false");
                //ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "visible", "false");
                //setnonMandatory("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
                //setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP");
                //ifr.setValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "");
                //ifr.setValue("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "");
                setMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR");
                //ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "visible", "true");
                //setMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP");
                
                ifr.setStyle("Q_PROPOSER_DETAILS.COMP_RELATIONSHIP_PROP", "visible", "true");
                ifr.setStyle("label178", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_NAME_COMPANY", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_SOURCE_FUND", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_CERTI_INCORPORATION", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_REG_CERTI", "visible", "true");
                
                  setMandatory("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP");
                  setMandatory("Q_PROPOSER_DETAILS_NAME_COMPANY");
                  setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY");
                  setMandatory("Q_PROPOSER_DETAILS_SOURCE_FUND");
                  setMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY");
                  ifr.setStyle("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY", "visible", "false"); 
                  setnonMandatory("Q_PROPOSER_DETAILS_OCCUPATION_SPECIFY");
                  //setMandatory("Q_PROPOSER_DETAILS_CERTI_INCORPORATION");
                  //setMandatory("Q_PROPOSER_DETAILS_REG_CERTI");
                  
                   ifr.setStyle("Q_PROPOSER_DETAILS_PREFERRED_LANGUAGE", "visible", "false");
                 ifr.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "false");

                  
                  ifr.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "visible", "true");
                  ifr.setStyle("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "disable", "true");
                    setMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER");
                   ifr.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER", "visible", "true");
                   ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION", "visible", "false");
                    ifr.setStyle("Q_PROPOSER_DETAILS_PAN_ACK_NO", "visible", "false");
			setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_APPLICATION");
			setnonMandatory("Q_PROPOSER_DETAILS_PAN_ACK_NO");
                        ifr.setValue("Q_PROPOSER_DETAILS_DO_YOU_HAVE_PAN", "Y");
                        
                         ifr.setStyle("t4s5", "visible", "false");
                 
                    
              
                
            } else {
                 ifr.setStyle("Q_PROPOSER_DETAILS_PREFERRED_LANGUAGE", "visible", "true");
                 ifr.setStyle("Q_PROPOSER_DETAILS_RESIDENTIAL_STATUS", "visible", "true");

               // ifr.setValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "");
                ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR", "visible", "false");
                setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR");
               // ifr.setValue("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "");
                ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP", "visible", "false");
                setnonMandatory("Q_PROPOSER_DETAILS_DATE_OF_INCOR_DUP");

                ifr.setStyle("Q_PROPOSER_DETAILS_NATIONALITY", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH", "visible", "true");
                ifr.setStyle("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP", "visible", "true");
                setMandatory("Q_PROPOSER_DETAILS_DATE_OF_BIRTH");
                
                
                 ifr.setStyle("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP", "visible", "false");
                ifr.setStyle("label178", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_NAME_COMPANY", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_SOURCE_FUND", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_CERTI_INCORPORATION", "visible", "false");
                ifr.setStyle("Q_PROPOSER_DETAILS_REG_CERTI", "visible", "false");
                
                  setnonMandatory("Q_PROPOSER_DETAILS_COMP_RELATIONSHIP_PROP");
                  setnonMandatory("Q_PROPOSER_DETAILS_NAME_COMPANY");
                  setnonMandatory("Q_PROPOSER_DETAILS_PAN_NUMBER_COMPANY");
                  setnonMandatory("Q_PROPOSER_DETAILS_SOURCE_FUND");
                  setnonMandatory("Q_PROPOSER_DETAILS_EXACT_INCOME_COMPANY");
                  setnonMandatory("Q_PROPOSER_DETAILS_CERTI_INCORPORATION");
                  setnonMandatory("Q_PROPOSER_DETAILS_REG_CERTI");
                  
                   ifr.setStyle("t4s5", "visible", "true");
                  
                  
            }

            if (planCode.equalsIgnoreCase("UPPRPF") || planCode.equalsIgnoreCase("UPPSPF") || planCode.equalsIgnoreCase("UPPSCF")) {
                ifr.setStyle("Q_PROPOSER_DETAILS_ANNUITY_OPTION", "visible", "true");
                setMandatory("Q_PROPOSER_DETAILS_ANNUITY_OPTION");
            } else {
                ifr.setStyle("Q_PROPOSER_DETAILS_ANNUITY_OPTION", "visible", "false");
            }
            if (planCode.equalsIgnoreCase("EFGEP8") || planCode.equalsIgnoreCase("EFGEPL") || planCode.equalsIgnoreCase("U2ESF5") || planCode.equalsIgnoreCase("U2ESFV")) {
                ifr.setStyle("t2s5", "visible", "true");
            } else {
                ifr.setStyle("t2s5", "visible", "false");
            }

            if (!(planType.equalsIgnoreCase("ULIP")) && !(planType.equalsIgnoreCase("COMBO"))) {
                ifr.setStyle("t3s4", "visible", "false");//Fund Selected Section To Be Set Invisible 
            } else {
                ifr.setStyle("Q_COVERAGE_DETAILS_SUM_ASSURED", "disable", "true"); // To Disable Sum Assured In Coverage Details Section For Ulip
            }
            if (planType.equalsIgnoreCase("TRAD")) {
                ifr.setStyle("Q_POLICY_VALIDATION_DETAILS.INCOME_SEGMENT", "visible", "true");
                ifr.setStyle("Q_POLICY_VALIDATION_DETAILS.BSE_500", "visible", "true");
            } else {
                ifr.setStyle("Q_POLICY_VALIDATION_DETAILS.INCOME_SEGMENT", "visible", "false");
                ifr.setStyle("Q_POLICY_VALIDATION_DETAILS.BSE_500", "visible", "false");
            }
            
            
            if (!(planCode.equalsIgnoreCase("UFIPFS") || planCode.equalsIgnoreCase("UFIPFL") || planCode.equalsIgnoreCase("UFIPFR")|| planCode.equalsIgnoreCase("UFIPFW") || planCode.equalsIgnoreCase("UIPWFS")
                    || planCode.equalsIgnoreCase("UIPWF5") || planCode.equalsIgnoreCase("UIPWFR")|| planCode.equalsIgnoreCase("U2NIFS") || planCode.equalsIgnoreCase("U2NF20") || planCode.equalsIgnoreCase("U2NIF5") || planCode.equalsIgnoreCase("UFISFL")|| planCode.equalsIgnoreCase("UFISFR") || planCode.equalsIgnoreCase("UFINFL") || planCode.equalsIgnoreCase("UFINFR")))
            {
            if ( planType.equalsIgnoreCase("ULIP") && !activityName.equalsIgnoreCase("Manual_UW")  && !activityName.equalsIgnoreCase("Manual_UW_Vendor")  && !activityName.equalsIgnoreCase("Manual_UW_Supervisor") && !activityName.equalsIgnoreCase("UW_HOD")) {
                ifr.setValue("AFYP", atp);
                ifr.setValue("AFYP_DUP", atp);
                ifr.setValue("label120", atp);
            }
            }
            
             // DR-14792
            if (activityName.equalsIgnoreCase("Manual_UW")||activityName.equalsIgnoreCase("Manual_UW_Vendor")||activityName.equalsIgnoreCase("Manual_UW_Supervisor") ||activityName.equalsIgnoreCase("UW_HOD")) {
            	String RiskCategory = ifr.getValue("Q_DECISION_SECTION_UW_RISK_CATEGORY").toString().toUpperCase();
            	if(RiskCategory.contains("EXTREME RISK")) {
                 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "backcolor", "red");
                 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "fontcolor", "white");
            	}
            	else if(RiskCategory.contains("SEVERE RISK")) {
            	 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "backcolor", "orange");
            	 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "fontcolor", "white");
            	}
            	else if(RiskCategory.contains("MODERATE RISK")) {
               	 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "backcolor", "yellow");
               	ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "fontcolor", "black");
            	}
            	else if(RiskCategory.contains("MILD RISK")) {
               	 ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "backcolor", "green");
            	ifr.setStyle("Q_DECISION_SECTION_UW_RISK_CATEGORY", "fontcolor", "white");
            	}
            }	
           

            if (activityName.equalsIgnoreCase("Source")) {
                ifr.setValue("SOURCING_SYSTEM", "Offline");
            } else if (activityName.equalsIgnoreCase("QC")) {
                ifr.setStyle("QC_REQUIREMENTS", "disable", "true");
                ifr.setStyle("button124", "visible", "true");
            } else if (activityName.equalsIgnoreCase("CT")) {
                ifr.setStyle("button175", "visible", "true");
                ifr.setStyle("combo485", "visible", "false");
                ifr.setStyle("Q_NOTES_QC_REMARKS", "visible", "false");
                ifr.setStyle("Q_NOTES_CET_REMARKS", "visible", "false");
                ifr.setStyle("Q_NOTES_URMU_REMARKS", "visible", "false");
                ifr.setStyle("Q_NOTES_UW_REMARKS", "visible", "false");
                ifr.setStyle("Q_NOTES_CMO_REMARKS", "visible", "false");
                ifr.setStyle("Q_NOTES_CMO_REMARKS_label", "visible", "false");
                ifr.setStyle("Q_NOTES_UW_REMARKS_label", "visible", "false");
                ifr.setStyle("Q_NOTES_URMU_REMARKS_label", "visible", "false");
                ifr.setStyle("Q_NOTES_CET_REMARKS_label", "visible", "false");
                ifr.setStyle("Q_NOTES_QC_REMARKS_label", "visible", "false");

                //ifr.setTabStyle("mytab", "1", "visible", "false");
                //ifr.setTabStyle("mytab", "2", "visible", "false");      //added by Prakhar
                ifr.setTabStyle("mytab", "10", "visible", "true"); //shhet8---sheet9 JOINT  //9-10 IIB

            } else if (activityName.equalsIgnoreCase("mPRO_CET")) {
                ifr.setStyle("t1s5", "disable", "true");
            } else if (activityName.equalsIgnoreCase("CMO")) {
                ifr.setStyle("Q_DECISION_SECTION_UW.BASE_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.APP_SUM_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.ADDITIONAL_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.SUBRACTION_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.REV_SUM_INVISIBLE", "visible", "false");
                ifr.setStyle("table60", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.EXCESS_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.TERMS_OF_POLICY", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.EMR_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.SUM_ASSURED_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.TOT_PRE_ANNUAL", "visible", "false");
                ifr.setStyle("t5s1", "disable", "true");
                ifr.setStyle("t5s4", "disable", "true");
                ifr.setStyle("t5s1", "disable", "true");
                ifr.setStyle("t5s4", "disable", "true");
                ifr.setStyle("t5s10", "disable", "true");
                ifr.setStyle("t5s6", "disable", "true");
                ifr.setStyle("t5s5", "disable", "true");
                ifr.setStyle("t4s11", "disable", "true");
                ifr.setStyle("CMO_DECISION", "visible", "true");
                setMandatory("CMO_DECISION");
                setMandatory("combo409");
                setMandatory("textarea20");

                ifr.setTabStyle("mytab", "4", "disable", "true"); //shhet2---sheet3 JOINT  //IIB

            } else if (activityName.equalsIgnoreCase("Manual_UW") || activityName.equalsIgnoreCase("Manual_UW_Vendor")|| activityName.equalsIgnoreCase("Manual_UW_Supervisor") || activityName.equalsIgnoreCase("UW_HOD")) {
                String counterOfferSelected, reinsurerFlag, uwDecision, brmsMerModOp;
                counterOfferSelected = ifr.getValue("Q_DECISION_SECTION_UW_COUNTER_OFFER_SELECTED").toString();
                reinsurerFlag = ifr.getValue("Reinsurer_Flag").toString();
                uwDecision = ifr.getValue("Decision").toString();
                brmsMerModOp = ifr.getValue("Q_BRMS_UW_MOD_OP_MER_MOD_OP").toString();
                if(brmsMerModOp.matches("(.*)Report Data Not Found,Report Data Not Found,Report Data Not Found(.*)"))
                {
                    ifr.setValue("Q_BRMS_UW_MOD_OP_TELE_MER_MOD_OP", "Report Data Not Found");
                }
                if (brmsMerModOp.matches("(.*)Report Data Not Found,(.*)")) {
                    ifr.setValue("Q_BRMS_UW_MOD_OP_MER_MOD_OP", "Report Data Not Found");
                }

               // ifr.setValue("Q_BRMS_UW_MOD_OP_BLOOD_PROFILE_MOD_OP", ifr.getValue("Q_BRMS_UW_MOD_OP_MER_MOD_OP").toString());  //PROD BUG

                ifr.setStyle("QC_REQUIREMENTS", "disable", "true");
                ifr.setStyle("UW_REQUIREMENTS", "disable", "false");
                ifr.setStyle("t5s10", "sectionstate", "expanded");
                ifr.setStyle("table51", "disable", "true");
                String P_SER_TA_APPL, P_WITH_SER_TA_REV;
                double P_SER_TA_APPL_NUM, P_WITH_SER_TA_REV_NUM;
                P_SER_TA_APPL = ifr.getValue("Q_DECISION_SECTION_UW.TO_P_SER_TA_APPL").toString();
                P_WITH_SER_TA_REV = ifr.getValue("Q_DECISION_SECTION_UW.TO_P_WITH_SER_TA_REV").toString();

                P_SER_TA_APPL_NUM = P_SER_TA_APPL.isEmpty() ? 0 : Double.parseDouble(P_SER_TA_APPL);
                P_WITH_SER_TA_REV_NUM = P_WITH_SER_TA_REV.isEmpty() ? 0 : Double.parseDouble(P_WITH_SER_TA_REV);

                if (P_SER_TA_APPL_NUM >= P_WITH_SER_TA_REV_NUM) {
                    ifr.setValue("Q_DECISION_SECTION_UW.E_PRE_COLL_CUST_label", "Extra premium to be refunded to Customer");
                } else {
                    ifr.setValue("Q_DECISION_SECTION_UW.E_PRE_COLL_CUST_label", "Extra premium to be Collected from Customer");
                }

                userLevel = getUserLevel();
                ifr.setValue("Q_DECISION_SECTION_UW.puserlevel", userLevel);

                if (userLevel.equalsIgnoreCase("L-8")) {
                    ifr.removeItemFromCombo("REFER_TO", 1);
                }

                if (counterOfferSelected.equalsIgnoreCase("Y")) {
                    ifr.addItemInCombo("Decision", "CO Accept", "Counter Offer Accept");
                    ifr.addItemInCombo("Decision", "CO Reconsider", "CO Reconsider");
                }

                if (reinsurerFlag.equalsIgnoreCase("Y") && (uwDecision.equalsIgnoreCase("Refer") || uwDecision.equalsIgnoreCase("Select"))) {
                    ifr.setStyle("Q_DECISION_SECTION_UW_REF_NUM", "visible", "true");
                    setMandatory("Q_DECISION_SECTION_UW_REF_NUM");
                    ifr.setStyle("Q_DECISION_SECTION_UW_OPINION_RECEIVED_BY", "visible", "true");
                    ifr.setStyle("Q_DECISION_SECTION_UW_OPINION_RECEIVED_BY", "disable", "false");
                    setMandatory("Q_DECISION_SECTION_UW_OPINION_RECEIVED_BY");
                    ifr.setStyle("Q_DECISION_SECTION_UW_REF_NUM", "disable", "false");
                    ifr.setStyle("Q_DECISION_SECTION_UW_REINSURER_ref_Reason", "disable", "false");
                }

            } else if (activityName.equalsIgnoreCase("URMU")) {
                ifr.setStyle("QC_REQUIREMENTS", "disable", "true");
                ifr.setStyle("Decision", "disable", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW.BASE_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.APP_SUM_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.ADDITIONAL_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.SUBRACTION_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.REV_SUM_INVISIBLE", "visible", "false");
                ifr.setStyle("table60", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.EXCESS_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.TERMS_OF_POLICY", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.EMR_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.SUM_ASSURED_INVISIBLE", "visible", "false");
                ifr.setStyle("Q_DECISION_SECTION_UW.TOT_PRE_ANNUAL", "visible", "false");
                ifr.setStyle("t5s1", "disable", "true");
                ifr.setStyle("t5s4", "disable", "true");
                ifr.setStyle("t5s1", "disable", "true");
                ifr.setStyle("t5s4", "disable", "true");
                ifr.setStyle("t5s10", "disable", "true");
                ifr.setStyle("t5s6", "disable", "true");
                ifr.setStyle("t5s5", "disable", "true");
                ifr.setStyle("t4s11", "disable", "true");
                ifr.setStyle("t8s2", "disable", "true");
                setMandatory("combo409");
                setMandatory("textarea20");
                ifr.setTabStyle("mytab", "2", "disable", "true"); //IIB

            } else if (activityName.equalsIgnoreCase("Reinsurance")) {
                ifr.setValue("Reinsurer_Flag", "Y");
                ifr.setStyle("button175", "visible", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_REF_NUM", "disable", "true");
                ifr.setStyle("Decision", "disable", "true");
                ifr.setStyle("REFER_TO", "disable", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_REINSURER_ref_Reason", "disable", "true");
                ifr.setStyle("Q_LIST_REINSURER_LIST", "disable", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_OPINION_RECEIVED_BY", "disable", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_REINSURER_ref_Reason", "visible", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_REINSURER_ref_Reason", "disable", "true");
                ifr.setStyle("Decision", "disable", "true");
                ifr.setStyle("button218", "disable", "true");
                ifr.setStyle("t3s2", "disable", "true");
                ifr.setStyle("t3s3", "disable", "true");
                ifr.setStyle("t3s5", "disable", "true");
                ifr.setStyle("t3s7", "disable", "true");
                ifr.setStyle("t3s8", "disable", "true");
                ifr.setStyle("t3s6", "disable", "true");
                ifr.setStyle("t3s4", "disable", "true");
                ifr.setStyle("t4s2", "disable", "true");
                ifr.setStyle("t4s3", "disable", "true");
                ifr.setStyle("t4s5", "disable", "true");
                ifr.setStyle("t4s6", "disable", "true");
                ifr.setStyle("t4s8", "disable", "true");
                ifr.setStyle("t4s9", "disable", "true");
                ifr.setStyle("t4s10", "disable", "true");
                ifr.setStyle("t4s11", "disable", "true");
                ifr.setStyle("t4s7", "disable", "true");
                ifr.setStyle("t4s1", "disable", "true");
                ifr.setStyle("t4s4", "disable", "true");
                ifr.setStyle("Q_DECISION_SECTION_UW_ASSESSED_INCOME", "disable", "true");

            } //else if (activityName.equalsIgnoreCase("WC_Hold")) {
                //ifr.setTabStyle("mytab", "1", "visible", "false");
                //ifr.setTabStyle("mytab", "3", "visible", "false");  //shhet2---sheet3 JOINT
                //ifr.setTabStyle("mytab", "0", "visible", "false");
//            }   //aanchal //15feb

            if (activityName.equalsIgnoreCase("QC") || activityName.equalsIgnoreCase("CT") || activityName.equalsIgnoreCase("mPRO_CET")
                    || activityName.equalsIgnoreCase("Medical_Report_Analysis") || activityName.equalsIgnoreCase("Medical_Report_Awaited")) {

                if (clientType.equalsIgnoreCase("ProposerInsured")) {
                    ifr.setValue("textbox814", ifr.getValue("Q_PROPOSER_DETAILS.CITY_DISTRICT").toString());
                } else {
                    ifr.setValue("textbox814", ifr.getValue("Q_L2BI_DETAILS.CITY_DISTRICT").toString());
                }

            }

            if (!(activityName.equalsIgnoreCase("Manual_UW") || activityName.equalsIgnoreCase("Manual_UW_Vendor") || activityName.equalsIgnoreCase("Manual_UW_Supervisor") || activityName.equalsIgnoreCase("UW_HOD")  || activityName.equalsIgnoreCase("URMU") || activityName.equalsIgnoreCase("CMO"))) {
                String payorDiffFromProp, payortitle, payorPanNumber, payorAppliedFor, payorDOB, qcProposerTtitle, qcInsuredTitle;
                payorDiffFromProp = ifr.getValue("Q_PAYOR_PAN_DETAILS.PAYOR_DIFF_PROP").toString();
                payortitle = ifr.getValue("Q_PAYOR_PAN_DETAILS.TITLE").toString();
                payorPanNumber = ifr.getValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER").toString();
                payorAppliedFor = ifr.getValue("Q_PAYOR_PAN_DETAILS.APPLIED_FOR_PAN").toString();
                payorDOB = ifr.getValue("Q_PAYOR_PAN_DETAILS.DATE_OF_BIRTH").toString();

                
                qcProposerTtitle = ifr.getValue("Q_PROPOSER_DETAILS_TITLE_DUP").toString();
                qcInsuredTitle = ifr.getValue("Q_L2BI_DETAILS_TITLE_DUP").toString();
                if(ifr.getValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED").toString().equalsIgnoreCase(""))
			{ifr.setValue(
				"Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED",ifr.getValue("Q_COVERAGE_DETAILS.SMOKER_CLASS").toString());
                         }

                //DR-23942 sparsh
                if(ifr.getValue("Q_DECISION_SECTION_UW.SMOKER_CLASS_INSURED").toString().equalsIgnoreCase(""))
    			{ifr.setValue(
    				"Q_DECISION_SECTION_UW.SMOKER_CLASS_INSURED",ifr.getValue("Q_COVERAGE_DETAILS.SMOKER_CLASS_INSURED").toString());
                             }

                if (ifr.getValue("Q_PROPOSER_DETAILS.PERM_RESIDENTIAL_ADD").toString().equalsIgnoreCase("true")) {
                    ifr.setValue("SAME_AS_ABOVE_QC_PROP", "true");
                }
                if (ifr.getValue("Q_L2BI_DETAILS.PERM_RESIDENTIAL_ADD").toString().equalsIgnoreCase("true")) {
                    ifr.setValue("SAME_AS_ABOVE_QC_L2BI", "true");
                }

                if (payorDiffFromProp.equalsIgnoreCase("N")) {
                    ifr.setStyle("t0s3", "visible", "false");
                      ifr.setStyle("t6s3", "visible", "false");   //dr-14620 mansi
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.CLIENT_ID", ifr.getValue("Q_PROPOSER_DETAILS.CLIENT_ID").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.TITLE", ifr.getValue("Q_PROPOSER_DETAILS.TITLE").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", ifr.getValue("Q_PROPOSER_DETAILS.SPECIFY_TITLE").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.FIRST_NAME", ifr.getValue("Q_PROPOSER_DETAILS.FIRST_NAME").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.MIDDLE_NAME", ifr.getValue("Q_PROPOSER_DETAILS.MIDDLE_NAME").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.LAST_NAME", ifr.getValue("Q_PROPOSER_DETAILS.LAST_NAME").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.DATE_OF_BIRTH", ifr.getValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", ifr.getValue("Q_PROPOSER_DETAILS.GENDER").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", ifr.getValue("Q_PROPOSER_DETAILS.PAN_NUMBER").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.APPLIED_FOR_PAN", ifr.getValue("Q_PROPOSER_DETAILS.DO_YOU_HAVE_PAN").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", ifr.getValue("Q_PROPOSER_DETAILS.DATE_OF_APPLICATION").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", ifr.getValue("Q_PROPOSER_DETAILS.PAN_ACK_NO").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.BANK_NAME", ifr.getValue("Q_NEFT_DETAILS.NAME_BRANCH_NEFT").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.BANK_ACC_NO", ifr.getValue("Q_NEFT_DETAILS.ACC_NO_NEFT").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.RELATIONSHIP", "SELF");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.NAME_COMPANY", ifr.getValue("Q_PROPOSER_DETAILS.NAME_COMPANY").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.DATE_OF_INCOR", ifr.getValue("Q_PROPOSER_DETAILS.DATE_OF_INCOR").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER_COMPANY", ifr.getValue("Q_PROPOSER_DETAILS.PAN_NUMBER_COMPANY").toString());
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.EXACT_INCOME_COMPANY", ifr.getValue("Q_PROPOSER_DETAILS.EXACT_INCOME_COMPANY").toString());

                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.CLIENT_ID", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.TITLE", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.FIRST_NAME", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.MIDDLE_NAME", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.LAST_NAME", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_BIRTH", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.GENDER", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APPLIED_FOR_PAN", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "disable", "true");
                    ifr.setStyle("Q_COVERAGE_DETAILS.TOTAL_REQ_PREMIUM", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.RELATIONSHIP", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.BANK_NAME", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.BANK_ACC_NO", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.NAME_COMPANY", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_INCOR", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER_COMPANY", "disable", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.EXACT_INCOME_COMPANY", "disable", "true");

                } else {
                    ifr.setStyle("t0s3", "visible", "true");
                    ifr.setStyle("t3s8", "disable", "false");
  ifr.setStyle("t6s3", "visible", "true");    //dr-14620 mansi
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.CLIENT_ID", "");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.CLIENT_ID");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.TITLE", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.FIRST_NAME", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.MIDDLE_NAME", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.LAST_NAME", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.DATE_OF_BIRTH", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.APPLIED_FOR_PAN", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.RELATIONSHIP", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.BANK_NAME", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.BANK_ACC_NO", "");

                }

                if (payortitle.equalsIgnoreCase("Others")) {
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "visible", "true");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP", "visible", "true");
                    setMandatory("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE");
                    setMandatory("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP");
                    setMandatory("Q_PAYOR_PAN_DETAILS_GENDER");
                } else {
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "");
//                    ifr.setValue("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP", "");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE", "visible", "false");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.SPECIFY_TITLE");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS_SPECIFY_TITLE_DUP");
                }
                if (payortitle.equalsIgnoreCase("Mr.")) {
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", "M");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS_GENDER_DUP", "M");
                } else if (payortitle.equalsIgnoreCase("Mrs.") || payortitle.equalsIgnoreCase("Ms.")) {
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", "F");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS_GENDER_DUP", "F");
                } else if (payortitle.equalsIgnoreCase("Mx.")) {
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", "T");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS_GENDER_DUP", "T");
                    //DR-7163  //AANCHAL 
                } else if (payortitle.equalsIgnoreCase("Others")) {
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.GENDER", "O");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS_GENDER_DUP", "O");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.GENDER", "disable", "false");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS_GENDER_DUP", "disable", "false");
                    setMandatory("Q_PAYOR_PAN_DETAILS_GENDER_DUP");
                }

                if (qcProposerTtitle.equalsIgnoreCase("Others")) {
                    ifr.setStyle("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP", "visible", "true");
                    setMandatory("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP");
                    setMandatory("Q_PROPOSER_DETAILS_GENDER");
                } else {
                    ifr.setValue("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP", "");
                    ifr.setStyle("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");
                    setnonMandatory("Q_PROPOSER_DETAILS_SPECIFY_TITLE_DUP");
                    ifr.setStyle("Q_PROPOSER_DETAILS_GENDER", "disable", "true");
                    ifr.setStyle("Q_PROPOSER_DETAILS_GENDER_DUP", "disable", "true");
                }
                if (qcProposerTtitle.equalsIgnoreCase("Mr.")) {
                    ifr.setValue("Q_PROPOSER_DETAILS.GENDER", "M");
                    ifr.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "M");
                } else if (qcProposerTtitle.equalsIgnoreCase("Mrs.") || qcProposerTtitle.equalsIgnoreCase("Ms.")) {
                    ifr.setValue("Q_PROPOSER_DETAILS.GENDER", "F");
                    ifr.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "F");
                } else if (qcProposerTtitle.equalsIgnoreCase("Mx.")) {
                    ifr.setValue("Q_PROPOSER_DETAILS.GENDER", "T");
                    ifr.setValue("Q_PROPOSER_DETAILS_GENDER_DUP", "T");//DR-7163  //AANCHAL Q_PROPOSER_DETAILS_MARITAL_STATUS
                    ifr.setValue("Q_PROPOSER_DETAILS.MARITAL_STATUS", "SNG");
                     ifr.setStyle("Q_PROPOSER_DETAILS.MARITAL_STATUS", "disable", "true");
                    
                } else if (qcProposerTtitle.equalsIgnoreCase("Others")) {
                    ifr.setStyle("Q_PROPOSER_DETAILS.GENDER", "disable", "false");
                    ifr.setStyle("Q_PROPOSER_DETAILS_GENDER_DUP", "disable", "false");
                    setMandatory("Q_PROPOSER_DETAILS.GENDER");
                }
                if (qcInsuredTitle.equalsIgnoreCase("Others")) {
                    ifr.setStyle("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP", "visible", "true");
                    setMandatory("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP");
                    setMandatory("Q_L2BI_DETAILS.GENDER");
                } else {
                    ifr.setValue("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP", "");
                    ifr.setStyle("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP", "visible", "false");
                    setnonMandatory("Q_L2BI_DETAILS_SPECIFY_TITLE_DUP");
                    ifr.setStyle("Q_L2BI_DETAILS.GENDER", "disable", "true");
                    ifr.setStyle("Q_L2BI_DETAILS_GENDER_DUP", "disable", "true");
                }
                if (qcInsuredTitle.equalsIgnoreCase("Mr.")) {
                    ifr.setValue("Q_L2BI_DETAILS.GENDER", "M");
                    ifr.setValue("Q_L2BI_DETAILS_GENDER_DUP", "M");
                } else if (qcInsuredTitle.equalsIgnoreCase("Mrs.") || qcInsuredTitle.equalsIgnoreCase("Ms.")) {
                    ifr.setValue("Q_L2BI_DETAILS.GENDER", "F");
                    ifr.setValue("Q_L2BI_DETAILS_GENDER_DUP", "F");
                } else if (qcInsuredTitle.equalsIgnoreCase("Mx.")) {
                    ifr.setValue("Q_L2BI_DETAILS.GENDER", "T");
                    ifr.setValue("Q_L2BI_DETAILS_GENDER_DUP", "T");
                     ifr.setValue("Q_L2BI_DETAILS_MARITAL_STATUS", "SNG");
                     ifr.setStyle("Q_L2BI_DETAILS_MARITAL_STATUS", "disable", "true");
                    
                } else if (qcInsuredTitle.equalsIgnoreCase("Others")) {
                    ifr.setStyle("Q_L2BI_DETAILS.GENDER", "disable", "false");
                    ifr.setStyle("Q_L2BI_DETAILS_GENDER_DUP", "disable", "false");
                    setMandatory("Q_L2BI_DETAILS.GENDER");
                }

                if (payorPanNumber.length() > 0) {
                    setMandatory("Q_PAYOR_PAN_DETAILS.PAN_NUMBER");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.APP_ACK_NO");
                }
                setMandatory("Q_PAYOR_PAN_DETAILS.APPLIED_FOR_PAN");

                if (payorAppliedFor.equalsIgnoreCase("Y")) {
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "visible", "true");
                    setMandatory("Q_PAYOR_PAN_DETAILS.PAN_NUMBER");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.APP_ACK_NO");
                    if (payorDiffFromProp.equalsIgnoreCase("Y")) {
                        ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "disable", "false");
                    } else {
                        ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "disable", "true");
                    }
                    if (activityName.equalsIgnoreCase("Manual_UW")  || activityName.equalsIgnoreCase("Manual_UW_Vendor") || activityName.equalsIgnoreCase("Manual_UW_Supervisor") || activityName.equalsIgnoreCase("UW_HOD") ) //aanchal //DR-4002
                    {
                        ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "disable", "true");
                    }
                } else if (payorAppliedFor.equalsIgnoreCase("AF")) {
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "visible", "true");
                    setMandatory("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "visible", "false");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "disable", "true");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.PAN_NUMBER");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "visible", "true");
                    setMandatory("Q_PAYOR_PAN_DETAILS.APP_ACK_NO");
                } else if (payorAppliedFor.equalsIgnoreCase("NA")) {
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.DATE_OF_APPLICATION");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.PAN_NUMBER");
                    ifr.setValue("Q_PAYOR_PAN_DETAILS.PAN_NUMBER", "");
                    ifr.setStyle("Q_PAYOR_PAN_DETAILS.APP_ACK_NO", "visible", "false");
                    setnonMandatory("Q_PAYOR_PAN_DETAILS.APP_ACK_NO");
                }

                ifr.setTabStyle("mytab", "4", "disable", "true");  //shhet2---sheet3 JOINT //IIB
            }

            if (activityName.equalsIgnoreCase("Manual_UW")|| activityName.equalsIgnoreCase("Manual_UW_Vendor") || activityName.equalsIgnoreCase("Manual_UW_Supervisor") || activityName.equalsIgnoreCase("UW_HOD") || activityName.equalsIgnoreCase("URMU") || activityName.equalsIgnoreCase("CMO")) {
                ifr.setStyle("t2s1", "disable", "true");
                ifr.setStyle("t2s2", "disable", "true");  //aanchal //DR-6990
            }

            if (!activityName.equalsIgnoreCase("Source")) {

                setMandatory("DocFlag");
                setMandatory("CC_Flag");
                setMandatory("Discrepancy_Flag");
                setMandatory("Auto_UW_Flag");
                setMandatory("Med_Kickout_Flag");
                setMandatory("Req_in_flag");
                setMandatory("PI_ATTACHED");
                setMandatory("ULIP_CHECK");

                //requirements section hardcode.
                //IDs not found on the form
                /*ifr.setValue("label43", "3");
                ifr.setValue("category", "ID proof");
                ifr.setValue("Q_Subcategory", "ID proof required");*/
                ifr.setStyle("button178", "visible", "false"); //source introduce button
            }

            String userRole = userRole();

            if (!userRole.equalsIgnoreCase("UW")) {
                JSONArray notesTable;
                int size;
                JSONObject obj;
                String viewName;

                ifr.clearCombo("combo409");
                ifr.addItemInCombo("combo409", "Max Life View", "MV", "", "");
                notesTable = ifr.getDataFromGrid("table57");
                size = notesTable.size();

            }

        } catch (Exception e) {
            System.out.println("Exception in formLoadDolphinLater  " + e.toString());
        }

    }

}
