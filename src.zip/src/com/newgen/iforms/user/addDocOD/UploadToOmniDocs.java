/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user.addDocOD;


import com.newgen.iforms.user.Dolphin_CommonFunctions;
import static com.newgen.iforms.user.callREST_API.propertiesFileData;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.XML;

public class UploadToOmniDocs {
         static final String CONFIG_PATH = "Dolphin\\config.properties";
          public static Properties propertiesFileData;
	public String UploadToOmniDocsRest(String cabinetName,String folderIndex, String documentPath, String userDbId, String volumeId) throws IOException {
//                cabinetName="myflow";
//		String userName="";
//		String userPassword="";
		String comment="Gtration"; //docType
//		String folderIndex="30";
//		String documentPath="D:\\a.pdf";
//		String volumeId="136";
		
//		String dataDefIndex="8";
//		String dataDefName="ACC_Audit5";
//		
//		String indexId1="25";
//		String indexType1="S";
//		String indexValue1="TestRest";
//		
//		String indexId2="26";
//		String indexType2="S";
//		String indexValue2="TestRest1";
//		
//		String indexId3="27";
//		String indexType3="F";
//		String indexValue3="25.0014";
		
		String fileName = "";
  	  	String fileExtns = "";
  	  	String filePath = "";
  	  	
                 
  	  	//String TARGET_URL = "myflowuatcloud.maxlifeinsurance.com";
  	  	String inputXML = "";
  	  	String message="";
  	  	
  	  	//TARGET_URL="https://"+TARGET_URL+"/OmniDocsRestWS/rest/services/addDocument";
                readPropoertiesFile();
                String TARGET_URL = propertiesFileData.getProperty("TARGET_URL");
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, TARGET_URL,TARGET_URL );
		filePath=documentPath.substring(0, documentPath.lastIndexOf("\\"));
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, filePath,TARGET_URL );
		fileName=documentPath.substring(documentPath.lastIndexOf("\\")+1,documentPath.lastIndexOf("."));
                 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, fileName,TARGET_URL );
		fileExtns=documentPath.substring(documentPath.lastIndexOf(".")+1);
		documentPath = filePath + "\\" + fileName + "." + fileExtns;
		 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, documentPath,TARGET_URL );
		inputXML="<NGOAddDocumentBDO>" +
				"<cabinetName>"+ cabinetName + "</cabinetName>" +
				"<folderIndex>"+ folderIndex + "</folderIndex>" +
				"<documentName>"+ fileName +"</documentName>" +
				"<userDBId>"+userDbId+"</userDBId>" +
				"<volumeId>"+volumeId+"</volumeId>" +
				"<accessType>S</accessType>" +
				"<createdByAppName>"+ fileExtns +"</createdByAppName>" +
				"<enableLog>Y</enableLog>" +
				"<FTSFlag>PP</FTSFlag>" +
				"<userName></userName>" +
				"<userPassword></userPassword>" +
				"<comment>"+comment+"</comment>" +
                                "<documentType>N</documentType>" +
			"</NGOAddDocumentBDO>";		
		System.out.println(inputXML);
		Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, inputXML,inputXML );
		String response="";
		try {
		 response = sendAddDocuemntRequest(inputXML, documentPath,TARGET_URL);
		 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, response+"Sparsh0",response+"Sparsh0" );
			
		}catch(Exception e)
		{e.printStackTrace();
		Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, e+"Sparsh1",e+"Sparsh1" );
		}
		
		if(response != null) {
			message = response;
			System.out.println("Response========="+message);
                        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, message,message );
		}
		else
		{
			System.out.println("Error in sending request to server.");
		}
  
  	 
		System.out.println("Exiting successfully from the main");
                
                try {
			message = XML.toJSONObject(message).toString(4);
		} catch (JSONException e) {
			e.printStackTrace();
		}
                
                return message;
                
	}
          public void readPropoertiesFile() {
        try {
            propertiesFileData = new Properties();
            String configPath = System.getProperty("user.dir") + "\\" + CONFIG_PATH;
            FileReader reader;
            try {
                reader = new FileReader(configPath);
                propertiesFileData.load(reader);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
	
public  String sendAddDocuemntRequest(String request, String documentPath,String TARGET_URL) {
	try {
	Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, documentPath +"Sparsh2",documentPath+"Sparsh2" );
 	
    	CloseableHttpClient httpClient = HttpClients.createDefault();
    	HttpPost uploadFile = new HttpPost(TARGET_URL);
    	 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, "Sparsh3","Sparsh3" );
     	
        try
        {
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, documentPath+"Sparsh4",documentPath+"Sparsh4" );
    	
        builder.addTextBody("NGOAddDocumentBDO", request, ContentType.TEXT_PLAIN);
        
    	
    	File file = new File(documentPath);
        Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, documentPath+"Sparsh6",documentPath+"Sparsh6" );
    	if(file.exists()) {
	    	try {
				builder.addBinaryBody(
				    "file",
				    new FileInputStream(file),
				    ContentType.APPLICATION_OCTET_STREAM,
				    file.getName()
				);
				
				HttpEntity multipart = builder.build();
		    	uploadFile.setEntity(multipart);
		    	CloseableHttpResponse response = httpClient.execute(uploadFile);
		    	String responseStr = EntityUtils.toString(response.getEntity());
		    	return responseStr;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                        
    	}
    	else {
        	System.out.println("File doesn't exist. Please check");
                Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, "File doesn't exist. Please check","File doesn't exist. Please check" );
        }
}
        catch(Exception e)
        {
             e.printStackTrace();
             Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE,e+"Sparsh6",e+"Sparsh6");
        }    
            
    
}catch(Exception e) {
	 Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE,e+"Sparsh5",e+"Sparsh5");
}
return null;
}
}
