/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;

/**
 *
 * @author prakhar.saxena
 */
public class DolphinUtil {
    /*
        This function will return the planCode based on PlanName as per th Master Table "NG_NB_MS_PLAN_CODE"
    */
    public static String getPlanCodeFromName(String planName) {
        String planCode = "";
        if (planName.equalsIgnoreCase("LPPS07")
                || planName.equalsIgnoreCase("LPPS10")
                || planName.equalsIgnoreCase("LPPS15")
                || planName.equalsIgnoreCase("LPPS20")) {
            planCode = "LPPS";
        } else if (planName.equalsIgnoreCase("U2NIFS")
                || planName.equalsIgnoreCase("U2NIF5")
                || planName.equalsIgnoreCase("U2NF20")) {
            planCode = "FTSP";
        } else if (planName.equalsIgnoreCase("UIPWFS")
                || planName.equalsIgnoreCase("UIPWF5")
                || planName.equalsIgnoreCase("UIPWFR")) {
            planCode = "PWP";
        } else if (planName.equalsIgnoreCase("UPPRPF")
                || planName.equalsIgnoreCase("UPPSPF")
                || planName.equalsIgnoreCase("UPPSCF")) {
            planCode = "FYPP";
        } else if (planName.equalsIgnoreCase("U2ESF5")
                || planName.equalsIgnoreCase("U2ESFV")) {
            planCode = "SPS";
        } else if (planName.equalsIgnoreCase("UCOSCF")
                || planName.equalsIgnoreCase("UCOSWF")
                || planName.equalsIgnoreCase("UNOSCF")
                || planName.equalsIgnoreCase("UNOSWF")
                ) {
            planCode = "OSP";
        } else if (planName.equalsIgnoreCase("ESMI12")
                || planName.equalsIgnoreCase("ESMI15")
                || planName.equalsIgnoreCase("ESMI8")
                || planName.equalsIgnoreCase("ESMIL")) {
            planCode = "MIAP";
        } else if (planName.equalsIgnoreCase("WP010")
                || planName.equalsIgnoreCase("WP015")
                || planName.equalsIgnoreCase("WP020")) {
            planCode = "WLS";
        } else if (planName.equalsIgnoreCase("TG2P6")
                || planName.equalsIgnoreCase("TG2P12")) {
            planCode = "GIP";
        } else if (planName.equalsIgnoreCase("EFGEP8")
                || planName.equalsIgnoreCase("EFGEPL")) {
            planCode = "FGEP";
        } else if (planName.equalsIgnoreCase("UFIPFS")
                || planName.equalsIgnoreCase("UFIPFL")
                || planName.equalsIgnoreCase("UFIPFR")
                 || planName.equalsIgnoreCase("UFISFL")
                || planName.equalsIgnoreCase("UFISFR")
                 || planName.equalsIgnoreCase("UFINFL")
                || planName.equalsIgnoreCase("UFINPR")
                || planName.equalsIgnoreCase("UFIPFW")
                || planName.equalsIgnoreCase("UFINFR")) {
            planCode = "FWP";
        } else if (planName.equalsIgnoreCase("TFSTP")
                || planName.equalsIgnoreCase("TSSTP")) {
            planCode = "STP";
        } else if (planName.equalsIgnoreCase("EPRSCL")
                || planName.equalsIgnoreCase("EPRSCT")
                || planName.equalsIgnoreCase("EPRSCS")
                || planName.equalsIgnoreCase("EPRSCR")) {
            planCode = "SAP";
        } else if (planName.equalsIgnoreCase("TNOTPL")
                || planName.equalsIgnoreCase("TCOT60")
                || planName.equalsIgnoreCase("TCOTP2")
                || planName.equalsIgnoreCase("TNOT60")) {
            planCode = "OTP";
        }
        else if(planName.equalsIgnoreCase("TSWPPL")
                || planName.equalsIgnoreCase("TSWPPR")
                || planName.equalsIgnoreCase("TSWPVL")
                || planName.equalsIgnoreCase("TSWPVR")
                || planName.equalsIgnoreCase("TSWPTL")
                || planName.equalsIgnoreCase("TSWPTS")
                || planName.equalsIgnoreCase("TSWPW1")// new plan codes
                || planName.equalsIgnoreCase("TSWVTL")
                || planName.equalsIgnoreCase("TSWVTS")
                || planName.equalsIgnoreCase("TSWPVL")
                || planName.equalsIgnoreCase("TSWPVR")
                || planName.equalsIgnoreCase("TSWRW1")
                || planName.equalsIgnoreCase("TSWRW2")
                || planName.equalsIgnoreCase("TSWPLR")// 2 new plan codes // Dr-28244 sparsh
                || planName.equalsIgnoreCase("TSWVLR")) {
            planCode = "SWP";
        }
        else if (planName.equalsIgnoreCase("TSJBR")
                || planName.equalsIgnoreCase("TSJBL")
                || planName.equalsIgnoreCase("TSJBS")) {
            planCode = "SJB";
        }
         else if (planName.equalsIgnoreCase("TNSTPS")
                || planName.equalsIgnoreCase("TCSTPS")
                || planName.equalsIgnoreCase("TNSTPL")
                 || planName.equalsIgnoreCase("TCSTPL")
                 || planName.equalsIgnoreCase("TNSTPR")
                 || planName.equalsIgnoreCase("TCSTPR")
                 || planName.equalsIgnoreCase("TNST60")
                 || planName.equalsIgnoreCase("TCST60")
                 || planName.equalsIgnoreCase("TNSTRS")
                 || planName.equalsIgnoreCase("TCSTRS")
                 || planName.equalsIgnoreCase("TNSTRL")
                 || planName.equalsIgnoreCase("TCSTRL")
                 || planName.equalsIgnoreCase("TNSTRR")
                 || planName.equalsIgnoreCase("TCSTRR")
                  || planName.equalsIgnoreCase("TNSR60")
                  || planName.equalsIgnoreCase("TCSR60")
                 || planName.equalsIgnoreCase("TSSEPL")
                  || planName.equalsIgnoreCase("TSSERL")
                 || planName.equalsIgnoreCase("TSEP60")
                  || planName.equalsIgnoreCase("TSER60")
                 ) {
            planCode = "SSP";
        }
         else if (planName.equalsIgnoreCase("IAS")
                || planName.equalsIgnoreCase("IASR")
                || planName.equalsIgnoreCase("IASC")
                 || planName.equalsIgnoreCase("IASRC")
                 || planName.equalsIgnoreCase("TDAS")
                 || planName.equalsIgnoreCase("TDASC")
                 || planName.equalsIgnoreCase("IAJ")
                 || planName.equalsIgnoreCase("IAJR")
                 || planName.equalsIgnoreCase("IAJC")
                 || planName.equalsIgnoreCase("IAJRC")
                 || planName.equalsIgnoreCase("TDAJ")
                 || planName.equalsIgnoreCase("TDAJC")
                  || planName.equalsIgnoreCase("IASRP")
                 || planName.equalsIgnoreCase("TDASN")
                 || planName.equalsIgnoreCase("TDAJN")
                 || planName.equalsIgnoreCase("TDASNC")
                 || planName.equalsIgnoreCase("TDAJNC")
                
                 
                 ) {
            planCode = "GLIP";
        }
         else if (planName.equalsIgnoreCase("TIASR")
                || planName.equalsIgnoreCase("TIASRC")
                || planName.equalsIgnoreCase("TIAJRC")
                 || planName.equalsIgnoreCase("TIAJR")
                 )
                 
                  {
            planCode = "SPP";
        }
          else if (planName.equalsIgnoreCase("TSWEIB")
                || planName.equalsIgnoreCase("TSWEMB")
                || planName.equalsIgnoreCase("TSWDIB")
                 || planName.equalsIgnoreCase("TSWEI")
                   || planName.equalsIgnoreCase("TSWEM")
                 || planName.equalsIgnoreCase("TSWDI")
                  
                 )
                 
                  {
            planCode = "SWIP";
        }
           else if (planName.equalsIgnoreCase("UFWAFS")
                || planName.equalsIgnoreCase("UFWAPS")
                || planName.equalsIgnoreCase("UFWARS")
                 || planName.equalsIgnoreCase("UFWAPS")
                   || planName.equalsIgnoreCase("UFWARS")
                 || planName.equalsIgnoreCase("UFWAFL")
                    || planName.equalsIgnoreCase("UFWAPL")
                   || planName.equalsIgnoreCase("UFWARL")
                 || planName.equalsIgnoreCase("UFWAFR")
                     || planName.equalsIgnoreCase("UFWAPR")
                   || planName.equalsIgnoreCase("UFWARR")
                 || planName.equalsIgnoreCase("UFWAFW")
                   || planName.equalsIgnoreCase("UFWAPW")
                     || planName.equalsIgnoreCase("UFWARW")
                 || planName.equalsIgnoreCase("ULWP")
                  
                 )
                 
                  {
            planCode = "FWAP";
        }
            else if (planName.equalsIgnoreCase("TIAGSR")
                || planName.equalsIgnoreCase("TIAGJR")
                || planName.equalsIgnoreCase("TIAGS")
                
                 || planName.equalsIgnoreCase("TIAGJ")
                  
                 )
                 
                  {
            planCode = "SGPP";
        }
            else if (planName.equalsIgnoreCase("DNCCP")
                || planName.equalsIgnoreCase("DCCCP")
               
                 )
                 
                  {
            planCode = "CIP";
        }
            else if(planName.equalsIgnoreCase("TSFDGS")
                || planName.equalsIgnoreCase("TSFDG1")
                || planName.equalsIgnoreCase("TSFDG2")
                || planName.equalsIgnoreCase("TSFDPL")
                || planName.equalsIgnoreCase("TSFDPR")
                || planName.equalsIgnoreCase("TSFDTL")
                || planName.equalsIgnoreCase("TSFDTR")// new plan codes
                || planName.equalsIgnoreCase("TPFDGS")
                || planName.equalsIgnoreCase("TPFDG1")
                || planName.equalsIgnoreCase("TPFDG2")
                || planName.equalsIgnoreCase("TPFDPL")
                || planName.equalsIgnoreCase("TPFDPR")
                || planName.equalsIgnoreCase("TPFDTL")
                || planName.equalsIgnoreCase("TPFDTR")    
                ){
            planCode = "SFRD";
        }
       else if (planName.equalsIgnoreCase("TSGMS")
                    || planName.equalsIgnoreCase("TSGML")
                    || planName.equalsIgnoreCase("TSGMB")
                     || planName.equalsIgnoreCase("TSGRL")
                       || planName.equalsIgnoreCase("TSGRB")
                     || planName.equalsIgnoreCase("TSGLL")
                        || planName.equalsIgnoreCase("TSGLB")
                       || planName.equalsIgnoreCase("TSGEL")
                     || planName.equalsIgnoreCase("TSGER")
                         || planName.equalsIgnoreCase("TSGWL")
                || planName.equalsIgnoreCase("TPSGEL")
                         || planName.equalsIgnoreCase("TPSGER")
                || planName.equalsIgnoreCase("TSGELB")
                         || planName.equalsIgnoreCase("TSGERB")
               || planName.equalsIgnoreCase("TPSGELB")
                         || planName.equalsIgnoreCase("TPGELR")
               || planName.equalsIgnoreCase("TPSGER")
                         || planName.equalsIgnoreCase("TPSERB")
               || planName.equalsIgnoreCase("TSGMS")
|| planName.equalsIgnoreCase("TSGML")
|| planName.equalsIgnoreCase("TSGMB")
|| planName.equalsIgnoreCase("TSGRL")
|| planName.equalsIgnoreCase("TSGRB")
|| planName.equalsIgnoreCase("TPSGMS") 
|| planName.equalsIgnoreCase("TPSGML")
|| planName.equalsIgnoreCase("TPSGMB")
|| planName.equalsIgnoreCase("TPSGRL") 
|| planName.equalsIgnoreCase("TPSGRB") 
                     ) {
                planCode = "SWAG";
            }
       else if (planName.equalsIgnoreCase("TSPIFB")
             || planName.equalsIgnoreCase("TSPIF")
             || planName.equalsIgnoreCase("TSPIW")
             || planName.equalsIgnoreCase("TSPIWB")
             || planName.equalsIgnoreCase("TSPBFB")
             || planName.equalsIgnoreCase("TSPBF")
             || planName.equalsIgnoreCase("TSPBW")
             || planName.equalsIgnoreCase("TSPBWB")
             || planName.equalsIgnoreCase("TSPFFB")
             || planName.equalsIgnoreCase("TSPFF")
             || planName.equalsIgnoreCase("TSPFW")
             || planName.equalsIgnoreCase("TSPFWB")
             || planName.equalsIgnoreCase("TSPLW")
             || planName.equalsIgnoreCase("TSPLWB")
          ) {
                planCode = "SWAGP";
            }
       else if (planName.equalsIgnoreCase("TSEWAL")
               || planName.equalsIgnoreCase("TSEWAR")
            ) {
                  planCode = "SEWA";
              }
       else if (planName.equalsIgnoreCase("TNSTES") //DR-33983 Nikita
               || planName.equalsIgnoreCase("TNSTER")
               || planName.equalsIgnoreCase("TNSTEL")
               || planName.equalsIgnoreCase("TNSTE6")
               || planName.equalsIgnoreCase("TCSTES")
               || planName.equalsIgnoreCase("TCSTER")
               || planName.equalsIgnoreCase("TCSTEL")
               || planName.equalsIgnoreCase("TCSTE6")
    		   ) {
           			planCode = "STEP";
       			 }
       else if (planName.equalsIgnoreCase("TIRS") //DR-33955 Nikita
               || planName.equalsIgnoreCase("TIRJ")
               || planName.equalsIgnoreCase("TDRS")
               || planName.equalsIgnoreCase("TDRJ")
               || planName.equalsIgnoreCase("TIRSR")
               || planName.equalsIgnoreCase("TIRJR")
               || planName.equalsIgnoreCase("TDRSR")
               || planName.equalsIgnoreCase("TDRJR")
               || planName.equalsIgnoreCase("TIRSMR")
               || planName.equalsIgnoreCase("TIRSIR")
               || planName.equalsIgnoreCase("TIRSRP")
               || planName.equalsIgnoreCase("TIRJRP")
               || planName.equalsIgnoreCase("TIRSRF")
               || planName.equalsIgnoreCase("TIRJRF")
               || planName.equalsIgnoreCase("TDRSN")
               || planName.equalsIgnoreCase("TDRJN")
               || planName.equalsIgnoreCase("TDRSNR")
               || planName.equalsIgnoreCase("TDRJNR")
               || planName.equalsIgnoreCase("TIRJF")
               || planName.equalsIgnoreCase("TIRJFR")
               || planName.equalsIgnoreCase("TIRSG")
               || planName.equalsIgnoreCase("TIRSBR")
               || planName.equalsIgnoreCase("TIGRS") //DR-43220 Nikita Start
               || planName.equalsIgnoreCase("TIGRJ") 
               || planName.equalsIgnoreCase("TDGRS") 
               || planName.equalsIgnoreCase("TDGRJ") 
               || planName.equalsIgnoreCase("TIGRSR") 
               || planName.equalsIgnoreCase("TIGRJR") 
               || planName.equalsIgnoreCase("TDGRSR") 
               || planName.equalsIgnoreCase("TDGRJR") 
               || planName.equalsIgnoreCase("TIGSMR") 
               || planName.equalsIgnoreCase("TIGSIR") //DR-43220 Nikita End 
                ) {
           			planCode = "SWAGPP";
       			 }
       else if (planName.equalsIgnoreCase("TSEWM") //DR-40123 Nikita
               || planName.equalsIgnoreCase("TSEWMB")
               || planName.equalsIgnoreCase("TSELT")
               || planName.equalsIgnoreCase("TSELTB")
               ) {
           			planCode = "SWAGE";
       			 }
        else {
            planCode = "AWP";
        }
        return planCode;
    }
    
    public static String getValueFromMaster(IFormReference iFormRef, String key, String MS_Table, String valCol, String labelCol){
        //getValueFromMaster(iFormRef,policyHolderStateName,"NG_NB_MS_STATE","VALUE","LABEL");
        String label="";
        String query = "SELECT "+labelCol+" FROM "+MS_Table+"(NOLOCK) WHERE "+valCol+" = '"+key+"' ";
         List labelName = (List) iFormRef.getDataFromDB(query);
                if (!labelName.isEmpty()) {
                    label = (String) ((List) labelName.get(0)).get(0);
                }
        return label;
    }
    
    public static String CalculateYears(String age, IFormReference iFormRef){
        
        if(age.equalsIgnoreCase("") || age==null)  //aanchal SIT 30 April
            return "0";
        
        String years="";
         String effectiveDateStr ="";
       effectiveDateStr = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
       if( effectiveDateStr.equalsIgnoreCase(""))
        {
            String winame = (String) iFormRef.getControlValue("WorkItemName");
            String query = "select EFFECTIVE_DATE from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME = '"+winame+"' ";
        List queryResult = getValFromQuery(query, iFormRef);
        if(queryResult!=null){
            effectiveDateStr = (String) ((List) queryResult.get(0)).get(0);
        }
            
            
        }
                
        Date inDate = null;
        Date effectiveDate = null;
        SimpleDateFormat formatter=new SimpleDateFormat();
        try {
            formatter = new SimpleDateFormat("dd/MM/yyyy");
            inDate = formatter.parse(age);
            formatter = new SimpleDateFormat("yyyy-MM-dd");
            if(!effectiveDateStr.equals("")){
            effectiveDateStr=effectiveDateStr.substring(0,10);
            effectiveDate = formatter.parse(effectiveDateStr);
            }
        } catch (Exception ex) {
            formatter = new SimpleDateFormat("yyyy-MM-dd");
            try {
                inDate = formatter.parse(age);
                if(!effectiveDateStr.equals("")){
                effectiveDateStr=effectiveDateStr.substring(0,10);
                effectiveDate = formatter.parse(effectiveDateStr);
                }
            } catch (ParseException ex1) {
                Logger.getLogger(DolphinUtil.class.getName()).log(Level.SEVERE, null, ex1);
            }
            Logger.getLogger(DolphinUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String productDating = getProductdating(iFormRef);
        if(productDating.equals("CD")){
            if(inDate!=null)
                years =  String.valueOf(getAge(inDate,null));
        }
        else
        {   if(inDate!=null && effectiveDate!=null)
                years =  String.valueOf(getAge(inDate,effectiveDate));
        }    
        
        return years;
    }
    
    private static int getAge(Date dateOfBirth, Date effectiveDate) {

	    Calendar today = Calendar.getInstance();
	    Calendar birthDate = Calendar.getInstance();
            Calendar effDate = Calendar.getInstance();

	    int age = 0;

	    birthDate.setTime(dateOfBirth);
                        
            if(effectiveDate!=null){
                effDate.setTime(effectiveDate);
                today=effDate;
            }
            
            
	    if (birthDate.after(today)) {
	        throw new IllegalArgumentException("Can't be born in the future");
	    }

	    age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

	    // If birth date is greater than todays date (after 2 days adjustment of leap year) then decrement age one year   
	    if ( (birthDate.get(Calendar.DAY_OF_YEAR) - today.get(Calendar.DAY_OF_YEAR) > 3) ||
	            (birthDate.get(Calendar.MONTH) > today.get(Calendar.MONTH ))){
	        age--;

	     // If birth date and todays date are of same month and birth day of month is greater than todays day of month then decrement age
	    }else if ((birthDate.get(Calendar.MONTH) == today.get(Calendar.MONTH )) &&
	              (birthDate.get(Calendar.DAY_OF_MONTH) > today.get(Calendar.DAY_OF_MONTH ))){
	        age--;
	    }
	    return age;
	}
    
    public static String getChannelDescFromVal(String Channel, IFormReference iFormRef) {
        String channelDesc="";
        String query = "SELECT TOP(1) CHANNEL_DESC FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE = '"+Channel+"' ";
        List queryResult = getValFromQuery(query, iFormRef);
        if(queryResult!=null){
            channelDesc = (String) ((List) queryResult.get(0)).get(0);
        }
        return channelDesc;
    }
    
    static List getValFromQuery(String query, IFormReference iFormRef) {
        String queryResult = "";
        List queryResultList = (List) iFormRef.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
    }

    public static String getProductdating(IFormReference iFormRef) {
        String resultString  ="";
        String plan_type = (String) iFormRef.getControlValue("PLAN_TYPE");
                String prodDatingQuery="";
                String planCode = (String) iFormRef.getControlValue("PLAN_NAME");
                String Channel = (String) iFormRef.getControlValue("CHANNEL");
                if(plan_type.equalsIgnoreCase("TRAD")){
                    prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_TRAD(NOLOCK) WHERE Plan_Code='"+planCode+"' AND Channel='"+Channel+"' AND "
                            + "Sub_Channel='"+getValueFromMaster(iFormRef,Channel,"NG_NB_MS_CHANNEL_MAPPING_CODE_DESC","CHANNEL_CODE","SUB_CHANNEL")+"'";                    
                }else if(plan_type.equalsIgnoreCase("ULIP")){
                       prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_ULIP(NOLOCK) WHERE Plan_Code='"+planCode+"' AND Channel='"+Channel+"' AND "
                            + "Sub_Channel='"+getValueFromMaster(iFormRef,Channel,"NG_NB_MS_CHANNEL_MAPPING_CODE_DESC","CHANNEL_CODE","SUB_CHANNEL")+"'"; 
                    }
                  else if(plan_type.equalsIgnoreCase("JOINT")){
                           prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_JOINT(NOLOCK) WHERE Plan_Code='"+planCode+"' AND Channel='"+Channel+"' AND "
                                + "Sub_Channel='"+getValueFromMaster(iFormRef,Channel,"NG_NB_MS_CHANNEL_MAPPING_CODE_DESC","CHANNEL_CODE","SUB_CHANNEL")+"'"; 
                        }
                 else if(plan_type.equalsIgnoreCase("ANNUITY")){
                           prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_ANNUITANT(NOLOCK) WHERE Plan_Code='"+planCode+"' AND Channel='"+Channel+"' AND "
                                + "Sub_Channel='"+getValueFromMaster(iFormRef,Channel,"NG_NB_MS_CHANNEL_MAPPING_CODE_DESC","CHANNEL_CODE","SUB_CHANNEL")+"'"; 
                        }
                else if(plan_type.equalsIgnoreCase("HEALTH")){
                           prodDatingQuery = "SELECT PRODUCT_DATING FROM NG_NB_MS_HEALTH(NOLOCK) WHERE Plan_Code='"+planCode+"' AND Channel='"+Channel+"' AND "
                                + "Sub_Channel='"+getValueFromMaster(iFormRef,Channel,"NG_NB_MS_CHANNEL_MAPPING_CODE_DESC","CHANNEL_CODE","SUB_CHANNEL")+"'"; 
                        }
                List queryList  =(List) iFormRef.getDataFromDB(prodDatingQuery);
                if(!queryList.isEmpty()){
                String productDating = (String) ((List) queryList.get(0)).get(0);
                resultString=productDating;
                }
        return resultString;
    }

    public static boolean isAdminEnabled(String serviceName, IFormReference iFormRef){
        String query = "SELECT FLAG FROM NG_NB_MS_ADMIN_MODULE(NOLOCK) WHERE FUNCTIONALITY_NAME='"+serviceName+"'";
        List queryResult = (List)iFormRef.getDataFromDB(query);
        if(!queryResult.isEmpty()){
            String flag = (String) ((List) queryResult.get(0)).get(0);
            if(flag.equalsIgnoreCase("Y"))
                return true;
        }
        return false;
    }
    
    public static String generateRandomString(int n) {
	    int leftLimit = 48; // numeral '0'
	    int rightLimit = 122; // letter 'z'
	    int targetStringLength = n;
	    Random random = new Random();
	 
	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();
	 
	    return generatedString;
	}
    
    public static String getUW_EDC_Date(IFormReference iFormRef){
        String edc="";
        String uw_edc ="";
        String planType=(String) iFormRef.getControlValue("PLAN_TYPE");
        String planCode=(String) iFormRef.getControlValue("PLAN_NAME");
        String channel = (String) iFormRef.getControlValue("CHANNEL");
        String subChannel = (String) iFormRef.getControlValue("Q_DEFENCE_DETAILS.Defence_Channel_Case");
        if(subChannel.equalsIgnoreCase("Y"))
            subChannel = "Defence";
        else{
            String query = "SELECT TOP(1) CHANNEL_DESC FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE = '"+channel+"' ";
            List queryResult = iFormRef.getDataFromDB(query);
            if(queryResult!=null)
                subChannel = (String) ((List) queryResult.get(0)).get(0);
        }   
        String masterTable="";
        if(planType.equals("TRAD"))
            masterTable="NG_NB_MS_TRAD";
        else if(planType.equals("ULIP"))
            masterTable="NG_NB_MS_ULIP";
         else if(planType.equals("ANNUITY"))
            masterTable="NG_NB_MS_ANNUITANT";
         else if(planType.equals("HEALTH"))
            masterTable="NG_NB_MS_HEALTH";
        else
        	masterTable="NG_NB_MS_JOINT";
        
        String decision=(String)iFormRef.getControlValue("Decision");
        
        String query="SELECT  uw_edc "
            + " FROM "+masterTable+"(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + channel + "' "
            + " AND Sub_Channel='" + subChannel + "'; ";
        List queryResult = iFormRef.getDataFromDB(query);
        if (queryResult != null) {
            uw_edc = (String) ((List) queryResult.get(0)).get(0);
        }
        if (uw_edc.equals("N")) {
            edc = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
        }
        else{
            if(decision.equalsIgnoreCase("Accept") || decision.equalsIgnoreCase("Counter Offer Accept")|| decision.equalsIgnoreCase("Counter Offer") || decision.equalsIgnoreCase("CO Reconsider") )
                edc = (String) iFormRef.getControlValue("Q_DECISION_SECTION_UW.EDC");
            else
                edc = (String) iFormRef.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
        }
        return edc;
    }
    
    public static String createODxml(JSONObject json){
        String xml="";
        xml=xml+getXMLTag("Option","NGOAddDocument");
        xml=xml+getXMLTag("Status","0");
        xml=xml+"<Document>"
                + getXMLTag("ParentFolderIndex",json.get("parentFolderIndex"))
                + getXMLTag("DocOrderNo",json.get("docOrderNo"))
                + getXMLTag("DocumentIndex",json.get("documentIndex"))
                + getXMLTag("DocumentVersionNo",json.get("documentVersionNo"))
                + getXMLTag("DocumentName",json.get("documentName"))
                + getXMLTag("OwnerIndex",json.get("ownerIndex"))
                + getXMLTag("ISIndex",json.get("isIndex"))
                + getXMLTag("NoOfPages",json.get("noOfPages"))
                + getXMLTag("DocumentSize",json.get("documentSize"))
                + getXMLTag("Comment",json.get("comment"))
                + getXMLTag("Author",json.get("author"))
                + getXMLTag("Owner",json.get("owner"))
                + getXMLTag("CreatedByAppName",json.get("createdByAppName"))                
                + "</Document>";
        return xml;
    }
    
    private static <E> String getXMLTag(String key,E value)  {
        String xml="";
        xml = "<"+key+">"+value+"</"+key+">";
        return xml;
    }
    
    /*
        Will return the file path after creating the file from base 64 String
    */
    public static String getFileFromBase64(String bas64String, String wi_name) throws IOException{
        String pathToBin=System.getProperty("user.dir");
        String filePath = pathToBin+"\\CreateWorkitemService\\tmpIllustration\\"+wi_name;
         Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null,filePath+"aan0" );
        File file = new File(filePath);
        try
        {
        file.mkdir();
        }
        catch(Exception e)
        {
            Logger.getLogger(Dolphin_CommonFunctions.class.getName()).log(Level.SEVERE, null, e);
        }
        filePath=filePath+"\\Illustrations.pdf";
        
        byte[] data = Base64.getDecoder().decode(bas64String);

        try( OutputStream stream = new FileOutputStream(filePath) ) 
        {
           stream.write(data);
        }
        catch (Exception e) 
        {
           System.err.println("Couldn't write to file...");
           return "1";
        }
        
        return filePath;
    }
    
    static public boolean deleteDirectory(File path) {
        if( path.exists() ) {
          File[] files = path.listFiles();
          for(int i=0; i<files.length; i++) {
             if(files[i].isDirectory()) {
               deleteDirectory(files[i]);
             }
             else {
               files[i].delete();
             }
          }
        }
        return( path.delete() );
        }
    
}


