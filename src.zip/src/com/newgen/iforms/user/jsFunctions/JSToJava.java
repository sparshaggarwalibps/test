/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user.jsFunctions;

import com.newgen.iforms.custom.IFormReference;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * This class will convert the client side APIs to the corresponding JAVA APIs
 * @author prakhar
 * Date Written: 30 Sep 2021
 */
public class JSToJava {
    
    private IFormReference iFormRef;
       
    public JSToJava(IFormReference iFormRef){
        this.iFormRef = iFormRef;
    }

    public void setStyle(String controlId, String prop, String atrue) {
        iFormRef.setStyle(controlId, prop, atrue);        
    }

    public void setMandatory(String controlId) {
        iFormRef.setStyle(controlId, "mandatory", "true");
    }
    
    public void setnonMandatory(String controlId) {
        iFormRef.setStyle(controlId, "mandatory", "false");
    }

    public void setValue(String controlId, String value) {
        iFormRef.setValue(controlId, value);
    }

    public String getValue(String controlId) {
        return (String) iFormRef.getValue(controlId);
    }

    public void setValues(String controlJsonString, boolean b) {
        controlJsonString = controlJsonString.replaceAll("'", "\""); 
        JSONObject responseObj = new JSONObject();
        JSONParser jsonParser = new JSONParser();
        try {
            responseObj = (JSONObject) jsonParser.parse(controlJsonString);
            for(Object key: responseObj.keySet()){
                iFormRef.setValue((String)key, (String)responseObj.get(key));
            }
        } catch (ParseException ex) {
            Logger.getLogger(JSToJava.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
