/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user.combovalidations;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.DolphinUtil;
import static com.newgen.iforms.user.DolphinUtil.getProductdating;
import static com.newgen.iforms.user.combovalidations.BusinessLogicDao.queryExecutor;
import static com.newgen.iforms.user.combovalidations.BusinessLogicDao.whereClause;
import static com.newgen.iforms.user.combovalidations.CheckFieldVisible.mdmColName;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * This class will interact with form and db via business logic.
 *
 * @author prakhar.saxena
 */
public class ComboValidator {

    private int i = 0;
    BusinessLogicDao businessLogcDao;
    IFormReference ifr;
    String fieldValue;
    String message = "";
    String controlName = "";
    String whereClause, Channel, subChannel, planCode;

    //Constructor
    public ComboValidator(String controlName, String fieldValue, IFormReference ifr) {
        super();
        this.ifr = ifr;
        this.controlName = controlName;
        this.fieldValue = fieldValue;

        String channel = ifr.getValue("CHANNEL").toString();
        String planCode = (String) ifr.getControlValue("PLAN_NAME");
        String DefenceChannelCase = (String) ifr.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
        String secondaryPlanCode=(String) ifr.getControlValue("PLAN_NAME_COMBO");
        String productsolution=(String) ifr.getControlValue("PRODUCT_SOLUTION");
//        if(!controlName.equals("onLoad"))
//            planCode = fieldValue;
        if (controlName.equals("PLAN_NAME")) {
            planCode = fieldValue;
        }

        this.planCode = planCode;
        this.Channel = channel;

        if (channel.equalsIgnoreCase("A") && DefenceChannelCase.equalsIgnoreCase("Y")) {
            this.subChannel = "Defence";
        } else {
            this.subChannel = getSubChannel(channel);
        }

        this.whereClause = " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + channel
                + "' AND  combo_plan_code='"+secondaryPlanCode+"' and product_Solution='"+productsolution+"' and  Sub_Channel='" + this.subChannel + "' AND Is_Active_Ind='Y'";

        this.businessLogcDao = new BusinessLogicDao(planCode, channel, "", "IFORM", "", "", ifr);

    }

    //To get SubChannel
    private String getSubChannel(String Channel) {
        String subChannel = "";
        String query = "SELECT SUB_CHANNEL FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE='" + Channel + "' AND SUB_CHANNEL!='Defence'";
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            subChannel = (String) ((List) queryResult.get(0)).get(0);
        }
        return subChannel;
    }

    public String isCOMBOFundValid() {
        String result = "false";
        String isSTPSelected = (String) ifr.getControlValue("Q_FUND_SELECTED.STP");
        String planCode = (String) ifr.getControlValue("PLAN_NAME_COMBO");
        result = businessLogcDao.validateULIPFund(fieldValue, isSTPSelected, planCode);
        return result;
    }

    public void addMandatoryBenefitRiders() {
        addMandatoryBenefitRidersToGrid();
    }

    public String getErrorMessage() throws ParseException {
        if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_EFFECTIVE_DATE") || controlName.equalsIgnoreCase("Q_CUSTOMER_INFORMATION_CUSTOMER_SIGN_DATE")
                || controlName.equalsIgnoreCase("Q_DECISION_SECTION_UW_EDC")) {
            message = validate_EffectiveDate();
        } else if (controlName.equalsIgnoreCase("Q_L2BI_DETAILS_DOB") || controlName.equalsIgnoreCase("Q_PROPOSER_DETAILS_DATE_OF_BIRTH")
                || controlName.equalsIgnoreCase("Q_PROPOSER_DETAILS_DATE_OF_BIRTH_DUP") || controlName.equalsIgnoreCase("Q_L2BI_DETAILS_DOB_DUP")) {
            message = validate_IssueAge("");
            message = ""; //As no error message has to be shown just COverage term will be set
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_SUM_ASSURED")) {
            message = validate_SumAssured();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_SUM_ASSURED_UW")) {
            message = validate_SumAssured_UW();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_COVERAGE_TERM")) {
            message = validate_CoverageTerm();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_MODAL_PREMIUM")) {
            message = validate_ModalPremium();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_MODAL_PREMIUM_UW")) {
            message = validate_ModalPremium_UW();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_PPT")) {
            message = validate_PremiumPayment();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE")) {
            message = validate_CoverageMultiple();
        } else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_VESTING_AGE")) {
            message = validate_VestingAge();
        }
        else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_VESTING_AGE")) {
            message = validate_VestingAge();
        }
        /*else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_Premium_Break_1")) {
            message = validate_PremiumBreak1();
        }
        else if (controlName.equalsIgnoreCase("Q_COVERAGE_DETAILS_Premium_Break_2")) {
            message = validate_PremiumBreak2();
        }*/
        return message;
    }

    public String getAllErrorMessagesJSON() {
        JSONObject responseJSON = new JSONObject();
        //validating effective/customer date
        String productDating = getProductdating(ifr);
        if (productDating.equals("CD")) {
            this.fieldValue = (String) ifr.getControlValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE");
            responseJSON.put("effectiveDateMsg", validate_EffectiveDate());
        } else//ED
        {
            this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE");
            responseJSON.put("effectiveDateMsg", validate_EffectiveDate());
        }

        //for proposer/insured DOB
        //form 1 case
        if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
            this.fieldValue = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
            responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        } else {
            this.fieldValue = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
            responseJSON.put("dobMsg", validate_IssueAge("getAll"));
        }

        this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_SUM_ASSURED");
        responseJSON.put("sumAssuredMsg", validate_SumAssured());

        this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_PPT");
        responseJSON.put("premiumPaymentTermMsg", validate_PremiumPayment());

        this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE_COMBO");
        responseJSON.put("coverageMultipleMsg", validate_CoverageMultiple());

        try {
            this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.VESTING_AGE");
            responseJSON.put("vestingAgeMsg", validate_VestingAge());
        } catch (Exception ex) {
            responseJSON.put("vestingAgeMsg", "");
            System.out.println("Error in vesting age vlidation!");
        }

        this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
        responseJSON.put("coverageTermMsg", validate_CoverageTerm());
        
        /* this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.Premium_Break_1");
        responseJSON.put("PremiumBreakOption1", validate_PremiumBreak1()); //added by aaanchal
         this.fieldValue = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.Premium_Break_2");
        responseJSON.put("PremiumBreakOption2", validate_PremiumBreak2());*/

        return responseJSON.toJSONString();
    }

    public String getAllErrorMessagesJSON_UW() {
        JSONObject responseJSON = new JSONObject();

        JSONArray coverageDetailsArray = new JSONArray();
        coverageDetailsArray = ifr.getDataFromGrid("COVERAGE_DETAILS_REVISED");

        //getting fist row values only
        if (coverageDetailsArray.size() > 0) {
            JSONObject jsonObj = new JSONObject();
            jsonObj = (JSONObject) coverageDetailsArray.get(0);

            this.fieldValue = (String) jsonObj.getOrDefault("Revised Coverage Term", "");
            responseJSON.put("coverageTermMsg", validate_CoverageTerm());

            this.fieldValue = (String) jsonObj.getOrDefault("Revised Premium Payment Term", "");
            responseJSON.put("premiumPaymentTermMsg", validate_PremiumPayment());

            this.fieldValue = (String) jsonObj.getOrDefault("Approved Sum Assured", "");
            responseJSON.put("sumAssuredMsg", validate_SumAssured_UW());

            this.fieldValue = (String) jsonObj.getOrDefault("Cover Multiple", "");
            responseJSON.put("coverageMultipleMsg", validate_CoverageMultiple());

        }
        return responseJSON.toJSONString();
    }

    private String validate_VestingAge() {
        String smessage = businessLogcDao.validateVestingAge(fieldValue);
        if (!smessage.equals("")) {
            ifr.setValue("Q_COVERAGE_DETAILS.VESTING_AGE", "");
        } else {
            String age = "";
            if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
                age = ifr.getControlValue("PROPOSER_AGE").toString();
            } else {
                age = ifr.getControlValue("INSURED_AGE").toString();
            }

            if (!fieldValue.equals("") && !age.equals("")) {
                ifr.setValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM", String.valueOf(Integer.parseInt(fieldValue)
                        - Integer.parseInt(age)));
            }
        }

        return smessage;
    }
     private String validate_PremiumBreak1()    //added by Aanchal for PremiumBreak
    {
         String result = "",PremiumBreak="",PremiumBreak1="";
      
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");	
        String PremiumBreakOption1 = fieldValue;	
    	String query="SELECT Premium_Break,Premium_Break_Option_1 FROM NG_NB_MS_ULIP(NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  
           List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            PremiumBreak = (String) ((List) queryResult.get(0)).get(0);
            PremiumBreak1 = (String) ((List) queryResult.get(0)).get(1);
        }
        if(PremiumBreak.equals("Y"))
        {
            int numericCT,numerciPB1,numerciPB_1;
        numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
        numerciPB1=PremiumBreak1.isEmpty()?0:Integer.parseInt(PremiumBreak1);
        numerciPB_1=PremiumBreakOption1.isEmpty()?0:Integer.parseInt(PremiumBreakOption1);
           if(numerciPB_1<numerciPB1 || numerciPB_1>numericCT ) 
           {
               result="1st Premium Break Option must lie between "+PremiumBreak1+" and"+ coverageTerm;
               ifr.setValue("Q_COVERAGE_DETAILS_Premium_Break_1","");
           }
        }
        return result;
    }
      private String validate_PremiumBreak2() 
    {
         String result = "",PremiumBreak="",PremiumBreak2="";
      
        String plan_type = (String) ifr.getControlValue("PLAN_TYPE");
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");	
        String PremiumBreakOption2 = fieldValue;	
    	String query="SELECT Premium_Break,Premium_Break_Option_2 FROM NG_NB_MS_ulip (NOLOCK) "
                + " WHERE Plan_Code='" + planCode + "' AND Channel='" + Channel + "' "
                + " AND Sub_Channel='" + subChannel + "'; ";
		  
           List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            PremiumBreak = (String) ((List) queryResult.get(0)).get(0);
            PremiumBreak2 = (String) ((List) queryResult.get(0)).get(1);
        }
        if(PremiumBreak.equals("Y"))
        {
            int numericCT,numerciPB2,numerciPB_2;
        numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
        numerciPB2=PremiumBreak2.isEmpty()?0:Integer.parseInt(PremiumBreak2);
        numerciPB_2=PremiumBreakOption2.isEmpty()?0:Integer.parseInt(PremiumBreakOption2);
           if(numerciPB_2<numerciPB2 || numerciPB_2>numericCT ) 
           {
               result="2nd Premium Break Option must lie between "+PremiumBreak2+" and"+ coverageTerm;
               ifr.setValue("Q_COVERAGE_DETAILS_Premium_Break_2","");
           }
        }
        return result;
    }
    
    
    private String validate_CoverageMultiple() {
        String dob = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
         String PLACODEULIP = (String) ifr.getControlValue("PLAN_NAME_COMBO");
        if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
            dob = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH"); //changed by Prakhar on 5Nov2020
        }
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.COVERAGE_TERM");
        String smessage = businessLogcDao.validateCoverageMultiple(fieldValue, coverageTerm, dob,PLACODEULIP);
        if (!smessage.equals("")) {
            if (!ifr.getActivityName().equals("Manual_UW")) {
                ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE", "");
                ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE_COMBO", "");
            }
        }
        return smessage;
    }

    private String validate_SumAssured() {
        String smessage = businessLogcDao.validateSumAssured(fieldValue);
        if (!smessage.equals("")) {
            if (!ifr.getActivityName().equals("Manual_UW")) {
                ifr.setValue("Q_COVERAGE_DETAILS.SEC_SUM_ASSURED", "");
            }
        }
        return smessage;
    }

    private String validate_SumAssured_UW() {
        String smessage = businessLogcDao.validateSumAssured_UW(fieldValue);
        if (!smessage.equals("")) {
            if (!ifr.getActivityName().equals("Manual_UW")) {
                ifr.setValue("Q_COVERAGE_DETAILS.SEC_SUM_ASSURED", "");
            }
        }
        return smessage;
    }

    private String validate_CoverageTerm() {
        String insuredDOB = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
            insuredDOB = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        }
        String smessage = businessLogcDao.validateCoverageTerm(fieldValue, insuredDOB);
        if (!smessage.equals("")) {
            if (!ifr.getActivityName().equals("Manual_UW")) {
                ifr.setValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM", "");
            }
        }
        return smessage;
    }

    private String validate_ModalPremium() {
        String ModeofPayment = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");
        String smessage = businessLogcDao.validateModalPremium(fieldValue, ModeofPayment);
        if (!smessage.equals("")) {
            ifr.setValue("Q_COVERAGE_DETAILS.SEC_MODAL_PREMIUM", "");
        }
        return smessage;
    }

    private String validate_ModalPremium_UW() {
        String ModeofPayment = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.MODE_OF_PAY");
        String smessage = businessLogcDao.validateModalPremium_UW(fieldValue, ModeofPayment);
        if (!smessage.equals("")) {
            ifr.setValue("Q_COVERAGE_DETAILS.SEC_MODAL_PREMIUM", "");   //modified by aanchal for 1066285
        }
        return smessage;
    }

    private String validate_PremiumPayment() {
        String insuredDob = "";
        insuredDob = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH");
        if (!ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
            insuredDob = (String) ifr.getControlValue("Q_L2BI_DETAILS.DOB");
        }
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
        String smessage = businessLogcDao.validatePremiumPaymentTerm(fieldValue, insuredDob, coverageTerm);
        if (!smessage.equals("")) {
            if (!ifr.getActivityName().equals("Manual_UW")) {
                ifr.setValue("Q_COVERAGE_DETAILS.SEC_PPT", "");  //Mofified by Aanchal for 1084169
            }
        }
        return smessage;
    }

    private String validate_EffectiveDate() {
        String smessage = businessLogcDao.validateEffectiveDate(fieldValue);
        if (!smessage.equals("")) {
            if (controlName.equals("Q_COVERAGE_DETAILS_EFFECTIVE_DATE")) {
                ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
            } else if (controlName.equals("Q_DECISION_SECTION_UW_EDC")) {
                ifr.setValue("Q_DECISION_SECTION.UW_EDC", "");
            } else {
                ifr.setValue("Q_CUSTOMER_INFORMATION.CUSTOMER_SIGN_DATE", "");
            }
        }
        return smessage;
    }

    private String validate_IssueAge(String type) {
        String coverageTerm = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM");
        String smessage = businessLogcDao.validateIssueAge(fieldValue, coverageTerm, ifr);
        if (type.equals("")) {
            smessage = "";
        }
        if (!smessage.equals("") && !type.equals("getAll")) {
            if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equals("ProposerInsured")) {
                //ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH", "");
                //ifr.setValue("Q_PROPOSER_DETAILS.DATE_OF_BIRTH_DUP", "");
            } else {
                //ifr.setValue("Q_L2BI_DETAILS.DOB", "");
                //ifr.setValue("Q_L2BI_DETAILS.DOB_DUP", "");
            }

        }
        return smessage;
    }

    public void populateCombos() {
        if (controlName.equals("onLoad")) {
         //   populateComboField("Q_COVERAGE_DETAILS.BONUS_OPTION");
           // populateComboField("Q_COVERAGE_DETAILS.NON_FORFEITURE");
            //populateComboField("Q_RENEWAL_PREMIUM_DETAILS.RENEWAL_PREM_METHOD");
            //populateComboField("Q_COVERAGE_DETAILS.MODE_OF_PAY");
            //populateComboField("Q_COVERAGE_DETAILS.DEATH_BENEFIT");
            populateComboField("Q_POLICY_DETAILS.PRODUCT_SOLUTION");
            populateComboField("Q_PROPOSER_DETAILS.CLIENT_TYPE");
            //populateComboField("Q_COVERAGE_DETAILS.INCOME_FREQUENCY");  //1075872
            //populateComboField("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
            //populateComboField("Q_COVERAGE_DETAILS.SMART_WITHDRAWL_MODE");
            populateComboField("Q_COVERAGE_DETAILS.SEC_DISCOUNT");
            populateComboField("Q_COVERAGE_DETAILS.SEC_SMART_WITHDRAWAL_PAYOUT");
        } else {
          
          //  populateComboField("Q_COVERAGE_DETAILS.EMP_DISCOUNT");
            //populateComboField("Q_COVERAGE_DETAILS.SMART_WITHDRAWL_MODE");
             populateComboField("Q_COVERAGE_DETAILS.SEC_DISCOUNT");
            populateComboField("Q_COVERAGE_DETAILS.SEC_SMART_WITHDRAWAL_PAYOUT");
        }
    }

    private void populateComboField(String controlId) {

        //clearing combos in case of Plan Change Event and not onload
        String oldClientVal = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE");
        String oldRenVal = (String) ifr.getControlValue("Q_RENEWAL_PREMIUM_DETAILS.RENEWAL_PREM_METHOD");
        if (!controlName.equals("onLoad")) {
            ifr.clearCombo(controlId);   //1076674
        }

        Map<String, String> hm = new HashMap<>();
        //in form load it takes id in dot format while in run time it takes id as underscore format
        if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.BONUS_OPTION") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_BONUS_OPTION")) {
            hm = validateCommaSeparatedValues("", "", "Bonus_Option_Code", "NG_NB_MS_BONUS_OPT", "BONUS_VALUE", "BONUS_LABEL");
        } else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.NON_FORFEITURE") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_NON_FORFEITURE")) {
            hm = validateCommaSeparatedValues("", "NonForfeitureOption", "NFO_Option_Code", "NG_NB_MS_NON_FORFEITURE", "FORF_VALUE", "FORF_LABEL");
        } else if (controlId.equalsIgnoreCase("Q_RENEWAL_PREMIUM_DETAILS.RENEWAL_PREM_METHOD") || controlId.equalsIgnoreCase("Q_RENEWAL_PREMIUM_DETAILS_RENEWAL_PREM_METHOD")) {
            hm = validateCommaSeparatedValues("", "RenewalPremiumMethod", "Billing_Type_Code", "NG_NB_MS_BILL_TYPE_CODE_DESC", "BILL_TYPE_CODE", "BILL_TYPE_DESC");
        } else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.MODE_OF_PAY") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_MODE_OF_PAY")) {
            hm = validateCommaSeparatedValues("", "ModeofPayment", "Billing_Mode_Desc", "NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL");
        } else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.DEATH_BENEFIT") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_DEATH_BENEFIT")) {
            hm = validateCommaSeparatedValues("", "DeathBenefit", "Death_Benefit_Option_Name", "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_VALUE", "BENEFIT_LABEL");
        } else if (controlId.equalsIgnoreCase("Q_POLICY_DETAILS.PRODUCT_SOLUTION") || controlId.equalsIgnoreCase("Q_POLICY_DETAILS_PRODUCT_SOLUTION")) {
            hm = validateCommaSeparatedValues("", "ProductSolution", "Product_Solution", "NG_NB_MS_PRODUCT_SOLUTION", "SOLUTION_VALUE", "SOLUTION_LABEL");
        } else if (controlId.equalsIgnoreCase("Q_PROPOSER_DETAILS.CLIENT_TYPE") || controlId.equalsIgnoreCase("Q_PROPOSER_DETAILS_CLIENT_TYPE")) {
            hm = validateCommaSeparatedValues("", "ClientType", "Company_Entity", "NG_NB_MS_CLIENT_TYPE", "TYPE_VALUE", "TYPE_LABEL");
        } else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.INCOME_FREQUENCY") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_INCOME_FREQUENCY")) {
            hm = validateCommaSeparatedValues("", "income_frequency", "income_frequency", "NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL");
        } /*else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.EMP_DISCOUNT") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_EMP_DISCOUNT")) {
            hm = validateCommaSeparatedValues("", "discount", "discount", "NG_NB_MS_DISCOUNT_OPTION_CODE_DESC", "Discount_Option_Code", "Discount_Option_Desc");
        }*/
        else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.SEC_DISCOUNT") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_DISCOUNT")) {
            hm = validateCommaSeparatedValues("", "secondary_discount", "secondary_discount", "NG_NB_MS_DISCOUNT_OPTION_CODE_DESC", "Discount_Option_Code", "Discount_Option_Desc");
        }
        else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.SMART_WITHDRAWL_MODE") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE")) {
            hm = validateCommaSeparatedValues("", "smart_withdrawl_mode", "smart_withdrawl_mode", "NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL");
        }
         else if (controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS.SEC_SMART_WITHDRAWAL_PAYOUT") || controlId.equalsIgnoreCase("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_PAYOUT")) {
            hm = validateCommaSeparatedValues("", "Secondary_Smart_Withdrawl_Mode", "Secondary_Smart_Withdrawl_Mode", "NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL");
        }


        boolean isReset = true, isRenReset = true;
        String clientVal = "";
        if (!hm.isEmpty()) {
            Iterator it = hm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                System.out.println(pair.getKey() + " = " + pair.getValue());
                ifr.addItemInCombo(controlId, pair.getValue().toString(), pair.getKey().toString());
                clientVal = pair.getKey().toString().trim();
                if (controlId.equalsIgnoreCase("Q_PROPOSER_DETAILS_CLIENT_TYPE")) {
                    if (oldClientVal.equals(pair.getKey().toString().trim())) {
                        isReset = false;
                    }
                }
                //Renewal Prem Method
                if (controlId.equalsIgnoreCase("Q_RENEWAL_PREMIUM_DETAILS_RENEWAL_PREM_METHOD")) {
                    if (oldRenVal.equals(pair.getKey().toString().trim())) {
                        isRenReset = false;
                    }
                }
            }
            if (!isReset) {
                if (controlId.equals("Q_PROPOSER_DETAILS_CLIENT_TYPE")) {
                    ifr.setValue("Q_PROPOSER_DETAILS.CLIENT_TYPE", oldClientVal);
                }
            }
            if (!isRenReset) {
                if (controlId.equals("Q_RENEWAL_PREMIUM_DETAILS_RENEWAL_PREM_METHOD")) {
                    ifr.setValue("Q_RENEWAL_PREMIUM_DETAILS.RENEWAL_PREM_METHOD", oldRenVal);
                }
            }
            if (hm.size() == 1) {
                if (controlId.equals("Q_PROPOSER_DETAILS_CLIENT_TYPE")) {
                    ifr.setValue("Q_PROPOSER_DETAILS.CLIENT_TYPE", clientVal);
                }
            }
        } else {
            ifr.setStyle(controlId, "visible", "false");
        }

    }

    /*
	 * General Function for checking valid values which are present in MDM as comma separated values.
     */
    private Map<String, String> validateCommaSeparatedValues(String field, String jsonFieldName, String MDM_ColumnName, String masterTableName, String masterValue, String masterLabel) {
        Map<String, String> hm = new HashMap<>();
        Map<String, String> hm2 = new HashMap<>();
        //Setting values for MDM
        hm2.put("MDM_ColumnName", MDM_ColumnName);
        hm2.put("masterTableName", masterTableName);
        hm2.put("masterLabel", masterLabel);
        hm2.put("masterValue", masterValue);

        hm = businessLogcDao.validateCommaSeparatedValues(fieldValue, hm2); //will return HashMap of valid code and their values from Masters
        return hm;
    }

    private void addToResponse(JSONObject jsonObj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void hideFields() {
        boolean triggerBasedPortfolicApplicable;
        hideField("Q_COVERAGE_DETAILS_PREMIUM_BREAK", "PREMIUM_BREAK");  //aanchal //16MarchQ_DECISION_SECTION_UW_PREMIUM_BREAK
         hideField("Q_DECISION_SECTION_UW_PREMIUM_BREAK", "PREMIUM_BREAK");
         
            hideField("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_OPTION", "SMART_WITHDRAWL"); 
             hideField("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_OPTION", "Secondary_Smart_Withdrawl"); 
         
        hideField("Q_COVERAGE_DETAILS_VESTING_AGE", "Vesting_Age");
        hideField("Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW", "Save_More_Tomorrow");
        hideField("Q_COVERAGE_DETAILS_SMOKER_CLASS", "Smoker_Class");
        hideField("Q_COVERAGE_DETAILS_LIFE_EVENT", "Life_Event");
        //hideField("Q_COVERAGE_DETAILS.Guaranteed_Death_Benefit", "Guaranteed_Death_Benefit");
        hideField("Q_FUND_SELECTED_DFA", "DFA_Applicable");
        hideField("table48", "Fund_Applicable");
        hideField("Q_FUND_SELECTED_STP", "STP_Applicable");
        hideField("Q_FUND_SELECTED_LIFECYCLE_FOLIO_STRATEGY", "Lifecycle_Portfolio_Strategy");
        hideField("Q_FUND_SELECTED_TRIGGER_PORTFOLIO_STRATEGY", "Trigger_Based_Portfolio_Strategy");
        
        //showing cover multiple field as it is hidden by default
        showField("Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE_COMBO", "Is_Cover_Multiple_App");
//        hideFundFields();
        hideField("Q_COVERAGE_DETAILS_INCOME", "Income");
        hideField("Q_COVERAGE_DETAILS_GUARANTEE_DEATH_BENEFIT", "Guaranteed_Death_Benefit");
        hideField("Q_COVERAGE_DETAILS_MATURITY_AGE", "MATURITY_AGE");
         hideField("Q_COVERAGE_DETAILS_SEC_GDB", "Secondary_Guaranteed_Death_Benefit");
         
        //hideDiscount();

        //Added by Pranav as per Product Logic 1.2
        triggerBasedPortfolicApplicable = isFieldApplicable("", "Trigger_Based_Portfolio_Strategy");//returns true if Field is Applicable
        if (triggerBasedPortfolicApplicable) {
            hideField("Q_FUND_SELECTED_MOVEMENT_PERCENTAGE", "Movement_Percentage");
        }

    }

    public void hideUWFields() {
        hideField("Q_DECISION_SECTION_UW.SMOKER_CLASS_REVISED", "Smoker_Class");
        hideField("Q_DECISION_SECTION_UW.LIFE_STAGE_REV", "Life_Event");
        hideField("Q_DECISION_SECTION_UW.EDC", "uw_edc");
    }

    public String isEDCVisible() {
        boolean isVisible = businessLogcDao.isFieldApplicable("", "uw_edc");
        if (isVisible) {
            return "true";
        } else {
            return "false";
        }
    }

    public String getHiddenColumns() {
        String hiddenColumns = "", appliedTable = "", revisedTable = ""; //appliedTableIndex;revisedTableIndex
        //applied table indices to hide:
        //income
        if (!businessLogcDao.isFieldApplicable("", "Income")) {
            appliedTable = appliedTable + "4,";
        }
        if (!businessLogcDao.isFieldApplicable("", "Guaranteed_Death_Benefit")) {
            appliedTable = appliedTable + "11,";
        }
        //gst
        //appliedTable=appliedTable+"6,";
        //death benefit
        Map<String, String> hm = new HashMap<>();
        hm = validateCommaSeparatedValues("", "DeathBenefit", "Death_Benefit_Option_Name", "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_VALUE", "BENEFIT_LABEL");
        if (hm.isEmpty()) {
            appliedTable = appliedTable + "1";
        }

        //revised table indices to hide:
        //income
        if (!businessLogcDao.isFieldApplicable("", "Income")) {
            revisedTable = revisedTable + "3,";
        }
        if (!businessLogcDao.isFieldApplicable("", "Guaranteed_Death_Benefit")) {
            revisedTable = revisedTable + "15,";
        }
        //gst
        //revisedTable=revisedTable+"4,";
        //death benefit
        if (hm.isEmpty()) {
            revisedTable = revisedTable + "8,";
        }
//        else{
//            //ifr.clearTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 7);
//            Iterator it = hm.entrySet().iterator();
//                        while (it.hasNext()) {
//                            Map.Entry pair = (Map.Entry)it.next();
//                            //System.out.println(pair.getKey() + " = " + pair.getValue());
//                            ifr.addItemInTableCellCombo("COVERAGE_DETAILS_REVISED",0,7,pair.getValue().toString(),pair.getKey().toString());
//                        }
//        }

        hiddenColumns = appliedTable + ";" + revisedTable;
        return hiddenColumns;
    }

    private void hideDiscount() {
        if (!businessLogcDao.isDiscountApplicable("ED")) {
            //ifr.setStyle("Q_COVERAGE_DETAILS.EMP_DISCOUNT", "visible", "false");
            //ifr.setStyle("Q_DECISION_SECTION_UW_DISCOUNT_ANY", "visible", "true");  //AANCHAL16MARCH
        }
        if (!businessLogcDao.isDiscountApplicable("EC")) {
          //  ifr.setStyle("Q_COVERAGE_DETAILS.EXISTING_CUST_DISCOUNT", "visible", "false");
            //ifr.setStyle("Q_DECISION_SECTION_UW_DISCOUNT_ANY", "visible", "true");  //AANCHAL16MARCH
        }
    }

    private void showField(String fieldId, String mdmColName) {
        if (businessLogcDao.isFieldApplicable("", mdmColName)) {
            ifr.setStyle(fieldId, "visible", "true");
        }
    }

    private void hideField(String fieldId, String mdmColName) {
        if (!isFieldApplicable("", mdmColName)) {
            ifr.setStyle(fieldId, "visible", "false");

            if (fieldId.equals("Q_FUND_SELECTED_LIFECYCLE_FOLIO_STRATEGY")) {
                ifr.setStyle("Q_FUND_SELECTED.FUND1", "visible", "false");
                ifr.setStyle("Q_FUND_SELECTED.FUND2", "visible", "false");
                ifr.setStyle("Q_FUND_SELECTED_FUND1", "visible", "false");
                ifr.setStyle("Q_FUND_SELECTED_FUND2", "visible", "false");
            }
            if (fieldId.equals("Q_FUND_SELECTED_TRIGGER_PORTFOLIO_STRATEGY")) {
                ifr.setStyle("Q_FUND_SELECTED_TRIGGER_FUND1", "visible", "false");
                ifr.setStyle("Q_FUND_SELECTED_TRIGGER_FUND2", "visible", "false");
                ifr.setStyle("Q_FUND_SELECTED_MOVEMENT_PERCENTAGE", "visible", "false");
            }
            if(fieldId.equals("Q_COVERAGE_DETAILS_PREMIUM_BREAK"))
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_2", "visible", "false"); 
            }
             if(fieldId.equals("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_OPTION"))
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE", "visible", "false"); 
            }
             if(fieldId.equals("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_OPTION"))
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_STARTYEAR", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_PAYOUT", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHRAWAL_PERCENT", "visible", "false"); 
            }

        } else {
            ifr.setStyle(fieldId, "visible", "true");
            if(fieldId.equals("Q_COVERAGE_DETAILS_PREMIUM_BREAK"))
            {
               String WorkItemName = (String) ifr.getControlValue("WorkItemName");
                String query ="Select premium_break from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME='"+WorkItemName+"' ";
		List queryResult1 = getValFromQuery(query);
                String PB = (String) ((List) queryResult1.get(0)).get(0);
                if (PB.equals("Y")) 
                {
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_PREMIUM_BREAK", "mandatory", "true");  //DR-7399
                ifr.setStyle("Q_DECISION_SECTION_UW_PREMIUM_BREAK", "mandatory", "true");
                }
                else
                {
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_1", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_Premium_Break_2", "visible", "false"); 
                }   
                
                
            }
            if(fieldId.equals("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_OPTION"))
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_OPTION", "mandatory", "true");
                String WorkItemName = (String) ifr.getControlValue("WorkItemName");
                String query ="Select SECONDARY_SMART_WITHDRAWL_OPTION from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME='"+WorkItemName+"' ";
		List queryResult1 = getValFromQuery(query);
                String SW = (String) ((List) queryResult1.get(0)).get(0);
                 if (SW.equals("Y")) 
                 {
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_STARTYEAR", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_PAYOUT", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHRAWAL_PERCENT", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_STARTYEAR", "mandatory", "true");  //DR-7399
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_PAYOUT", "mandatory", "true");
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHRAWAL_PERCENT", "mandatory", "true");
                 }
                 else
                 {
                     ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_STARTYEAR", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHDRAWAL_PAYOUT", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_SMART_WITHRAWAL_PERCENT", "visible", "false");
                 }
            }
             if(fieldId.equals("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_OPTION"))
            {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_OPTION", "mandatory", "true");
                String WorkItemName = (String) ifr.getControlValue("WorkItemName");
                String query ="Select SMART_WITHDRAWL_OPTION from NG_NB_COVERAGE_DETAILS(NOLOCK) where WI_NAME='"+WorkItemName+"' ";
		List queryResult1 = getValFromQuery(query);
                String SW = (String) ((List) queryResult1.get(0)).get(0);
                 if (SW.equals("Y")) 
                 {
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE", "visible", "true"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR", "mandatory", "true");  //DR-7399
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE", "mandatory", "true");
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE", "mandatory", "true");
                 }
                 else
                 {
                     ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE", "visible", "false"); 
                ifr.setStyle("Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE", "visible", "false");
                 }
            }
            if (fieldId.equals("Q_COVERAGE_DETAILS_VESTING_AGE")) {
                ifr.setStyle("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM", "disable", "true");
                ifr.setStyle("Q_COVERAGE_DETAILS_SEC_COVERAGE_TERM", "disable", "true");
            }

            if (fieldId.equals("Q_FUND_SELECTED_STP")) {
                ifr.setStyle("table48", "visible", "true");
            }
            if (fieldId.equals("table48")) {
                ifr.setStyle("table48", "visible", "true");
            }
        }
    }

    public void populateProductNamesCombo() {
        String query = "";
        if (!ifr.getActivityName().equalsIgnoreCase("Source")) {
            query = "SELECT PLANS, PLAN_CODE FROM NG_NB_MS_PLAN_CODE(NOLOCK)";
            List queryResult = getValFromQuery(query);
            if (queryResult != null) {
                for (int i = 0; i < queryResult.size(); i++) {
                    String label = "", val = "";
                    label = (String) ((List) queryResult.get(i)).get(0);
                    val = (String) ((List) queryResult.get(i)).get(1);
                    if (!label.equalsIgnoreCase("") && !val.equalsIgnoreCase("")) {
                        ifr.addItemInCombo("PLAN_NAME",
                                label, val);
                    }
                }
            }
        }
    }

    private List getValFromQuery(String query) {
        String queryResult = "";
        List queryResultList = (List) ifr.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
    }

    public String getFundsCombos() {
        String result = "";    //key~~value,key2~~value2
        JSONArray dummy = new JSONArray();
        result = businessLogcDao.validateFunds(controlName, ifr.getControlValue("Q_FUND_SELECTED.STP").toString(), "",
                "", "", "", "",
                "", "");

        return result;
    }

    public void clearFields() {
        String[] fields = {"Q_COVERAGE_DETAILS_SUM_ASSURED", "Q_COVERAGE_DETAILS.COVERAGE_TERM",
            "Q_COVERAGE_DETAILS.MODAL_PREMIUM", "Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "Q_COVERAGE_DETAILS.COVERAGE_MULTIPLE",
            "Q_COVERAGE_DETAILS.REQ_MODAL_PREMIUM", "Q_COVERAGE_DETAILS.TOTAL_REQ_PREMIUM", "AFYP", "Q_COVERAGE_DETAILS.GST", "Q_COVERAGE_DETAILS.GUARANTEE_DEATH_BENEFIT", "label123",
            "Q_FUND_SELECTED.FUND1", "Q_FUND_SELECTED.FUND2", "Q_FUND_SELECTED.TRIGGER_FUND1", "Q_FUND_SELECTED.TRIGGER_FUND2", "Q_COVERAGE_DETAILS.VESTING_AGE","Q_COVERAGE_DETAILS.SMART_WITHDRAWL_OPTION",
            "Q_COVERAGE_DETAILS.SMART_WITHDRAWL_STARTYEAR","Q_COVERAGE_DETAILS.SMART_WITHDRAWL_MODE","Q_COVERAGE_DETAILS.SMART_WITHDRAWL_PERCENTAGE"};
        for (int i = 0; i < fields.length; i++) {
            ifr.setValue(fields[i], "");
        }
        
        ifr.clearTable("table48");
    }

    //Added by Pranav 11042020
    public void setFieldsOnPlanChange() {
        String[] fundsSelectedRadio = {"Q_FUND_SELECTED.DFA", "Q_FUND_SELECTED.STP", "Q_FUND_SELECTED.LIFECYCLE_FOLIO_STRATEGY",
            "Q_FUND_SELECTED.TRIGGER_PORTFOLIO_STRATEGY"};
        for (int i = 0; i < fundsSelectedRadio.length; i++) {
            ifr.setValue(fundsSelectedRadio[i], "N");
        }

        ifr.setStyle("Q_FUND_SELECTED_TRIGGER_FUND1", "visible", "false");
        ifr.setStyle("Q_FUND_SELECTED_TRIGGER_FUND2", "visible", "false");
        ifr.setStyle("Q_FUND_SELECTED_MOVEMENT_PERCENTAGE", "visible", "false");
        ifr.setStyle("Q_FUND_SELECTED_FUND1", "visible", "false");
        ifr.setStyle("Q_FUND_SELECTED_FUND2", "visible", "false");
    }
    //End by Pranav

    public boolean isPlanValid() {
        return isFundValid();
    }

    private void addMandatoryBenefitRidersToGrid() {
        String riders = businessLogcDao.validateBenefitRiders(null);
        String insuredName = (String) ifr.getControlValue("Q_L2BI_DETAILS.FIRST_NAME");
        if (ifr.getControlValue("Q_PROPOSER_DETAILS.CLIENT_TYPE").toString().equalsIgnoreCase("ProposerInsured")) {
            insuredName = (String) ifr.getControlValue("Q_PROPOSER_DETAILS.FIRST_NAME");
        }
        String ppt = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM");
        String sumAssured = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.SUM_ASSURED");
        String atp = (String) ifr.getControlValue("Q_COVERAGE_DETAILS.ATP_COMBO");
        ifr.clearTable("table37");
        JSONArray jsonArray = new JSONArray();
        if (riders != "" && riders != null) {
            String[] benefitRidersArr = riders.split(",");
            int i = 0;
            for (String benefitRider : benefitRidersArr) {
                JSONObject rowObj = new JSONObject();
                rowObj.put("Rider Type", benefitRider);
                rowObj.put("Rider Insured Details", insuredName);

//                rowObj.put("Coverage term", ppt);
                if (i == 0) {
                    rowObj.put("Sum Assured", atp);
                    rowObj.put("RiderBenefit", "B1");
                } else {
                    rowObj.put("Sum Assured", sumAssured);
                    rowObj.put("RiderBenefit", "B2");
                }

                jsonArray.add(rowObj);
                i++;
            }
            ifr.addDataToGrid("table37", jsonArray);
        }

    }

    public void populateComboCoverageRevised() {
        Map<String, String> hm = new HashMap<>();
        hm = validateCommaSeparatedValues("", "DeathBenefit", "Death_Benefit_Option_Name", "NG_NB_MS_DEATH_BENEFIT", "BENEFIT_VALUE", "BENEFIT_LABEL");
        if (!hm.isEmpty()) {
            //ifr.clearTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 7);
            Iterator it = hm.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry) it.next();
                //System.out.println(pair.getKey() + " = " + pair.getValue());
                ifr.addItemInTableCellCombo("COVERAGE_DETAILS_REVISED", 0, 8, pair.getValue().toString(), pair.getKey().toString());
            }
        }
    }

    //Added by Pranav
    boolean isFundValid() {
        String count = "";
        String query = "SELECT COUNT(*) AS TOTAL_COUNT " + whereClause;
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            count = (String) ((List) queryResult.get(0)).get(0);
        }
        if (count.equals("")) {
            count = "0";
        }
        if (Integer.parseInt(count) > 0) {
            return true;
        } else {
            return false;
        }

    }

    public boolean isFieldApplicable(String fieldValue, String mdmColName) {
        String result = "";
        String query = "SELECT " + mdmColName + whereClause;
        List queryResult = getValFromQuery(query);
        if (queryResult != null) {
            result = (String) ((List) queryResult.get(0)).get(0);
        }
        //Added by Pranav(Product Logic 1.2)
        if (mdmColName.equalsIgnoreCase("Movement_Percentage") && !result.equals("")) {
            return true;
        }//End    
        else if (!result.equals("")) {
            if (result.equalsIgnoreCase("Y") && fieldValue.equals("")) //field is blank but in mdm its Y then error will be thrown
            {
                return true;
            }
        }
        return false;
    }

}
