package com.newgen.iforms.user.combovalidations;

import com.newgen.iforms.custom.IFormReference;
import static com.newgen.iforms.user.DolphinUtil.CalculateYears;
import com.newgen.iforms.user.combovalidations.QueryExecutor;
import java.awt.List;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class BusinessLogicDao {
	public static String whereClause;
        public static String whereClauseWithoutTable;
	public static String source; // JSON OR IFORM
	static QueryExecutor queryExecutor = new QueryExecutor();
        String planCode,secondaryPlanCode ,productsolution;
        public static IFormReference ifr;

	// Constructors
	private BusinessLogicDao() {
	}

	public BusinessLogicDao(String planCode, String channel, String sub_Channel, String source, String sessionId, String cabinetName, IFormReference ifr) {
		super();
		queryExecutor.setSessionID(sessionId);
		queryExecutor.setCabinetName(cabinetName);
                queryExecutor.setFormRef(ifr);
                this.planCode  = planCode;
                this.ifr = ifr;
		//Date date = new Date();
		//String effectiveDate = new SimpleDateFormat("MM/dd/yyyy").format(date);
                sub_Channel = (String) ifr.getControlValue("Q_DEFENCE_DETAILS.DEFENCE_CHANNEL_CASE");
                if(sub_Channel.equalsIgnoreCase("Y") && channel.equals("A"))
                    sub_Channel = "Defence";
                else
                    sub_Channel = queryExecutor.getChannelDescFromVal(channel, source);
                
                
                secondaryPlanCode=(String) ifr.getControlValue("PLAN_NAME_COMBO");
               productsolution=(String) ifr.getControlValue("PRODUCT_SOLUTION");
                
                
		this.whereClause = " FROM NG_NB_MS_COMBO(NOLOCK) WHERE Plan_Code='" + planCode + "' AND Channel='" + channel
                + "' AND  combo_plan_code='"+secondaryPlanCode+"' and product_Solution='"+productsolution+"' and  Sub_Channel='" + sub_Channel + "' AND Is_Active_Ind='Y'";

		this.whereClauseWithoutTable =  " WHERE Plan_Code='" + secondaryPlanCode + "' AND Channel='" + channel
				+ "' AND Sub_Channel='" + sub_Channel + "' ";
                this.source = source;
	}

	// methods      
	public String validateEffectiveDate(String effectiveDate) {
		new EffectiveDate(effectiveDate);
		EffectiveDate.validateField();
		return EffectiveDate.getResult();
	}
	
	public String validateSumAssured(String value) {
		new SumAssured(value);
		SumAssured.validateField();
		return SumAssured.getResult();
	}
        
        public String validateSumAssured_UW(String value) {
		new SumAssured_UW(value);
		SumAssured_UW.validateField();
		return SumAssured_UW.getResult();
	}

	public String validateCoverageTerm(String coverageTerm, String insuredDOB) {
		// initializing values
		new CoverageTerm(coverageTerm, insuredDOB);
		// validating
		CoverageTerm.validateField();
		// returning message
		return CoverageTerm.getResult();
	}

	public String validateModalPremium(String modalPremium, String modeOfPay) {
		new ModalPremium(modalPremium, modeOfPay);
		ModalPremium.validateField();
		return ModalPremium.getResult();
	}
        
        public String validateModalPremium_UW(String modalPremium, String modeOfPay) {
		new ModalPremium_UW(modalPremium, modeOfPay);
		ModalPremium_UW.validateField();
		return ModalPremium_UW.getResult();
	}

	public Map<String, String> validateCommaSeparatedValues(String fieldValue, Map<String,String> hm) {
		CommaSeparatedValues.getValidKeyValues(hm.get("MDM_ColumnName"), hm.get("masterTableName"), hm.get("masterValue"), hm.get("masterLabel"));
		return CommaSeparatedValues.getResult();
	}
	
	public String validatePremiumPaymentTerm(String premiumPaymentTerm, String insuredDOB, String coverageTerm) {
		new PremiumPaymentTerm(premiumPaymentTerm, insuredDOB, coverageTerm, whereClauseWithoutTable);
		PremiumPaymentTerm.validateField();
		return PremiumPaymentTerm.getResult();
	}
	
	public String validateIssueAge(String insuredDob, String coverageTerm, IFormReference ifr) {
		new IssueAge(insuredDob, coverageTerm);
		IssueAge.validateField(ifr);
		return IssueAge.getResult();
	}
	
//	public boolean isDiscountApplicable(String discount, String discountType) {
//		new Discount(discount, discountType);
//		return Discount.isApplicable();
//	}
	
	public boolean isFieldApplicable(String fieldValue, String mdmColName) {
		new CheckFieldVisible(fieldValue, mdmColName);
		return CheckFieldVisible.isVisible();
	}
	
	public String validateCoverageMultiple(String coverageMultiple, String coverageTerm, String propDOB, String PLACODEULIP) {
		new CoverageMultiple(coverageMultiple,coverageTerm,propDOB,planCode,PLACODEULIP);
		CoverageMultiple.validateField();
		return CoverageMultiple.getResult();
	}
	
	public String validatePlanPayOptionCode(String premiumPaymentTerm, String coverageTerm) {
		new PlanPayOptionCode(premiumPaymentTerm, coverageTerm);
		PlanPayOptionCode.validateField();
		return PlanPayOptionCode.getMessage();
	}
	
	public String validateBenefitRiders(JSONArray riderDetailsArr) {
		new BenefitRiders(riderDetailsArr);
		BenefitRiders.validateRiders();
		return BenefitRiders.getMessage();
	}
	
	public String validateRiders(JSONArray riderDetailsArr) {
		new Riders(riderDetailsArr);
		Riders.validateRiders();
		return Riders.getMessage();
	}
        
        public String validateFunds(String controlName, String systematicTransferFund, String dynamicfundallocation,
			String lifeStylePortfolioStrategy, String lifescycleFund1, String lifecycleFund2,
			String triggerPortfolioStrategy, String trigger_Fund1, String trigger_Fund2) {
		
		new Funds(controlName, systematicTransferFund, dynamicfundallocation,
				lifeStylePortfolioStrategy, lifescycleFund1, lifecycleFund2, triggerPortfolioStrategy,
				trigger_Fund1, trigger_Fund2, secondaryPlanCode);
		Funds.validateFunds();
		return Funds.getMessage();
	}
        
        boolean isDiscountApplicable(String discountType) {
            new Discount(discountType);
            return Discount.isApplicable();
        }

	boolean isFundValid() {
        String query = "SELECT COUNT(*) AS TOTAL_COUNT " + whereClause;
        return queryExecutor.isFundValid(source, query);
        }

        String validateULIPFund(String fundName, String isSTPSelected, String planCode) {
            new ULIPFund(fundName,isSTPSelected,planCode);
            ULIPFund.validateFund();
            return ULIPFund.getMessage();
        }

    String validateVestingAge(String fieldValue) {
        new VestingAge(fieldValue);
        VestingAge.validateVestingAge();
        return VestingAge.getMessage();
    }

    
}

class VestingAge{
    static String vestingAge;
    static String message;
    
    public VestingAge(String fieldValue){
        this.vestingAge=fieldValue;
    }
    
    public static void validateVestingAge(){
        message="";
        if(isVestingAgeApplicable()){
            if(Integer.parseInt(vestingAge)<50 || Integer.parseInt(vestingAge)>75){
                message="Vesting Age must lie between 50 and 75. Please correct!";
            }
        }
    }
    
    public static String getMessage(){
        return message;
    }
    
    private static boolean isVestingAgeApplicable() {
        String query = "SELECT Vesting_Age " +BusinessLogicDao.whereClause;
        String Vesting_Age = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Vesting_Age");
        if(Vesting_Age.equalsIgnoreCase("Y"))
            return true;
        else
            return false;
    }
}

class ULIPFund{
    static String fund;
    static String message;
    static String isSTPSelected;
    static String planCode;
    
    public ULIPFund(String fund, String isSTPSelected,String planCode){
        this.fund = fund;
        this.isSTPSelected = isSTPSelected;
        this.planCode=planCode;
    }
    
    public static void validateFund(){
        message="";
        String query = "";
        if(isSTPSelected.equals("Y")){
            query = "SELECT FUND_CODE FROM NG_NB_MS_PLAN_FUND_ASSOC(NOLOCK) WHERE STP_Fund='Y' AND Plan_Code='"+planCode+"'";
            ArrayList<String> validfunds = new ArrayList<String>();
            validfunds = BusinessLogicDao.queryExecutor.runULIPFundsQuery(BusinessLogicDao.source,query);
            if(validfunds.contains(fund))
                message="true";
            else
                message="false";
        }
        else{
            query = "SELECT FUND_CODE FROM NG_NB_MS_PLAN_FUND_ASSOC(NOLOCK) WHERE Fund_Applicable='Y' AND Plan_Code='"+planCode+"'";
            ArrayList<String> validfunds = new ArrayList<String>();
            validfunds = BusinessLogicDao.queryExecutor.runULIPFundsQuery(BusinessLogicDao.source,query);
            if(validfunds.contains(fund))
                message="true";
            else
                message="false";
        }
        
    }
    
    public static String getMessage(){
        return message;
    }
    
}

class Discount{
    static String discountTpe;
    static boolean isApplicable;
    
    public Discount(String discountTpe){
        this.discountTpe = discountTpe;     //ED or EC
    }
    
    public static boolean isApplicable(){
        isApplicable = false;
        String query = "SELECT Discount" +BusinessLogicDao.whereClause;
        String discount = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Discount"); //comma separated ED or EC
        String[] DiscountArr = discount.split(",");
        for (int i = 0; i < DiscountArr.length; i++) {
             if (DiscountArr[i].equalsIgnoreCase(discountTpe)) {
                    isApplicable = true;
                }
         }
        return isApplicable;
    }
    
}

class Funds{

	static String message;
	static String controlName; 
	static String systematicTransferFund; 
	static String dynamicfundallocation;
	String lifeStylePortfolioStrateg; 
	static String lifecycleFund1; 
	static String lifecycleFund2;
	String triggerPortfolioStrategy; 
	static String trigger_Fund1;
	static String trigger_Fund2;
	static String secondaryPlanCode;
	

	public Funds(String controlName, String systematicTransferFund, String dynamicfundallocation,
			String lifeStylePortfolioStrateg, String lifecycleFund1, String lifecycleFund2,
			String triggerPortfolioStrategy, String trigger_Fund1, String trigger_Fund2, String secondaryPlanCode) {
		super();
		this.controlName = controlName;
		this.systematicTransferFund = systematicTransferFund;
		this.dynamicfundallocation = dynamicfundallocation;
		this.lifeStylePortfolioStrateg = lifeStylePortfolioStrateg;
		this.lifecycleFund1 = lifecycleFund1;
		this.lifecycleFund2 = lifecycleFund2;
		this.triggerPortfolioStrategy = triggerPortfolioStrategy;
		this.trigger_Fund1 = trigger_Fund1;
		this.trigger_Fund2 = trigger_Fund2;
		this.secondaryPlanCode = secondaryPlanCode;
	}

	public static void validateFunds() {
		message="";
		String query="";
               
		query = "SELECT Fund_Applicable" +BusinessLogicDao.whereClause;
		String Fund_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Fund_Applicable");
		query = "SELECT STP_Applicable" +BusinessLogicDao.whereClause;
		String STP_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "STP_Applicable");
		query = "SELECT DFA_Applicable" +BusinessLogicDao.whereClause;
		String DFA_Applicable = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "DFA_Applicable");
		query = "SELECT Lifecycle_Portfolio_Strategy" +BusinessLogicDao.whereClause;
		String Lifecycle_Portfolio_Strategy = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Lifecycle_Portfolio_Strategy");
		query = "SELECT Trigger_Based_Portfolio_Strategy" +BusinessLogicDao.whereClause;
		String Trigger_Based_Portfolio_Strategy = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Trigger_Based_Portfolio_Strategy");
		
//		if(controlName.equalsIgnoreCase("table48") && Fund_Applicable.equalsIgnoreCase("Y")) {
//			String fundApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
//					+ "WHERE FA.Plan_Code='"+planCode+"' AND FA.Fund_Applicable='Y' AND FA.Fund_Code=FN.FUND_VALUE";
//			Map<String, String> hm = new HashMap<String,String>();
//			hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source,fundApplicableQuery);
//			//hm-> UEBL1:Balanced Fund-Pr Driven
//			boolean isInvalid = false;
//			if(!hm.isEmpty()) {
////				for(Object fund:fundsGridArr) {
////					JSONObject jsonObj = (JSONObject)fund;
////					if(!hm.keySet().contains(jsonObj.get("FundName"))) {
////						isInvalid=true;
////					}
////				}
////				if(isInvalid) {
////					message = "Please select the valid funds: " +hm.keySet();
////				}for
//                                for (Map.Entry<String, String> entry : hm.entrySet()) {
//                                    message = message+ entry.getValue() + "~~" + entry.getKey() + ",";
//                                }
//                                if(message.endsWith(","))
//                                    message = message.substring(0, message.length()-1);
//			}
//		}
//		else
		if(controlName.equalsIgnoreCase("t3s4") && STP_Applicable.equalsIgnoreCase("Y") 
                        && systematicTransferFund.equalsIgnoreCase("Y")) {
			String STP_ApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
					+ "WHERE FA.Plan_Code='"+secondaryPlanCode+"' AND FA.STP_Fund='Y' AND FA.Fund_Code=FN.FUND_VALUE";
			Map<String, String> hm = new HashMap<String,String>();
			hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source,STP_ApplicableQuery);
			//hm-> UEBL1:Balanced Fund-Pr Driven
			boolean isInvalid = false;
			if(!hm.isEmpty()) {
//				for(Object fund:fundsGridArr) {
//					JSONObject jsonObj = (JSONObject)fund;
//					if(!hm.keySet().contains(jsonObj.get("FundName"))) {
//						isInvalid=true;
//					}
//				}
//				if(isInvalid) {
//					message = "Please select the valid funds: " +hm.keySet();
//				}
                                for (Map.Entry<String, String> entry : hm.entrySet()) {
                                    message = message+ entry.getValue() + "~~" + entry.getKey() + ",";
                                }
                                if(message.endsWith(","))
                                    message = message.substring(0, message.length()-1);
			}
		}
                if(controlName.equalsIgnoreCase("Q_FUND_SELECTED_STP_0") && STP_Applicable.equalsIgnoreCase("Y") 
                       ) {
			String STP_ApplicableQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
					+ "WHERE FA.Plan_Code='"+secondaryPlanCode+"' AND FA.STP_Fund='Y' AND FA.Fund_Code=FN.FUND_VALUE";
			Map<String, String> hm = new HashMap<String,String>();
			hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source,STP_ApplicableQuery);
			//hm-> UEBL1:Balanced Fund-Pr Driven
			boolean isInvalid = false;
			if(!hm.isEmpty()) {
//				for(Object fund:fundsGridArr) {
//					JSONObject jsonObj = (JSONObject)fund;
//					if(!hm.keySet().contains(jsonObj.get("FundName"))) {
//						isInvalid=true;
//					}
//				}
//				if(isInvalid) {
//					message = "Please select the valid funds: " +hm.keySet();
//				}
                                for (Map.Entry<String, String> entry : hm.entrySet()) {
                                    message = message+ entry.getValue() + "~~" + entry.getKey() + ",";
                                }
                                if(message.endsWith(","))
                                    message = message.substring(0, message.length()-1);
			}
		}
//		else
//		if(DFA_Applicable.equalsIgnoreCase("Y")) {
//			if(dynamicfundallocation.equalsIgnoreCase("N")) {
//				message = "Please correct the Dynamicfundallocation value.";
//			}
//		}
//		else
//		if(controlName.equalsIgnoreCase("LifecycleFund") && Lifecycle_Portfolio_Strategy.equalsIgnoreCase("Y")) {
//			String lifeCycleQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
//					+ "WHERE FA.Plan_Code='"+planCode+"' AND FA.Lifecycle_Fund_Details='Y' AND FA.Fund_Code=FN.FUND_VALUE";
//			Map<String, String> hm = new HashMap<String,String>();
//			hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source,lifeCycleQuery);
//			boolean isInvalid = false;
//			if(!hm.isEmpty()) {
////				if(!hm.keySet().contains(lifecycleFund1))
////					isInvalid=true;WHERE
////				if(!hm.keySet().contains(lifecycleFund2))
////					isInvalid=true;
////				if(isInvalid) {
////					message = "Please select the valid funds: " +hm.keySet();
////				}
//                                for (Map.Entry<String, String> entry : hm.entrySet()) {
//                                    message = message+ entry.getValue() + "~~" + entry.getKey() + ",";
//                                }
//                                if(message.endsWith(","))
//                                    message = message.substring(0, message.length()-1);
//			}
//		}
//		else
//		if(controlName.equalsIgnoreCase("TriggerFund") && Trigger_Based_Portfolio_Strategy.equalsIgnoreCase("Y")) {
//			String triggerFundeQuery = "SELECT FA.Fund_Code, FN.FUND_LABEL FROM NG_NB_MS_PLAN_FUND_ASSOC FA, NG_NB_MS_FUND_NAME FN "
//					+ "WHERE FA.Plan_Code='"+planCode+"' AND FA.Trigger_Based_Fund_Details='Y' AND FA.Fund_Code=FN.FUND_VALUE";
//			Map<String, String> hm = new HashMap<String,String>();
//			hm = BusinessLogicDao.queryExecutor.runFundsQuery(BusinessLogicDao.source,triggerFundeQuery);
//			boolean isInvalid = false;
//			if(!hm.isEmpty()) {
////				if(!hm.keySet().contains(trigger_Fund1))TriggerFund
////					isInvalid=true;
////				if(!hm.keySet().contains(trigger_Fund2))
////					isInvalid=true;
////				if(isInvalid) {
////					message = "Please select the valid funds: " +hm.keySet();
////				}
//                                for (Map.Entry<String, String> entry : hm.entrySet()) {
//                                    message = message+ entry.getValue() + "~~" + entry.getKey() + ",";
//                                }
//                                if(message.endsWith(","))
//                                    message = message.substring(0, message.length()-1);
//			}
//		}
		
	}
        
        public static String getMessage() {
		return message;
	}
}

class Riders{
	static JSONArray riderDetailsArr;
	static String message;
	
	public Riders(JSONArray riderDetailsArr) {
		this.riderDetailsArr = riderDetailsArr;
	}
	
	static void validateRiders() {
		message="";
		ArrayList<String> invalidRiders = new ArrayList<String>();
		for(int i=1; i<=20; i++) {
			String riderQuery = "SELECT Riders"+i+""+ BusinessLogicDao.whereClause +" AND Is_Active_Rider"+i+"='Y' ";
			String rider = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,riderQuery, "Riders"+i);
			int k=0;
			for(Object obj:riderDetailsArr) {
				JSONObject jsonObj = (JSONObject)obj;
				
				if(k!=0 && k!=1) {  			//skipping first and second riders.
					if(!jsonObj.get("RiderType").equals("")) {
						if(!rider.equals(""))	
							if(!rider.equals(jsonObj.get("RiderType").toString()))
								invalidRiders.add((String) jsonObj.get("RiderType"));
					}
				}
				k++;
			}
		}
		if(!invalidRiders.isEmpty())
			message = "Invalid/Inactive Riders present: " +invalidRiders;
	}
	
	static String getMessage() {
		return message;
	}
	
}

class BenefitRiders{
	static JSONArray riderDetailsArr;
	static String message;
	
	public BenefitRiders(JSONArray riderDetailsArr) {
		this.riderDetailsArr = riderDetailsArr;
	}
	
	static void validateRiders() {
		message="";
		Map<String, String> hm = new HashMap<String, String>();
		String benefit1Query = "SELECT Benefit1"+ BusinessLogicDao.whereClause + " AND Is_Active_Benefit1='Y' AND Is_Benefit1_Mandatory='Y'";
		String Benefit1 = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,benefit1Query, "Benefit1");
		String benefit2Query = "SELECT Benefit2"+ BusinessLogicDao.whereClause + " AND Is_Active_Benefit2='Y' AND Is_Benefit2_Mandatory='Y'";
		String Benefit2 = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,benefit2Query, "Benefit2");
		Boolean isValidBenefit1 = false;
		Boolean isValidBenefit2 = false;
//		for(Object obj:riderDetailsArr) {
//			JSONObject jsonObj = (JSONObject)obj;
//			
//			if(!Benefit1.equals(""))
//				if(jsonObj.get("RiderType").equals(Benefit1))
//					isValidBenefit1=true;
//			
//			if(!Benefit2.equals(""))
//				if(jsonObj.get("RiderType").equals(Benefit2))
//					isValidBenefit2=true;
//		}
//		if(!isValidBenefit1 && !Benefit1.equals(""))
//			message = "Benefit Rider not present: " +Benefit1 ;
//		
//			if(!isValidBenefit2 && !Benefit2.equals(""))
//				message = "Benefit Rider not present: " +Benefit2 ;
//			
//				if(!isValidBenefit1 && !isValidBenefit2 && !Benefit1.equalsIgnoreCase("") && !Benefit2.equalsIgnoreCase(""))
//					message = "Valid Benefit Riders not present: "+ Benefit1 + "," + Benefit2;
                message = Benefit1+","+Benefit2;
		
	}
	
	static String getMessage() {
		return message;
	}
}

class PlanPayOptionCode{
	static String premiumPaymentTerm;
	static String coverageTerm;
	static String message;
	
	public PlanPayOptionCode(String premiumPaymentTerm, String coverageTerm) {
		this.premiumPaymentTerm = premiumPaymentTerm;
		this.coverageTerm = coverageTerm;
	}
	
	public static void validateField() {
		message = "";
		
		String query = "SELECT Plan_Pay_Option_Code_Desc" + BusinessLogicDao.whereClause;
		String Plan_Pay_Option_Code_Desc = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Plan_Pay_Option_Code_Desc");
		
		if(Plan_Pay_Option_Code_Desc.equalsIgnoreCase("RGLR")) {
			if(Float.parseFloat(premiumPaymentTerm)!=Float.parseFloat(coverageTerm))
				message = "Premium Payment Term and Coverage Term should be same as the Plan Pay Option Code is RGLR.";
		}
		else
			if(Plan_Pay_Option_Code_Desc.equalsIgnoreCase("LTD") || Plan_Pay_Option_Code_Desc.equalsIgnoreCase("SNGL") 
                                || Plan_Pay_Option_Code_Desc.equalsIgnoreCase("PAY60")) {
				if(Float.parseFloat(premiumPaymentTerm)==Float.parseFloat(coverageTerm))
					message = "Premium Payment Term and Coverage Term can not be same as the Plan Pay Option Code is LTD/SNGL/PAY60.";
			}
		
	}
	
	public static String getMessage() {
		return message;
	}
}

class CoverageMultiple{
	static String fieldValue;
	static String coverageTerm;
	static String propDOB;
	static String message;
        static String planCode,PLACODEULIP;
	
	public CoverageMultiple (String fieldValue, String coverageTerm, String propDOB, String planCode, String PLACODEULIP){
		this.fieldValue = fieldValue;
		this.coverageTerm = coverageTerm;
		this.propDOB = propDOB;
                this.planCode = planCode;
                this.PLACODEULIP=PLACODEULIP;
	}	
	
	public static void validateField() {
		message="";		
		String query = "SELECT Is_Cover_Multiple_App" + BusinessLogicDao.whereClause;
		String isCoverMultipleAppQuery = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Is_Cover_Multiple_App");
		query="SELECT Dur_Typ_Cd" + BusinessLogicDao.whereClause;
		String Dur_Typ_Cd = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source,query, "Dur_Typ_Cd");
		ArrayList<String> Cover_Multiple = new ArrayList<String>();
		query = "SELECT Cover_Multiple"+ BusinessLogicDao.whereClause;
		Cover_Multiple = BusinessLogicDao.queryExecutor.runCoverMultipleQuery(query,BusinessLogicDao.source); //return list of Cover_Multiple from MDM
		String propAge = CalculateYears(propDOB,BusinessLogicDao.ifr);
		
		if(isCoverMultipleAppQuery.equals("Y")) {
			if(Dur_Typ_Cd.equals("N")) {
				if(!Cover_Multiple.contains(fieldValue))
					message = "Please enter the correct Cover Multiple value. Valid value are: " + Cover_Multiple;
			}
			else {	//if Dur_Typ_Cd is Y -> then e have to check the table -> NG_NB_MS_MIN_MAX_COVER_MULTIPLE
				Map<String, String> hm = new HashMap<>();
				Boolean matched = false;
				query = "SELECT MINIMUM_COV_MUL, MAXIMUM_COV_MUL FROM NG_NB_MS_MIN_MAX_COVER_MULTIPLE(NOLOCK) WHERE "
						+ "MIN_TERM<="+coverageTerm+" AND MAX_TERM>="+coverageTerm+" "
						+ "AND AGE_DURATION="+propAge+ " AND PLAN_CODE='"+PLACODEULIP+"'";
				hm = BusinessLogicDao.queryExecutor.runMinMaxCovMulQuery(query ,BusinessLogicDao.source);
				String Minimum_Cov_Mul = hm.get("MINIMUM_COV_MUL");	//float
				String Maximum_Cov_Mul = hm.get("MAXIMUM_COV_MUL");	//float
				
				for(String cover_multiple:Cover_Multiple) {
					
					if(Float.parseFloat(cover_multiple)>=Float.parseFloat(Minimum_Cov_Mul) &&
							Float.parseFloat(cover_multiple)<=Float.parseFloat(Maximum_Cov_Mul)) {
							if(cover_multiple.equals(fieldValue))
								matched=true;
					}
				}
				if(!matched)
					message = "Please enter the correct Cover Multiple value.";				
			}
		}
		else
			message="";
	}
	
	public static String getResult() {
		return message;
	}
	
}

class CheckFieldVisible{
	static String fieldValue;
	static String mdmColName;
	
	public CheckFieldVisible(String fieldValue, String mdmColName) {
		this.fieldValue = fieldValue;
		this.mdmColName = mdmColName;
	}
	
	public static boolean isVisible() {
		
		String query = "SELECT "+mdmColName + BusinessLogicDao.whereClause;
		String result = BusinessLogicDao.queryExecutor.runIsVisibleQuery(query, BusinessLogicDao.source, mdmColName);	
		
		if(!result.equals(""))
			if(result.equalsIgnoreCase("Y") && fieldValue.equals(""))		//field is blank but in mdm its Y then error will be thrown
				return true;
		return false;
	}
}

class IssueAge{
	static String insuredDob;
	static String coverageTerm;
	static String message="";
	
	public IssueAge(String insuredDob, String coverageTerm) {
		this.insuredDob = insuredDob;
		this.coverageTerm = coverageTerm;
	}
	
	static void validateField(IFormReference ifr) {
		message="";
		String ageOfInsured = CalculateYears(insuredDob,BusinessLogicDao.ifr);
		Map<String,String> hm = new HashMap<>();
		String query = "SELECT Min_Issue_Age,Max_Issue_Age,Minimum_Expiry_Age,Maximum_Expiry_Age" + BusinessLogicDao.whereClause;
		hm = BusinessLogicDao.queryExecutor.runIssueAgeQuery(query, BusinessLogicDao.source); 
		
		if (hm != null) {
            String minimunIssueAge = hm.get("Min_Issue_Age");
            String maximumIssueAge = hm.get("Max_Issue_Age");

            if (Integer.parseInt(ageOfInsured) < Integer.parseInt(minimunIssueAge) || Integer.parseInt(ageOfInsured) > Integer.parseInt(maximumIssueAge)) {
            	message = "Age of Insured must lie between " + minimunIssueAge + " and " + maximumIssueAge + ". Please correct!";
//                ifr.setValue("Q_L2BI_DETAILS.DOB", "");
            }
            
            //Coverage term to auto populate when term calc code is B.
            String coverageQuery = "SELECT Plan_Age_Expiry, Secondary_Term_CalC_Code,Combo_Minimum_Term, Combo_Maximum_Term,Minimum_Expiry_Age,Maximum_Expiry_Age"
				+ BusinessLogicDao.whereClause;
            Map<String, String> hm2 = new HashMap<>();
	    hm2 = BusinessLogicDao.queryExecutor.runCoverageTermQuery(coverageQuery, BusinessLogicDao.source);
            if(!hm2.isEmpty()){
                if(hm2.get("Secondary_Term_CalC_Code").equalsIgnoreCase("B")){
                        String cTerm="";
                        if (!hm2.get("Plan_Age_Expiry").equalsIgnoreCase("") && !ageOfInsured.equalsIgnoreCase("")) {
                            cTerm =String.valueOf(Integer.parseInt(hm2.get("Plan_Age_Expiry")) - Integer.parseInt(ageOfInsured));
                            if(!ifr.getActivityName().equals("Manual_UW"))
                                ifr.setValue("Q_COVERAGE_DETAILS.SEC_COVERAGE_TERM", cTerm);
                        }
                }            
            }
            /*
            //Expiry Age check
            String Min_Expiry_Age = "", Max_Expiry_Age = "";
            Min_Expiry_Age = hm.get("Minimum_Expiry_Age");
            Max_Expiry_Age = hm.get("Maximum_Expiry_Age");
            if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("") && !Max_Expiry_Age.equalsIgnoreCase("")) {
                if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer.parseInt(Min_Expiry_Age)
                        || Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer.parseInt(Max_Expiry_Age)) {
                            if(!ifr.getActivityName().equals("Manual_UW"))
                            message = message+"|"+" Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age + ". Please correct!";
//                    ifr.setValue("Q_L2BI_DETAILS.DOB", "");
                }
            }
            */
        }
		
	}
	
	static String getResult() {
		return message;
	}
}
/**
 * Logic for Effective Date
 * 
 * @author prakhar.saxena
 *
 */
class EffectiveDate{
	static String effectiveDate;
	static String message = "";
	
	public EffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	
	static void validateField() {
		message="";
		String query = "SELECT Plan_Effective_Date,Channel_Effective_Date,Plan_Expiry_Date" + BusinessLogicDao.whereClause;
		EffectiveDateResult effectiveDateResult = BusinessLogicDao.queryExecutor.runEffectiveDateQuery(query, BusinessLogicDao.source); 
		
	        if (effectiveDateResult != null) {
	            String planEffectiveDate = effectiveDateResult.getPlanEffectiveDate();
	            String channelEffectiveDate = effectiveDateResult.getChannelEffectiveDate();
	            String planExpiryDate = effectiveDateResult.getPlanExpiryDate();

	            Date effectiveDateObj = null;
	            Date planEffectiveDateObj = null;
	            Date channelEffectiveDateObj = null;
	            Date planExpiryDateObj = null;
                    try{
                    effectiveDateObj = new SimpleDateFormat("dd/MM/yyyy").parse(effectiveDate);
                    }catch(Exception ex){
                        try {
                            effectiveDateObj = new SimpleDateFormat("yyyy-MM-dd").parse(effectiveDate);
                        } catch (ParseException ex1) {
                            Logger.getLogger(EffectiveDate.class.getName()).log(Level.SEVERE, null, ex1);
                        }
                    }
				try {
					//effectiveDateObj = new SimpleDateFormat("dd/MM/yyyy").parse(effectiveDate);
					planEffectiveDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(planEffectiveDate);
					channelEffectiveDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(channelEffectiveDate);
					planExpiryDateObj = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").parse(planExpiryDate);
					
					if (effectiveDateObj.before(planEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
                                            message = "Effective/Customer Date Should lie between Plan Effective Date: " + planEffectiveDate + " and Plan Expiry Date: " + planExpiryDate + " Please Correct!";
            //		                ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
                                        }
                                        if (effectiveDateObj.before(channelEffectiveDateObj) || effectiveDateObj.after(planExpiryDateObj)) {
                                            message = "Effective/Customer Date Should lie between Channel Effective Date: " + channelEffectiveDate + " and Plan Expiry Date: " + planExpiryDate + " Please Correct!";
            //		                ifr.setValue("Q_COVERAGE_DETAILS.EFFECTIVE_DATE", "");
                                        }
				} catch (ParseException e) {
					message="";
					e.printStackTrace();
				}

	            
	        }
	}
	
	static String getResult() {
		return message;
	}
}

/**
 * Logic for Sum Assured
 * 
 * @author prakhar.saxena
 *
 */
class SumAssured {
	static String fieldValue;
	static String minAmount;
	static String maxAmount;
	static String message = "";

	public SumAssured(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public static void validateField() {
		message="";
                double intervalDouble=0;
//		MinMaxValues query = queryExecutor.runMinMaxQuery(
//				"SELECT Minimum_Issue_Age, Max_Issue_Age"+BusinessLogicDao.whereClause, BusinessLogicDao.source, "Minimum_Issue_Age", "Max_Issue_Age");
		String query = "SELECT Secondary_Min_Issue_Amount, Secondary_Max_Issue_Amount" + BusinessLogicDao.whereClause;

		MinMaxValues minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
				"Secondary_Min_Issue_Amount", "Secondary_Max_Issue_Amount");
                
                query = "SELECT interval" + BusinessLogicDao.whereClause;
                String interval = BusinessLogicDao.queryExecutor.runDBQuery(BusinessLogicDao.source, query, "interval");
                if(!interval.equals("")){
                intervalDouble = Double.parseDouble(interval);
                }
                if(intervalDouble!=0 && interval!=null && !interval.equals("") && !fieldValue.equals("")){
                    if(!(Double.parseDouble(fieldValue)%intervalDouble==0)){
                        message = "Sum assured must be the multiple of "+intervalDouble+". Please correct!";
//                        if(!ifr.getActivityName().equals("Manual_UW"))
//                            ifr.setValue("Q_COVERAGE_DETAILS.SUM_ASSURED", "");
                        //return result;
                    }
                }
		// Logic
		if(!minMaxValues.minValue.equals("") && !minMaxValues.maxValue.equals("") && !fieldValue.equals(""))
		if (Double.parseDouble(fieldValue) < Double.parseDouble(minMaxValues.minValue)
				|| Double.parseDouble(fieldValue) > Double.parseDouble(minMaxValues.maxValue))
			message = "Please enter the Sum Assured between " + minMaxValues.minValue + " and " + minMaxValues.maxValue;
	}

	public static String getResult() {
		return message;
	}
}

class SumAssured_UW {
	static String fieldValue;
	static String minAmount;
	static String maxAmount;
	static String message = "";

	public SumAssured_UW(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public static void validateField() {
		message="";
//		MinMaxValues query = queryExecutor.runMinMaxQuery(
//				"SELECT Minimum_Issue_Age, Max_Issue_Age"+BusinessLogicDao.whereClause, BusinessLogicDao.source, "Minimum_Issue_Age", "Max_Issue_Age");
		String query = "SELECT ISNULL(Secondary_UW_Minimum_Issue_Amount,0.00) AS 'Secondary_UW_Minimum_Issue_Amount',ISNULL(Secondary_UW_Maximum_Issue_Amount,0.00) AS 'Secondary_UW_Maximum_Issue_Amount'" + BusinessLogicDao.whereClause;

		MinMaxValues minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
				"Secondary_UW_Minimum_Issue_Amount", "Secondary_UW_Maximum_Issue_Amount");
		// Logic
		if(!minMaxValues.minValue.equals("") && !minMaxValues.maxValue.equals("") && !fieldValue.equals(""))
		if (Double.parseDouble(fieldValue) < Double.parseDouble(minMaxValues.minValue)
				|| Double.parseDouble(fieldValue) > Double.parseDouble(minMaxValues.maxValue))
			message = "Please enter the Sum Assured between " + minMaxValues.minValue + " and " + minMaxValues.maxValue;
	}

	public static String getResult() {
		return message;
	}
}

/**
 * Logic for Coverage Term
 * 
 * @author prakhar.saxena
 *
 */
class CoverageTerm {
	static String coverageTerm;
	static String insuredDOB;

	static String Plan_Age_Expiry;
	static String Term_CalC_Code;
	static String Min_Term;
	static String Max_Term;
	static String Min_Expiry_Age;
	static String Max_Expiry_Age;

	static String message = "";

	public CoverageTerm(String coverageTerm, String insuredDOB) {
		this.coverageTerm = coverageTerm;
		this.insuredDOB = insuredDOB;
	}

	public static void validateField() {
		String ageOfInsured = "";
                String term_calc_desc = "";
		message="";
		String query = "SELECT ISNULL(Plan_Age_Expiry,0), Secondary_Term_CalC_Code, ISNULL(Combo_Minimum_Term,0), ISNULL(Combo_Maximum_Term,0),ISNULL(Minimum_Expiry_Age,0),"
                        + "ISNULL(Maximum_Expiry_Age,0)" + BusinessLogicDao.whereClause;
		Map<String, String> hm = new HashMap<>();
		hm = BusinessLogicDao.queryExecutor.runCoverageTermQuery(query, BusinessLogicDao.source);

		// Calculating insured age
		if (!insuredDOB.equalsIgnoreCase("")) {
			ageOfInsured = CalculateYears(insuredDOB,BusinessLogicDao.ifr);
		}

		// Logic
		if (hm.get("Secondary_Term_CalC_Code").equalsIgnoreCase("A")) {
			if (!coverageTerm.equalsIgnoreCase("") && !hm.get("Combo_Minimum_Term").equalsIgnoreCase("")
					&& !hm.get("Combo_Maximum_Term").equalsIgnoreCase("")) {
				if (Integer.parseInt(coverageTerm) < Integer.parseInt(hm.get("Combo_Minimum_Term"))
						|| Integer.parseInt(coverageTerm) > Integer.parseInt(hm.get("Combo_Maximum_Term"))) {
					message = "Coverage Term must lie between " + hm.get("Combo_Minimum_Term") + " and " + hm.get("Combo_Maximum_Term")
							+ ". Please correct!";
					// ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
				}
			}
                }else if(hm.get("Secondary_Term_CalC_Code").equalsIgnoreCase("B")){
                    if (!coverageTerm.equalsIgnoreCase("") && !hm.get("Plan_Age_Expiry").equalsIgnoreCase("")
					&& !ageOfInsured.equalsIgnoreCase("")) {
				if (Integer.parseInt(coverageTerm) != Integer.parseInt(hm.get("Plan_Age_Expiry"))
						- Integer.parseInt(ageOfInsured)) {
					message = "Coverage Term must be equal to "
							+ (Integer.parseInt(hm.get("Plan_Age_Expiry")) - Integer.parseInt(ageOfInsured));
//                    ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
				}
			}
                }
                else if(hm.get("Secondary_Term_CalC_Code").equalsIgnoreCase("C")){
                    boolean matched = false;
                    term_calc_desc = hm.get("Combo_Minimum_Term");
                    String[]  term_calc_descArr = term_calc_desc.split(",");
                    if(term_calc_descArr.length!=0){
                        for(String code:term_calc_descArr){
                            code = code.trim();
                            if(coverageTerm.equals(code))
                                matched = true;
                        }
                    }
                    if(!matched)
                    {
                        message = "Please enter the valid coverage term! : "+term_calc_desc;
                    }
                }

			// Logic 2
			String Min_Expiry_Age = "", Max_Expiry_Age = "";
			Min_Expiry_Age = hm.get("Minimum_Expiry_Age");
			Max_Expiry_Age = hm.get("Maximum_Expiry_Age");

			if (!coverageTerm.equalsIgnoreCase("") && !Min_Expiry_Age.equalsIgnoreCase("")
					&& !ageOfInsured.equalsIgnoreCase("") && !Max_Expiry_Age.equalsIgnoreCase("")) {
				if (Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) < Integer.parseInt(Min_Expiry_Age)
						|| Integer.parseInt(coverageTerm) + Integer.parseInt(ageOfInsured) > Integer
								.parseInt(Max_Expiry_Age)) {
					message = message + "|" + "Expiry Age must lie between " + Min_Expiry_Age + " and " + Max_Expiry_Age
							+ ". Please correct!";
//                    ifr.setValue("Q_COVERAGE_DETAILS.COVERAGE_TERM", "");
				}
			}

	}

	

	// result
	public static String getResult() {
		return message;
	}

}

/**
 * Logic for Modal Premium
 * 
 * @author prakhar.saxena
 *
 */
class ModalPremium {
	static String modalPremium;
	static String modeofPay;
	static String message = "";

	public ModalPremium(String modalPremium, String modeofPay) {
		this.modalPremium = modalPremium;
		this.modeofPay = modeofPay;
	}

	public static void validateField() {
		message="";
		DecimalFormat df = new DecimalFormat("#");
		MinMaxValues minMaxValues = new MinMaxValues();
		String query = "";
		if (modeofPay.equalsIgnoreCase("01")) { // monthly
			query = "SELECT Secondary_Minimum_Monthly_Premium, Secondary_Maximum_Monthly_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_Minimum_Monthly_Premium", "Secondary_Maximum_Monthly_Premium");
			;
			if (minMaxValues != null) {
				String Min_Monthly_Premium = minMaxValues.minValue;
				String Max_Monthly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Monthly_Premium.equalsIgnoreCase("")
						&& !Max_Monthly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Monthly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Monthly_Premium)) {
						message = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("03")) { // quarterly
			query = "SELECT Secondary_Minimum_Quarterly_Premium,Secondary_Maximum_Quarterly_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_Minimum_Quarterly_Premium", "Secondary_Maximum_Quarterly_Premium");
			if (minMaxValues != null) {
				String Min_Quarterly_Premium = minMaxValues.minValue;
				String Max_Quarterly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Quarterly_Premium.equalsIgnoreCase("")
						&& !Max_Quarterly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Quarterly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Quarterly_Premium)) {
						message = "Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Quarterly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("06")) { // semi annual
			query = "SELECT Secondary_Minimum_Semi_Annual_Premium,Secondary_Maximum_Semi_Annual_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Minimum_Semi_Annual_Premium", "Secondary_Maximum_Semi_Annual_Premium");
			if (minMaxValues != null) {
				String Min_Semi_Annual_Premium = minMaxValues.minValue;
				String Max_Semi_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Semi_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Semi_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Semi_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Semi_Annual_Premium)) {
						message = "Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Semi_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("12")) { // annual
			query = "SELECT Secondary_Minimum_Annual_Premium, Secondary_Maximum_Annual_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_Minimum_Annual_Premium", "Secondary_Maximum_Annual_Premium");
			if (minMaxValues != null) {
				String Min_Annual_Premium = minMaxValues.minValue;
				String Max_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Annual_Premium)) {
						message = "Modal Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		}
	}

	// result
	public static String getResult() {
		return message;
	}
}

class ModalPremium_UW {
	static String modalPremium;
	static String modeofPay;
	static String message = "";

	public ModalPremium_UW(String modalPremium, String modeofPay) {
		this.modalPremium = modalPremium;
		this.modeofPay = modeofPay;
	}

	public static void validateField() {
		message="";
		DecimalFormat df = new DecimalFormat("#");
		MinMaxValues minMaxValues = new MinMaxValues();
		String query = "";
		if (modeofPay.equalsIgnoreCase("01")) { // monthly
			query = "SELECT Secondary_UW_Minimum_Monthly_Premium,Secondary_UW_Maximum_Monthly_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_UW_Minimum_Monthly_Premium", "Secondary_UW_Maximum_Monthly_Premium");
			;
			if (minMaxValues != null) {
				String Min_Monthly_Premium = minMaxValues.minValue;
				String Max_Monthly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Monthly_Premium.equalsIgnoreCase("")
						&& !Max_Monthly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Monthly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Monthly_Premium)) {
						message = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Monthly_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Monthly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("03")) { // quarterly
			query = "SELECT Secondary_UW_Minimum_Quarterly_Premium, Secondary_UW_Maximum_Quarterly_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_UW_Minimum_Quarterly_Premium", "Secondary_UW_Maximum_Quarterly_Premium");
			if (minMaxValues != null) {
				String Min_Quarterly_Premium = minMaxValues.minValue;
				String Max_Quarterly_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Quarterly_Premium.equalsIgnoreCase("")
						&& !Max_Quarterly_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Quarterly_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Quarterly_Premium)) {
						message = "UW Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Quarterly_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Quarterly_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("06")) { // semi annual
			query = "SELECT Secondary_UW_Minimum_Semi_Annual_Premium,Secondary_UW_Maximum_Semi_Annual_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_UW_Minimum_Semi_Annual_Premium", "Secondary_UW_Maximum_Semi_Annual_Premium");
			if (minMaxValues != null) {
				String Min_Semi_Annual_Premium = minMaxValues.minValue;
				String Max_Semi_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Semi_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Semi_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Semi_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Semi_Annual_Premium)) {
						message = "UW Modal Premium must lie between "
								+ df.format(Double.parseDouble(Min_Semi_Annual_Premium)) + " and "
								+ df.format(Double.parseDouble(Max_Semi_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		} else if (modeofPay.equalsIgnoreCase("12")) { // annual
			query = "SELECT Secondary_UW_Minimum_Annual_Premium,Secondary_UW_Maximum_Annual_Premium" + BusinessLogicDao.whereClause;
			minMaxValues = BusinessLogicDao.queryExecutor.runMinMaxQuery(query, BusinessLogicDao.source,
					"Secondary_UW_Minimum_Annual_Premium", "Secondary_UW_Maximum_Annual_Premium");
			if (minMaxValues != null) {
				String Min_Annual_Premium = minMaxValues.minValue;
				String Max_Annual_Premium = minMaxValues.maxValue;

				if (!modalPremium.equalsIgnoreCase("") && !Min_Annual_Premium.equalsIgnoreCase("")
						&& !Max_Annual_Premium.equalsIgnoreCase("")) {
					if (Double.parseDouble(modalPremium) < Double.parseDouble(Min_Annual_Premium)
							|| Double.parseDouble(modalPremium) > Double.parseDouble(Max_Annual_Premium)) {
						message = "UW Modal Premium must lie between " + df.format(Double.parseDouble(Min_Annual_Premium))
								+ " and " + df.format(Double.parseDouble(Max_Annual_Premium));
//						ifr.setValue("Q_COVERAGE_DETAILS.MODAL_PREMIUM", "");
					}
				}
			}
		}
	}

	// result
	public static String getResult() {
		return message;
	}
}
/**
 * Will return hashMap of valid key and value pairs whose entries are present in ULIP master table as comma separated values.
 * @author prakhar.saxena
 *
 */
class CommaSeparatedValues {
	static Map<String, String> hm = new HashMap<>();

	public static void getValidKeyValues(String MDM_ColumnName, String masterTableName, String valueCol, String labelCol) {
		hm.clear();
		String query = "Select "+MDM_ColumnName+" " + BusinessLogicDao.whereClause;
		hm = BusinessLogicDao.queryExecutor.getValidKeyValuePair(query, BusinessLogicDao.source, MDM_ColumnName,
				masterTableName, valueCol, labelCol);
	}
	
	public static Map<String, String> getResult(){
		return hm;
	}
	
}
/**
 * Logic for Premium Payment Term
 * @author prakhar.saxena
 *
 */
class PremiumPaymentTerm{
	static String premiumPaymentTerm;
	static String insuredDOB;
	static String coverageTerm;
	private static String message="";
        private static String whereClause;
	
	public PremiumPaymentTerm(String premiumPaymentTerm, String insuredDOB, String coverageTerm, String whereClause) {
		this.premiumPaymentTerm = premiumPaymentTerm;
		this.insuredDOB = insuredDOB;
		this.coverageTerm = coverageTerm;
                this.whereClause = whereClause;
	}
	
	public static void validateField() {
		message="";
		Map<String,String> queryResult = new HashMap<>();
		String query = "SELECT Secondary_PPT_Cal_Logic_Code,Secondary_Payment_Term,Calculation_Value, ISNULL(Plan_Pay_Option_Code_Desc,'') AS 'Plan_Pay_Option_Code_Desc'" + BusinessLogicDao.whereClause;
		queryResult = BusinessLogicDao.queryExecutor.runPPTQuery(query, BusinessLogicDao.source);
		String PPT_Cal_Logic_code = queryResult.get("Secondary_PPT_Cal_Logic_Code");
		String Payment_Term = queryResult.get("Secondary_Payment_Term");
		String Calculation_Value = queryResult.get("Calculation_Value");
		String ageOfInsured = CalculateYears(insuredDOB,BusinessLogicDao.ifr);
		String planPayOptionCode=queryResult.get("Plan_Pay_Option_Code_Desc");
                
                int numericCT,numerciPPT;
                numericCT=coverageTerm.isEmpty()?0:Integer.parseInt(coverageTerm);
                numerciPPT=premiumPaymentTerm.isEmpty()?0:Integer.parseInt(premiumPaymentTerm);

		if (queryResult != null) {
            if (PPT_Cal_Logic_code.equalsIgnoreCase("A")) {
                String[] Payment_TermArr = Payment_Term.split(",");
                Boolean match = false;
                for (int i = 0; i < Payment_TermArr.length; i++) {
                    if (premiumPaymentTerm.equalsIgnoreCase(Payment_TermArr[i])) {
                        match = true;
                    }
                }
                if (!match) {
                	message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("B")) {
                if (!premiumPaymentTerm.isEmpty() && !ageOfInsured.isEmpty()) {
                    if (Integer.parseInt(premiumPaymentTerm) != Integer.parseInt(Calculation_Value) - Integer.parseInt(ageOfInsured)) {
                    	message = "Premium Payment Term is not valid. Please check.";
//                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                    }
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("C")) {
                if (!coverageTerm.equalsIgnoreCase(premiumPaymentTerm)) {
                	message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("D")) {
                if (!premiumPaymentTerm.equalsIgnoreCase("1")) {
                	message = "Premium Payment Term is not valid. Please check.";
//                    ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                }
            } else if (PPT_Cal_Logic_code.equalsIgnoreCase("E")) {
                if (!premiumPaymentTerm.isEmpty() && !coverageTerm.isEmpty() && !Calculation_Value.isEmpty()) {
                    if (Integer.parseInt(premiumPaymentTerm) != Integer.parseInt(coverageTerm) - Integer.parseInt(Calculation_Value)) {
                    	message = "Premium Payment Term is not valid. Please check.";
//                        ifr.setValue("Q_COVERAGE_DETAILS.PREMIUM_PAY_TERM", "");
                    }
                }
            } else if(PPT_Cal_Logic_code.equalsIgnoreCase("F")){
                String ppt_query = "SELECT Premium_Payment_Term FROM NG_NB_MS_TRAD_PT_PPT(nolock) "+whereClause+" AND Term = " + coverageTerm;
				ArrayList<String> ppt_list = new ArrayList<>();
				ppt_list = BusinessLogicDao.queryExecutor.runPPTQuery2(ppt_query, BusinessLogicDao.source);
				boolean matched = false;
                if(ppt_list!=null){
                    for(int i=0;i<ppt_list.size(); i++){
                        if(ppt_list.contains(premiumPaymentTerm))
                            matched = true;
                    }
                }
                if(!matched){
                	message = "Premium Payment Term is not valid. Please check. Valid values are: " +ppt_list;
                }
            }
            
            if((planPayOptionCode.equalsIgnoreCase("LTD") || planPayOptionCode.equalsIgnoreCase("PAY60"))&& numerciPPT>numericCT){
                message+="-----Premium Payment Term should not be greater than Coverage Term";
            }
        }
				
	}
	
	public static String getResult() {
		return message;
	}
}
