package com.newgen.iforms.user.combovalidations;


import com.newgen.iforms.custom.IFormReference;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//import com.newgen.util.XMLGen;
import com.newgen.omni.jts.cmgr.XMLParser;
import java.util.List;
//import com.newgen.util.CommonFunctions;


public class QueryExecutor {

	private static String cabinetName;
	private static String sessionID;
	static XMLParser xml = new XMLParser();
        private static IFormReference ifr;

	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
        
        public void setFormRef(IFormReference ifr){
            this.ifr = ifr;
        }

	public MinMaxValues runMinMaxQuery(String query, String source, String minColName, String maxColName) {
		MinMaxValues minMaxValues = new MinMaxValues();

		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			minMaxValues.minValue = xml.getValueOf(minColName);
			minMaxValues.maxValue = xml.getValueOf(maxColName);
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List result = null;
                        result = runQueryIform(query);
                        if(result!=null){
                            minMaxValues.minValue = (String) ((List) result.get(0)).get(0);
                            minMaxValues.maxValue = (String) ((List) result.get(0)).get(1);
                        }
                }
		return minMaxValues;
	}

	public Map<String, String> runCoverageTermQuery(String query, String source) {
		Map<String, String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Plan_Age_Expiry", xml.getValueOf("Plan_Age_Expiry"));
			hm.put("Secondary_Term_CalC_Code", xml.getValueOf("Secondary_Term_CalC_Code"));
			hm.put("Combo_Minimum_Term", xml.getValueOf("Combo_Minimum_Term"));
			hm.put("Combo_Maximum_Term", xml.getValueOf("Combo_Maximum_Term"));
			hm.put("Minimum_Expiry_Age", xml.getValueOf("Minimum_Expiry_Age"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));

		}
                 if (source.equalsIgnoreCase("IFORM")){
                        List result = null;
                        result = runQueryIform(query);
                        if(result!=null){
                            hm.put("Plan_Age_Expiry", (String) ((List) result.get(0)).get(0));
                            hm.put("Secondary_Term_CalC_Code", (String) ((List) result.get(0)).get(1));
                            hm.put("Combo_Minimum_Term", (String) ((List) result.get(0)).get(2));
                            hm.put("Combo_Maximum_Term", (String) ((List) result.get(0)).get(3));
                            hm.put("Minimum_Expiry_Age", (String) ((List) result.get(0)).get(4));
                            hm.put("Maximum_Expiry_Age", (String) ((List) result.get(0)).get(5));
                        }
                }
		return hm;
	}

	public Map<String, String> getValidKeyValuePair(String query, String source, String colName, String masterTableName,
			String valueCol, String labelCol) {
		Map<String, String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);

			String validValues = xml.getValueOf(colName); // MDM valid values ( , separated)
			if (validValues != null && !validValues.equals("")) {
				String[] validValuesArr = validValues.split(",");
				for (int i = 0; i < validValuesArr.length; i++) {
					hm.put(validValuesArr[i].trim(),
							getValueFromMDM(validValuesArr[i].trim(), masterTableName, source, valueCol, labelCol));
				}
			}
		}
                 if (source.equalsIgnoreCase("IFORM")){
                        List result = null;
                        result = runQueryIform(query);
                        if(result!=null){
                            String validValues = (String) ((List) result.get(0)).get(0); // MDM valid values ( , separated)
                            if (validValues != null && !validValues.equals("")) {
				String[] validValuesArr = validValues.split(",");
				for (int i = 0; i < validValuesArr.length; i++) {
					hm.put(validValuesArr[i].trim(),
							getValueFromMDM(validValuesArr[i].trim(), masterTableName, source, valueCol, labelCol));
				}
                            }
                        }
                }
		return hm;
	}

	private String getValueFromMDM(String code, String masterTableName, String source, String valueCol,
			String labelCol) {
		String value = "";
		if (source.equalsIgnoreCase("JSON")) {
			String query = "SELECT " + labelCol + " FROM " + masterTableName + " WHERE " + valueCol + "='" + code + "'";
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			value = xml.getValueOf(labelCol);
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List result = null;
                        String query = "SELECT " + labelCol + " FROM " + masterTableName + " WHERE " + valueCol + "='" + code + "'";
                        result = runQueryIform(query);
                        if(result!=null){
                            value = (String) ((List) result.get(0)).get(0);
                        }
                }
		return value;
	}

	public Map<String, String> runPPTQuery(String query, String source) {
		Map<String, String> result = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result.put("Secondary_PPT_Cal_Logic_Code", xml.getValueOf("Secondary_PPT_Cal_Logic_Code"));
			result.put("Secondary_Payment_Term", xml.getValueOf("Secondary_Payment_Term"));
			result.put("Calculation_Value", xml.getValueOf("Calculation_Value"));
                        result.put("Plan_Pay_Option_Code_Desc", xml.getValueOf("Plan_Pay_Option_Code_Desc"));
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                            result.put("Secondary_PPT_Cal_Logic_Code", (String) ((List) queryResult.get(0)).get(0));
                            result.put("Secondary_Payment_Term", (String) ((List) queryResult.get(0)).get(1));
                            result.put("Calculation_Value", (String) ((List) queryResult.get(0)).get(2));
                            result.put("Plan_Pay_Option_Code_Desc", (String) ((List) queryResult.get(0)).get(3));
                        }
                }
		return result;
	}
        
        public Map<String, String> runFundsQuery(String source, String fundApplicableQuery) {
		Map<String, String> hm = new HashMap<String,String>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(fundApplicableQuery);
			xml.setInputXML(outputXML);
			int noOfRecords = Integer.parseInt(xml.getValueOf("TotalRetrieved"));
			for(int i=0;i<noOfRecords;i++) {
				hm.put(xml.getNextValueOf("Fund_Code"), xml.getNextValueOf("FUND_LABEL"));
			}
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(fundApplicableQuery);
                        if(queryResult!=null){
                            for(int i=0;i<queryResult.size(); i++){
                                hm.put((String) ((List) queryResult.get(i)).get(0), (String) ((List) queryResult.get(i)).get(1));
                            }
                        }
                }
		return hm;
	}

	/*
	 * Will return sub-channel from Channel Code
	 */
	public String getChannelDescFromVal(String Channel, String source) {
		String query = "SELECT TOP(1) CHANNEL_DESC FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE = '"
				+ Channel + "' ";
		String channelDesc = "";
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			channelDesc = xml.getValueOf("CHANNEL_DESC");
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                            channelDesc = (String) ((List) queryResult.get(0)).get(0);
                        }
                }
		return channelDesc;
	}

	public EffectiveDateResult runEffectiveDateQuery(String query, String source) {
		EffectiveDateResult effectiveDateResult = new EffectiveDateResult();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			effectiveDateResult.planEffectiveDate = xml.getValueOf("Plan_Effective_Date");
			effectiveDateResult.channelEffectiveDate = xml.getValueOf("Channel_Effective_Date");
			effectiveDateResult.planExpiryDate = xml.getValueOf("Plan_Expiry_Date");
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                            effectiveDateResult.planEffectiveDate = (String) ((List) queryResult.get(0)).get(0);
                            effectiveDateResult.channelEffectiveDate = (String) ((List) queryResult.get(0)).get(1);
                            effectiveDateResult.planExpiryDate = (String) ((List) queryResult.get(0)).get(2);
                        }
                }
		return effectiveDateResult;
	}

	public Map<String, String> runIssueAgeQuery(String query, String source) {
		Map<String,String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Min_Issue_Age", xml.getValueOf("Min_Issue_Age"));
			hm.put("Max_Issue_Age", xml.getValueOf("Max_Issue_Age"));
			hm.put("Minimum_Expiry_Age", xml.getValueOf("Minimum_Expiry_Age"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                        hm.put("Min_Issue_Age", (String) ((List) queryResult.get(0)).get(0));
			hm.put("Max_Issue_Age", (String) ((List) queryResult.get(0)).get(1));
			hm.put("Minimum_Expiry_Age", (String) ((List) queryResult.get(0)).get(2));
			hm.put("Maximum_Expiry_Age", (String) ((List) queryResult.get(0)).get(3));
                        }
                }
		return hm;
	}

	public ArrayList runDiscountQuery(String query, String source) {
		ArrayList list = new ArrayList();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			String result = xml.getValueOf("Discount");
			if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					list.add(val.trim());
				}
			}
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                        String result = (String) ((List) queryResult.get(0)).get(0);
                            if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					list.add(val.trim());
				}
                            }   
                        }
                }
		return list;
	}

	public String runIsVisibleQuery(String query, String source, String colName) {
		String result="";
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result = xml.getValueOf(colName);			
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
			result = (String) ((List) queryResult.get(0)).get(0);
                        }
                }
		return result;
	}

	public String runDBQuery(String source, String query, String colName) {
		String result = "";
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result = xml.getValueOf(colName);
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
			result = (String) ((List) queryResult.get(0)).get(0);
                        }
                }
		return result;
	}

	public ArrayList<String> runCoverMultipleQuery(String query, String source) {
		ArrayList<String> Cover_Multiple = new ArrayList<String>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			String result = xml.getValueOf("Cover_Multiple");
			if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					Cover_Multiple.add(val);
				}
			}
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
                            String result = (String) ((List) queryResult.get(0)).get(0);
                            if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					Cover_Multiple.add(val);
				}
                            }
                        }
                }
		return Cover_Multiple;
	}

	public Map<String, String> runMinMaxCovMulQuery(String query, String source) {
		Map<String, String> hm = new HashMap<>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("MINIMUM_COV_MUL",xml.getValueOf("MINIMUM_COV_MUL"));
			hm.put("MAXIMUM_COV_MUL",xml.getValueOf("MAXIMUM_COV_MUL"));
		}
                if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
			hm.put("MINIMUM_COV_MUL",(String) ((List) queryResult.get(0)).get(0));
			hm.put("MAXIMUM_COV_MUL",(String) ((List) queryResult.get(0)).get(1));
                        }
                }		
		return hm;
	}

	public Map<String, String> runBenefitRidersQuery(String query, String source) {
		Map<String, String> hm = new HashMap<String, String>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("MINIMUM_COV_MUL",xml.getValueOf("MINIMUM_COV_MUL"));
			hm.put("MAXIMUM_COV_MUL",xml.getValueOf("MAXIMUM_COV_MUL"));
		}
                else if (source.equalsIgnoreCase("IFORM")){
                        List queryResult = null;
                        queryResult = runQueryIform(query);
                        if(queryResult!=null){
			hm.put("MINIMUM_COV_MUL",(String) ((List) queryResult.get(0)).get(0));
			hm.put("MAXIMUM_COV_MUL",(String) ((List) queryResult.get(0)).get(1));
                        }
                }
		
		return hm;
	}
        
        ArrayList<String> runPPTQuery2(String query, String source) {
        ArrayList<String> list = new ArrayList<>();
        if (source.equalsIgnoreCase("JSON")) {
                String outputXML = runQueryJSON(query);
                xml.setInputXML(outputXML);
                int noOfRecords = Integer.parseInt(xml.getValueOf("TotalRetrieved"));
                for(int i=0;i<noOfRecords;i++) {
                        list.add(xml.getNextValueOf("Premium_Payment_Term").trim());
                }
        }        
        else if (source.equalsIgnoreCase("IFORM")){
                List queryResult = null;
                queryResult = runQueryIform(query);
                if(queryResult!=null){
                for(int i=0;i<queryResult.size(); i++){
                        list.add(((List) queryResult.get(i)).get(0).toString().trim());
                    }
                }
        }
        return list;
        }
	
	private String runQueryJSON(String query) {
		String outputXML="";
//		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
//		try {
//			outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		return outputXML;
	}
        
        List runQueryIform(String query) {
        String queryResult = "";
        List queryResultList = (List) ifr.getDataFromDB(query);
        if (!queryResultList.isEmpty()) {
            return queryResultList;
        } else {
            return null;
        }
        }		

    boolean isFundValid(String source, String query) {
        String count = "0";
        if (source.equalsIgnoreCase("IFORM")){
                List queryResult = null;
                queryResult = runQueryIform(query);
                if(queryResult!=null){
                    count = (String) ((List) queryResult.get(0)).get(0);
                }
        }
        if(count.equals("")) count = "0";
        if(Integer.parseInt(count)>0)
            return true;
        else 
            return false;
    }

    ArrayList<String> runULIPFundsQuery(String source, String query) {
        ArrayList<String> validfunds = new ArrayList<String>();
        
         if (source.equalsIgnoreCase("IFORM")){
                List queryResult = null;
                queryResult = runQueryIform(query);
                if(queryResult!=null){
                     for(int i=0;i<queryResult.size(); i++){
                                validfunds.add((String) ((List) queryResult.get(i)).get(0));
                            }
                }
        }
        return validfunds;
    }

        
}


class MinMaxValues {
	String minValue = "";
	String maxValue = "";
}

class EffectiveDateResult{
	String planEffectiveDate="";
	String channelEffectiveDate="";
	String planExpiryDate = "";
	
	public String getPlanEffectiveDate() {
		return planEffectiveDate;
	}
	public String getChannelEffectiveDate() {
		return channelEffectiveDate;
	}
	public String getPlanExpiryDate() {
		return planExpiryDate;
	}
}


