/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.user.jsFunctions.JSToJava;

/**
 *
 * @author SY03531
 */
public class Section_Load {
    
     public void AgentDetalsLoad(String id, String stringData, IFormReference iFormRef) {
          String controlName = id;
            String value = stringData;
          
            JSToJava agentDetailsOBJ=new JSToJava(iFormRef);
            try
            {
                String channel=agentDetailsOBJ.getValue("CHANNEL") ;   //aanchal //16nov
	
	
	

	if (channel.equalsIgnoreCase("A")) { // CHANGES MADE BY AMULYA
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SP_CERTIFICATE_NO", "visible", "false");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SOL_ID", "visible", "false");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SSN_CODE", "visible", "false");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_APPLICATION_ID", "visible", "false");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_WMS_SERIAL_NO", "visible", "false");
		iFormRef.setColumnVisible("table47", "20", true);  //DR7118
		iFormRef.setColumnVisible("table47", "21", true);

		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SP_CERTIFICATE_NO");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SOL_ID");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SSN_CODE");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_APPLICATION_ID");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_WMS_SERIAL_NO");
	}
	else
	{
		iFormRef.setColumnVisible("table47", "20", false);  //DR7118
		iFormRef.setColumnVisible("table47", "21", false);
	}
	if (channel.equalsIgnoreCase("X") || channel.equalsIgnoreCase("BY") || channel.equalsIgnoreCase("LVB") || channel.equalsIgnoreCase("F") || channel.equalsIgnoreCase("P")  || channel.equalsIgnoreCase("C0")) { // CHANGES MADE BY AMULYA, DR-44145 Lovnish
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SP_CERTIFICATE_NO", "visible", "true");
		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_SP_CERTIFICATE_NO");
	} else {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SP_CERTIFICATE_NO", "visible", "false");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SP_CERTIFICATE_NO");
	}

	if (channel.equalsIgnoreCase("X")) { // CHANGES MADE BY AMULYA
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SOL_ID", "visible", "true");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_APPLICATION_ID", "visible", "true");

		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_SOL_ID");
		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_APPLICATION_ID");

	} else {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SOL_ID", "visible", "false");
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_APPLICATION_ID", "visible", "false");

		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SOL_ID");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_APPLICATION_ID");
	}
	if (channel.equalsIgnoreCase("X") || channel.equalsIgnoreCase("BY") || channel.equalsIgnoreCase("LVB")) { // CHANGES MADE BY AMULYA
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SSN_CODE", "visible", "true");
		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_SSN_CODE");
	} else {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_SSN_CODE", "visible", "false");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_SSN_CODE");
	}
	if (channel.equalsIgnoreCase("BY")) { // CHANGES MADE BY AMULYA
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_WMS_SERIAL_NO", "visible", "true");
		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_WMS_SERIAL_NO");
	} else {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_WMS_SERIAL_NO", "visible", "false");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_WMS_SERIAL_NO");
	}


	if ((!(agentDetailsOBJ.getValue("PLAN_TYPE").equalsIgnoreCase("ULIP"))) && (!(agentDetailsOBJ.getValue("PLAN_TYPE").equalsIgnoreCase("COMBO")))) {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_LOGIN_PRIOR_3PM", "visible", "false");
		agentDetailsOBJ.setnonMandatory("Q_AGENT_DETAILS_LOGIN_PRIOR_3PM");

		iFormRef.setColumnVisible("table47", "12", false);
		iFormRef.setColumnVisible("table47", "13", false);
		iFormRef.setColumnVisible("table47", "14", false);
		iFormRef.setColumnVisible("table47", "15", false);

	} else {
		agentDetailsOBJ.setStyle("Q_AGENT_DETAILS_LOGIN_PRIOR_3PM", "visible", "true");
		agentDetailsOBJ.setMandatory("Q_AGENT_DETAILS_LOGIN_PRIOR_3PM");


		iFormRef.setColumnVisible("table47", "12", true);
		iFormRef.setColumnVisible("table47", "13", true);
		iFormRef.setColumnVisible("table47", "14", true);
		iFormRef.setColumnVisible("table47", "15", true);
	}
            }
            catch(Exception e)
            {
                System.out.println("Error in Agent Details Load" + e.toString());
            }
     }
    
}
