package com.newgen.validationsCombo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JsonArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.services.CreateWI;

public class ComboValidator {
	
	private static Logger logger = Logger.getLogger("UlipValidator");
	
	private String requestJson;
	private String responseJson;
	private String Plan_Type;
	private JSONObject responseJsonobj = new JSONObject();
	private JSONArray failedFieldsArr = new JSONArray();
	private boolean validationFailed = false;
	private int i = 0;
	private JSONObject requestJsonObj = new JSONObject();
	private JSONObject productandPaymentInformationObj = new JSONObject();
	private JSONObject FundSelectedObj = new JSONObject();
	private JSONObject personalInformationObj = new JSONObject();
	private JSONObject l2BIDetailsObj = new JSONObject();
	private JSONObject ProposerDetailsObj = new JSONObject();
	private JSONObject coverageDetailsObj = new JSONObject();
	private JSONObject RenewalPremiumDetailsObj = new JSONObject();
	private JSONObject PolicyAgentCustomerInfoObj = new JSONObject();
	private JSONObject DefenceDetails = new JSONObject();
	private JSONObject CustomerInformation = new JSONObject();
	private JSONObject PolicyDetailsObj = new JSONObject();
	private JSONObject AgentDetailsObj = new JSONObject();
	private JSONArray AgentGridObj = new JSONArray();
	private JSONParser jsonParser = new JSONParser();
	BusinessLogicDao businessLogcDao;

	// Constructor
	public ComboValidator(String requestJson, String sessionId, String cabinetName) throws ParseException {
		super();
		this.requestJson = requestJson;
		logger.info("requestJson: " +requestJson);
		this.requestJsonObj = (JSONObject) this.jsonParser.parse(requestJson);
		this.productandPaymentInformationObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("ProductandPaymentInformation").toString());
		this.coverageDetailsObj = (JSONObject) this.jsonParser
				.parse(this.productandPaymentInformationObj.get("CoverageDetails").toString());
		this.RenewalPremiumDetailsObj = (JSONObject) this.jsonParser
				.parse(this.productandPaymentInformationObj.get("RenewalPremiumDetails").toString());
		this.FundSelectedObj = (JSONObject) this.jsonParser
				.parse(this.productandPaymentInformationObj.get("FundSelected").toString());

		this.personalInformationObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("PersonalInformation").toString());
		this.l2BIDetailsObj = (JSONObject) this.jsonParser
				.parse(this.personalInformationObj.get("L2BIDetails").toString());
		this.ProposerDetailsObj = (JSONObject) this.jsonParser
				.parse(this.personalInformationObj.get("ProposerDetails").toString());

		this.PolicyAgentCustomerInfoObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("PolicyAgentCustomerInfo").toString());
		this.PolicyDetailsObj = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("PolicyDetails").toString());
		this.DefenceDetails = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("DefenceDetails").toString());

		this.CustomerInformation=(JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("CustomerInformation").toString());
		
		this.AgentDetailsObj = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("AgentDetails").toString());
		this.AgentGridObj = (JSONArray) this.jsonParser.parse(this.AgentDetailsObj.get("AgentGrid").toString());
		String channel = "", DefenceChannelCase, ybltelesaleCase;



		for (Object j : AgentGridObj) {
			JSONObject jsonObj = (JSONObject) j;
			channel = jsonObj.get("Channel").toString();
		}
		
		DefenceChannelCase = this.DefenceDetails.get("DefenceChannelCase").toString();
		if(channel.equalsIgnoreCase("BY"))
		{
			DefenceChannelCase= this.CustomerInformation.getOrDefault("isYBLTeleSales", "").toString();
		}  //DR12411

		String planCode = PolicyDetailsObj.getOrDefault("ProductName", "").toString();
		String planCodeCombo=PolicyDetailsObj.getOrDefault("ProductNameCombo", "").toString();
		String productSolution=PolicyDetailsObj.getOrDefault("ProductSolution", "").toString();
		logger.info("planCode: " +planCode);
		logger.info("channel: " +channel);
		this.businessLogcDao = new BusinessLogicDao(planCode,planCodeCombo,productSolution, channel, "", "JSON", sessionId, cabinetName,
				DefenceChannelCase);
	}

	// Another Constructor specific to Riders
	public ComboValidator(String requestJson, String sessionId, String cabinetName, String param) throws ParseException {

		this.requestJson = requestJson;
		this.requestJsonObj = (JSONObject) this.jsonParser.parse(requestJson);
		this.Plan_Type=param;

		// PersonalInformation
		this.personalInformationObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("PersonalInformation").toString());
		this.l2BIDetailsObj = (JSONObject) this.jsonParser
				.parse(this.personalInformationObj.get("L2BIDetails").toString());

		this.ProposerDetailsObj = (JSONObject) this.jsonParser
				.parse(this.personalInformationObj.get("ProposerDetails").toString());
		// PersonalInformation End

		// ProductandPaymentInformation
		this.productandPaymentInformationObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("ProductandPaymentInformation").toString());
		this.coverageDetailsObj = (JSONObject) this.jsonParser
				.parse(this.productandPaymentInformationObj.get("CoverageDetails").toString());

		// ProductandPaymentInformation End

		// PolicyAgentCustomerInfo
		this.PolicyAgentCustomerInfoObj = (JSONObject) this.jsonParser
				.parse(this.requestJsonObj.get("PolicyAgentCustomerInfo").toString());
		this.PolicyDetailsObj = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("PolicyDetails").toString());

		String ProductName = (String) PolicyDetailsObj.get("ProductName");

		this.DefenceDetails = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("DefenceDetails").toString());

		this.AgentDetailsObj = (JSONObject) this.jsonParser
				.parse(this.PolicyAgentCustomerInfoObj.get("AgentDetails").toString());
		this.AgentGridObj = (JSONArray) this.jsonParser.parse(this.AgentDetailsObj.get("AgentGrid").toString());

		String channel = "", DefenceChannelCase;

		DefenceChannelCase = this.DefenceDetails.get("DefenceChannelCase").toString();
		for (Object j : AgentGridObj) {
			JSONObject jsonObj = (JSONObject) j;
			channel = jsonObj.get("Channel").toString();
		}
		
		if(channel.equalsIgnoreCase("BY"))
		{
			DefenceChannelCase= this.CustomerInformation.getOrDefault("isYBLTeleSales", "").toString();
		}  //DR12411

		// PolicyAgentCustomerInfo End
		
		String planCodeCombo=PolicyDetailsObj.getOrDefault("ProductNameCombo", "").toString();
		String productSolution=PolicyDetailsObj.getOrDefault("ProductSolution", "").toString();
		this.businessLogcDao = new BusinessLogicDao(channel,planCodeCombo,productSolution, DefenceChannelCase, "JSON", sessionId, cabinetName,
				ProductName);
	}
	// End of Constructor

	// Function to validate RiderDetails in JSON
	public void validateRiderBenefit() {

		// Get Values from Input JSON
		JSONArray riderDetailsArr = (JSONArray) coverageDetailsObj.getOrDefault("RiderDetails", "[]");
		String clientType = ProposerDetailsObj.getOrDefault("ClientType", "").toString();
		String effectiveDate = coverageDetailsObj.getOrDefault("EffectiveDate", "1970-01-01").toString();
		String insuredDob = l2BIDetailsObj.getOrDefault("DateOfBirth", "").toString();
		String baseCoverageTerm=coverageDetailsObj.getOrDefault("CoverageTerm", "").toString();
		String basePPT=coverageDetailsObj.getOrDefault("PremiumPaymentTerm", "").toString();
		String baseSA=coverageDetailsObj.getOrDefault("SumAssured", "0").toString();
		String proposerDOB= ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();
		String PLANTYPE=Plan_Type;
		
		if (clientType.equalsIgnoreCase("ProposerInsured"))
			insuredDob = ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();

		//String coverageTerm = coverageDetailsObj.getOrDefault("CoverageTerm", "").toString();
		String modeOfPayment = coverageDetailsObj.getOrDefault("ModeofPayment", "").toString();

		// Get Values from Input JSON - End

		String riderTag = "CoverageDetails.RiderDetails",riderTagMessage,riderClass,rowCountRiderSetup;
		int rowCount = 0;
		ArrayList<String> riderFamily=new ArrayList<>();
		
		if (riderDetailsArr.size() > 0) {
			JSONObject riderJsonObj;
			String RiderType, CoverageTerm, SumAssured, ModalPremium, GST, RiderInsuredDetails,termCalcCode="",PPT;

			for (Object riderObj : riderDetailsArr) {
				riderJsonObj = (JSONObject) riderObj;
				RiderType = riderJsonObj.getOrDefault("RiderType", "").toString();
				CoverageTerm = riderJsonObj.getOrDefault("CoverageTerm", "0").toString();
				SumAssured = riderJsonObj.getOrDefault("SumAssured", "0").toString();
				ModalPremium = riderJsonObj.getOrDefault("ModalPremium", "0").toString();
				PPT = riderJsonObj.getOrDefault("PPT", "0").toString();
				
				riderTagMessage=riderTag+"-"+RiderType;
				// 1. Validate Rider in NG_NB_MS_RIDER_BENEFIT_CODE_DESC
				riderClass = validateRiderInMaster(RiderType, "1", riderTagMessage,"Rider Type is not defined in Rider Code Desc Master");
				if (!riderClass.isEmpty()) {
					riderFamily.add(riderClass);
					
					// Used for validateCommaSeparatedValues function
					//set where clause	//added by Prakhar on 31Jan21
					businessLogcDao.setWhereClause(RiderType,effectiveDate);

					// 2. validate rider in NG_NB_MS_RIDER_BENEFIT_SET_UP Table
					rowCountRiderSetup = validateRiderInMaster(RiderType, "2", riderTagMessage,"Rider doest not exists in Rider Setup Table");
					if (Integer.parseInt(rowCountRiderSetup )>0) {
						// 3. validate the client Type of rider
						/*logger.info(PLANTYPE);
						if (PLANTYPE.equalsIgnoreCase("JOINT"))
							validateCommaSeparatedValues(clientType, "", "Client_Type_Joint", "NG_NB_MS_CLIENT_TYPE", "TYPE_VALUE",
									"TYPE_LABEL", riderTagMessage, "Client Type is not applicable for rider");
						else*/
							validateCommaSeparatedValues(clientType, "", "Client_Type", "NG_NB_MS_CLIENT_TYPE", "TYPE_VALUE",
								"TYPE_LABEL", riderTagMessage, "Client Type is not applicable for rider");
						// Next Step

						// Check for Active Indicator
						//validateRiderIndicator(RiderType, riderTagMessage, "");

						// Check Effective date
						//validateEffectiveDate(effectiveDate, riderTagMessage);

						// Age Validations - Min/Max Issue Age and Min/Max
						// Expiry Age
						validateIssueAge(insuredDob,proposerDOB, CoverageTerm,effectiveDate, riderTagMessage);

						// Check Min/Max issue amount
						validateSumAssured(SumAssured, "", "", riderTagMessage,riderClass,baseSA);

						// Validating Min/Max Term based on Term Calc Logic
						
					
						validateRiderCoverageTerm(CoverageTerm,insuredDob,proposerDOB,effectiveDate,baseCoverageTerm,basePPT,riderTagMessage);
						
						validateRiderPPT(PPT,baseCoverageTerm,basePPT,insuredDob,effectiveDate,CoverageTerm,riderTagMessage);
						//Validate Modal Premium
						validateModalPremium(ModalPremium, modeOfPayment, riderTagMessage);
					}
					else{
						JSONObject jsonObj = new JSONObject();
						jsonObj.put(riderTagMessage, "Rider doest not exists in Rider Setup Table");
						addToResponse(jsonObj);
					}
				}
			}
			
			//To check multiple rider of same family
			int riderFamilyLen=riderFamily.size();
			String duplicateRiderFlag="N";
			for(int i=0;i<riderFamilyLen;i++){
				for(int j=i+1;j<riderFamilyLen;j++){
					if(riderFamily.get(i).equalsIgnoreCase(riderFamily.get(j))){
						duplicateRiderFlag="Y";
					}
				}
			}
			if(duplicateRiderFlag.equalsIgnoreCase("Y")){
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("Rider - ", "Riders of same family are not allowed");
				addToResponse(jsonObj);
			}
			
		}
	}

	public void validateJson() {
		String CoverageMultiple = "", ATP = "";

		// Check if plan exists in MDM
		if (!isPlanValid())
			return;

		// Validating effevtive date
		String effectiveDate = coverageDetailsObj.getOrDefault("EffectiveDate", "").toString();
		String customerSignDate=CustomerInformation.getOrDefault("CustomerSignDate","1900-01-01").toString();
		logger.info("effectiveDate: " + effectiveDate + "; customerSignDate: " + customerSignDate);
		validateEffectiveDate(effectiveDate,customerSignDate, "");

		// Validating issue age (age of insured)
		String clientType = ProposerDetailsObj.getOrDefault("ClientType", "").toString();
		String insuredDob = l2BIDetailsObj.getOrDefault("DateOfBirth", "").toString();
		if (clientType.equalsIgnoreCase("ProposerInsured"))
			insuredDob = ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();
		String coverageTerm = coverageDetailsObj.getOrDefault("CoverageTerm", "").toString();
		String propDOB = ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();
		logger.info("insuredDob: " + insuredDob + "; coverageTerm: " + coverageTerm + "'; effectiveDate: " + effectiveDate);
		validateIssueAge(insuredDob,propDOB, coverageTerm,effectiveDate, "");
		
		// Validating Sum Assured
		CoverageMultiple = coverageDetailsObj.getOrDefault("CoverageMultiple", "").toString();
		ATP = coverageDetailsObj.getOrDefault("ATPCombo", "").toString();
		String sumAssured = coverageDetailsObj.getOrDefault("SumAssuredCombo", "").toString();
		logger.info("sumAssured: " + sumAssured + "; CoverageMultiple: " + CoverageMultiple + "'; ATP: " + ATP);
		if (!sumAssured.equals(""))
			validateSumAssured(sumAssured, CoverageMultiple, ATP, "","","");
		
		logger.info("log3 aanchalll");

		
		
		// Validating Coverage Term
		coverageTerm = coverageDetailsObj.getOrDefault("CoverageTermCombo", "").toString();
		String insuredDOB = l2BIDetailsObj.getOrDefault("DateOfBirth", "").toString();
		logger.info("log aanchalll");

		logger.info("coverageTerm: " + coverageTerm + "; insuredDOB: " + effectiveDate + "'; ATP: " + ATP);
		if (!coverageTerm.equals(""))
			validateCoverageTerm(coverageTerm, insuredDOB,effectiveDate, "");

		// Validating Modal Premium
		String modalPremium = coverageDetailsObj.getOrDefault("ModalPremiumCombo", "").toString();
		String modeOfPay = coverageDetailsObj.getOrDefault("ModeofPayment", "").toString();
		logger.info("modalPremium: " + modalPremium + "; modeOfPay: " + modeOfPay);
		if (!modalPremium.equals(""))
			validateModalPremium(modalPremium, modeOfPay, "");

		// Validating Bonus Option
		String bonusOption = coverageDetailsObj.getOrDefault("BonusOption", "").toString();
		if (!bonusOption.equals(""))
			validateCommaSeparatedValues(bonusOption, "BonusOption", "Bonus_Option_Code", "NG_NB_MS_BONUS_OPT",
					"BONUS_VALUE", "BONUS_LABEL", "", "");

		// Validating NFO_Option_Code
		String nfo = coverageDetailsObj.getOrDefault("NonForfeitureOption", "").toString();
		if (!nfo.equals(""))
			validateCommaSeparatedValues(nfo, "NonForfeitureOption", "NFO_Option_Code", "NG_NB_MS_NON_FORFEITURE",
					"FORF_VALUE", "FORF_LABEL", "", "");

		// Validating Billing_Type_Code
		String renewalPremiumMethod = RenewalPremiumDetailsObj.getOrDefault("RenewalPremiumMethod", "").toString();
		validateCommaSeparatedValues(renewalPremiumMethod, "RenewalPremiumMethod", "Billing_Type_Code",
				"NG_NB_MS_BILL_TYPE_CODE_DESC", "BILL_TYPE_CODE", "BILL_TYPE_DESC", "", "");

		// Validating Billing_Mode_Desc
		String modeofPayment = coverageDetailsObj.getOrDefault("ModeofPayment", "").toString();
		if (!modeofPayment.equals(""))
			validateCommaSeparatedValues(modeofPayment, "ModeofPayment", "Billing_Mode_Desc",
					"NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL", "", "");
		
		String SmartWithdrawalMODE = coverageDetailsObj.getOrDefault("SmartWithdrawalMode", "").toString();
		if (!SmartWithdrawalMODE.equals(""))
			validateCommaSeparatedValues(SmartWithdrawalMODE, "SmartWithdrawalMode", "Smart_Withdrawl_mode",
					"NG_NB_MS_MODE_OF_PAYMENT", "VALUE", "LABEL", "", "");  //SMARTWITHDRAWL
	
		String SmartWithdrawalOption = coverageDetailsObj.getOrDefault("SmartWithdrawalOption", "").toString();
		String mdmColNameSW = "smart_Withdrawl";
		checkFieldApplicable(SmartWithdrawalOption, "SmartWithdrawalOption", mdmColNameSW);
		if (SmartWithdrawalOption.equals("Y"))
		{
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR =  coverageDetailsObj.getOrDefault("SmartWithdrawalStartYear","").toString();
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE = coverageDetailsObj.getOrDefault("SmartWithdrawalMode","").toString();
			String 	Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE = coverageDetailsObj.getOrDefault("SmartWithdrawalPercentage","").toString();
			checkFieldApplicable(Q_COVERAGE_DETAILS_SMART_WITHDRAWL_STARTYEAR, "SmartWithdrawalStartYear", mdmColNameSW);
			checkFieldApplicable(Q_COVERAGE_DETAILS_SMART_WITHDRAWL_MODE, "SmartWithdrawalMode", mdmColNameSW);
			checkFieldApplicable(Q_COVERAGE_DETAILS_SMART_WITHDRAWL_PERCENTAGE, "SmartWithdrawalPercentage", mdmColNameSW);
		}


		// Validating Death_Benefit_Option_Name
		String deathBenefit = coverageDetailsObj.getOrDefault("DeathBenefit", "").toString();
		logger.info("deathBenefit: " + deathBenefit);
		validateCommaSeparatedValues(deathBenefit, "DeathBenefit", "Death_Benefit_Option_Name",
				"NG_NB_MS_DEATH_BENEFIT", "BENEFIT_VALUE", "BENEFIT_LABEL", "", "");

		// Validating Payment_Term
		String premiumPaymentTerm = coverageDetailsObj.getOrDefault("PremiumPaymentTermCombo", "").toString();
		insuredDOB = l2BIDetailsObj.getOrDefault("DateOfBirth", "").toString();
		coverageTerm = coverageDetailsObj.getOrDefault("CoverageTermCombo", "").toString();
		if (!premiumPaymentTerm.equals(""))
			validatePremiumPaymentTerm(premiumPaymentTerm, insuredDOB, coverageTerm,effectiveDate);

		// Product Solution
		String productSolution = PolicyDetailsObj.getOrDefault("ProductSolution", "").toString();
		validateCommaSeparatedValues(productSolution, "ProductSolution", "Product_Solution",
				"NG_NB_MS_PRODUCT_SOLUTION", "SOLUTION_VALUE", "SOLUTION_LABEL", "", "");

		// Employee Discount
		/*String employeeDiscount = coverageDetailsObj.getOrDefault("EmployeeDiscount", "").toString();
		checkDiscountApplicable(employeeDiscount, "ED");
		// ExistingCustDisc
		String existingCustomerDiscount = coverageDetailsObj.getOrDefault("ExistingCustomerDiscountCombo", "").toString();
		checkDiscountApplicable(existingCustomerDiscount, "EC");*/

		// Validating Client type
		clientType = ProposerDetailsObj.getOrDefault("ClientType", "").toString();
		validateCommaSeparatedValues(clientType, "ClientType", "Company_Entity", "NG_NB_MS_CLIENT_TYPE", "TYPE_VALUE",
				"TYPE_LABEL", "", "");

		// Vesting_Age UI validation
		String vestingAge = coverageDetailsObj.getOrDefault("VestingAge", "").toString();
		String mdmColName = "Vesting_Age";
		checkFieldApplicable(vestingAge, "VestingAge", mdmColName);
		
		//Validating Vesting Age
		insuredDob = l2BIDetailsObj.getOrDefault("DateOfBirth", "").toString();
		if (clientType.equalsIgnoreCase("ProposerInsured"))
			insuredDob = ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();
		validateVestingAge(vestingAge,mdmColName,coverageTerm, insuredDob,effectiveDate);

		// Save_More_Tomorrow UI validations
		String save_More_Tomorrow = coverageDetailsObj.getOrDefault("SaveMoreTomorrow", "").toString();
		mdmColName = "Save_More_Tomorrow";
		checkFieldApplicable(save_More_Tomorrow, "SaveMoreTomorrow", mdmColName);

		// Smoker_Class UI validations
		String smoker_Class = coverageDetailsObj.getOrDefault("SmokerClass", "").toString();
		mdmColName = "Smoker_Class";
		checkFieldApplicable(smoker_Class, "SmokerClass", mdmColName);

		// Life_Event UI validations
		String life_Event = coverageDetailsObj.getOrDefault("LifeEvent", "").toString();
		mdmColName = "Life_Event";
		checkFieldApplicable(life_Event, "LifeEvent", mdmColName);

		// Guaranteed_Death_Benefit UI validations
		String guaranteed_Death_Benefit = coverageDetailsObj.getOrDefault("GuaranteedDeathBenefitCombo", "").toString();
		mdmColName = "Secondary_Guaranteed_Death_Benefit";
		checkFieldApplicable(guaranteed_Death_Benefit, "GuaranteedDeathBenefitCombo", mdmColName);

		// IncomeFrequency UI validations
		String IncomeFrequency = coverageDetailsObj.getOrDefault("IncomeFrequency", "").toString();
		mdmColName = "Income_Frequency";
		checkFieldApplicable(IncomeFrequency, "IncomeFrequency", mdmColName);
		
		// Validating multiple coverage term field
		String coverageMultiple = coverageDetailsObj.getOrDefault("CoverageMultiple", "").toString();
		propDOB = ProposerDetailsObj.getOrDefault("DateofBirth", "").toString();
		validateCoverageMultiple(coverageMultiple, coverageTerm, propDOB,effectiveDate);

		// Validating Plan_Pay_Option_Code_Desc MDM field
		validatePlanPayOptionCode(premiumPaymentTerm, coverageTerm);

		// Validating Benefit Riders
		JSONArray riderDetailsArr = new JSONArray();
		riderDetailsArr = (JSONArray) coverageDetailsObj.get("RiderDetails");
		
		// validateBenefitRiders(riderDetailsArr);

		// Validate Riders
		validateRiders(riderDetailsArr,effectiveDate,customerSignDate);

		// Validating Funds
		JSONArray fundsGridArr = new JSONArray();

		fundsGridArr = (JSONArray) FundSelectedObj.get("FundsGrid");
		String systematicTransferFund = FundSelectedObj.getOrDefault("SystematicTransferFund", "").toString();
		String dynamicfundallocation = FundSelectedObj.getOrDefault("Dynamicfundallocation", "").toString();
		String lifeStylePortfolioStrategy = FundSelectedObj.getOrDefault("LifeStylePortfolioStrategy", "").toString();
		String lifescycleFund1 = FundSelectedObj.getOrDefault("Fund1", "").toString();
		String lifecycleFund2 = FundSelectedObj.getOrDefault("Fund2", "").toString();
		String triggerPortfolioStrategy = FundSelectedObj.getOrDefault("TriggerPortfolioStrategy", "").toString();
		String trigger_Fund1 = FundSelectedObj.getOrDefault("Trigger_Fund1", "").toString();
		String trigger_Fund2 = FundSelectedObj.getOrDefault("Trigger_Fund2", "").toString();
		String movementPercentage = FundSelectedObj.getOrDefault("MovementPercentage", "").toString();
		String SystematicTransferFund = FundSelectedObj.getOrDefault("SystematicTransferFund", "").toString();
		String TriggerPortfolioStrategy = FundSelectedObj.getOrDefault("TriggerPortfolioStrategy", "").toString();
		String LifeStylePortfolioStrategy = FundSelectedObj.getOrDefault("LifeStylePortfolioStrategy", "").toString();
		String modeOfPayment = coverageDetailsObj.getOrDefault("ModeofPayment", "").toString();

		validateFunds(fundsGridArr, systematicTransferFund, dynamicfundallocation, lifeStylePortfolioStrategy,
				lifescycleFund1, lifecycleFund2, triggerPortfolioStrategy, trigger_Fund1, trigger_Fund2,
				SystematicTransferFund, TriggerPortfolioStrategy, LifeStylePortfolioStrategy,modeOfPayment,movementPercentage);
	}

	private void validateVestingAge(String vestingAge, String mdmColName, String coverageTerm, 
			String insuredDob, String effectiveDate) {
		boolean isApplcable,isValid = true;
		isApplcable = businessLogcDao.isFieldApplicable("", mdmColName);
		if(!vestingAge.equals(""))
			if(Integer.parseInt(vestingAge)<50 || Integer.parseInt(vestingAge)>75)
				isValid=false;
		if(isApplcable && !isValid) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("ProductandPaymentInformation.CoverageDetailsCombo.VestingAge",
					"Vesting Age Must lie between 50 and 75. Please correct!");
			// adding to array
			addToResponse(jsonObj);
		}
		if(isApplcable && isValid) {
			String age = BusinessLogicDao.CalculateYears(insuredDob, effectiveDate,businessLogcDao.productDating);
			int ageInt = 0;
			if(!age.equals(""))
			ageInt = Integer.parseInt(age);
			
			if(!coverageTerm.equals("") && !vestingAge.equals(""))
				if(Integer.parseInt(coverageTerm)!=Integer.parseInt(vestingAge)-ageInt) {
					JSONObject jsonObj = new JSONObject();
					jsonObj.put("ProductandPaymentInformation.CoverageDetails.CoverageTerm",
							"CoverageTermCombo must be: "+(Integer.parseInt(vestingAge)-ageInt));
					// adding to array
					addToResponse(jsonObj);
				}
		}
	}

	private boolean isPlanValid() {
		boolean isValid = businessLogcDao.validateFund();
		logger.info("isValid: " +isValid);
		if (!isValid) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("MDM Error: ", "Plan not present in MDM!");
			addToResponse(jsonObj);
		}
		return isValid;
	}

	private void validateFunds(JSONArray fundsGridArr, String systematicTransferFund, String dynamicfundallocation,
			String lifeStylePortfolioStrategy, String lifescycleFund1, String lifecycleFund2,
			String triggerPortfolioStrategy, String trigger_Fund1, String trigger_Fund2, String SystematicTransferFund,
			String TriggerPortfolioStrategy, String LifeStylePortfolioStrategy, String modeOfPayment,String movementPercentage) {
		try {
			String message = businessLogcDao.validateFunds(fundsGridArr, systematicTransferFund, dynamicfundallocation,
					lifeStylePortfolioStrategy, lifescycleFund1, lifecycleFund2, triggerPortfolioStrategy,
					trigger_Fund1, trigger_Fund2, SystematicTransferFund, TriggerPortfolioStrategy,
					LifeStylePortfolioStrategy, modeOfPayment,movementPercentage);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("ProductandPaymentInformation.FundSelected", message);
				// adding to array
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	private void validateRiders(JSONArray riderDetailsArr,String effectiveDate,String customerSigndate) {
		try {
			String message = businessLogcDao.validateRiders(riderDetailsArr,effectiveDate,customerSigndate);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.RiderDetails", message);
				// adding to array
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	private void validateBenefitRiders(JSONArray riderDetailsArr) {
		try {
			String message = businessLogcDao.validateBenefitRiders(riderDetailsArr);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.RiderDetails", message);
				// adding to array
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	private void validatePlanPayOptionCode(String premiumPaymentTerm, String coverageTerm) {
		try {
			String message = businessLogcDao.validatePlanPayOptionCode(premiumPaymentTerm, coverageTerm);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("MDM Message: ", message);
				// adding to array
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	private void validateCoverageMultiple(String coverageMultiple, String coverageTerm, String propDOB,String effectiveDate) {
		try {
			String message = businessLogcDao.validateCoverageMultiple(coverageMultiple, coverageTerm, propDOB,effectiveDate);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.CoverageMultiple", message);
				// adding to array
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	/*
	 * For fields having Y or N values to be shown on UI or not or in interface
	 * present or not?
	 */
	private void checkFieldApplicable(String fieldValue, String fieldName, String mdmColName) {
		boolean applicable = businessLogcDao.isFieldApplicable(fieldValue, mdmColName);
		logger.info("fieldValue: " +fieldValue);
		logger.info("fieldName: " +fieldName);
		logger.info("mdmColName: " +mdmColName);
		logger.info("applicable: " +applicable);
		if (applicable) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("ProductandPaymentInformation.CoverageDetails." + fieldName,
					"Field is mandatory for this plan can't be blank.");
			// adding to array
			logger.info("jsonObj: " +jsonObj);
			addToResponse(jsonObj);
		}
	}

	private void checkDiscountApplicable(String discount, String discountType) {
		boolean applicable = businessLogcDao.isDiscountApplicable(discount, discountType);
		if (applicable) {
			JSONObject jsonObj = new JSONObject();
			String fieldName = "";
			if (discountType.equals("EC"))
				fieldName = "ExistingCustomerDiscount";
			else
				fieldName = "EmployeeDiscount";
			jsonObj.put("ProductandPaymentInformation.CoverageDetails." + fieldName,
					"Field is mandatory for this plan");
			// adding to array
			addToResponse(jsonObj);
		}
	}

	// private void validateProductSolution(String productSolution) {
	// String message = businessLogcDao.validateIssueAge(productSolution);
	// if(!message.equalsIgnoreCase("")) {
	// JSONObject jsonObj = new JSONObject();
	// jsonObj.put("PersonalInformation.PolicyDetails.ProductSolution",
	// message);
	// //adding to array
	// addToResponse(jsonObj);
	// }
	// }

	private void validateIssueAge(String insuredDob,String propDOB, String coverageTerm,String effectiveDate, String messageKey) {
		try {
			String message = businessLogcDao.validateIssueAge(insuredDob,propDOB, coverageTerm,effectiveDate);
			if (!message.equalsIgnoreCase("")) {
				JSONObject jsonObj = new JSONObject();
				if (messageKey.length() > 0)
					jsonObj.put(messageKey, message);
				else
					jsonObj.put("PersonalInformation.DateOfBirth", message);
				// adding to array
				logger.info("logger2:validateIssueAge: "+jsonObj);
				addToResponse(jsonObj);
			}
		} catch (Exception Ex) {
		}
	}

	private void validateEffectiveDate(String effectiveDate,String customerSignDate, String messageKey) {
		String message = businessLogcDao.validateEffectiveDate(effectiveDate,customerSignDate);
		logger.info("validateEffectiveDate_message: " + message);
		if (!message.equalsIgnoreCase("")) {
			JSONObject jsonObj = new JSONObject();
			if (messageKey.length() > 0)
				jsonObj.put(messageKey, message);
			else
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.EffectiveDate", message);

			// adding to array
			logger.info("logger1:validateEffectiveDate: "+jsonObj);
			addToResponse(jsonObj);
		}
	}

	private void validateSumAssured(String sumAssured, String CoverageMultiple, String ATP, String messageKey, String riderClass, String baseSA) {
		String saMessage = businessLogcDao.validateSumAssured(sumAssured, CoverageMultiple, ATP,riderClass, baseSA);
		if (!saMessage.equalsIgnoreCase("")) {
			JSONObject jsonObj = new JSONObject();

			if (messageKey.length() > 0)
				jsonObj.put(messageKey, saMessage);
			else
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.SumAssuredCombo", saMessage);
			// adding to array
			addToResponse(jsonObj);
		}
	}

	private void validateCoverageTerm(String coverageTerm, String insuredDOB, String effectiveDate, String messageKey) {
		String ctMessage = businessLogcDao.validateCoverageTerm(coverageTerm, insuredDOB,effectiveDate);
		if (!ctMessage.equalsIgnoreCase("")) {
			JSONObject jsonObj = new JSONObject();
			if (messageKey.length() > 0)
				jsonObj.put(messageKey, ctMessage);
			else
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.CoverageTermCombo", ctMessage);
			addToResponse(jsonObj);
		}
	}

	private void validateModalPremium(String modalPremium, String modeOfPay, String messageKey) {
		String ctMessage = businessLogcDao.validateModalPremium(modalPremium, modeOfPay);
		if (!ctMessage.equalsIgnoreCase("")) {
			JSONObject jsonObj = new JSONObject();
			if (messageKey.length() > 0)
				jsonObj.put(messageKey, ctMessage);
			else
				jsonObj.put("ProductandPaymentInformation.CoverageDetails.ModalPremiumCombo", ctMessage);
			addToResponse(jsonObj);
		}
	}
	
	//Rider Functions
	private void validateRiderCoverageTerm(String CoverageTerm, String insuredDob,String proposerDOB,String effectiveDate,String baseCoverageTerm,String basePPT, String messageKey) {
		
		String ctMessage = businessLogcDao.validateRiderCoverageTerm(CoverageTerm, insuredDob,proposerDOB,effectiveDate,baseCoverageTerm,basePPT);
		if(!ctMessage.isEmpty()){
			if(ctMessage.equalsIgnoreCase("RAN")){
				validateCoverageTerm(CoverageTerm, insuredDob,effectiveDate, messageKey);
			}
			else{
				JSONObject jsonObj = new JSONObject();
				jsonObj.put(messageKey, ctMessage);
				addToResponse(jsonObj);
			}
		}
	}
	
	private void validateRiderPPT(String PPT,String baseCoverageTerm,String basePPT,String insuredDob,String effectiveDate,String CoverageTerm,String messageKey) {
		
		String pptMessage = businessLogcDao.validateRiderPPT(PPT, baseCoverageTerm,basePPT,insuredDob,effectiveDate,CoverageTerm);
		if(!pptMessage.isEmpty()){
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(messageKey, pptMessage);
			addToResponse(jsonObj);
		}
	}
	
	//Rider Functions End
	/*
	 * General Function for checking valid values which are present in MDM as
	 * comma separated values.
	 */
	private void validateCommaSeparatedValues(String fieldValue, String jsonFieldName, String MDM_ColumnName,
			String masterTableName, String masterValue, String masterLabel, String messageKey, String messageValue) {
		Map<String, String> hm = new HashMap<>();
		Map<String, String> hm2 = new HashMap<>();
		// Setting values for MDM
		hm2.put("MDM_ColumnName", MDM_ColumnName);
		hm2.put("masterTableName", masterTableName);
		hm2.put("masterLabel", masterLabel);
		hm2.put("masterValue", masterValue);

		hm = businessLogcDao.validateCommaSeparatedValues(fieldValue, hm2); // will
																			// return
																			// HashMap
																			// of
																			// valid
																			// code
																			// and
																			// their
																			// values
																			// from
																			// Masters
		logger.info("hm: " + hm);
		if (!hm.isEmpty()) {
			if (!hm.containsKey(fieldValue)) {
				JSONObject jsonObj = new JSONObject();
				if (messageKey.length() > 1 && messageValue.length() > 1)
					jsonObj.put(messageKey, messageValue +"  Valid values are: " + hm.keySet());
				else
					jsonObj.put("ProductandPaymentInformation.CoverageDetails." + jsonFieldName,
							"Valid values are: " + hm.keySet());
				
				logger.info("jsonObj: " + jsonObj.toJSONString());
				addToResponse(jsonObj);
			}
		}
	}

	private void validatePremiumPaymentTerm(String premiumPaymentTerm, String insuredDOB, String coverageTerm,String effectiveDate) {
		String message = businessLogcDao.validatePremiumPaymentTerm(premiumPaymentTerm, insuredDOB, coverageTerm,effectiveDate);
		if (!message.equals("")) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("ProductandPaymentInformation.CoverageDetails.PremiumPaymentTermCombo", message);
			addToResponse(jsonObj);
		}
	}

	public String createResponseJson(JSONObject error) {
		logger.info("validationFailed: " +validationFailed);
		if (!validationFailed)
			return "Validated";
		else {
			responseJsonobj.put("Message", "COMBO Validation(s) Failed");
			responseJsonobj.put("Fields", failedFieldsArr);
			responseJsonobj.put("msgInfo",error);
			logger.info("responseJsonobj: " +responseJsonobj.toString());
			return responseJsonobj.toString();
		}
	}

	public ArrayList<String> createRiderResponseJson() {
		ArrayList<String> failedFieldArr=new ArrayList<>();
		JSONObject failedJsonOnj;
		Iterator value;
		String key;
		if(failedFieldsArr.size()>0){
		for(Object failedField:failedFieldsArr){
			failedJsonOnj=(JSONObject)failedField;
					
			value = failedJsonOnj.keySet().iterator(); 
			
			 while (value.hasNext()) { 
				 key=(String) value.next();
				 failedFieldArr.add(key+":"+failedJsonOnj.get(key)); 
		        } 
		}
		}
		
		return failedFieldArr;
	}

	private void addToResponse(JSONObject jsonObj) {
		failedFieldsArr.add(i++, jsonObj);
		logger.info("failedFieldsArr: " + failedFieldsArr.toString());
		validationFailed = true;
	}

	public void set_SessionIDCabName(String sessionID, String cabName) {
		// TODO Auto-generated method stub

	}

	// Rider Functions
	private String validateRiderInMaster(String riderCode, String queryId, String messageKey, String messageValue) {
		String riderFamily = businessLogcDao.validateRiderInMaster(riderCode, queryId);

		if (riderFamily.isEmpty()) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(messageKey, messageValue);
			addToResponse(jsonObj);
		}
		return riderFamily;

	}
	
	private String getRiderTermCalcCode(String riderCode) {
		String termCalcCode = businessLogcDao.getRiderTermCalcCode(riderCode);
		return termCalcCode;

	}

	private void validateRiderIndicator(String riderCode, String messageKey, String messageValue) {
		String message = businessLogcDao.validateRiderIndicator(riderCode);

		if (!message.equals("")) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(messageKey, message);
			addToResponse(jsonObj);
		}

	}
}
