package com.newgen.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.newgen.util.*;

/**
 * 
 * @author prakhar.saxena
 *
 */
public class GetWIName {
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName()); 
	
	public String getWIFromPolicyNo(String policyNo, String sessionId) throws FileNotFoundException, IOException {
		
		propertiesFileData = new Properties();
		Properties props = new Properties();
		
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);		
		
		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
        FileReader reader = new FileReader(configPath);
        
         logger.info("configPath: "+configPath);
        
        propertiesFileData = new Properties();
		propertiesFileData.load(reader);		 
		
		String cabinetName = propertiesFileData.getProperty("cabinetName");		
		
		String winame = "";
		
		String query = "SELECT WI_NAME FROM NG_NB_EXT_TABLE(NOLOCK) WHERE PROPOSAL_NUMBER = '"+policyNo+"'";
		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionId);
		logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML);
		String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_Output_outputXML: "+outputXML);
		
		
		
		if(outputXML.indexOf("WI_NAME")!=-1) {
			String processInstanceID = outputXML.substring(outputXML.indexOf("WI_NAME")+8, outputXML.indexOf("</WI_NAME>"));
			query = "SELECT ITEMINDEX FROM NG_NB_EXT_TABLE(NOLOCK) WHERE WI_NAME = '"+processInstanceID+"'";
			inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionId);
			logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML);
			outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
			String itemIndex = outputXML.substring(outputXML.indexOf("ITEMINDEX")+10, outputXML.indexOf("</ITEMINDEX>"));
			
			winame="{"
					+ "\"processinstanceId\":"+"\""+processInstanceID+"\","
					+ "\"folderIndex\":"+"\""+itemIndex+"\","
					+ "\"MainCode\":"+"0"
					+ "}";
			
		}
		else
			winame="{"
					+ "\"Message\":"+"\"processinstanceId not found for Policy: "+policyNo+"\","
					+ "\"MainCode\":"+"404"
					+ "}";
		return winame;
	}
}
