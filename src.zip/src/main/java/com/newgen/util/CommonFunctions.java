package com.newgen.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Properties;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.omni.wf.util.app.NGEjbClient;
import com.newgen.omni.wf.util.excp.NGException;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;


@SuppressWarnings("deprecation")
public class CommonFunctions {
	public static String connectout;
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger("CommonFunctions");

	/*
	 * public String addDocument(InputStream incomingData) throws
	 * FileNotFoundException, IOException { propertiesFileData = new Properties();
	 * Properties props = new Properties();
	 * 
	 * String configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\log4j.properties"; props.load(new
	 * FileInputStream(configPath)); PropertyConfigurator.configure(props);
	 * 
	 * configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\config.properties"; FileReader reader = new
	 * FileReader(configPath);
	 * 
	 * logger.info("configPath: "+configPath);
	 * 
	 * propertiesFileData = new Properties(); propertiesFileData.load(reader);
	 * 
	 * String cabinetName = propertiesFileData.getProperty("cabinetName"); String
	 * ipAddress = propertiesFileData.getProperty("ipAddress"); String username =
	 * propertiesFileData.getProperty("username"); String password =
	 * propertiesFileData.getProperty("password"); String volID =
	 * propertiesFileData.getProperty("volID");
	 * 
	 * StringBuilder inputJSON = new StringBuilder(); String result = ""; try {
	 * BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
	 * String line = null; while ((line = in.readLine()) != null) {
	 * inputJSON.append(line); }
	 * 
	 * logger.info("Data Received: " + inputJSON.toString()); String
	 * DocumentName="",ProposalNumber="",DocumentCategory="",documentData="",
	 * createdByAppName="", DocumentNameOD=""; String
	 * folderIndex="",documentDetailsJSON;
	 * 
	 * String outputXML="",inputXML="",query=""; String proposalFolderIndex="";
	 * 
	 * //documentDetailsJSON=
	 * "{\"DocumentName\":\"test.txt\",\"ProposalNumber\":\"123456789\",\"DocumentCategory\":\"Others\",\"DocumentData\":\"dGVzdERhdGE=\"}";
	 * documentDetailsJSON=inputJSON.toString();
	 * 
	 * JSONParser jsonParser = new JSONParser(); JSONObject json = (JSONObject)
	 * jsonParser.parse(documentDetailsJSON);
	 * 
	 * ProposalNumber = (String) json.get("ProposalNumber");
	 * query="SELECT itemindex FROM NG_NB_EXT_TABLE(NOLOCK) WHERE Proposal_Number = '"
	 * + ProposalNumber +"' ";
	 * 
	 * //getting sessionID // inputXML =
	 * XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // String sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML);
	 * 
	 * String sessionIDJSON = json.get("SessionID").toString(); String sessionID="";
	 * if(!sessionIDJSON.equalsIgnoreCase("")&&sessionIDJSON!=null) { sessionID =
	 * sessionIDJSON; } else sessionID = getSessionID();
	 * 
	 * //select call inputXML =
	 * XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
	 * logger.info(inputXML+" "+ProposalNumber); //outputXML =
	 * WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); outputXML =
	 * callRestAPI_JTS(inputXML);
	 * 
	 * //WI already exists for given Proposal number
	 * if(outputXML.indexOf("<itemindex>")!=-1) { folderIndex =
	 * outputXML.substring(outputXML.indexOf("<itemindex>")+11,outputXML.indexOf(
	 * "</itemindex>")); //attaching documents to WI corresponding to the given
	 * Proposal Number JSONArray DocumentsArray;
	 * DocumentsArray=(JSONArray)json.get("Documents");
	 * 
	 * for (Object j : DocumentsArray) { JSONObject jsonObj=(JSONObject)j;
	 * //attributesXML = attributesXML + DocumentCategory = (String)
	 * jsonObj.get("DocumentCategory"); documentData = (String)
	 * jsonObj.get("DocumentDataBase64"); DocumentName = (String)
	 * jsonObj.get("DocumentName");
	 * 
	 * createdByAppName = DocumentName.substring(DocumentName.indexOf(".")+1,
	 * DocumentName.length()); DocumentNameOD = DocumentName.substring(0,
	 * DocumentName.indexOf(".")); //changed here by prakhar String docData =
	 * "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ngo=\"http://bdo.ws.jts.omni.newgen.com/NGOAddDocumentService/\"><soapenv:Header/><soapenv:Body>"
	 * + "<ngo:NGOAddDocumentBDO>" + "<cabinetName>"+cabinetName+"</cabinetName>" +
	 * "<documentPath></documentPath>" +
	 * "<folderIndex>"+folderIndex+"</folderIndex>" //+
	 * "<folderIndex>"+""+"</folderIndex>" +
	 * "<documentName>"+DocumentCategory+"."+createdByAppName+"</documentName>" +
	 * "<userDBId>"+sessionID+"</userDBId>" + "<volumeId>"+volID+"</volumeId>" +
	 * "<creationDateTime></creationDateTime>" + "<versionFlag>N</versionFlag>" +
	 * "<accessType>S</accessType>" + "<documentType>N</documentType>" +
	 * "<createdByAppName>"+createdByAppName+"</createdByAppName>" +
	 * "<enableLog>Y</enableLog>" + "<comment>"+DocumentNameOD+"</comment>" +
	 * "<author></author>" + "<FTSFlag>Y</FTSFlag>" + "<groupIndex></groupIndex>" +
	 * "<ownerIndex></ownerIndex>" + "<nameLength></nameLength>" +
	 * "<duplicateName></duplicateName>" + "<textAlsoFlag></textAlsoFlag>" +
	 * "<imageData></imageData>" +
	 * "<transactionRequired></transactionRequired><ownerType></ownerType>" +
	 * "<signFlag></signFlag><thumbNailFlag></thumbNailFlag>" +
	 * "<userName></userName>" +
	 * "<encrFlag></encrFlag><passAlgoType></passAlgoType>" +
	 * "<userPassword></userPassword>" + "<document>"+documentData+"</document>" +
	 * "</ngo:NGOAddDocumentBDO></soapenv:Body></soapenv:Envelope>"; String
	 * docResult = uploadDoc(docData); //Inserting doc data to table String
	 * documentType="",isIndex="",noOfPages="",documentSize="",createdByApp="",
	 * comment="",createdDateTime="",
	 * proposalNumber="",DocIndex="",parentFolderIndex=""; documentType =
	 * docResult.substring(docResult.indexOf("<documentName>")+14,docResult.indexOf(
	 * "</documentName>")); isIndex =
	 * docResult.substring(docResult.indexOf("<isIndex>")+9,docResult.indexOf(
	 * "</isIndex>")); isIndex = isIndex.substring(0, isIndex.length() - 1);
	 * //removing last # noOfPages =
	 * docResult.substring(docResult.indexOf("<noOfPages>")+11,docResult.indexOf(
	 * "</noOfPages>")); documentSize =
	 * docResult.substring(docResult.indexOf("<documentSize>")+14,docResult.indexOf(
	 * "</documentSize>")); createdByApp =
	 * docResult.substring(docResult.indexOf("<createdByAppName>")+18,docResult.
	 * indexOf("</createdByAppName>")); comment =
	 * docResult.substring(docResult.indexOf("<comment>")+9,docResult.indexOf(
	 * "</comment>")); createdDateTime =
	 * docResult.substring(docResult.indexOf("<createdDateTime>")+17,docResult.
	 * indexOf("</createdDateTime>")); proposalNumber = ProposalNumber; DocIndex =
	 * docResult.substring(docResult.indexOf("<documentIndex>")+15,docResult.indexOf
	 * ("</documentIndex>")); parentFolderIndex =
	 * docResult.substring(docResult.indexOf("<parentFolderIndex>")+19,docResult.
	 * indexOf("</parentFolderIndex>"));
	 * 
	 * query =
	 * "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
	 * +
	 * " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
	 * + "VALUES ('"+documentType+"', '"+isIndex+"', '"+noOfPages+"', '"
	 * +documentSize+"', '"+createdByApp+"'," +
	 * " '"+comment+"', '"+createdDateTime+"', '"+proposalNumber+"', '"
	 * +DocIndex+"', '"+parentFolderIndex+"', 'Y')"; // //getting sessionID //
	 * inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML); //select call
	 * inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
	 * logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML); //outputXML
	 * = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); outputXML =
	 * callRestAPI_JTS(inputXML);
	 * logger.info("APSelectWithColumnNames_outputXML: "+outputXML);
	 * 
	 * 
	 * 
	 * result = result + docResult; logger.info(docData); logger.info(result); } }
	 * 
	 * //WI not exists for given Proposal Number else { //create a folder with the
	 * name of Proposal Number try { proposalFolderIndex =
	 * createFolder(ProposalNumber,sessionID);
	 * 
	 * if(proposalFolderIndex.indexOf("Error")==-1) { JSONArray DocumentsArray;
	 * DocumentsArray=(JSONArray)json.get("Documents");
	 * 
	 * for (Object j : DocumentsArray) { JSONObject jsonObj=(JSONObject)j;
	 * //attributesXML = attributesXML + DocumentCategory = (String)
	 * jsonObj.get("DocumentCategory"); documentData = (String)
	 * jsonObj.get("DocumentDataBase64"); DocumentName = (String)
	 * jsonObj.get("DocumentName");
	 * 
	 * createdByAppName = DocumentName.substring(DocumentName.indexOf(".")+1,
	 * DocumentName.length()); DocumentNameOD = DocumentName.substring(0,
	 * DocumentName.indexOf(".")); //changed by Prakhar String docData =
	 * "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ngo=\"http://bdo.ws.jts.omni.newgen.com/NGOAddDocumentService/\"><soapenv:Header/><soapenv:Body>"
	 * + "<ngo:NGOAddDocumentBDO>" + "<cabinetName>"+cabinetName+"</cabinetName>" +
	 * "<documentPath></documentPath>" +
	 * "<folderIndex>"+proposalFolderIndex+"</folderIndex>" //+
	 * "<folderIndex>"+""+"</folderIndex>" +
	 * "<documentName>"+DocumentCategory+"."+createdByAppName+"</documentName>" +
	 * "<userDBId>"+sessionID+"</userDBId>" + "<volumeId>"+volID+"</volumeId>" +
	 * "<creationDateTime></creationDateTime>" + "<versionFlag>Y</versionFlag>" +
	 * "<accessType>S</accessType>" + "<documentType>N</documentType>" +
	 * "<createdByAppName>"+createdByAppName+"</createdByAppName>" +
	 * "<enableLog>Y</enableLog>" + "<comment>"+DocumentNameOD+"</comment>" +
	 * "<author></author>" + "<FTSFlag>Y</FTSFlag>" + "<groupIndex></groupIndex>" +
	 * "<ownerIndex></ownerIndex>" + "<nameLength></nameLength>" +
	 * "<duplicateName></duplicateName>" + "<textAlsoFlag></textAlsoFlag>" +
	 * "<imageData></imageData>" +
	 * "<transactionRequired></transactionRequired><ownerType></ownerType>" +
	 * "<signFlag></signFlag><thumbNailFlag></thumbNailFlag>" +
	 * "<userName></userName>" +
	 * "<encrFlag></encrFlag><passAlgoType></passAlgoType>" +
	 * "<userPassword></userPassword>" + "<document>"+documentData+"</document>" +
	 * "</ngo:NGOAddDocumentBDO></soapenv:Body></soapenv:Envelope>"; String
	 * docResult = uploadDoc(docData);
	 * 
	 * //Inserting doc data to table String
	 * documentType="",isIndex="",noOfPages="",documentSize="",createdByApp="",
	 * comment="",createdDateTime="",
	 * proposalNumber="",DocIndex="",parentFolderIndex=""; documentType =
	 * docResult.substring(docResult.indexOf("<documentName>")+14,docResult.indexOf(
	 * "</documentName>")); isIndex =
	 * docResult.substring(docResult.indexOf("<isIndex>")+9,docResult.indexOf(
	 * "</isIndex>")); isIndex = isIndex.substring(0, isIndex.length() - 1);
	 * //removing last # noOfPages =
	 * docResult.substring(docResult.indexOf("<noOfPages>")+11,docResult.indexOf(
	 * "</noOfPages>")); documentSize =
	 * docResult.substring(docResult.indexOf("<documentSize>")+14,docResult.indexOf(
	 * "</documentSize>")); createdByApp =
	 * docResult.substring(docResult.indexOf("<createdByAppName>")+18,docResult.
	 * indexOf("</createdByAppName>")); comment =
	 * docResult.substring(docResult.indexOf("<comment>")+9,docResult.indexOf(
	 * "</comment>")); createdDateTime =
	 * docResult.substring(docResult.indexOf("<createdDateTime>")+17,docResult.
	 * indexOf("</createdDateTime>")); proposalNumber = ProposalNumber; DocIndex =
	 * docResult.substring(docResult.indexOf("<documentIndex>")+15,docResult.indexOf
	 * ("</documentIndex>")); parentFolderIndex =
	 * docResult.substring(docResult.indexOf("<parentFolderIndex>")+19,docResult.
	 * indexOf("</parentFolderIndex>"));
	 * 
	 * query =
	 * "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
	 * +
	 * " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
	 * + "VALUES ('"+documentType+"', '"+isIndex+"', '"+noOfPages+"', '"
	 * +documentSize+"', '"+createdByApp+"'," +
	 * " '"+comment+"', '"+createdDateTime+"', '"+proposalNumber+"', '"
	 * +DocIndex+"', '"+parentFolderIndex+"', 'N')"; // //getting sessionID //
	 * inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML); //select call
	 * inputXML = XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
	 * logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML); //outputXML
	 * = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); outputXML =
	 * callRestAPI_JTS(inputXML);
	 * logger.info("APSelectWithColumnNames_outputXML: "+outputXML);
	 * 
	 * 
	 * result = result + docResult; logger.info("docResult: "+docResult); //
	 * logger.info(result); } } else return "{\r\n" + "	\"Exception\":\r\n" +
	 * "		{\r\n" + "			\"statusCode\": 1,\r\n" +
	 * "			\"Subject\":\""+proposalFolderIndex+"\"\r\n"+ "		}\r\n" +
	 * "}";
	 * 
	 * //disconnecting user logger.info("Disconnecting User..."); String ipXML =
	 * XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
	 * logger.info("ipXMLDisconnect_inputXML: "+ipXML); //String outputXML =
	 * WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); String opXML =
	 * callRestAPI_JTS(ipXML); logger.info("ipXMLDisconnect_outputXML: "+opXML); }
	 * catch(Exception ex) { ex.printStackTrace(); } }
	 * 
	 * } catch (Exception e) { logger.info(e.toString()); }
	 * 
	 * //converting xml to json org.json.JSONObject jsonObj = null; try { jsonObj =
	 * XML.toJSONObject(result); } catch (JSONException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } try { result = jsonObj.toString(4); }
	 * catch (JSONException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); }
	 * 
	 * return result; }
	 * 
	 */

	public static String createFolder(String proposalNumber, String sessionID) throws IOException, Exception {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");
		String folderIndexParent = propertiesFileData.getProperty("parentFolderIndex");

		// TODO Auto-generated method stub
		String inputXML = "", outputXML = "", folderIndex = "", result = "";

//		inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//         logger.info("get_WMConnect_Input_inputXML: "+inputXML);
//        //outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
//        outputXML = callRestAPI_JTS(inputXML);
//        sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));
//         logger.info("get_WMConnect_Input_outputXML: "+outputXML);

		if (sessionID != "" || sessionID != null) {
			inputXML = XMLGen.NGAddFolder(cabinetName, sessionID, folderIndexParent, proposalNumber);
			logger.info("NGAddFolder_inputXML: " + inputXML);
			// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);

			outputXML = ExecuteAPI_OD(inputXML);
			logger.info("NGAddFolder_outputXML: " + outputXML);

			folderIndex = outputXML.substring(outputXML.indexOf("<FolderIndex>") + 13,
					outputXML.indexOf("</FolderIndex>"));
			if (folderIndex != "" || folderIndex != null)
				result = folderIndex;
			else
				result = "Error in creating folder. Check OD logs!";
		} else
			result = "Session ID Not Found!";

		return result;
	}

	private String deleteFolder(String proposalNumber) throws IOException, Exception {

		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");
		String folderIndexParent = propertiesFileData.getProperty("parentFolderIndex");

		String inputXML = "", outputXML = "", sessionID = "", folderIndex = "", result = "", statusCode = "";

		inputXML = XMLGen.get_WMConnect_Input(cabinetName, username, password, "N");
		logger.info("get_WMConnect_Input_inputXML: " + inputXML);
		// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
		outputXML = callRestAPI_JTS(inputXML);
		sessionID = outputXML.substring(outputXML.indexOf("<SessionId>") + 11, outputXML.indexOf("</SessionId>"));
		logger.info("get_WMConnect_Input_outputXML: " + outputXML);

		// getting folder index
		String query = "SELECT folderindex FROM PDBFolder(nolock) WHERE Name = '" + proposalNumber + "' ";
		// getting sessionID
		inputXML = XMLGen.get_WMConnect_Input(cabinetName, username, password, "N");
		logger.info("get_WMConnect_Input_inputXML: " + inputXML);
		outputXML = callRestAPI_JTS(inputXML);
		sessionID = outputXML.substring(outputXML.indexOf("<SessionId>") + 11, outputXML.indexOf("</SessionId>"));
		logger.info("get_WMConnect_Input_outputXML: " + outputXML);
		// select call
		inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		logger.info(inputXML + " " + proposalNumber);
		// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
		outputXML = callRestAPI_JTS(inputXML);
		folderIndex = outputXML.substring(outputXML.indexOf("<folderindex>") + 13, outputXML.indexOf("</folderindex>"));

		if (sessionID != "" || sessionID != null) {
			inputXML = XMLGen.NGDeleteFolder(cabinetName, sessionID, folderIndexParent, folderIndex);
			logger.info("NGDeleteFolder_inputXML: " + inputXML);
			// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
			// outputXML = callRestAPI_JTS(inputXML);
			outputXML = ExecuteAPI_OD(inputXML);
			logger.info("NGDeleteFolder_outputXML: " + outputXML);

			statusCode = outputXML.substring(outputXML.indexOf("<Status>") + 8, outputXML.indexOf("</Status>"));
			if (statusCode.equalsIgnoreCase("0"))
				result = outputXML;
			else
				result = "Error in creating folder. Check OD logs!";
		} else
			result = "Error in connect call!";

		return result;
	}

	/*
	 * 
	 * public String createWI(InputStream incomingData) throws IOException,
	 * Exception { propertiesFileData = new Properties(); Properties props = new
	 * Properties();
	 * 
	 * String configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\log4j.properties"; props.load(new
	 * FileInputStream(configPath)); PropertyConfigurator.configure(props);
	 * 
	 * configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\config.properties"; FileReader reader = new
	 * FileReader(configPath);
	 * 
	 * logger.info("configPath: "+configPath);
	 * 
	 * propertiesFileData = new Properties(); propertiesFileData.load(reader);
	 * 
	 * String cabinetName = propertiesFileData.getProperty("cabinetName"); String
	 * ipAddress = propertiesFileData.getProperty("ipAddress"); String username =
	 * propertiesFileData.getProperty("username"); String password =
	 * propertiesFileData.getProperty("password");
	 * 
	 * StringBuilder inputJSON = new StringBuilder(); try { BufferedReader in = new
	 * BufferedReader(new InputStreamReader(incomingData)); String line = null;
	 * while ((line = in.readLine()) != null) { inputJSON.append(line); } } catch
	 * (Exception e) { logger.info("Error Parsing: - "); }
	 * 
	 * logger.info("Data Received: " + inputJSON.toString());
	 * 
	 * 
	 * //String sessionID="",result=""; //wiData =
	 * "{\"documentData\": \"\",\"QC\": {\"ProposerDetails\": {  \"Salutation\": \"Mr.\",  \"FirstName\": \"Prakhar\"\"MiddleName\": \"Saxena\"},\"LifeInsuredDetails	\": {  \"Salutation\": \"Mr.\",  \"InsuredFirstName\": \"Prakhar\"\"MiddleName\": \"Saxena\"}},\"PolicyAgenCustomerInfo\": {\"AgentdDetails\": {  \"AgentCode\": \"Mr.\",  \"GOCode\": \"Prakhar\"\"AgentName\": \"Saxena\"},\"Policy Details\": {  \"ProductName\": \"Mr.\",  \"Need\": \"Prakhar\"\"LifeStage\": \"Saxena\"}}}"
	 * ; //wiData =
	 * "{\"documentData\": \"\",\"PolicyAgenCustomerInfo\": {\"AgentdDetails\": {  \"AgentCode\": \"Mr.\",  \"GOCode\": \"Prakhar\",\"AgentName\": \"Saxena\"},\"Policy Details\": {  \"ProductName\": \"Mr.\",  \"Need\": \"Prakhar\",\"LifeStage\": \"Saxena\"}}}"
	 * ; //String wiData =
	 * "{  \"documentData\": \"\",\"QC_Summary\": {      \"ProposerDetails\": {    \"Salutation\": \"Mr\",    \"FirstName\": \"Prakhar\",\"MiddleName\": \"Saxena\",\"LastName\": \"lastNameTest\",\"Address\": \"testAddress\"  },\"LifeInsuredDetails\": {    \"Salutation\": \"Mr\",    \"InsuredFirstName\": \"Prakhar\",\"MiddleName\": \"Saxena\",\"LastName\": \"testLastName\",\"TotalSumAssured\" : \"100\"  },\"PayorDetails\": {    \"Salutation\": \"Mr\",    \"PayorFirstName\": \"Prakhar\",\"MiddleName\": \"Saxena\",\"LastName\": \"testLastName\",\"BankNameECS\" : \"testBankNameECS\"  }      },\"PolicyAgentCustomerInfo\": {      \"AgentDetails\": {    \"AgentCode\": \"Mr\",    \"GOCode\": \"Prakhar\",\"AgentName\": \"Saxena\",\"AgentContactNumber\": \"9458407777\",\"BranchName\": \"testBranchName\",\"AgentStatus\": \"testAgentStatus\"  },\"PolicyDetails\": {    \"ProductName\": \"SmartTerm\",    \"Need\": \"random1\",\"LifeStage\": \"random1\"  }    },\"PersonalInformation\": {      \"ProposerDetails\": {    \"ClientType\": \"Company\",    \"Title\": \"Mr\",\"FirstName\": \"testFirstName\",\"MiddleName\": \"testMiddleName\",\"LastName\": \"testLastName\",\"PanNumber\": \"18784565\"  },\"L2BIDetails\": {    \"ClientType\": \"SmartTerm\",    \"FirstName\": \"testFirstName\",\"MiddleName\": \"testMiddleName\",\"LastName\": \"testLastName\",\"MaritalStatus\": \"Single\",\"IncomeSource\": \"Others\",\"ExactIncome\": \"100\"  },\"NomineeDetails\": {    \"ClientType\": \"company\",\"Title\": \"Mr\",    \"FirstName\": \"testFirstName\",\"MiddleName\": \"testMiddleName\",\"LastName\": \"testLastName\"	    }     }}"
	 * ; String wiData=inputJSON.toString(); //ipAddress = "192.168.54.97"; //
	 * String method = "POST"; // String url =
	 * "http://"+ipAddress+":9090/iBPSRestFulWebServices/ibps/Restful/"+cabinetName+
	 * "/WMConnect/?userName="+username+"&UserExist=N"; // // HashMap<String,
	 * String> hm = new HashMap<>(); // hm.put("Password", password); // //
	 * sessionID=callRestAPI(url, method, hm); //
	 * if(sessionID.indexOf("<SessionId>")==-1) { // result = "Invalid Session ID!";
	 * // return result; // } // else { // sessionID =
	 * sessionID.substring(sessionID.indexOf("<SessionId>")+11,
	 * sessionID.indexOf("</SessionId>")); // JSONParser jsonParser = new
	 * JSONParser(); JSONObject json = (JSONObject) jsonParser.parse(wiData); String
	 * sessionIDJSON = json.get("SessionID").toString(); String sessionID="";
	 * if(!sessionIDJSON.equalsIgnoreCase("") && sessionIDJSON!=null) { sessionID =
	 * sessionIDJSON; } else sessionID = getSessionID();
	 * 
	 * String result=""; try { result = uploadWI (sessionID,wiData); } catch
	 * (ParseException e) { // TODO Auto-generated catch block e.printStackTrace();
	 * }
	 * 
	 * //} return result; }
	 */
	public static String callRestAPI(String url, String method, HashMap<String, String> request) {
		URL urlForGetRequest;
		// String data = "";
		String readLine = null;
		String returnJSON = "", returnVal = null;
		HttpURLConnection conection;

		try {
			urlForGetRequest = new URL(url);
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod(method);

			// logger.info(url);
			// logger.info(method);
			for (String i : request.keySet()) {
				conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
			}
			// conection.setRequestProperty("Authorization", "Basic
			// YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp");
			// // set userId its a sample here
			// conection.setRequestProperty("Content-Type",
			// "application/x-www-form-urlencoded"); // set userId its a sample here

			conection.setDoOutput(true);

			/*
			 * if (method.equalsIgnoreCase("POST")) {
			 * 
			 * data = "grant_type=openapi_2lo"; OutputStreamWriter obj = new
			 * OutputStreamWriter(conection.getOutputStream()); obj.write(data);
			 * obj.close();
			 * 
			 * }
			 */
			/*
			 * else if(method.equalsIgnoreCase("GET")) { apiCount++;
			 * logger.info("API Count " + apiCount); }
			 */

			int responseCode = conection.getResponseCode();
			logger.info(responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				returnJSON = response.toString();
				// logger.info("JSON String Result " + response.toString());
				returnVal = returnJSON;
			} else {

				// Ariba disconnectUser = new Ariba();
				// disconnectUser.disconnectUser();
				returnVal = "ERROR";
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return returnVal;
	}

	public static String disconnectUser(String seesionID) throws FileNotFoundException, IOException {

		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");

		String url = "http://" + ipAddress +":"+port +"/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
				+ "/WMDisconnect?userName=" + username + "";
		String method = "POST";
		HashMap<String, String> hm = new HashMap<>();
		hm.put("sessionId", seesionID);
		String disconnectUserXML = callRestAPI(url, method, hm);
		System.out.println("disconnectUserXML: " + disconnectUserXML);
		return disconnectUserXML;

	}

	public static String callRestAPI(String url, String method, String WFUploadWorkItem_XML,
			HashMap<String, String> request) {
		URL urlForGetRequest;
		// String data = "";
		String readLine = null;
		String returnJSON = "", returnVal = null;
		HttpURLConnection conection;
		try {
			urlForGetRequest = new URL(url);
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod(method);

			// logger.info(url);
			// logger.info(method);
			for (String i : request.keySet()) {
				conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
			}
			// conection.setRequestProperty("Authorization", "Basic
			// YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp");
			// // set userId its a sample here
			// conection.setRequestProperty("Content-Type",
			// "application/x-www-form-urlencoded"); // set userId its a sample here

			conection.setDoOutput(true);

			if (method.equalsIgnoreCase("POST")) {

				String data = WFUploadWorkItem_XML;
				OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
				obj.write(data);
				obj.close();

			}
			/*
			 * else if(method.equalsIgnoreCase("GET")) { apiCount++;
			 * logger.info("API Count " + apiCount); }
			 */

			int responseCode = conection.getResponseCode();
			logger.info(responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				returnJSON = response.toString();
				// logger.info("JSON String Result " + response.toString());
				returnVal = returnJSON;
			} else {

				// Ariba disconnectUser = new Ariba();
				// disconnectUser.disconnectUser();
				returnVal = "ERROR";
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return returnVal;
	}

	public static String callRestAPI_JTS_old(String Body_XML) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		//logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");

		URL urlForGetRequest;
		String readLine = null;
		String returnJSON = "", returnVal = null;
		HttpURLConnection conection;

		String method = "POST";
		// ipAddress = "192.168.54.97";
		String url = "http://" + ipAddress + ":"+port+"/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
				+ "/WFUploadWorkItem";
		HashMap<String, String> request = new HashMap<>();
		request.put("Content-Type", "application/xml");

		try {
			urlForGetRequest = new URL(url);
			conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod(method);

			for (String i : request.keySet()) {
				conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
			}

			conection.setDoOutput(true);

			if (method.equalsIgnoreCase("POST")) {
				String data = Body_XML;
				OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
				obj.write(data);
				obj.close();
			}

			int responseCode = conection.getResponseCode();
			//logger.info(responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				returnJSON = response.toString();
				returnVal = returnJSON;
			} else {
				returnVal = "ERROR";
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return returnVal;
	}

	/*
	 * Added by Prakhar to make JTS calls without Wrapper and Rest Service
	 */
	public static String callRestAPI_JTS(String Body_XML) throws FileNotFoundException, IOException{
		String outputXML="";
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);
		propertiesFileData = new Properties();
		propertiesFileData.load(reader);
		
		String port = propertiesFileData.getProperty("port");
		logger.info("callRestAPI_JTS_inputXML: " + Body_XML);
		try {
			outputXML = NGEjbClient.getSharedInstance().makeCall("127.0.0.1", port, "JBossEAP", Body_XML);
			logger.info("port: " + port);
		} catch (NGException e) {
			e.printStackTrace();
		}
		System.out.println("outputXML: " + outputXML);
		logger.info("callRestAPI_JTS_outputXML: " + outputXML);
		return outputXML;
		
	}
	
	/*
	 * @SuppressWarnings("unused") public static String uploadWI(String sessionID,
	 * String wiData) throws IOException, Exception { propertiesFileData = new
	 * Properties(); Properties props = new Properties();
	 * 
	 * String configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\log4j.properties"; props.load(new
	 * FileInputStream(configPath)); PropertyConfigurator.configure(props);
	 * 
	 * configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\config.properties"; FileReader reader = new
	 * FileReader(configPath);
	 * 
	 * logger.info("configPath: "+configPath);
	 * 
	 * propertiesFileData = new Properties(); propertiesFileData.load(reader);
	 * 
	 * String cabinetName = propertiesFileData.getProperty("cabinetName"); String
	 * ipAddress = propertiesFileData.getProperty("ipAddress"); String username =
	 * propertiesFileData.getProperty("username"); String password =
	 * propertiesFileData.getProperty("password"); String processDefId =
	 * propertiesFileData.getProperty("processDefId"); String volID =
	 * propertiesFileData.getProperty("volID");
	 * 
	 * String attributesXML = "",wfuploadXML=""; JSONParser jsonParser = new
	 * JSONParser(); JSONObject json = (JSONObject) jsonParser.parse(wiData);
	 * JSONObject jsonValidate=new JSONObject();
	 * 
	 * //Variables Declaration //QC_Summary->ProposerDetails String Prop_Salutation
	 * = "", Prop_FirstName = "", Prop_MiddleName = "", Prop_LastName = "",
	 * Prop_Address = "", Prop_DOB = "", Prop_Gender = "", Prop_Mobile = "",
	 * Prop_Email = "", Prop_PAN = "", Prop_FatherName = "", Prop_TotalAFYP = "",
	 * Prop_BankName = "", Prop_AccountNo = "", Prop_IFSC = "", Prop_CKYC = "",
	 * Proposer_Tag1 = "", Proposer_Tag2 = "", Proposer_Tag3 = "", Proposer_Tag4 =
	 * "", Proposer_Reason1 = "", Proposer_Reason2 = "", Proposer_Reason3 = "",
	 * Proposer_Reason4 = ""; //QC_Summary->LifeInsuredDetails String
	 * Insured_Salutation = "", Insured_FirstName = "", Insured_MiddleName = "",
	 * Insured_LastName = "", Insured_Gender = "", Insured_TSA = "", Insured_DOB =
	 * "", Insured_Tag1 = "", Insured_Tag2 = "", Insured_Tag3 = "", Insured_Tag4 =
	 * "", Insured_Reason1 = "", Insured_Reason2 = "", Insured_Reason3 = "",
	 * Insured_Reason4 = ""; //QC-Summary->PayorDetails String Payor_salutation =
	 * "", Payor_FirstName = "", Payor_MiddleName = "", Payor_LastName = "",
	 * Payor_PAN = "", Payor_Address = "", Payor_Gender = "", Payor_BankName = "",
	 * Payor_AccountNo = "", Payor_IFSC = "", Payor_DOB = "", Payor_Tag1 = "",
	 * Payor_Tag2 = "", Payor_Tag3 = "", Payor_Tag4 = "", Payor_Reason1 = "",
	 * Payor_Reason2 = "", Payor_Reason3 = "", Payor_Reason4 = "";
	 * //PolicyAgentCustomerInfo->AgentDetails String Agent_Code = "", GO_code = "",
	 * Agent_Name = "", Agent_Contact_Number = "", Branch_Name = "", Channel = "",
	 * Agent_Joining_Date = "", Agent_Status = "", Current_AML_Start_Date = "",
	 * Current_AML_End_Date = "", Previous_AML_Start_Date = "",
	 * Previous_AML_End_Date = "", Current_ULIP_Start_Date = "",
	 * Current_ULIP_End_Date = "", Previous_ULIP_Start_Date = "",
	 * Previous_ULIP_End_Date = "", Reporting_Manager_Code = "",
	 * Reporting_Manager_Name = ""; //PolicyAgentCustomerInfo->PolicyDetails String
	 * Product_Name = "", Objective_of_insurance = "", Need = "", Life_Stage = "",
	 * Proposal_No = "", mPRO_initiation_date = "", App_Recvd_date_from_mPRO = "",
	 * Rural_urban_Social = "", Product_Solution = "", Combo_Proposal_Number = "",
	 * Previous_Proposal_Number = "", Source_of_Sale = "", SPARC_lead_Source = "",
	 * QROPS = ""; //PolicyAgentCustomerInfo->CEIPDetails String Business_Type = "",
	 * BDM_id = "", Enroller_id = "", Finder_id = "", Name_of_company = "";
	 * //PolicyAgentCustomerInfo->DefenceDetails String Defence_Channel_Case = "",
	 * Army_Number = "", Unit_Name = "";
	 * //PolicyAgentCustomerInfo->CustomerInformation String Customer_Sign_Date =
	 * "", Customer_ID = "", Customer_classification = "",
	 * YBL_Customer_Classification = "", Is_this_a_replacement_policy_sale = "";
	 * //PolicyAgentCustomerInfo->AgentInformation String Agent_Sign_Date = "",
	 * Agent_Code2 = "", Agent_Name2 = "", Commission_Share = "", SP_CERTIFICATE_NO
	 * = "", SOL_ID = "", SSN_code = "", Application_ID = "", WMS_Sr_No = "",
	 * Application_Received_Prior = ""; //PolicyAgentCustomerInfo->Customer String
	 * INVESTOR_RISK_PROFILE_SCORE=""; //PersonalInformation->ProposerDetails
	 * //adhaar ack number issue String Q_Personal_Proposer_Details_Client_type =
	 * "", Q_Personal_Proposer_Details_Title =
	 * "",Q_Personal_Proposer_Details_Last_Name="",
	 * Q_Personal_Proposer_Details_Please_Specify = "",
	 * Q_Personal_Proposer_Details_First_Name = "",
	 * Q_Personal_Proposer_Details_Middle_Name = "",
	 * Q_Personal_Proposer_Details_FatherHusband_Name = "",
	 * Q_Personal_Proposer_Details_Date_of_Incorporation = "",
	 * Q_Personal_Proposer_Details_Date_of_Birth = "",
	 * Q_Personal_Proposer_Details_Pan_Number = "",
	 * Q_Personal_Proposer_Details_Applied_for = "",
	 * Q_Personal_Proposer_Details_Date_of_Application = "",
	 * Q_Personal_Proposer_Details_Application_Number = "",
	 * Q_Personal_Proposer_Details_Gender = "",
	 * Q_Personal_Proposer_Details_Nationality = "",
	 * Q_Personal_Proposer_Details_Business_Source = "",
	 * Q_Personal_Proposer_Details_Marital_Status = "",
	 * Q_Personal_Proposer_Details_Education = "",
	 * Q_Personal_Proposer_Details_Industry_Type_mPRO = "",
	 * Q_Personal_Proposer_Details_Please_Specify2 = "",
	 * Q_Personal_Proposer_Details_Organization_Type_mPRO = "",
	 * Q_Personal_Proposer_Details_Income_source = "",
	 * Q_Personal_Proposer_Details_Please_Specify3 = "",
	 * Q_Personal_Proposer_Details_Occupation_mPRO = "",
	 * Q_Personal_Proposer_Details_Please_Specify4 = "",
	 * Q_Personal_Proposer_Details_Exact_income = "",
	 * Q_Personal_Proposer_Details_Life_Proposer = "",
	 * Q_Personal_Proposer_Details_Country1 = "",
	 * Q_Personal_Proposer_Details_Please_Specify5 = "",
	 * Q_Personal_Proposer_Details_Pin_Code1 = "",
	 * Q_Personal_Proposer_Details_HouseNo_Society1 = "",
	 * Q_Personal_Proposer_Details_Road_Area_Sector1 = "",
	 * Q_Personal_Proposer_Details_Landmark1 = "",
	 * Q_Personal_Proposer_Details_Village_Town1 = "",
	 * Q_Personal_Proposer_Details_City_District1 = "",
	 * Q_Personal_Proposer_Details_State_UT1 = "",
	 * Q_Personal_Proposer_Details_MobileNo_1_1 = "",
	 * Q_Personal_Proposer_Details_MobileNo_2_1 = "",
	 * Q_Personal_Proposer_Details_LandlineNo_1_1 = "",
	 * Q_Personal_Proposer_Details_LandlineNo_2_1 = "",
	 * Q_Personal_Proposer_Details_LandlineNo_STD_1_1 = "",
	 * Q_Personal_Proposer_Details_LandlineNo_STD_2_1 =
	 * "",Q_Personal_Proposer_Details_EmailId = "",
	 * Q_Personal_Proposer_Details_Address_Proposer = "",
	 * Q_Personal_Proposer_Details_Date_of_Issue = "",
	 * Q_Personal_Proposer_Details_Date_of_Expiry = "",
	 * Q_Personal_Proposer_Details_ID_Proposer = "",
	 * Q_Personal_Proposer_Details_Proof_Number = "",
	 * Q_Personal_Proposer_Details_Date_IssueIdentity_Proof = "",
	 * Q_Personal_Proposer_Details_Date_expiry_Identity_Proof = "",
	 * Q_Personal_Proposer_Details_e_Insurance = "",
	 * Q_Personal_Proposer_Details_EIA_available = "",
	 * Q_Personal_Proposer_Details_EIA_Number = "",
	 * Q_Personal_Proposer_Details_Repositoryaccount_1 = "",
	 * Q_Personal_Proposer_Details_Annuity = "",
	 * Q_Personal_Proposer_Details_Aadhaar_Number = "",
	 * Q_Personal_Proposer_Details_Aadhaar_Enrol_Ack_number = "",
	 * Q_Personal_Proposer_Details_Company_Type = "",
	 * Q_Personal_Proposer_Details_Preferred_language_English = "";
	 * //PersonalInformation->L2BIDetails //Q_Personal_Other_Occupation issue String
	 * Q_Personal_Other_Client_type1 = "", Q_Personal_Other_Title1 = "",
	 * Q_Personal_Other_specify1 = "", Q_Personal_Other_First_Name1 = "",
	 * Q_Personal_Other_Middle_Name1 = "", Q_Personal_Other_Last_Name1 = "",
	 * Q_Personal_Other_Father_Husband_Name = "", Q_Personal_Other_Date_of_Birth1 =
	 * "", Q_Personal_Other_Gender1 = "", Q_Personal_Other_Relationship_with_insured
	 * = "", Q_Personal_Other_specify2 = "", Q_Personal_Other_Nationality1 = "",
	 * Q_Personal_Other_Business_Source = "", Q_Personal_Other_Marital_Status = "",
	 * Q_Personal_Other_Education = "", Q_Personal_Other_Industry_Type = "",
	 * Q_Personal_Other_Specify3 = "", Q_Personal_Other_Organization_Type = "",
	 * Q_Personal_Other_Income_source = "", Q_Personal_Other_Specify4 = "",
	 * Q_Personal_Other_Occupation = "", Q_Personal_Other_Specify5 = "",
	 * Q_Personal_Other_Exact_income = ""; //PersonalInformation->NomineeDetails
	 * String Q_Personal_Other_Client_type2 = "", Q_Personal_Other_select_value =
	 * "", Q_Personal_Other_Objective_Insurance = "", Q_Personal_Other_Title2 = "",
	 * Q_Personal_Other_Specify6 = "", Q_Personal_Other_First_Name2 = "",
	 * Q_Personal_Other_Middle_Name2 = "", Q_Personal_Other_Last_Name2 = "",
	 * Q_Personal_Other_DOB2 = "", Q_Personal_Other_Gender2 = "",
	 * Q_Personal_Other_Relationship_with_Nominee = "", Q_Personal_Other_Specify7 =
	 * "", Q_Personal_Other_Reason_for_Nomination = "",
	 * Q_Personal_Other_Percentage_share = "", Q_Personal_Other_Nominee_Type = "",
	 * Q_Personal_Other_Pan_Number = "", Q_Personal_Other_Applied_for = "",
	 * Q_Personal_Other_Date_of_Application = "",
	 * Q_Personal_Other_Application_Acknowledgement_Number = "",
	 * Q_Personal_Other_Nationality2 = "", Q_Personal_Other_please_select2 = "",
	 * Q_Personal_Other_Business_Source2 = "",
	 * Q_Personal_Other_Current_residential_Address = "",
	 * Q_Personal_Other_Same_as_Proposer2 = "", Q_Personal_Other_Country3 = "",
	 * Q_Personal_Other_specify9 = "", Q_Personal_Other_Pin_Code = "",
	 * Q_Personal_Other_HouseNo_Society = "", Q_Personal_Other_Road_Area_Sector =
	 * "", Q_Personal_Other_Landmark = "", Q_Personal_Other_Village_Town = "",
	 * Q_Personal_Other_City_District = "", Q_Personal_Other_State_UT = "",
	 * Q_Personal_Other_MobileNo_1 = "", Q_Personal_Other_MobileNo_2 = "",
	 * Q_Personal_Other_LandlineNo_1 = "", Q_Personal_Other_LandlineNo_2 = "",
	 * Q_Personal_Other_STD_LandlineNo_1 = "", Q_Personal_Other_STD_LandlineNo_2 =
	 * "", Q_Personal_Other_Email_Id = ""; //PersonalInformation->AppointeeDetails
	 * String Q_Personal_Other_First_Name3 = "", Q_Personal_Other_Middle_Name3 = "",
	 * Q_Personal_Other_Last_Name3 = "",
	 * Q_Personal_Other_Relationship_of_apointee_nominee = "",
	 * Q_Personal_Other_specify8 = ""; //PersonalInformation->ChildDetails String
	 * Q_Personal_Other_Client_type3 = "", Q_Personal_Other_Same_as_Nominee = "",
	 * Q_Personal_Other_First_Name4 = "", Q_Personal_Other_Middle_Name4 = "",
	 * Q_Personal_Other_Last_Name4 = "", Q_Personal_Other_DOB4 = "";
	 * //PersonalInformation->PolicyValidationsDetails String
	 * Q_Personal_Other_straight_pass_case = "", Q_Personal_Other_Dedupe_exact_match
	 * = "", Q_Personal_Other_PAN_authentication = "",
	 * Q_Personal_Other_ID_DOB_authentication = "", Q_Personal_Other_OCR_ID = "",
	 * Q_Personal_Other_DOB_ID = "", Q_Personal_Other_Pan_Status = "",
	 * Q_Personal_Other_Proof_of_Address = "",
	 * Q_Personal_Other_Income_proof_Proposer = "", Q_Personal_Other_Address_proof =
	 * "", Q_Personal_Other_OCR_address_proof = "", Q_Personal_Other_OCR_NACH = "",
	 * Q_Personal_Other_eNACH_eMandate = "", Q_Personal_Other_OCR_photograph = "",
	 * Q_Personal_Other_OCR_Cheque = "", Q_Personal_Other_Credit_Score = "",
	 * Q_Personal_Other_Income_segment = "", Q_Personal_Other_BSE = "";
	 * //ProductAndPaymentInfo -> Bank Details String
	 * B_A_No="",B_A_Holder_name="",B_MICR="",B_IFSC="",B_Bname_branch="",B_TypeOfB=
	 * ""; //ProductAndPaymentInfo -> Coverage Details String
	 * Q_COVERAGE_DETAILS_PRODUCT_NAME="",Q_COVERAGE_DETAILS_VESTING_AGE="",
	 * Q_COVERAGE_DETAILS_COVERAGE_TERM="",Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM="",
	 * Q_COVERAGE_DETAILS_PREMIUM_BACK="",Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE="",
	 * Q_COVERAGE_DETAILS_SUM_ASSURED="",Q_COVERAGE_DETAILS_DEATH_BENEFIT="",
	 * Q_COVERAGE_DETAILS_ATP="",Q_COVERAGE_DETAILS_MODE_OF_PAY="",
	 * Q_COVERAGE_DETAILS_MODAL_PREMIUM="",Q_COVERAGE_DETAILS_GST="",
	 * Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW="",Q_COVERAGE_DETAILS_EMP_DISCOUNT="",
	 * Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT="",Q_COVERAGE_DETAILS_SMOKER_CLASS=
	 * "",Q_COVERAGE_DETAILS_LIFE_EVENT="",Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME=
	 * "",Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME="",
	 * Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY="",Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD="",
	 * Q_COVERAGE_DETAILS_NON_FORFEITURE="",Q_COVERAGE_DETAILS_BONUS_OPTION="",
	 * Q_COVERAGE_DETAILS_EFFECTIVE_DATE=""; //ProductAndPaymentInfo -> Financial
	 * Information String
	 * Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds="",L_IncomeProof="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2=""; //ProductAndPaymentInfo ->
	 * Fund Selected String Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_FundName="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation=""; //ProductAndPaymentInfo ->
	 * NEFT Details String
	 * Payout_to_Account="",Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1="",Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1=
	 * "",Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2="",Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2=
	 * "",Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2=""; //ProductAndPaymentInfo ->
	 * Payment Details String Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived=""; //ProductAndPaymentInfo ->
	 * Renewal Premium Details String
	 * Q_PRODUCT_AND_PAYMENT_INFO_RenewalPremiumMethod="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CompanyName="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_BillDrawDate1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_payor_same1="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CCHolderName="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CreditCardNo="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CCExpiryDate="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_CreditcardType="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_ECS_datails="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_payor_same2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_MICRCode="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_AccountHolderName="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_BillDrawDate2="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_PayorisdifferentfromProposer="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Relationshipofpayorwithproposer="";
	 * //ProductAndPaymentInfo -> Payor Pan Details String
	 * Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Middle="",Q_PRODUCT_AND_PAYMENT_INFO_Last="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth="",Q_PRODUCT_AND_PAYMENT_INFO_Gender=
	 * "",Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber="",AppliedFor="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber="",
	 * Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId=""; //MedicalAndPreviousInfo
	 * ->Family Information String
	 * Q_Medical_AND_PREV_POLICY_INFO_Plan_Insured_Details="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Family_Diagonosed="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Family_Member="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Age_at_diagnosis="",
	 * Q_Medical_AND_PREV_POLICY_INFO_conditions=""; //MedicalAndPreviousInfo
	 * ->Female Information String Q_Medical_AND_PREV_POLICY_INFO_Spouse_Details="",
	 * Q_Medical_AND_PREV_POLICY_INFO_details5="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Occupation="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Income="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Insuranceamount="",
	 * Q_Medical_AND_PREV_POLICY_INFO_FullMaidenName="",
	 * Q_Medical_AND_PREV_POLICY_INFO_pregnant="",
	 * Q_Medical_AND_PREV_POLICY_INFO_months="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Areantenatalreportsattached="";
	 * //MedicalAndPreviousInfo ->Habit Questions String
	 * Q_Habit_tobacco="",Q_Habit_PanMasala="",Q_Habit_Cigarettes="",Q_Habit_Beedi=
	 * "",Q_Habit_Gutkha="",Q_Habit_alcohol="",Q_Habit_Beer="",Q_Habit_Wine="",
	 * Q_Habit_HardLiquor="",Q_Habit_drugs="",Q_Habit_Cannabis="",Q_Habit_Marijuana=
	 * "",Q_Habit_Ecstacy="",Q_Habit_Heroin="",Q_Habit_LSD="",Q_Habit_Amphetamines=
	 * "",Q_Habit_other="",Q_Habit_Quantity1="",Q_Habit_PerDay1="",
	 * Q_Habit_NoofYears1="",Q_Habit_Quantity2="",Q_Habit_Quantity3="",
	 * Q_Habit_Quantity4="",Q_Habit_PerDay2="",Q_Habit_PerDay3="",Q_Habit_PerDay4=""
	 * ,Q_Habit_NoofYears2="",Q_Habit_NoofYears3="",Q_Habit_NoofYears4="",
	 * Q_Habit_Quantity5="",Q_Habit_NoofYears5="",Q_Habit_Quantity6="",
	 * Q_Habit_Quantity7="",Q_Habit_NoofYears6="",Q_Habit_NoofYears7="",Q_Habit_Qty8
	 * ="",Q_Habit_NoofYears8="",Q_Habit_Qty9="",Q_Habit_Qty10="",Q_Habit_Qty11="",
	 * Q_Habit_Qty12="",Q_Habit_Qty13="",Q_Habit_Qty14="",Q_Habit_NoofYears9="",
	 * Q_Habit_NoofYears10="",Q_Habit_NoofYears11="",Q_Habit_NoofYears12="",
	 * Q_Habit_NoofYears13="",Q_Habit_NoofYears14=""; //MedicalAndPreviousInfo
	 * ->Height and weight String Q_Medical_AND_PREV_POLICY_INFO_Height_in="",
	 * Q_Medical_AND_PREV_POLICY_INFO_InFeet="",
	 * Q_Medical_AND_PREV_POLICY_INFO_InInches="",
	 * Q_Medical_AND_PREV_POLICY_INFO_InCms="",Q_Medical_AND_PREV_POLICY_INFO_Weight
	 * ="",Q_Medical_AND_PREV_POLICY_INFO_details6="",
	 * Q_Medical_AND_PREV_POLICY_INFO_change_in_weight="",
	 * Q_Medical_AND_PREV_POLICY_INFO_details7="",
	 * Q_Medical_AND_PREV_POLICY_INFO_ReasonforWeightChange="",
	 * Q_Medical_AND_PREV_POLICY_INFO_ByKg=""; //MedicalAndPreviousInfo ->Juvenille
	 * info String Q_Medical_AND_PREV_POLICY_INFO_child_vaccinations="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Details2="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Insurance_coverage_parents="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Details3="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Insurance_Siblings="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Details4="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Parents_Siblings_Insurance_ack="";
	 * //MedicalAndPreviousInfo ->Life Style String
	 * Q_Medical_AND_PREV_POLICY_INFO_hazardous_activities="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Specify="",
	 * Q_Medical_AND_PREV_POLICY_INFO_details="",
	 * Q_Medical_AND_PREV_POLICY_INFO_travel_abroad="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Country="",Q_Medical_AND_PREV_POLICY_INFO_City
	 * ="",Q_Medical_AND_PREV_POLICY_INFO_Purpose="",
	 * Q_Medical_AND_PREV_POLICY_INFO_DurationofStay="",
	 * Q_Medical_AND_PREV_POLICY_INFO_convicted="",
	 * Q_Medical_AND_PREV_POLICY_INFO_details1=""; //MedicalAndPreviousInfo
	 * ->Medical Questions String Q_Medical_AND_PREV_POLICY_INFO_Chest_pain="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Hypertension_Highbp="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Diabetes="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Asthma="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Hormonal_disorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_liver_disorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Congenital_disorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Cancer_tumoror_growth="",
	 * Q_Medical_AND_PREV_POLICY_INFO_kidney_disorder="",
	 * Q_Medical_AND_PREV_POLICY_INFO_epilepsy_psychiatricdisorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_ENT_disorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_back_arthritis_disorders="",
	 * Q_Medical_AND_PREV_POLICY_INFO_last5years_surgery="",
	 * Q_Medical_AND_PREV_POLICY_INFO_any_other_illness="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Hiv_Aids="",
	 * Q_Medical_AND_PREV_POLICY_INFO_OFFWORK="",
	 * Q_Medical_AND_PREV_POLICY_INFO_attaching_medical_form="";
	 * //MedicalAndPreviousInfo ->Other Medical info String
	 * Q_Medical_AND_PREV_POLICY_INFO_diagnosed_with_disability="",
	 * Q_Medical_AND_PREV_POLICY_INFO_hospitalized="",
	 * Q_Medical_AND_PREV_POLICY_INFO_familymember_diagnosed_before60="";
	 * //MedicalAndPreviousInfo ->Other Policy info String
	 * Q_Medical_AND_PREV_POLICY_INFO_insurance_pending="",
	 * Q_Medical_AND_PREV_POLICY_INFO_PolicyNumber="",
	 * Q_Medical_AND_PREV_POLICY_INFO_NameofCompany="",
	 * Q_Medical_AND_PREV_POLICY_INFO_YearofIssue="",
	 * Q_Medical_AND_PREV_POLICY_INFO_TypeofPolicy="",
	 * Q_Medical_AND_PREV_POLICY_INFO_TotalSumAssued="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Reason="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Statusofpolicy="",
	 * Q_Medical_AND_PREV_POLICY_INFO_insurance_refused="",
	 * Q_Medical_AND_PREV_POLICY_INFO_PolicyNumber1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_NameofCompany1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_YearofIssue1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_TypeofPolicy1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_TotalSumAssued1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Reason1="",
	 * Q_Medical_AND_PREV_POLICY_INFO_Statusofpolicy1="";
	 * 
	 * 
	 * //Flags tag JSONObject FlagsObj = (JSONObject)
	 * jsonParser.parse(json.get("Flags").toString()); attributesXML = attributesXML
	 * + "<DOCFLAG>"+FlagsObj.get("DOCFLAG").toString()+"</DOCFLAG>" +
	 * "<CC_FLAG>"+FlagsObj.get("CC_FLAG").toString()+"</CC_FLAG>" +
	 * "<DISCREPANCY_FLAG>"+FlagsObj.get("DISCREPANCY_FLAG").toString()+
	 * "</DISCREPANCY_FLAG>" +
	 * "<AUTO_UW_FLAG>"+FlagsObj.get("AUTO_UW_FLAG").toString()+"</AUTO_UW_FLAG>" +
	 * "<MED_KICKOUT_FLAG>"+FlagsObj.get("MED_KICKOUT_FLAG").toString()+
	 * "</MED_KICKOUT_FLAG>" +
	 * "<ADD_INFO_FLAG>"+FlagsObj.get("ADD_INFO_FLAG").toString()+"</ADD_INFO_FLAG>"
	 * + "<DECISION>"+FlagsObj.get("DECISION").toString()+"</DECISION>" +
	 * "<REQ_IN_FLAG>"+FlagsObj.get("REQ_IN_FLAG").toString()+"</REQ_IN_FLAG>" +
	 * "<PI_ATTACHED>"+FlagsObj.get("PI_ATTACHED").toString()+"</PI_ATTACHED>" +
	 * "<ULIP_CHECK>"+FlagsObj.get("ULIP_CHECK").toString()+"</ULIP_CHECK>"
	 * 
	 * + "<SOURCING_SYSTEM>"+FlagsObj.get("SOURCING_SYSTEM").toString()+
	 * "</SOURCING_SYSTEM>" +
	 * "<MONEY_STATUS>"+FlagsObj.get("MONEY_STATUS").toString()+"</MONEY_STATUS>" +
	 * "<COLLECTED_AMOUNT>"+FlagsObj.get("COLLECTED_AMOUNT").toString()+
	 * "</COLLECTED_AMOUNT>" +
	 * "<CLEARED_AMOUNT>"+FlagsObj.get("CLEARED_AMOUNT").toString()+
	 * "</CLEARED_AMOUNT>" +
	 * "<BOUNCE_AMOUNT>"+FlagsObj.get("BOUNCE_AMOUNT").toString()+"</BOUNCE_AMOUNT>"
	 * ;
	 * 
	 * //PolicyAgentCustomerInfo tab JSONObject PolicyAgentCustomerObj =
	 * (JSONObject)
	 * jsonParser.parse(json.get("PolicyAgentCustomerInfo").toString());
	 * 
	 * //AgentDetails Section //JSONObject AgentDetailsObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("AgentDetails").toString());
	 * 
	 * 
	 * JSONArray AgentDetailsArray;
	 * AgentDetailsArray=(JSONArray)PolicyAgentCustomerObj.get("AgentDetails"); int
	 * insertionOrderId=0,hashID=1;
	 * 
	 * for (Object j : AgentDetailsArray) { JSONObject jsonObj=(JSONObject)j;
	 * attributesXML = attributesXML + "<Q_LIST_AGENT_DETAILS>\r\n" +
	 * "<InsertionOrderId>"+insertionOrderId+"</InsertionOrderId>" + "<HashId>"+
	 * hashID++ +"</HashId>" +
	 * "<GO_CODE>"+jsonObj.get("GOCode").toString()+"</GO_CODE>" +
	 * "<AGENT_CONTACT_NUMBER>"+jsonObj.get("AgentContactNumber").toString()+
	 * "</AGENT_CONTACT_NUMBER>" +
	 * "<BRANCH_NAME>"+jsonObj.get("BranchName").toString()+"</BRANCH_NAME>" +
	 * "<CHANNEL>"+jsonObj.get("Channel").toString()+"</CHANNEL>" +
	 * "<AGENT_JOINING_DATE>"+jsonObj.get("AgentJoiningDate").toString()+
	 * "</AGENT_JOINING_DATE>" +
	 * "<AGENT_STATUS>"+jsonObj.get("AgentStatus").toString()+"</AGENT_STATUS>" +
	 * "<CURRENT_AML_START_DATE>"+jsonObj.get("CurrentAMLStartDate").toString()+
	 * "</CURRENT_AML_START_DATE>" +
	 * "<CURRENT_AML_END_DATE>"+jsonObj.get("CurrentAMLEndDate").toString()+
	 * "</CURRENT_AML_END_DATE>\r\n" +
	 * "<PREVIOUS_AML_START_DATE>"+jsonObj.get("PreviousAMLStartDate").toString()+
	 * "</PREVIOUS_AML_START_DATE>\r\n" +
	 * "<PREVIOUS_AML_END_DATE>"+jsonObj.get("PreviousAMLEndDate").toString()+
	 * "</PREVIOUS_AML_END_DATE>\r\n" +
	 * "<CURRENT_ULIP_START_DATE>"+jsonObj.get("CurrentULIPStartDate").toString()+
	 * "</CURRENT_ULIP_START_DATE>\r\n" +
	 * "<CURRENT_ULIP_END_DATE>"+jsonObj.get("CurrentULIPEndDate").toString()+
	 * "</CURRENT_ULIP_END_DATE>\r\n" +
	 * "<PREVIOUS_ULIP_START_DATE>"+jsonObj.get("PreviousULIPStartDate").toString()+
	 * "</PREVIOUS_ULIP_START_DATE>\r\n" +
	 * "<PREVIOUS_ULIP_END_DATE>"+jsonObj.get("PreviousULIPEndDate").toString()+
	 * "</PREVIOUS_ULIP_END_DATE>\r\n" +
	 * "<REPORTING_MANAGER_CODE>"+jsonObj.get("ReportingManagerCode").toString()+
	 * "</REPORTING_MANAGER_CODE>\r\n" +
	 * "<REPORTING_MANAGER_NAME>"+jsonObj.get("ReportingManagerName").toString()+
	 * "</REPORTING_MANAGER_NAME>\r\n" + "</Q_LIST_AGENT_DETAILS>"; }
	 * 
	 * // logger.info(Agent_Code + GO_code + Agent_Name +Agent_Contact_Number +
	 * Branch_Name + Agent_Status); String
	 * INFLUENCER_CHANNEL="",EQUOTE_NUMBER="",CRMLeadID=""; //PolicyDetails Section
	 * JSONObject PolicyDetailsObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("PolicyDetails").toString());
	 * Product_Name = (String) PolicyDetailsObj.get("ProductName"); Need = (String)
	 * PolicyDetailsObj.get("Need"); Life_Stage = (String)
	 * PolicyDetailsObj.get("LifeStage"); Objective_of_insurance = (String)
	 * PolicyDetailsObj.get("Objectiveofinsurance"); Proposal_No = (String)
	 * PolicyDetailsObj.get("ProposalNo"); CRMLeadID = (String)
	 * PolicyDetailsObj.get("CRMLeadID"); INFLUENCER_CHANNEL = (String)
	 * PolicyDetailsObj.get("InfluencerChannel"); EQUOTE_NUMBER = (String)
	 * PolicyDetailsObj.get("EquoteNumber"); mPRO_initiation_date = (String)
	 * PolicyDetailsObj.get("mPROinitiationdate"); App_Recvd_date_from_mPRO =
	 * (String) PolicyDetailsObj.get("AppRecvddatefrommPRO"); Rural_urban_Social =
	 * (String) PolicyDetailsObj.get("RuralurbanSocial"); Product_Solution =
	 * (String) PolicyDetailsObj.get("ProductSolution"); Combo_Proposal_Number =
	 * (String) PolicyDetailsObj.get("ComboProposalNumber");
	 * Previous_Proposal_Number = (String)
	 * PolicyDetailsObj.get("PreviousProposalNumber"); Source_of_Sale = (String)
	 * PolicyDetailsObj.get("SourceofSale"); SPARC_lead_Source = (String)
	 * PolicyDetailsObj.get("SPARCleadSource"); QROPS = (String)
	 * PolicyDetailsObj.get("QROPS");
	 * 
	 * //Adding Data in jsonValidate for Policy Deatils
	 * jsonValidate.put("PolicyDetails.Objectiveofinsurance",
	 * Objective_of_insurance); jsonValidate.put("PolicyDetails.Need", Need);
	 * jsonValidate.put("PolicyDetails.LifeStage", Life_Stage);
	 * jsonValidate.put("PolicyDetails.ProductSolution", Product_Solution);
	 * jsonValidate.put("PolicyDetails.SourceofSale", Source_of_Sale);
	 * jsonValidate.put("PolicyDetails.SPARCleadSource", SPARC_lead_Source);
	 * 
	 * 
	 * attributesXML = attributesXML + "<Q_POLICY_DETAILS>" // + "<Product_Name>" +
	 * Product_Name + "</Product_Name>" + "<Need>" + Need + "</Need>" +
	 * "<Life_Stage>" + Life_Stage + "</Life_Stage>" // + "<OBJ_OF_INSURANCE>" +
	 * Objective_of_insurance + "</OBJ_OF_INSURANCE>" //+ "<Proposal_No>" +
	 * Proposal_No + "</Proposal_No>" + "<CRM_LEAD_ID>" + CRMLeadID +
	 * "</CRM_LEAD_ID>" + "<INFLUENCER_CHANNEL>" + INFLUENCER_CHANNEL +
	 * "</INFLUENCER_CHANNEL>" + "<INITIATION_DATE>" + mPRO_initiation_date +
	 * "</INITIATION_DATE>" + "<EQUOTE_NUMBER>" + EQUOTE_NUMBER + "</EQUOTE_NUMBER>"
	 * + "<APP_RECEIVE_DATE>" + App_Recvd_date_from_mPRO + "</APP_RECEIVE_DATE>" +
	 * "<Rural_urban_Social>" + Rural_urban_Social + "</Rural_urban_Social>" +
	 * "<Product_Solution>" + Product_Solution + "</Product_Solution>" +
	 * "<COMBO_PROPOSAL_NO>" + Combo_Proposal_Number + "</COMBO_PROPOSAL_NO>" +
	 * "<PREV_PROPOSAL_NO>" + Previous_Proposal_Number + "</PREV_PROPOSAL_NO>" +
	 * "<SRC_OF_SALE>" + Source_of_Sale + "</SRC_OF_SALE>" + "<SPARC_LEAD_SRC>" +
	 * SPARC_lead_Source + "</SPARC_LEAD_SRC>" + "<QROPS>" + QROPS + "</QROPS>" +
	 * "</Q_POLICY_DETAILS>" ; attributesXML = attributesXML+ "<PLAN_NAME>" +
	 * Product_Name + "</PLAN_NAME>"; attributesXML = attributesXML+
	 * "<OBJ_OF_INSURANCE>" + Objective_of_insurance + "</OBJ_OF_INSURANCE>";
	 * 
	 * //attributesXML = attributesXML+ "<PROPOSAL_NUMBER>" + Proposal_No +
	 * "</PROPOSAL_NUMBER>"; // logger.info(Product_Name + Need + Life_Stage);
	 * 
	 * //CEIP DETAILS JSONObject CEIPDetailsObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("CEIPDetails").toString());
	 * 
	 * Business_Type = (String) CEIPDetailsObj.get("BusinessType"); BDM_id =
	 * (String) CEIPDetailsObj.get("BDMid"); Enroller_id = (String)
	 * CEIPDetailsObj.get("Enrollerid"); Finder_id = (String)
	 * CEIPDetailsObj.get("Finderid"); Name_of_company = (String)
	 * CEIPDetailsObj.get("Nameofcompany"); attributesXML = attributesXML
	 * //Q_CEIP_DETAILS_BUSINESS_TYPE + "<Q_CEIP_DETAILS>" + "<Business_Type>" +
	 * Business_Type + "</Business_Type>" + "<BDM_id>" + BDM_id + "</BDM_id>" +
	 * "<Enroller_id>" + Enroller_id + "</Enroller_id>" + "<Finder_id>" + Finder_id
	 * + "</Finder_id>" + "<Name_of_company>" + Name_of_company +
	 * "</Name_of_company>" + "</Q_CEIP_DETAILS>" ;
	 * 
	 * //Defence Details JSONObject DefenceDetailsObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("DefenceDetails").toString());
	 * Defence_Channel_Case = (String) DefenceDetailsObj.get("DefenceChannelCase");
	 * Army_Number = (String) DefenceDetailsObj.get("ArmyNumber"); Unit_Name =
	 * (String) DefenceDetailsObj.get("UnitName"); attributesXML = attributesXML
	 * //Q_DEFENCE_DETAILS_DEFENCE_CHANNEL_CASE + "<Q_DEFENCE_DETAILS>" +
	 * "<Defence_Channel_Case>" + Defence_Channel_Case + "</Defence_Channel_Case>" +
	 * "<Army_Number>" + Army_Number + "</Army_Number>" + "<Unit_Name>" + Unit_Name
	 * + "</Unit_Name>" + "</Q_DEFENCE_DETAILS>" ;
	 * 
	 * //Customer information String IRPScore=""; JSONObject CustomerInformationObj
	 * = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("CustomerInformation").toString()
	 * ); Customer_Sign_Date = (String)
	 * CustomerInformationObj.get("CustomerSignDate"); Customer_ID = (String)
	 * CustomerInformationObj.get("CustomerID"); Customer_classification = (String)
	 * CustomerInformationObj.get("CustomerClassification");
	 * YBL_Customer_Classification = (String)
	 * CustomerInformationObj.get("YBLCustomerClassification");
	 * Is_this_a_replacement_policy_sale = (String)
	 * CustomerInformationObj.get("ReplacementPolicySale"); IRPScore = (String)
	 * CustomerInformationObj.get("IRPScore");
	 * 
	 * //Adding Data in jsonValidate for Customer Information
	 * jsonValidate.put("CustomerInformation.YBLCustomerClassification",
	 * YBL_Customer_Classification);
	 * jsonValidate.put("CustomerInformation.ReplacementPolicySale",
	 * Is_this_a_replacement_policy_sale);
	 * 
	 * attributesXML = attributesXML //Q_CUSTOMER_INFORMATION_IRP_SCORE +
	 * "<Q_CUSTOMER_INFORMATION>" + "<IRP_SCORE>" + IRPScore + "</IRP_SCORE>" +
	 * "<Customer_Sign_Date>" + Customer_Sign_Date + "</Customer_Sign_Date>" +
	 * "<Customer_ID>" + Customer_ID + "</Customer_ID>" + "<AXIS_CUST_CLASS>" +
	 * Customer_classification + "</AXIS_CUST_CLASS>" + "<YBL_CUST_CLASS>" +
	 * YBL_Customer_Classification + "</YBL_CUST_CLASS>" +
	 * "<REPLACEMENT_POLICY_SALE>" + Is_this_a_replacement_policy_sale +
	 * "</REPLACEMENT_POLICY_SALE>" + "</Q_CUSTOMER_INFORMATION>" ;
	 * 
	 * //Agent Information JSONObject AgentInformationObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("AgentInformation").toString());
	 * 
	 * Agent_Sign_Date = (String) AgentInformationObj.get("AgentSignDate");
	 * Agent_Code2 = (String) AgentInformationObj.get("AgentCode"); Agent_Name2 =
	 * (String) AgentInformationObj.get("AgentName"); Commission_Share = (String)
	 * AgentInformationObj.get("CommissionShare"); SP_CERTIFICATE_NO = (String)
	 * AgentInformationObj.get("SP_CERTIFICATE_NO"); SOL_ID = (String)
	 * AgentInformationObj.get("SOL_ID"); SSN_code = (String)
	 * AgentInformationObj.get("SSN_code"); Application_ID = (String)
	 * AgentInformationObj.get("Application_ID"); WMS_Sr_No = (String)
	 * AgentInformationObj.get("WMSSrNo"); Application_Received_Prior = (String)
	 * AgentInformationObj.get("LoginPrior"); attributesXML = attributesXML
	 * //id="Q_AGENT_INFORMATION_AGENT_SIGN_DATE" + "<Q_AGENT_INFORMATION>" +
	 * "<Agent_Sign_Date>" + Agent_Sign_Date + "</Agent_Sign_Date>" + "<AGENT_CODE>"
	 * + Agent_Code2 + "</AGENT_CODE>" + "<AGENT_NAME>" + Agent_Name2 +
	 * "</AGENT_NAME>" + "<Commission_Share>" + Commission_Share +
	 * "</Commission_Share>" + "<SP_CERTI_NO>" + SP_CERTIFICATE_NO +
	 * "</SP_CERTI_NO>" + "<SOL_ID>" + SOL_ID + "</SOL_ID>" + "<SSN_code>" +
	 * SSN_code + "</SSN_code>" + "<Application_ID>" + Application_ID +
	 * "</Application_ID>" + "<WMS_SERIAL_NO>" + WMS_Sr_No + "</WMS_SERIAL_NO>" +
	 * "<LOGIN_31_MARCH>" + Application_Received_Prior + "</LOGIN_31_MARCH>" +
	 * "</Q_AGENT_INFORMATION>" ;
	 * 
	 * //WelcomeCall JSONObject WelcomeCallObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("WelcomeCall").toString());
	 * String POSVResponse=""; POSVResponse = (String)
	 * WelcomeCallObj.get("POSVResponse");
	 * 
	 * //Adding Data in jsonValidate for Welcome Call
	 * jsonValidate.put("WelcomeCall.POSVResponse", POSVResponse);
	 * 
	 * // attributesXML = attributesXML // + "<Q_WELCOME_CALL>" // +
	 * "<POSV_RESPONSE>"+POSVResponse+"</POSV_RESPONSE>" // + "</Q_WELCOME_CALL>" //
	 * ; attributesXML = attributesXML+ "<POSV_RESPONSE>" + POSVResponse +
	 * "</POSV_RESPONSE>";
	 * 
	 * //Customer JSONObject CustomerObj = (JSONObject)
	 * jsonParser.parse(PolicyAgentCustomerObj.get("Customer").toString());
	 * 
	 * INVESTOR_RISK_PROFILE_SCORE = (String)
	 * CustomerObj.get("INVESTOR_RISK_PROFILE_SCORE"); attributesXML = attributesXML
	 * + "<Q_CUSTOMER>" +
	 * "<RISK_PROFILE_SCORE>"+INVESTOR_RISK_PROFILE_SCORE+"</RISK_PROFILE_SCORE>" +
	 * "</Q_CUSTOMER>" ;
	 * 
	 * //PersonalInformation tab JSONObject PersonalInformationObj = (JSONObject)
	 * jsonParser.parse(json.get("PersonalInformation").toString());
	 * //ProposerDetails Section
	 * 
	 * 
	 * JSONObject ProposerDetails = (JSONObject)
	 * jsonParser.parse(PersonalInformationObj.get("ProposerDetails").toString());
	 * 
	 * //Adding Data in jsonValidate for Proposer Details
	 * jsonValidate.put("ProposerDetails.ClientType", (String)
	 * ProposerDetails.get("ClientType")); jsonValidate.put("ProposerDetails.Title",
	 * (String) ProposerDetails.get("Title"));
	 * jsonValidate.put("ProposerDetails.PleaseSpecify", (String)
	 * ProposerDetails.get("PleaseSpecify"));
	 * jsonValidate.put("ProposerDetails.ResidentialStatus", (String)
	 * ProposerDetails.get("ResidentialStatus"));
	 * jsonValidate.put("ProposerDetails.BusinessSource", (String)
	 * ProposerDetails.get("BusinessSource"));
	 * jsonValidate.put("ProposerDetails.TypeOfVisa", (String)
	 * ProposerDetails.get("TypeOfVisa"));
	 * jsonValidate.put("ProposerDetails.FrequentCountries", (String)
	 * ProposerDetails.get("FrequentCountries"));
	 * jsonValidate.put("ProposerDetails.TypeOfForeignIdentification", (String)
	 * ProposerDetails.get("TypeOfForeignIdentification"));
	 * jsonValidate.put("ProposerDetails.AnnuityOption", (String)
	 * ProposerDetails.get("AnnuityOption"));
	 * jsonValidate.put("ProposerDetails.PEPPerson", (String)
	 * ProposerDetails.get("PEPPerson"));//New Field in below code
	 * jsonValidate.put("ProposerDetails.RoleInPoliticalParty", (String)
	 * ProposerDetails.get("RoleInPoliticalParty"));
	 * jsonValidate.put("ProposerDetails.Country", (String)
	 * ProposerDetails.get("Country"));
	 * jsonValidate.put("ProposerDetails.PermCountry", (String)
	 * ProposerDetails.get("PermCountry"));//New Field in below code
	 * jsonValidate.put("ProposerDetails.AddressProofofProposer", (String)
	 * ProposerDetails.get("AddressProofofProposer"));
	 * jsonValidate.put("ProposerDetails.IDproofofProposer", (String)
	 * ProposerDetails.get("IDproofofProposer"));
	 * jsonValidate.put("ProposerDetails.RepositorytoOpenAccount", (String)
	 * ProposerDetails.get("RepositorytoOpenAccount"));
	 * jsonValidate.put("ProposerDetails.CompanyType", (String)
	 * ProposerDetails.get("CompanyType"));
	 * jsonValidate.put("ProposerDetails.PreferredLanguage", (String)
	 * ProposerDetails.get("PreferredLanguage"));
	 * jsonValidate.put("ProposerDetails.OrganizationType", (String)
	 * ProposerDetails.get("OrganizationType"));
	 * 
	 * attributesXML = attributesXML + "<Q_PROPOSER_DETAILS>\r\n" +
	 * "<CLIENT_TYPE>"+(String)
	 * ProposerDetails.get("ClientType")+"</CLIENT_TYPE>\r\n" + "<TITLE>"+(String)
	 * ProposerDetails.get("Title")+"</TITLE>\r\n" + "<FIRST_NAME>"+(String)
	 * ProposerDetails.get("FirstName")+"</FIRST_NAME>\r\n" +
	 * "<MIDDLE_NAME>"+(String)
	 * ProposerDetails.get("MiddleName")+"</MIDDLE_NAME>\r\n" +
	 * "<LAST_NAME>"+(String) ProposerDetails.get("LastName")+"</LAST_NAME>\r\n" +
	 * "<FATHER_NAME>"+(String)
	 * ProposerDetails.get("FathersName")+"</FATHER_NAME>\r\n" +
	 * "<HUSBAND_NAME>"+(String)
	 * ProposerDetails.get("HusbandsName")+"</HUSBAND_NAME>\r\n" +
	 * "<MOTHER_NAME>"+(String)
	 * ProposerDetails.get("MothersName")+"</MOTHER_NAME>\r\n" +
	 * "<DATE_OF_INCOR>"+(String)
	 * ProposerDetails.get("DateofIncorporation")+"</DATE_OF_INCOR>\r\n" +
	 * "<DATE_OF_BIRTH>"+(String)
	 * ProposerDetails.get("DateofBirth")+"</DATE_OF_BIRTH>\r\n" +
	 * "<GENDER>"+(String) ProposerDetails.get("Gender")+"</GENDER>\r\n" +
	 * "<NATIONALITY>"+(String)
	 * ProposerDetails.get("Nationality")+"</NATIONALITY>\r\n" +
	 * "<PAN_NUMBER>"+(String) ProposerDetails.get("PanNumber")+"</PAN_NUMBER>\r\n"
	 * + "<RESIDENTIAL_STATUS>"+(String)
	 * ProposerDetails.get("ResidentialStatus")+"</RESIDENTIAL_STATUS>\r\n" +
	 * "<SPECIFY_STATUS>"+(String)
	 * ProposerDetails.get("PleaseSpecifyRS")+"</SPECIFY_STATUS>\r\n" +
	 * "<BUSINESS_SOURCE>"+(String)
	 * ProposerDetails.get("BusinessSource")+"</BUSINESS_SOURCE>\r\n" +
	 * "<TYPE_OF_VISA>"+(String)
	 * ProposerDetails.get("TypeOfVisa")+"</TYPE_OF_VISA>\r\n" +
	 * "<VISA_VALID_TILL>"+(String)
	 * ProposerDetails.get("ValidTill")+"</VISA_VALID_TILL>\r\n" +
	 * "<PASSPORT_EXP_DATE>"+(String)
	 * ProposerDetails.get("PassportExpiryDate")+"</PASSPORT_EXP_DATE>\r\n" +
	 * "<DATE_OF_LATEST_ENTRY_TO_INDIA>"+(String)
	 * ProposerDetails.get("LatestEntryDate")+"</DATE_OF_LATEST_ENTRY_TO_INDIA>\r\n"
	 * + "<TYPE_FOREIGN_ID>"+(String)
	 * ProposerDetails.get("TypeOfForeignIdentification")+"</TYPE_FOREIGN_ID>\r\n" +
	 * "<ANNUITY_OPTION>"+(String)
	 * ProposerDetails.get("AnnuityOption")+"</ANNUITY_OPTION>\r\n" +
	 * "<ISSUE_ADD_PROOF>"+(String)
	 * ProposerDetails.get("DateofIssueAddressProof")+"</ISSUE_ADD_PROOF>\r\n" +
	 * "<EXPIRY_OF_ADD_PROOF>"+(String)
	 * ProposerDetails.get("DateofExpiryofAddressProof")+
	 * "</EXPIRY_OF_ADD_PROOF>\r\n" + "<POLITICALLY_EXPOSED>"+(String)
	 * ProposerDetails.get("IsPoliticallyExposed")+"</POLITICALLY_EXPOSED>\r\n" +
	 * "<COUNTRY>"+(String) ProposerDetails.get("Country")+"</COUNTRY>\r\n" +
	 * "<PIN_CODE>"+(String) ProposerDetails.get("PinCode")+"</PIN_CODE>\r\n" +
	 * "<HOUSE_NO_APT_NAME>"+(String)
	 * ProposerDetails.get("HouseNoAptNameSociety")+"</HOUSE_NO_APT_NAME>\r\n" +
	 * "<ROAD_AREA_SECTOR>"+(String)
	 * ProposerDetails.get("RoadAreaSector")+"</ROAD_AREA_SECTOR>\r\n" +
	 * "<LANDMARK>"+(String) ProposerDetails.get("Landmark")+"</LANDMARK>\r\n" +
	 * "<VILLAGE_TOWN>"+(String)
	 * ProposerDetails.get("VillageTown")+"</VILLAGE_TOWN>\r\n" +
	 * "<CITY_DISTRICT>"+(String)
	 * ProposerDetails.get("CityDistrict")+"</CITY_DISTRICT>\r\n" +
	 * "<STATE_UT>"+(String) ProposerDetails.get("StateUT")+"</STATE_UT>\r\n" +
	 * "<MOBILE_NO_1>"+(String)
	 * ProposerDetails.get("MobileNo1")+"</MOBILE_NO_1>\r\n" +
	 * "<MOBILE_NO_2>"+(String)
	 * ProposerDetails.get("MobileNo2")+"</MOBILE_NO_2>\r\n" +
	 * "<LANDLINE_NO>"+(String)
	 * ProposerDetails.get("LandlineNo1")+"</LANDLINE_NO>\r\n" + "<STD>"+(String)
	 * ProposerDetails.get("STD_forLandlineNo1")+"</STD>\r\n" +
	 * "<PERM_RESIDENTIAL_ADD>"+(String)
	 * ProposerDetails.get("SameAsAbove")+"</PERM_RESIDENTIAL_ADD>\r\n"
	 * +"<EMAIL_ID>"+(String) ProposerDetails.get("EmailId")+"</EMAIL_ID>\r\n" +
	 * "<ADDR_PROOF_PROP>"+(String)
	 * ProposerDetails.get("AddressProofofProposer")+"</ADDR_PROOF_PROP>\r\n" +
	 * "<ID_PROOF_PROP>"+(String)
	 * ProposerDetails.get("IDproofofProposer")+"</ID_PROOF_PROP>\r\n" +
	 * "<PROOF_NUMBER>"+(String)
	 * ProposerDetails.get("ProofNumber")+"</PROOF_NUMBER>\r\n" +
	 * "<EXPIRY_ID_PROOF>"+(String)
	 * ProposerDetails.get("DateOfExpiryofIdentityProof")+"</EXPIRY_ID_PROOF>\r\n" +
	 * "<EIA_NO_AVAILABLE>"+(String)
	 * ProposerDetails.get("13DigitEIANumberAvailable")+"</EIA_NO_AVAILABLE>\r\n" +
	 * "<EIA_NUMBER>"+(String) ProposerDetails.get("EIANumber")+"</EIA_NUMBER>\r\n"
	 * + "<FTIN_Present>"+(String)
	 * ProposerDetails.get("HaveFTIN")+"</FTIN_Present>\r\n"
	 * +"<REPOSITORY>"+(String)
	 * ProposerDetails.get("RepositorytoOpenAccount")+"</REPOSITORY>\r\n" +
	 * "<AADHAAR_NUMBER>"+(String)
	 * ProposerDetails.get("AadhaarNumber")+"</AADHAAR_NUMBER>\r\n" +
	 * "<AADHAAR_ENROL_NO>"+(String)
	 * ProposerDetails.get("AadhaarEnrollmentNumber")+"</AADHAAR_ENROL_NO>\r\n" +
	 * "<COMPANY_TYPE>"+(String)
	 * ProposerDetails.get("CompanyType")+"</COMPANY_TYPE>\r\n" +
	 * "<PREFERRED_LANGUAGE>"+(String)
	 * ProposerDetails.get("PreferredLanguage")+"</PREFERRED_LANGUAGE>\r\n" +
	 * "<ORGANIZATION_TYPE>"+(String)
	 * ProposerDetails.get("OrganizationType")+"</ORGANIZATION_TYPE>\r\n" +
	 * "<PAN_APPLIED_FOR>"+(String)
	 * ProposerDetails.get("Appliedfor")+"</PAN_APPLIED_FOR>\r\n" +
	 * "<PERM_COUNTRY>"+(String)
	 * ProposerDetails.get("PermCountry")+"</PERM_COUNTRY>\r\n" +
	 * "<PERM_PIN_CODE>"+(String)
	 * ProposerDetails.get("PermPinCode")+"</PERM_PIN_CODE>\r\n" +
	 * "<PERM_HOUSE_NO_APT_NAME>"+(String)
	 * ProposerDetails.get("PermHouseNoAptNameSociety")+
	 * "</PERM_HOUSE_NO_APT_NAME>\r\n" + "<PERM_ROAD_AREA_SECTOR>"+(String)
	 * ProposerDetails.get("PermRoadAreaSector")+"</PERM_ROAD_AREA_SECTOR>\r\n" +
	 * "<PERM_LANDMARK>"+(String)
	 * ProposerDetails.get("PermLandmark")+"</PERM_LANDMARK>\r\n" +
	 * "<PERM_VILLAGE_TOWN>"+(String)
	 * ProposerDetails.get("PermVillageTown")+"</PERM_VILLAGE_TOWN>\r\n" +
	 * "<PERM_CITY_DISTRICT>"+(String)
	 * ProposerDetails.get("PermCityDistrict")+"</PERM_CITY_DISTRICT>\r\n" +
	 * "<PERM_STATE_UT>"+(String)
	 * ProposerDetails.get("PermStateUT")+"</PERM_STATE_UT>\r\n" +
	 * "<PERM_MOBILE_NO_1>"+(String)
	 * ProposerDetails.get("PermMobileNo1")+"</PERM_MOBILE_NO_1>\r\n" +
	 * "<PERM_MOBILE_NO_2>"+(String)
	 * ProposerDetails.get("PermMobileNo2")+"</PERM_MOBILE_NO_2>\r\n" +
	 * "<PERM_LANDLINE_NO>"+(String)
	 * ProposerDetails.get("PermLandlineNo1")+"</PERM_LANDLINE_NO>\r\n" +
	 * "<PERM_STD>"+(String)
	 * ProposerDetails.get("PermSTD_forLandlineNo1")+"</PERM_STD>\r\n" +
	 * "<CKYC_NO>"+(String) ProposerDetails.get("HaveCKYC")+"</CKYC_NO>\r\n" +
	 * "<PERON_PEP>"+(String) ProposerDetails.get("PEPPerson")+"</PERON_PEP>\r\n" +
	 * "<POLITICAL_EXP>"+(String)
	 * ProposerDetails.get("PoliticalExperience")+"</POLITICAL_EXP>\r\n" +
	 * "<AFFILIATION_POLITICAL_PARTY>"+(String)
	 * ProposerDetails.get("AffiliationToPoliticalParty")+
	 * "</AFFILIATION_POLITICAL_PARTY>\r\n" + "<PORTFLIO_HANDLED>"+(String)
	 * ProposerDetails.get("PortfolioHandled")+"</PORTFLIO_HANDLED>\r\n" +
	 * "<SPECIFY_POLITICAL_ROLE>"+(String)
	 * ProposerDetails.get("RoleInPoliticalParty")+"</SPECIFY_POLITICAL_ROLE>\r\n" +
	 * "<PARTY_IN_POWER>"+(String)
	 * ProposerDetails.get("IsPartyPower")+"</PARTY_IN_POWER>\r\n" +
	 * "<PEP_POSTED>"+(String)
	 * ProposerDetails.get("ForeignPortfolio")+"</PEP_POSTED>\r\n" +
	 * "<PEP_SPECIFY_OFFICE>"+(String)
	 * ProposerDetails.get("PEPOffice")+"</PEP_SPECIFY_OFFICE>\r\n" +
	 * "<PEP_INCOME_SOURCES>"+(String)
	 * ProposerDetails.get("PEPIncome")+"</PEP_INCOME_SOURCES>\r\n" +
	 * "<PEP_CONVICTED>"+(String)
	 * ProposerDetails.get("IsPEPconvicted")+"</PEP_CONVICTED>\r\n" +
	 * "<CONVICTION_DETAILS>"+(String)
	 * ProposerDetails.get("ConvictionDetails")+"</CONVICTION_DETAILS>\r\n" +
	 * "<PASSPORT_NO>"+(String)
	 * ProposerDetails.get("PassportNumber")+"</PASSPORT_NO>\r\n" +
	 * "<PASSPORT_ISSUE_COUNTRY>"+(String)
	 * ProposerDetails.get("PassportIssuingCountry")+"</PASSPORT_ISSUE_COUNTRY>\r\n"
	 * + "<COUNTRY_RESIDING_IN>"+(String)
	 * ProposerDetails.get("CurrentCountry")+"</COUNTRY_RESIDING_IN>\r\n" +
	 * "<COUNTRIES_VISIT_FREQ>"+(String)
	 * ProposerDetails.get("FrequentCountries")+"</COUNTRIES_VISIT_FREQ>\r\n" +
	 * "<BIRTH_COUNTRY>"+(String)
	 * ProposerDetails.get("BirthCountry")+"</BIRTH_COUNTRY>\r\n" +
	 * "<COUNTRY_OF_RESIDENCE>"+(String)
	 * ProposerDetails.get("CountryOfResidence")+"</COUNTRY_OF_RESIDENCE>\r\n" +
	 * "<OPT_FOR_POLICY>"+(String)
	 * ProposerDetails.get("EInsurance")+"</OPT_FOR_POLICY>\r\n" +
	 * "<ISSUING_COUNTRY>"+(String)
	 * ProposerDetails.get("IssuingCountry")+"</ISSUING_COUNTRY>\r\n" +
	 * 
	 * "<ID_NUMBER>"+(String)
	 * ProposerDetails.get("IdentificationNumber")+"</ID_NUMBER>\r\n" +
	 * "</Q_PROPOSER_DETAILS>";
	 * 
	 * 
	 * JSONArray FTINArray; FTINArray=(JSONArray)ProposerDetails.get("FTNDetails");
	 * insertionOrderId=0;hashID=1;
	 * 
	 * for (Object j : FTINArray) { JSONObject jsonObj=(JSONObject)j; attributesXML
	 * = attributesXML + "<Q_LIST_FTN_DETAILS>\r\n" +
	 * "<InsertionOrderId>"+insertionOrderId+"</InsertionOrderId>" + "<HashId>"+
	 * hashID++ +"</HashId>" +
	 * "<FTIN_NUMBER>"+jsonObj.get("FTIN_Number").toString()+"</FTIN_NUMBER>" +
	 * "<FTIN_ISSUING_COUNTRY>"+jsonObj.get("FTIN_IssuingCountry").toString()+
	 * "</FTIN_ISSUING_COUNTRY>" + "</Q_LIST_FTN_DETAILS>"; }
	 * 
	 * //L2BIDetails Section
	 * 
	 * JSONObject L2BIDetailsObj = (JSONObject)
	 * jsonParser.parse(PersonalInformationObj.get("L2BIDetails").toString());
	 * 
	 * //Adding Data in jsonValidate for L2BI Details
	 * jsonValidate.put("L2BIDetails.Title", (String) L2BIDetailsObj.get("Title"));
	 * jsonValidate.put("L2BIDetails.PleaseSpecify", (String)
	 * L2BIDetailsObj.get("PleaseSpecify"));
	 * jsonValidate.put("L2BIDetails.BusinessSource",
	 * L2BIDetailsObj.get("BusinessSource"));
	 * jsonValidate.put("L2BIDetails.MaritalStatus", (String)
	 * L2BIDetailsObj.get("MaritalStatus"));
	 * jsonValidate.put("L2BIDetails.RelationshipWithProposer", (String)
	 * L2BIDetailsObj.get("RelationshipWithProposer"));
	 * //jsonValidate.put("L2BIDetails.Title", (String)
	 * ProposerDetails.get("ClientType")); jsonValidate.put("L2BIDetails.Education",
	 * (String) L2BIDetailsObj.get("Education"));
	 * jsonValidate.put("L2BIDetails.IndustryType", (String)
	 * L2BIDetailsObj.get("IndustryType"));
	 * jsonValidate.put("L2BIDetails.OrganizationType", (String)
	 * L2BIDetailsObj.get("OrganizationType"));
	 * jsonValidate.put("L2BIDetails.IncomeSource",
	 * L2BIDetailsObj.get("IncomeSource"));
	 * jsonValidate.put("L2BIDetails.Occupation", (String)
	 * L2BIDetailsObj.get("Occupation")); jsonValidate.put("L2BIDetails.FlyWhat",
	 * (String) L2BIDetailsObj.get("FlyWhat"));
	 * jsonValidate.put("L2BIDetails.NatureOfJob", (String)
	 * L2BIDetailsObj.get("NatureOfJob"));
	 * jsonValidate.put("L2BIDetails.DiveLocation", (String)
	 * L2BIDetailsObj.get("DiveLocation"));
	 * jsonValidate.put("L2BIDetails.TypeOfVessel", (String)
	 * L2BIDetailsObj.get("TypeOfVessel"));
	 * 
	 * attributesXML = attributesXML + "<Q_L2BI_DETAILS>\r\n" +
	 * "<CLIENT_TYPE>"+(String)
	 * L2BIDetailsObj.get("ClientType")+"</CLIENT_TYPE>\r\n" + "<TITLE>"+(String)
	 * L2BIDetailsObj.get("Title")+"</TITLE>\r\n" + "<SPECIFY_TITLE>"+(String)
	 * L2BIDetailsObj.get("PleaseSpecify")+"</SPECIFY_TITLE>\r\n" +
	 * "<FIRST_NAME>"+(String) L2BIDetailsObj.get("FirstName")+"</FIRST_NAME>\r\n" +
	 * "<MIDDLE_NAME>"+(String)
	 * L2BIDetailsObj.get("MiddleName")+"</MIDDLE_NAME>\r\n" +
	 * "<LAST_NAME>"+(String) L2BIDetailsObj.get("LastName")+"</LAST_NAME>\r\n" +
	 * "<FATHER_NAME>"+(String)
	 * L2BIDetailsObj.get("FathersName")+"</FATHER_NAME>\r\n" +
	 * "<HUSBAND_NAME>"+(String)
	 * L2BIDetailsObj.get("HusbandsName")+"</HUSBAND_NAME>\r\n" + "<DOB>"+(String)
	 * L2BIDetailsObj.get("DateOfBirth")+"</DOB>\r\n" + "<GENDER>"+(String)
	 * L2BIDetailsObj.get("Gender")+"</GENDER>\r\n" + "<NATIONALITY>"+(String)
	 * L2BIDetailsObj.get("Nationality")+"</NATIONALITY>\r\n" +
	 * "<BUSINESS_SOURCE>"+(String)
	 * L2BIDetailsObj.get("BusinessSource")+"</BUSINESS_SOURCE>\r\n" +
	 * "<MARITAL_STATUS>"+(String)
	 * L2BIDetailsObj.get("MaritalStatus")+"</MARITAL_STATUS>\r\n" +
	 * "<EXACT_INCOME>"+(String)
	 * L2BIDetailsObj.get("ExactIncome")+"</EXACT_INCOME>\r\n" +
	 * "<EDUCATION>"+(String) L2BIDetailsObj.get("Education")+"</EDUCATION>\r\n" +
	 * "<INDUSTRY_TYPE>"+(String)
	 * L2BIDetailsObj.get("IndustryType")+"</INDUSTRY_TYPE>\r\n" +
	 * "<ORGANIZATION_TYPE>"+(String)
	 * L2BIDetailsObj.get("OrganizationType")+"</ORGANIZATION_TYPE>\r\n" +
	 * "<INCOME_SOURCE>"+(String)
	 * L2BIDetailsObj.get("IncomeSource")+"</INCOME_SOURCE>\r\n" +
	 * "<SPECIFY_OCCUPATION>"+(String)
	 * L2BIDetailsObj.get("PleaseSpecifyIncomeSource")+"</SPECIFY_OCCUPATION>\r\n"
	 * +"<OCCUPATION>"+(String) L2BIDetailsObj.get("Occupation")+"</OCCUPATION>\r\n"
	 * + "<RELATIONSHIP_WITH_PROPOSER>"+(String)
	 * L2BIDetailsObj.get("RelationshipWithProposer")+
	 * "</RELATIONSHIP_WITH_PROPOSER>\r\n" + "<SPECIFY_RELATION>"+(String)
	 * L2BIDetailsObj.get("PleaseSpecifyRelationshipWithProposer")+
	 * "</SPECIFY_RELATION>\r\n" + "<NATURE_OF_DUTIES>"+(String)
	 * L2BIDetailsObj.get("NatureOfDuties")+"</NATURE_OF_DUTIES>\r\n" +
	 * "<CURRENTLY_POSTED>"+(String)
	 * L2BIDetailsObj.get("IsSensitiveLocation")+"</CURRENTLY_POSTED>\r\n" +
	 * "<PROFESSIONAL_DIVER>"+(String)
	 * L2BIDetailsObj.get("ProfessionalDiver")+"</PROFESSIONAL_DIVER>\r\n" +
	 * "<ROLE_INVOLVE>"+(String)
	 * L2BIDetailsObj.get("MineRole")+"</ROLE_INVOLVE>\r\n" +
	 * "<ILLNESS_OCCUPATION>"+(String)
	 * L2BIDetailsObj.get("AnyIllness")+"</ILLNESS_OCCUPATION>\r\n" +
	 * "<OFFSHORE>"+(String) L2BIDetailsObj.get("IsTravelling")+"</OFFSHORE>\r\n" +
	 * "<NATURE_OF_JOB>"+(String)
	 * L2BIDetailsObj.get("NatureOfJob")+"</NATURE_OF_JOB>\r\n" +
	 * "<FLYING_ROLE>"+(String) L2BIDetailsObj.get("FlyWhat")+"</FLYING_ROLE>\r\n" +
	 * "<DIVE>"+(String) L2BIDetailsObj.get("DiveLocation")+"</DIVE>\r\n" +
	 * "<TYPE_OF_VESSEL>"+(String)
	 * L2BIDetailsObj.get("TypeOfVessel")+"</TYPE_OF_VESSEL>\r\n" +
	 * "</Q_L2BI_DETAILS>";
	 * 
	 * //NomineeDetails Section JSONObject NomineeDetailsObj = (JSONObject)
	 * jsonParser.parse(PersonalInformationObj.get("NomineeDetails").toString());
	 * 
	 * //Adding Data in jsonValidate for Nominee Details
	 * jsonValidate.put("NomineeDetails.ClientType", (String)
	 * NomineeDetailsObj.get("ClientType"));
	 * jsonValidate.put("NomineeDetails.MWPAToBeAdded", (String)
	 * NomineeDetailsObj.get("MWPAToBeAdded"));
	 * jsonValidate.put("NomineeDetails.PleaseSpecify", (String)
	 * NomineeDetailsObj.get("PleaseSpecify"));
	 * jsonValidate.put("NomineeDetails.NomineeType", (String)
	 * NomineeDetailsObj.get("NomineeType"));
	 * jsonValidate.put("NomineeDetails.BusinessSource", (String)
	 * NomineeDetailsObj.get("BusinessSource"));
	 * jsonValidate.put("NomineeDetails.Country", (String)
	 * NomineeDetailsObj.get("Country"));
	 * 
	 * 
	 * attributesXML = attributesXML + "<Q_NOMINEE_DETAILS>\r\n" +
	 * "<CLIENT_TYPE>"+(String)
	 * NomineeDetailsObj.get("ClientType")+"</CLIENT_TYPE>\r\n" +
	 * //"<REASON_FOR_NOMINATION>"+(String)
	 * NomineeDetailsObj.get("ReasonForNomination")+"</REASON_FOR_NOMINATION>\r\n" +
	 * "<MWPA>"+(String) NomineeDetailsObj.get("MWPAToBeAdded")+"</MWPA>\r\n" +
	 * "<NOMINEE_TYPE>"+(String)
	 * NomineeDetailsObj.get("NomineeType")+"</NOMINEE_TYPE>\r\n" +
	 * "<PAN_NUMBER>"+(String)
	 * NomineeDetailsObj.get("PanNumber")+"</PAN_NUMBER>\r\n" +
	 * "<APPLIED_FOR_PAN>"+(String)
	 * NomineeDetailsObj.get("AppliedFor")+"</APPLIED_FOR_PAN>\r\n" +
	 * "<APP_ACK_NO>"+(String)
	 * NomineeDetailsObj.get("AppAckNumber")+"</APP_ACK_NO>\r\n" +
	 * "<NATIONALITY>"+(String)
	 * NomineeDetailsObj.get("Nationality")+"</NATIONALITY>\r\n" +
	 * "<BUSINESS_SOURCE>"+(String)
	 * NomineeDetailsObj.get("BusinessSource")+"</BUSINESS_SOURCE>\r\n" +
	 * "<COUNTRY>"+(String) NomineeDetailsObj.get("Country")+"</COUNTRY>\r\n" +
	 * "<SPECIFY_COUNTRY>"+(String)
	 * NomineeDetailsObj.get("SpecifyCountry")+"</SPECIFY_COUNTRY>\r\n" +
	 * "<PIN_CODE>"+(String) NomineeDetailsObj.get("PinCode")+"</PIN_CODE>\r\n" +
	 * "<HOUSENO_APTNAME>"+(String)
	 * NomineeDetailsObj.get("HouseNo/AptName/Society")+"</HOUSENO_APTNAME>\r\n" +
	 * "<ROAD_AREA_SEC>"+(String)
	 * NomineeDetailsObj.get("Road/Area/Sector")+"</ROAD_AREA_SEC>\r\n" +
	 * "<LANDMARK>"+(String) NomineeDetailsObj.get("Landmark")+"</LANDMARK>\r\n" +
	 * "<VILLAGE_TOWN>"+(String)
	 * NomineeDetailsObj.get("Village/Town")+"</VILLAGE_TOWN>\r\n" +
	 * "<CITY_DISTRICT>"+(String)
	 * NomineeDetailsObj.get("City/District")+"</CITY_DISTRICT>\r\n" +
	 * "<STATE_UT>"+(String) NomineeDetailsObj.get("State/UT")+"</STATE_UT>\r\n" +
	 * "<MOBILE_NO_1>"+(String)
	 * NomineeDetailsObj.get("MobileNo1")+"</MOBILE_NO_1>\r\n" +
	 * "<MOBILE_NO_2>"+(String)
	 * NomineeDetailsObj.get("MobileNo2")+"</MOBILE_NO_2>\r\n" +
	 * "<LANDLINE_NO>"+(String)
	 * NomineeDetailsObj.get("LandlineNo1")+"</LANDLINE_NO>\r\n" + "<STD>"+(String)
	 * NomineeDetailsObj.get("STD(LandlineNo1)")+"</STD>\r\n" +
	 * "<EMAIL_ID>"+(String) NomineeDetailsObj.get("EmailId")+"</EMAIL_ID>\r\n" +
	 * "<DATE_OF_APP>"+(String)
	 * NomineeDetailsObj.get("DateofApplication")+"</DATE_OF_APP>\r\n" + //
	 * "<SPECIFY_MWPA>"+(String)
	 * NomineeDetailsObj.get("PleaseSpecify")+"</SPECIFY_MWPA>\r\n" +
	 * "</Q_NOMINEE_DETAILS>";
	 * 
	 * JSONArray NomineeDetailsArray;
	 * NomineeDetailsArray=(JSONArray)NomineeDetailsObj.get("NomineeDetailsGrid");
	 * insertionOrderId=0;hashID=1;
	 * 
	 * for (Object j : NomineeDetailsArray) { JSONObject jsonObj=(JSONObject)j;
	 * attributesXML = attributesXML + "<Q_LIST_NOMINEE_DETAILS>\r\n" +
	 * "<InsertionOrderId>"+insertionOrderId+"</InsertionOrderId>\r\n" + "<HashId>"+
	 * hashID++ +"</HashId>\r\n" +
	 * "<TITLE>"+jsonObj.get("Title").toString()+"</TITLE>\r\n" +
	 * "<SPECIFY_TITLE>"+jsonObj.get("PleaseSpecify").toString()+
	 * "</SPECIFY_TITLE>\r\n" +
	 * "<FIRST_NAME>"+jsonObj.get("FirstName").toString()+"</FIRST_NAME>\r\n" +
	 * "<MIDDLE_NAME>"+jsonObj.get("MiddleName").toString()+"</MIDDLE_NAME>\r\n" +
	 * "<LAST_NAME>"+jsonObj.get("LastName").toString()+"</LAST_NAME>\r\n" +
	 * "<DOB>"+jsonObj.get("DOB").toString()+"</DOB>\r\n" +
	 * "<GENDER>"+jsonObj.get("Gender").toString()+"</GENDER>\r\n" +
	 * "<PERCENTAGE>"+jsonObj.get("PercentageShare").toString()+"</PERCENTAGE>\r\n"
	 * +
	 * "<RELATIONSHIP_PROPOSER>"+jsonObj.get("RelationshipWithProposer").toString()+
	 * "</RELATIONSHIP_PROPOSER>\r\n" +
	 * "<PLEASE_SPECIFY>"+jsonObj.get("PleaseSpecifyRelationship").toString()+
	 * "</PLEASE_SPECIFY>\r\n" +
	 * "<REASON_FOR_NOMINATION>"+jsonObj.get("ReasonForNomination").toString()+
	 * "</REASON_FOR_NOMINATION>\r\n" +"</Q_LIST_NOMINEE_DETAILS>"; }
	 * 
	 * 
	 * //Guardian Details
	 * 
	 * JSONArray GuardianDetailsArray;
	 * GuardianDetailsArray=(JSONArray)PersonalInformationObj.get("GuardianDetails")
	 * ; insertionOrderId=0;hashID=1;
	 * 
	 * for (Object j : GuardianDetailsArray) { JSONObject jsonObj=(JSONObject)j;
	 * attributesXML = attributesXML + "<Q_LIST_GUARDIAN_DETAILS>\r\n" +
	 * "<InsertionOrderId>"+insertionOrderId+"</InsertionOrderId>" + "<HashId>"+
	 * hashID++ +"</HashId>" +
	 * "<FIRST_NAME>"+jsonObj.get("FirstName").toString()+"</FIRST_NAME>" +
	 * "<MIDDLE_NAME>"+jsonObj.get("MiddleName").toString()+"</MIDDLE_NAME>" +
	 * "<LAST_NAME>"+jsonObj.get("LastName").toString()+"</LAST_NAME>" +
	 * "<RELATIONSHIP>"+jsonObj.get("Relationship").toString()+"</RELATIONSHIP>" +
	 * "<SPECIFY_RELATION>"+jsonObj.get("PleaseSpecify").toString()+
	 * "</SPECIFY_RELATION>" + "</Q_LIST_GUARDIAN_DETAILS>"; }
	 * 
	 * 
	 * //child details JSONObject ChildDetailsObj = (JSONObject)
	 * jsonParser.parse(PersonalInformationObj.get("ChildDetails").toString());
	 * 
	 * Q_Personal_Other_Client_type3 = (String) ChildDetailsObj.get("ClientType");
	 * Q_Personal_Other_First_Name4 = (String) ChildDetailsObj.get("FirstName");
	 * Q_Personal_Other_Middle_Name4 = (String) ChildDetailsObj.get("MiddleName");
	 * Q_Personal_Other_Last_Name4 = (String) ChildDetailsObj.get("LastName");
	 * Q_Personal_Other_DOB4 = (String) ChildDetailsObj.get("DOB"); String
	 * Q_CHILD_DETAILS_SAME_AS_NOMINEE = (String)
	 * ChildDetailsObj.get("SameAsNominee"); attributesXML = attributesXML +
	 * "<Q_CHILD_DETAILS>" + "<CLIENT_TYPE>" + Q_Personal_Other_Client_type3 +
	 * "</CLIENT_TYPE>" + "<FIRST_NAME>" + Q_Personal_Other_First_Name4 +
	 * "</FIRST_NAME>" + "<Middle_Name>" + Q_Personal_Other_Middle_Name4 +
	 * "</Middle_Name>" + "<Last_Name>" + Q_Personal_Other_Last_Name4 +
	 * "</Last_Name>" + "<DOB>" + Q_Personal_Other_DOB4 + "</DOB>" +
	 * "<SAME_AS_NOMINEE>" + Q_CHILD_DETAILS_SAME_AS_NOMINEE + "</SAME_AS_NOMINEE>"
	 * //SAME_AS_NOMINEE + "</Q_CHILD_DETAILS>";
	 * 
	 * //policy validation details section JSONObject PolValidationDetailsObj =
	 * (JSONObject)
	 * jsonParser.parse(PersonalInformationObj.get("PolicyValidiationDetails").
	 * toString());
	 * 
	 * //Adding Data in jsonValidate for Policy Validiation Details
	 * jsonValidate.put("PolicyValidiationDetails.IncomeSegment", (String)
	 * PolValidationDetailsObj.get("IncomeSegment"));
	 * 
	 * 
	 * attributesXML = attributesXML + "<Q_POLICY_VALIDATION_DETAILS>\r\n" +
	 * //"<STRAIGHT_PASS_CASE>"+(String)
	 * PolValidationDetailsObj.get("StraightPassCase")+"</STRAIGHT_PASS_CASE>\r\n" +
	 * "<DEDUPE>"+(String)
	 * PolValidationDetailsObj.get("DedupeExactMatch")+"</DEDUPE>\r\n" +
	 * "<PAN_CARD_COPY_REQ>"+(String)
	 * PolValidationDetailsObj.get("PANCardCopyRequired")+"</PAN_CARD_COPY_REQ>\r\n"
	 * + "<ID_DOB_PROOF_REQ>"+(String)
	 * PolValidationDetailsObj.get("DOBProofRequired")+"</ID_DOB_PROOF_REQ>\r\n" +
	 * "<INCOME_PROOF_PROP>"+(String)
	 * PolValidationDetailsObj.get("IncomeProofForProposer")+
	 * "</INCOME_PROOF_PROP>\r\n" + "<NACH_REQ>"+(String)
	 * PolValidationDetailsObj.get("NACHRequired")+"</NACH_REQ>\r\n" +
	 * "<PHOTO_REQ>"+(String)
	 * PolValidationDetailsObj.get("PhotographRequired")+"</PHOTO_REQ>\r\n" +
	 * "<NEFT_SUPPORT_DOC_REQ>"+(String)
	 * PolValidationDetailsObj.get("NEFTDocRequired")+"</NEFT_SUPPORT_DOC_REQ>\r\n"
	 * + "<CREDIT_SCORE>"+(String)
	 * PolValidationDetailsObj.get("CreditScore")+"</CREDIT_SCORE>\r\n" +
	 * "<INCOME_SEGMENT>"+(String)
	 * PolValidationDetailsObj.get("IncomeSegment")+"</INCOME_SEGMENT>\r\n" +
	 * "<BSE_500>"+(String) PolValidationDetailsObj.get("BSE500")+"</BSE_500>\r\n" +
	 * "<IRP_REQ>"+(String)
	 * PolValidationDetailsObj.get("IRPRequired")+"</IRP_REQ>\r\n" +
	 * "<FACT_FINDER_REQ>"+(String)
	 * PolValidationDetailsObj.get("FactFinderRequired")+"</FACT_FINDER_REQ>\r\n" +
	 * "</Q_POLICY_VALIDATION_DETAILS>";
	 * 
	 * attributesXML = attributesXML+ "<STRAIGHT_PASS_CASE>" + (String)
	 * PolValidationDetailsObj.get("StraightPassCase") + "</STRAIGHT_PASS_CASE>";
	 * 
	 * //product and payment info TAB JSONObject ProductAndPaymentObj = (JSONObject)
	 * jsonParser.parse(json.get("ProductandPaymentInformation").toString());
	 * 
	 * //CoverageDetails String Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT =
	 * "",Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM = "",
	 * Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM = "",Q_COVERAGE_DETAILS_AFYP = "";
	 * //Q_COVERAGE_DETAILS_DEATH_BENEFIT JSONObject CoverageDetailsObj =
	 * (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("CoverageDetails").toString());
	 * 
	 * Q_COVERAGE_DETAILS_PRODUCT_NAME = (String)
	 * CoverageDetailsObj.get("ProductName"); Q_COVERAGE_DETAILS_VESTING_AGE =
	 * (String) CoverageDetailsObj.get("VestingAge");
	 * Q_COVERAGE_DETAILS_COVERAGE_TERM = (String)
	 * CoverageDetailsObj.get("CoverageTerm"); Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM =
	 * (String) CoverageDetailsObj.get("PremiumPaymentTerm");
	 * Q_COVERAGE_DETAILS_PREMIUM_BACK = (String)
	 * CoverageDetailsObj.get("PremiumBackOption");
	 * Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE = (String)
	 * CoverageDetailsObj.get("CoverageMultiple"); Q_COVERAGE_DETAILS_SUM_ASSURED =
	 * (String) CoverageDetailsObj.get("SumAssured");
	 * Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT = (String)
	 * CoverageDetailsObj.get("GuaranteedDeathBenefit");
	 * Q_COVERAGE_DETAILS_DEATH_BENEFIT = (String)
	 * CoverageDetailsObj.get("DeathBenefit"); Q_COVERAGE_DETAILS_ATP = (String)
	 * CoverageDetailsObj.get("ATP"); Q_COVERAGE_DETAILS_MODE_OF_PAY = (String)
	 * CoverageDetailsObj.get("ModeofPayment"); Q_COVERAGE_DETAILS_MODAL_PREMIUM =
	 * (String) CoverageDetailsObj.get("ModalPremium"); Q_COVERAGE_DETAILS_GST =
	 * (String) CoverageDetailsObj.get("ServiceTaxGST");
	 * Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW = (String)
	 * CoverageDetailsObj.get("SaveMoreTomorrow"); Q_COVERAGE_DETAILS_EMP_DISCOUNT =
	 * (String) CoverageDetailsObj.get("EmployeeDiscount");
	 * Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT = (String)
	 * CoverageDetailsObj.get("ExistingCustomerDiscount");
	 * Q_COVERAGE_DETAILS_SMOKER_CLASS = (String)
	 * CoverageDetailsObj.get("SmokerClass"); Q_COVERAGE_DETAILS_LIFE_EVENT =
	 * (String) CoverageDetailsObj.get("LifeEvent");
	 * Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME = (String)
	 * CoverageDetailsObj.get("GuaranteedMonthlyIncome");
	 * Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME = (String)
	 * CoverageDetailsObj.get("GuaranteeAnnualIncome");
	 * Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY = (String)
	 * CoverageDetailsObj.get("GIPPayoutDay"); Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD
	 * = (String) CoverageDetailsObj.get("GIPPayoutMethod");
	 * Q_COVERAGE_DETAILS_NON_FORFEITURE = (String)
	 * CoverageDetailsObj.get("NonForfeitureOption");
	 * Q_COVERAGE_DETAILS_BONUS_OPTION = (String)
	 * CoverageDetailsObj.get("BonusOption"); Q_COVERAGE_DETAILS_EFFECTIVE_DATE =
	 * (String) CoverageDetailsObj.get("EffectiveDate");
	 * Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM = (String)
	 * CoverageDetailsObj.get("RequiredModalPremium");
	 * Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM = (String)
	 * CoverageDetailsObj.get("TotalRequiredPremium"); Q_COVERAGE_DETAILS_AFYP =
	 * (String) CoverageDetailsObj.get("AFYP");
	 * 
	 * //Adding Data in jsonValidate for Coverage Details
	 * //jsonValidate.put("CoverageDetails.GIPPayoutDay", );
	 * jsonValidate.put("CoverageDetails.GIPPayoutDay",
	 * Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY);
	 * jsonValidate.put("CoverageDetails.GIPPayoutMethod",
	 * Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD);
	 * jsonValidate.put("CoverageDetails.NonForfeitureOption",
	 * Q_COVERAGE_DETAILS_NON_FORFEITURE );
	 * jsonValidate.put("CoverageDetails.BonusOption",
	 * Q_COVERAGE_DETAILS_BONUS_OPTION);
	 * jsonValidate.put("CoverageDetails.DeathBenefit",
	 * Q_COVERAGE_DETAILS_DEATH_BENEFIT);
	 * jsonValidate.put("CoverageDetails.SmokerClass",
	 * Q_COVERAGE_DETAILS_SMOKER_CLASS);
	 * 
	 * JSONArray riderDetailsArray;
	 * riderDetailsArray=(JSONArray)CoverageDetailsObj.get("RiderDetails");
	 * insertionOrderId=0;hashID=1;
	 * 
	 * for (Object j : riderDetailsArray) { JSONObject jsonObj=(JSONObject)j;
	 * 
	 * attributesXML = attributesXML + "<Q_LIST_RIDER_DETAILS>\r\n" +
	 * "<InsertionOrderId>"+insertionOrderId+"</InsertionOrderId>\r\n" + "<HashId>"+
	 * hashID++ +"</HashId>\r\n" +
	 * "<RIDER_TYPE>"+jsonObj.get("RiderType").toString()+"</RIDER_TYPE>"+
	 * "<COVERAGE_TERM>"+jsonObj.get("CoverageTerm").toString()+
	 * "</COVERAGE_TERM>\r\n" +
	 * "<SUM_ASSURED>"+jsonObj.get("SumAssured").toString()+"</SUM_ASSURED>\r\n" +
	 * "<MODAL_PREMIUM>"+jsonObj.get("ModalPremium").toString()+
	 * "</MODAL_PREMIUM>\r\n" + "<GST>"+jsonObj.get("GST").toString()+"</GST>\r\n" +
	 * "<INSURED_DETAILS>" +jsonObj.get("RiderInsuredDetails").toString()+
	 * "</INSURED_DETAILS>"+
	 * //"<REQD_MODAL_PREMIUM>"+jsonObj.get("RequriedModalPremium").toString()+
	 * "</REQD_MODAL_PREMIUM>\r\n" +
	 * //"<TOTAL_REQD_PREMIUM>"+jsonObj.get("TotalRequiredPremium").toString()+
	 * "</TOTAL_REQD_PREMIUM>\r\n" +
	 * //"<AFYP>"+jsonObj.get("AFYP").toString()+"</AFYP>\r\n" +
	 * "</Q_LIST_RIDER_DETAILS>"; } hashID=1;
	 * 
	 * attributesXML = attributesXML + "<Q_COVERAGE_DETAILS>" + "<PRODUCT_NAME>" +
	 * Q_COVERAGE_DETAILS_PRODUCT_NAME + "</PRODUCT_NAME>" + "<VESTING_AGE>" +
	 * Q_COVERAGE_DETAILS_VESTING_AGE + "</VESTING_AGE>" + "<COVERAGE_TERM>" +
	 * Q_COVERAGE_DETAILS_COVERAGE_TERM + "</COVERAGE_TERM>" + "<PREMIUM_PAY_TERM>"
	 * + Q_COVERAGE_DETAILS_PREMIUM_PAY_TERM + "</PREMIUM_PAY_TERM>" +
	 * "<PREMIUM_BACK>" + Q_COVERAGE_DETAILS_PREMIUM_BACK + "</PREMIUM_BACK>" +
	 * "<COVERAGE_MULTIPLE>" + Q_COVERAGE_DETAILS_COVERAGE_MULTIPLE +
	 * "</COVERAGE_MULTIPLE>" + "<SUM_ASSURED>" + Q_COVERAGE_DETAILS_SUM_ASSURED +
	 * "</SUM_ASSURED>" + "<GUARANTEE_DEATH_BENEFIT>" +
	 * Q_COVERAGE_DETAILS_GURANTEED_DEATH_BENEFIT + "</GUARANTEE_DEATH_BENEFIT>" +
	 * "<DEATH_BENEFIT>" + Q_COVERAGE_DETAILS_DEATH_BENEFIT + "</DEATH_BENEFIT>" +
	 * "<ATP>" + Q_COVERAGE_DETAILS_ATP + "</ATP>" + "<MODE_OF_PAY>" +
	 * Q_COVERAGE_DETAILS_MODE_OF_PAY + "</MODE_OF_PAY>" + "<MODAL_PREMIUM>" +
	 * Q_COVERAGE_DETAILS_MODAL_PREMIUM + "</MODAL_PREMIUM>" + "<GST>" +
	 * Q_COVERAGE_DETAILS_GST + "</GST>" + "<SAVE_MORE_TOMORROW>" +
	 * Q_COVERAGE_DETAILS_SAVE_MORE_TOMORROW + "</SAVE_MORE_TOMORROW>" +
	 * "<EMP_DISCOUNT>" + Q_COVERAGE_DETAILS_EMP_DISCOUNT + "</EMP_DISCOUNT>" +
	 * "<EXISTING_CUST_DISCOUNT>" + Q_COVERAGE_DETAILS_EXISTING_CUST_DISCOUNT +
	 * "</EXISTING_CUST_DISCOUNT>" + "<SMOKER_CLASS>" +
	 * Q_COVERAGE_DETAILS_SMOKER_CLASS + "</SMOKER_CLASS>" + "<LIFE_EVENT>" +
	 * Q_COVERAGE_DETAILS_LIFE_EVENT + "</LIFE_EVENT>" + "<GUARANTEE_MON_INCOME>" +
	 * Q_COVERAGE_DETAILS_GUARANTEE_MON_INCOME + "</GUARANTEE_MON_INCOME>" +
	 * "<GUARANTEE_ANNUAL_INCOME>" + Q_COVERAGE_DETAILS_GUARANTEE_ANNUAL_INCOME +
	 * "</GUARANTEE_ANNUAL_INCOME>" + "<GIP_PAYOUT_DAY>" +
	 * Q_COVERAGE_DETAILS_GIP_PAYOUT_DAY + "</GIP_PAYOUT_DAY>" +
	 * "<GIP_PAYOUT_METHOD>" + Q_COVERAGE_DETAILS_GIP_PAYOUT_METHOD +
	 * "</GIP_PAYOUT_METHOD>" + "<NON_FORFEITURE>" +
	 * Q_COVERAGE_DETAILS_NON_FORFEITURE + "</NON_FORFEITURE>" + "<BONUS_OPTION>" +
	 * Q_COVERAGE_DETAILS_BONUS_OPTION + "</BONUS_OPTION>" + "<EFFECTIVE_DATE>" +
	 * Q_COVERAGE_DETAILS_EFFECTIVE_DATE + "</EFFECTIVE_DATE>" +
	 * "<REQ_MODAL_PREMIUM>" + Q_COVERAGE_DETAILS_REQ_MODAL_PREMIUM +
	 * "</REQ_MODAL_PREMIUM>" + "<TOTAL_REQ_PREMIUM>" +
	 * Q_COVERAGE_DETAILS_TOTAL_REQ_PREMIUM + "</TOTAL_REQ_PREMIUM>" //+ "<AFYP>" +
	 * Q_COVERAGE_DETAILS_AFYP + "</AFYP>" + "</Q_COVERAGE_DETAILS>"; attributesXML
	 * = attributesXML+ "<AFYP>" + Q_COVERAGE_DETAILS_AFYP + "</AFYP>";
	 * 
	 * //FinancialInformation JSONObject FinancialInfoObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("FinancialInformation").toString())
	 * ;
	 * 
	 * Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds = (String)
	 * FinancialInfoObj.get("SourceofFunds"); L_IncomeProof = (String)
	 * FinancialInfoObj.get("IncomeProofofProposer");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle = (String)
	 * FinancialInfoObj.get("DoyouOwnaVehicle"); Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2
	 * = (String) FinancialInfoObj.get("2Wheeler");
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1 = (String)
	 * FinancialInfoObj.get("WhatwasThePriceofPurchase1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4 = (String)
	 * FinancialInfoObj.get("4Wheeler"); Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2
	 * = (String) FinancialInfoObj.get("WhatwasThePriceofPurchase2");
	 * 
	 * //Adding Data in jsonValidate for Financial Information
	 * jsonValidate.put("FinancialInformation.SourceofFunds",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds);
	 * jsonValidate.put("FinancialInformation.2Wheeler",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2);
	 * jsonValidate.put("FinancialInformation.WhatwasThePriceofPurchase1",
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1);
	 * jsonValidate.put("FinancialInformation.4Wheeler",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4);
	 * jsonValidate.put("FinancialInformation.WhatwasThePriceofPurchase2",
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2);
	 * 
	 * attributesXML = attributesXML + "<Q_FINANCIAL_INFORMATION>" +
	 * "<SOURCE_OF_FUNDS>" + Q_PRODUCT_AND_PAYMENT_INFO_Sourceoffunds +
	 * "</SOURCE_OF_FUNDS>" + "<OWN_VEHICLE>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_Doyouownavehicle + "</OWN_VEHICLE>" +
	 * "<Wheeler_2>" + Q_PRODUCT_AND_PAYMENT_INFO_Wheeler2 + "</Wheeler_2>" //+
	 * "<priceofpurchase1>" + Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase1 +
	 * "</priceofpurchase1>" + "<Wheeler_4>" + Q_PRODUCT_AND_PAYMENT_INFO_Wheeler4 +
	 * "</Wheeler_4>" //+ "<priceofpurchase2>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_priceofpurchase2 + "</priceofpurchase2>" +
	 * "</Q_FINANCIAL_INFORMATION>"; attributesXML = attributesXML
	 * //Q_LIST_INCOME_PROOF_PROP + "<Q_LIST>" + "<INCOME_PROOF_PROP>" +
	 * L_IncomeProof + "</INCOME_PROOF_PROP>" + "</Q_LIST>" ; //FundSelected
	 * JSONObject FundSelectedObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("FundSelected").toString());
	 * 
	 * Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation = (String)
	 * FundSelectedObj.get("Dynamicfundallocation");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile = (String)
	 * FundSelectedObj.get("InvesterProfile");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund = (String)
	 * FundSelectedObj.get("SystematicTransferFund");
	 * Q_PRODUCT_AND_PAYMENT_INFO_FundName = (String)
	 * FundSelectedObj.get("FundName"); Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation
	 * = (String) FundSelectedObj.get("InitialAllocation");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation = (String)
	 * FundSelectedObj.get("TotalFundAllocation");
	 * 
	 * //Adding Data in jsonValidate for Fund Selected
	 * jsonValidate.put("FundSelected.InvesterProfile",
	 * Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile);
	 * 
	 * attributesXML = attributesXML + "<Q_FUND_SELECTED>" + "<DFA>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_Dynamicfundallocation + "</DFA>" +
	 * "<INVESTER_PROFILE>" + Q_PRODUCT_AND_PAYMENT_INFO_Investerprofile +
	 * "</INVESTER_PROFILE>" + "<STP>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_Systematictransferfund + "</STP>" + "<Fund_Name>"
	 * + Q_PRODUCT_AND_PAYMENT_INFO_FundName + "</Fund_Name>" +
	 * "<INITIAL_ALLOCATION>" + Q_PRODUCT_AND_PAYMENT_INFO_Initialallocation +
	 * "</INITIAL_ALLOCATION>" + "<TOTAL_FUND_ALLOCATION>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_Totalfundallocation + "</TOTAL_FUND_ALLOCATION>" +
	 * "</Q_FUND_SELECTED>"; //NEFTDetails JSONObject NEFTDetailsObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("NEFTDetails").toString());
	 * 
	 * Payout_to_Account = (String) NEFTDetailsObj.get("IagreeforallPayouts");
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1 = (String)
	 * NEFTDetailsObj.get("BankAccountNumber1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1 = (String)
	 * NEFTDetailsObj.get("AccountHoldername1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1 = (String)
	 * NEFTDetailsObj.get("MICRCode1"); Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1 =
	 * (String) NEFTDetailsObj.get("IFSCCode1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1 = (String)
	 * NEFTDetailsObj.get("BankNameandBranch1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1 = (String)
	 * NEFTDetailsObj.get("TypeofBankAccount1");
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2 = (String)
	 * NEFTDetailsObj.get("BankAccountNumber2");
	 * Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2 = (String)
	 * NEFTDetailsObj.get("AccountHolderName2");
	 * Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2 = (String)
	 * NEFTDetailsObj.get("MICRCode2"); Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2 =
	 * (String) NEFTDetailsObj.get("IFSCCode2");
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2 = (String)
	 * NEFTDetailsObj.get("BankNameandBranch2");
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2 = (String)
	 * NEFTDetailsObj.get("TypeofBankAccount2");
	 * 
	 * //Adding Data in jsonValidate for NEFT Details
	 * jsonValidate.put("NEFTDetails.IagreeforallPayouts", Payout_to_Account);
	 * jsonValidate.put("NEFTDetails.TypeofBankAccount1",
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1);
	 * jsonValidate.put("NEFTDetails.TypeofBankAccount2",
	 * Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2);
	 * 
	 * 
	 * attributesXML = attributesXML + "<Q_NEFT_DETAILS>" + "<ACC_NO_NEFT>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber1 + "</ACC_NO_NEFT>" +
	 * "<HOLDER_NAME_NEFT>" + Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername1 +
	 * "</HOLDER_NAME_NEFT>" + "<MICR_NEFT>" + Q_PRODUCT_AND_PAYMENT_INFO_MICRCode1
	 * + "</MICR_NEFT>" + "<IFSC_NEFT>" + Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode1 +
	 * "</IFSC_NEFT>" + "<NAME_BRANCH_NEFT>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch1 + "</NAME_BRANCH_NEFT>" +
	 * "<TYPE_OF_ACC_NEFT>" + Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount1 +
	 * "</TYPE_OF_ACC_NEFT>" + "<ACC_NO_MWPA>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankAccountNumber2 + "</ACC_NO_MWPA>" +
	 * "<HOLDER_NAME_MWPA>" + Q_PRODUCT_AND_PAYMENT_INFO_AccountHoldername2 +
	 * "</HOLDER_NAME_MWPA>" + "<MICR_MWPA>" + Q_PRODUCT_AND_PAYMENT_INFO_MICRCode2
	 * + "</MICR_MWPA>" + "<IFSC_MWPA>" + Q_PRODUCT_AND_PAYMENT_INFO_IFSCCode2 +
	 * "</IFSC_MWPA>" + "<NAME_BRANCH_MWPA>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_BankNameandBranch2 + "</NAME_BRANCH_MWPA>" +
	 * "<TYPE_OF_ACC_MWPA>" + Q_PRODUCT_AND_PAYMENT_INFO_TypeofBankAccount2 +
	 * "</TYPE_OF_ACC_MWPA>" + "</Q_NEFT_DETAILS>"; attributesXML = attributesXML +
	 * "<Payout_to_Account>" + Payout_to_Account + "</Payout_to_Account>";
	 * //PaymentDetails
	 * 
	 * String Q_PAYMENT_DETAILS_BANK_ACC_NO="",Q_PAYMENT_DETAILS_MICR_CODE="",
	 * Q_PAYMENT_DETAILS_IFSC_CODE="", Q_PAYMENT_DETAILS_BANK_NAME="";
	 * 
	 * JSONObject PaymentDetailsObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("PaymentDetails").toString());
	 * 
	 * Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid = (String)
	 * PaymentDetailsObj.get("InitialPremiumPaid");
	 * Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod = (String)
	 * PaymentDetailsObj.get("InitialPremiumMethod"); //
	 * Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived = (String)
	 * PaymentDetailsObj.get("CashletterReceived"); Q_PAYMENT_DETAILS_BANK_ACC_NO =
	 * (String) PaymentDetailsObj.get("BankAccountNumber");
	 * Q_PAYMENT_DETAILS_MICR_CODE = (String) PaymentDetailsObj.get("MICRCode");
	 * Q_PAYMENT_DETAILS_IFSC_CODE = (String) PaymentDetailsObj.get("IFSCCode");
	 * Q_PAYMENT_DETAILS_BANK_NAME = (String)
	 * PaymentDetailsObj.get("BankNameAndBranch");
	 * 
	 * //Adding Data in jsonValidate for Payment Details
	 * jsonValidate.put("PaymentDetails.InitialPremiumMethod",
	 * Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod);
	 * 
	 * 
	 * attributesXML = attributesXML + "<Q_PAYMENT_DETAILS>" + "<INIT_PREM_PAID>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumPaid + "</INIT_PREM_PAID>" +
	 * "<INIT_PREM_METHOD>" + Q_PRODUCT_AND_PAYMENT_INFO_InitialPremiumMethod +
	 * "</INIT_PREM_METHOD>" //+ "<LETTER_RECEIVED>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_CashletterReceived + "</LETTER_RECEIVED>" +
	 * "<BANK_ACC_NO>" + Q_PAYMENT_DETAILS_BANK_ACC_NO + "</BANK_ACC_NO>" +
	 * "<MICR_CODE>" + Q_PAYMENT_DETAILS_MICR_CODE + "</MICR_CODE>" + "<IFSC_CODE>"
	 * + Q_PAYMENT_DETAILS_IFSC_CODE + "</IFSC_CODE>" + "<BANK_NAME>" +
	 * Q_PAYMENT_DETAILS_BANK_NAME + "</BANK_NAME>" + "</Q_PAYMENT_DETAILS>";
	 * //RenewalPremiumDetails JSONObject RenewalPremiumDetailsObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("RenewalPremiumDetails").toString()
	 * );
	 * 
	 * // String Q_RENEWAL_PREMIUM_DETAILS_CC_HOLDER_NAME =
	 * "",Q_RENEWAL_PREMIUM_DETAILS_CC_NO = "", //
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_EXPIRY_DATE = "",
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_TYPE = ""; // //
	 * Q_PRODUCT_AND_PAYMENT_INFO_RenewalPremiumMethod = (String)
	 * RenewalPremiumDetailsObj.get("RenewalPremiumMethod"); //
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_HOLDER_NAME = (String)
	 * RenewalPremiumDetailsObj.get("CCHolderName"); //
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_NO = (String)
	 * RenewalPremiumDetailsObj.get("CreditCardNo"); //
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_EXPIRY_DATE = (String)
	 * RenewalPremiumDetailsObj.get("CCExpiryDate"); //
	 * Q_RENEWAL_PREMIUM_DETAILS_CC_TYPE = (String)
	 * RenewalPremiumDetailsObj.get("CreditCardType"); // // //Adding Data in
	 * jsonValidate for Renewal Premium Details //
	 * jsonValidate.put("RenewalPremiumDetails.RenewalPremiumMethod", (String)
	 * RenewalPremiumDetailsObj.get("RenewalPremiumMethod")); //
	 * jsonValidate.put("RenewalPremiumDetails.BankAccountType", (String)
	 * RenewalPremiumDetailsObj.get("BankAccountType")); //
	 * jsonValidate.put("RenewalPremiumDetails.BillDrawDate1", (String)
	 * RenewalPremiumDetailsObj.get("BillDrawDate1")); //
	 * jsonValidate.put("RenewalPremiumDetails.CreditCardType", (String)
	 * RenewalPremiumDetailsObj.get("CreditCardType"));
	 * 
	 * attributesXML = attributesXML + "<Q_RENEWAL_PREMIUM_DETAILS>" +
	 * "<RENEWAL_PREM_METHOD>"+(String)
	 * RenewalPremiumDetailsObj.get("RenewalPremiumMethod")+"</RENEWAL_PREM_METHOD>"
	 * + "<BANK_ACCOUNT_NUMBER>"+(String)
	 * RenewalPremiumDetailsObj.get("BankAccountNumber")+"</BANK_ACCOUNT_NUMBER>" +
	 * "<ACCOUNT_HOLDER_NAME>"+(String)
	 * RenewalPremiumDetailsObj.get("AccountHolderName")+"</ACCOUNT_HOLDER_NAME>" +
	 * "<MICR_CODE>"+(String)
	 * RenewalPremiumDetailsObj.get("MICRCode")+"</MICR_CODE>" +
	 * "<IFSC_CODE>"+(String)
	 * RenewalPremiumDetailsObj.get("IFSCCode")+"</IFSC_CODE>" +
	 * "<BANK_NAME_BRANCH>"+(String)
	 * RenewalPremiumDetailsObj.get("BankNameAndBranch")+"</BANK_NAME_BRANCH>" +
	 * "<TYPE_OF_ACCOUNT>"+(String)
	 * RenewalPremiumDetailsObj.get("BankAccountType")+"</TYPE_OF_ACCOUNT>" +
	 * "<BILL_DRAW_DATE2>"+(String)
	 * RenewalPremiumDetailsObj.get("BillDrawDate1")+"</BILL_DRAW_DATE2>" +
	 * "<COMPANY_NAME>"+(String)
	 * RenewalPremiumDetailsObj.get("CompanyName")+"</COMPANY_NAME>" +
	 * "<BILL_DRAW_DATE1>"+(String)
	 * RenewalPremiumDetailsObj.get("BillDrawDate2")+"</BILL_DRAW_DATE1>" +
	 * "<CC_HOLDER_NAME>"+(String)
	 * RenewalPremiumDetailsObj.get("CCHolderName")+"</CC_HOLDER_NAME>" +
	 * "<CC_NO>"+(String) RenewalPremiumDetailsObj.get("CreditCardNo")+"</CC_NO>" +
	 * "<CC_EXPIRY_DATE>"+(String)
	 * RenewalPremiumDetailsObj.get("CCExpiryDate")+"</CC_EXPIRY_DATE>" +
	 * "<CC_TYPE>"+(String)
	 * RenewalPremiumDetailsObj.get("CreditCardType")+"</CC_TYPE>" +
	 * "</Q_RENEWAL_PREMIUM_DETAILS>";
	 * 
	 * 
	 * //PayorPANDetails JSONObject PayorPANDetailsObj = (JSONObject)
	 * jsonParser.parse(ProductAndPaymentObj.get("PayorPANDetails").toString());
	 * 
	 * String
	 * Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP="",Q_PAYOR_PAN_DETAILS_RELATIONSHIP="",
	 * Q_PAYOR_PAN_DETAILS_BANK_ACC_NO="",
	 * Q_PAYOR_PAN_DETAILS_BANK_NAME="",Q_PAYOR_PAN_DETAILS_CLIENT_ID="" ;
	 * 
	 * Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP = (String)
	 * PayorPANDetailsObj.get("IsPayorDifferent"); Q_PAYOR_PAN_DETAILS_RELATIONSHIP
	 * = (String) PayorPANDetailsObj.get("PayorProposerRelationship");
	 * Q_PAYOR_PAN_DETAILS_BANK_ACC_NO = (String)
	 * PayorPANDetailsObj.get("BankAccountNumber"); Q_PAYOR_PAN_DETAILS_BANK_NAME =
	 * (String) PayorPANDetailsObj.get("BankNameAndBranch");
	 * Q_PAYOR_PAN_DETAILS_CLIENT_ID = (String)
	 * PayorPANDetailsObj.get("PayorClientId");
	 * Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName = (String)
	 * PayorPANDetailsObj.get("PayorFirstName"); Q_PRODUCT_AND_PAYMENT_INFO_Middle =
	 * (String) PayorPANDetailsObj.get("Middle"); Q_PRODUCT_AND_PAYMENT_INFO_Last =
	 * (String) PayorPANDetailsObj.get("Last");
	 * Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth = (String)
	 * PayorPANDetailsObj.get("DateofBirth"); Q_PRODUCT_AND_PAYMENT_INFO_Gender =
	 * (String) PayorPANDetailsObj.get("Gender");
	 * Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber = (String)
	 * PayorPANDetailsObj.get("PayorPanNumber"); AppliedFor = (String)
	 * PayorPANDetailsObj.get("AppliedFor");
	 * Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication = (String)
	 * PayorPANDetailsObj.get("DateofApplication");
	 * Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber = (String)
	 * PayorPANDetailsObj.get("AppAckNumber");
	 * //Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId = (String)
	 * PayorPANDetailsObj.get("PayorClientId");
	 * 
	 * //Adding Data in jsonValidate for Payor PAN Details
	 * jsonValidate.put("PayorPANDetails.PayorProposerRelationship",
	 * Q_PAYOR_PAN_DETAILS_RELATIONSHIP);
	 * 
	 * attributesXML = attributesXML + "<Q_PAYOR_PAN_DETAILS>" + "<PAYOR_DIFF_PROP>"
	 * + Q_PAYOR_PAN_DETAILS_PAYOR_DIFF_PROP + "</PAYOR_DIFF_PROP>" +
	 * "<RELATIONSHIP>" + Q_PAYOR_PAN_DETAILS_RELATIONSHIP + "</RELATIONSHIP>" +
	 * "<BANK_ACC_NO>" + Q_PAYOR_PAN_DETAILS_BANK_ACC_NO + "</BANK_ACC_NO>" +
	 * "<BANK_NAME>" + Q_PAYOR_PAN_DETAILS_BANK_NAME + "</BANK_NAME>" +
	 * "<CLIENT_ID>" + Q_PAYOR_PAN_DETAILS_CLIENT_ID + "</CLIENT_ID>" +
	 * "<FIRST_NAME>" + Q_PRODUCT_AND_PAYMENT_INFO_PayorsFirstName + "</FIRST_NAME>"
	 * + "<MIDDLE_NAME>" + Q_PRODUCT_AND_PAYMENT_INFO_Middle + "</MIDDLE_NAME>" +
	 * "<LAST_NAME>" + Q_PRODUCT_AND_PAYMENT_INFO_Last + "</LAST_NAME>" +
	 * "<DATE_OF_BIRTH>" + Q_PRODUCT_AND_PAYMENT_INFO_Dateofbirth +
	 * "</DATE_OF_BIRTH>" + "<Gender>" + Q_PRODUCT_AND_PAYMENT_INFO_Gender +
	 * "</Gender>" + "<PAN_NUMBER>" + Q_PRODUCT_AND_PAYMENT_INFO_PayorsPanNumber +
	 * "</PAN_NUMBER>" + "<DATE_OF_APPLICATION>" +
	 * Q_PRODUCT_AND_PAYMENT_INFO_DateofApplication + "</DATE_OF_APPLICATION>" +
	 * "<APP_ACK_NO>" + Q_PRODUCT_AND_PAYMENT_INFO_ApplicationAcknowledgementNumber
	 * + "</APP_ACK_NO>" + "<APPLIED_FOR_PAN>" + AppliedFor + "</APPLIED_FOR_PAN>"
	 * //+ "<CLIENT_ID>" + Q_PRODUCT_AND_PAYMENT_INFO_PayorClientId + "</CLIENT_ID>"
	 * + "</Q_PAYOR_PAN_DETAILS>"; // // attributesXML = attributesXML // +
	 * "<AppliedFor>" + AppliedFor + "</AppliedFor>"; //
	 * 
	 * 
	 * //Medical&PreviousPolicyinformation JSONObject MedicalPrevPolInfoObj =
	 * (JSONObject)
	 * jsonParser.parse(json.get("MedicalAndPreviousPolicyinformation").toString());
	 * 
	 * //FamilyInformation JSONObject FamilyInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("FamilyInformation").toString());
	 * 
	 * attributesXML = attributesXML + "<Q_FAMILY_INFORMATION>\r\n" +
	 * "<DIAGNOSED_WITH>"+(String)
	 * FamilyInformationObj.get("HasDiagnosed")+"</DIAGNOSED_WITH>\r\n" +
	 * "</Q_FAMILY_INFORMATION>";
	 * 
	 * 
	 * //FemaleInformation JSONObject FemaleInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("FemaleInformation").toString());
	 * 
	 * //Adding Data in jsonValidate for Female Information
	 * jsonValidate.put("FemaleInformation.HowManyMonths", (String)
	 * FemaleInformationObj.get("HowManyMonths"));
	 * jsonValidate.put("FemaleInformation.SpouceOccupation", (String)
	 * FemaleInformationObj.get("SpouceOccupation"));
	 * 
	 * attributesXML = attributesXML + "<Q_FEMALE_INFORMATION>\r\n" +
	 * "<ARE_YOU_PREGNANT>"+(String)
	 * FemaleInformationObj.get("IsPregnant")+"</ARE_YOU_PREGNANT>\r\n" +
	 * "<HOW_MANY_MONTHS>"+(String)
	 * FemaleInformationObj.get("HowManyMonths")+"</HOW_MANY_MONTHS>\r\n" +
	 * "<PREGNANCY_COMPLICATIONS>"+(String)
	 * FemaleInformationObj.get("IsComplications")+"</PREGNANCY_COMPLICATIONS>\r\n"
	 * + "<PREGNANCY_COMPLICATIONS_DETAILS>"+(String)
	 * FemaleInformationObj.get("GiveDetails")+
	 * "</PREGNANCY_COMPLICATIONS_DETAILS>\r\n" + "<SPOUCE_OCCUPATION>"+(String)
	 * FemaleInformationObj.get("SpouceOccupation")+"</SPOUCE_OCCUPATION>\r\n" +
	 * "<SPOUCE_INCOME>"+(String)
	 * FemaleInformationObj.get("SpouceIncome")+"</SPOUCE_INCOME>\r\n" +
	 * "<SPOUCE_INSURANCE_AMOUNT>"+(String)
	 * FemaleInformationObj.get("AreyouPregnant")+"</SPOUCE_INSURANCE_AMOUNT>\r\n" +
	 * "</Q_FEMALE_INFORMATION>";
	 * 
	 * //Habit Information JSONObject HabitInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("HabitInformation").toString());
	 * attributesXML = attributesXML + "<Q_HABIT_QUESTIONS>\r\n" +
	 * "<TOBACCO_PROP>"+(String)
	 * HabitInformationObj.get("TobaccoProp")+"</TOBACCO_PROP>\r\n" +
	 * "<TOBACCO_INSUR>"+(String)
	 * HabitInformationObj.get("TobaccoInsur")+"</TOBACCO_INSUR>\r\n" +
	 * "<SMOKING_PROP>"+(String)
	 * HabitInformationObj.get("SmokingProp")+"</SMOKING_PROP>\r\n" +
	 * "<SMOKING_INSUR>"+(String)
	 * HabitInformationObj.get("SmokingInsur")+"</SMOKING_INSUR>\r\n" +
	 * "<ALCOHOL_PROP>"+(String)
	 * HabitInformationObj.get("AlcoholProp")+"</ALCOHOL_PROP>\r\n" +
	 * "<ALCOHOL_INSUR>"+(String)
	 * HabitInformationObj.get("AlcoholInsur")+"</ALCOHOL_INSUR>\r\n" +
	 * "<LIQUOR_PROP>"+(String)
	 * HabitInformationObj.get("LiquorProp")+"</LIQUOR_PROP>\r\n" +
	 * "<LIQUOR_INSUR>"+(String)
	 * HabitInformationObj.get("LiquorInsur")+"</LIQUOR_INSUR>\r\n" +
	 * "<QUIT_ALCOHOL_PROP>"+(String)
	 * HabitInformationObj.get("QuitAlcoholProp")+"</QUIT_ALCOHOL_PROP>\r\n" +
	 * "<QUIT_ALCOHOL_INSUR>"+(String)
	 * HabitInformationObj.get("QuitAlcoholInsur")+"</QUIT_ALCOHOL_INSUR>\r\n" +
	 * "<DRUGS_PROP>"+(String)
	 * HabitInformationObj.get("DrugsProp")+"</DRUGS_PROP>\r\n" +
	 * "<DRUGS_INSUR>"+(String)
	 * HabitInformationObj.get("DrugsInsur")+"</DRUGS_INSUR>\r\n" +
	 * "<DRUGS_DETAILS_PROP>"+(String)
	 * HabitInformationObj.get("DrugsDetailsProp")+"</DRUGS_DETAILS_PROP>\r\n" +
	 * "<DRUGS_DETAILS_INSUR>"+(String)
	 * HabitInformationObj.get("DrugsDetailsInsur")+"</DRUGS_DETAILS_INSUR>\r\n" +
	 * "</Q_HABIT_QUESTIONS>";
	 * 
	 * //MedicalInformationProp JSONObject MedInfoProposer = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("MedicalInformationProp").toString
	 * ());
	 * 
	 * //Adding Data in jsonValidate for Medical Information Prop
	 * jsonValidate.put("MedicalInformationProp.ManagingDiabetes", (String)
	 * MedInfoProposer.get("ManagingDiabetes"));
	 * jsonValidate.put("MedicalInformationProp.DiabeticFor", (String)
	 * MedInfoProposer.get("DiabeticFor"));
	 * 
	 * attributesXML = attributesXML + "<Q_MED_INFO_PROP>"+ "<DIABETES>"+(String)
	 * MedInfoProposer.get("Diabetes")+"</DIABETES>"+ "<MANAGING_DIABETES>"+(String)
	 * MedInfoProposer.get("ManagingDiabetes")+"</MANAGING_DIABETES>"+
	 * "<DIABETIC_FOR>"+(String)
	 * MedInfoProposer.get("DiabeticFor")+"</DIABETIC_FOR>"+
	 * "<DIABETES_COMPLICATIONS>"+(String)
	 * MedInfoProposer.get("DiabetesComplications")+"</DIABETES_COMPLICATIONS>"+
	 * "<DIABETES_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("DiabetesOtherDetails")+"</DIABETES_OTHER_DETAILS>"+
	 * "<HYPERTENSION_BP>"+(String)
	 * MedInfoProposer.get("HypertensionBp")+"</HYPERTENSION_BP>"+
	 * "<BP_UNDER_CONTROL>"+(String)
	 * MedInfoProposer.get("BpUnderControl")+"</BP_UNDER_CONTROL>"+
	 * "<CHOLESTEROL_UNDER_CONTROL>"+(String)
	 * MedInfoProposer.get("CholesterolUnderControl")+
	 * "</CHOLESTEROL_UNDER_CONTROL>"+ "<THYROID_UNDER_CONTROL>"+(String)
	 * MedInfoProposer.get("ThyroidUnderControl")+"</THYROID_UNDER_CONTROL>"+
	 * "<BP_CHOLESTEROL_DETAILS>"+(String)
	 * MedInfoProposer.get("BpCholesterolDetails")+"</BP_CHOLESTEROL_DETAILS>"+
	 * "<HEART_DISORDER>"+(String)
	 * MedInfoProposer.get("HeartDisorder")+"</HEART_DISORDER>"+
	 * "<HISTORY_OF_CHEST_PAIN>"+(String)
	 * MedInfoProposer.get("HistoryOfChestPain")+"</HISTORY_OF_CHEST_PAIN>"+
	 * "<CHEST_PAIN_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("ChestPainOtherDetails")+"</CHEST_PAIN_OTHER_DETAILS>"+
	 * "<LUNG_DISORDERS>"+(String)
	 * MedInfoProposer.get("LungDisorders")+"</LUNG_DISORDERS>"+
	 * "<HISTORY_OF_TUBERCULOSIS>"+(String)
	 * MedInfoProposer.get("HistoryOfTuberculosis")+"</HISTORY_OF_TUBERCULOSIS>"+
	 * "<ALLERGIC_BRONCHITIS>"+(String)
	 * MedInfoProposer.get("AllergicBronchitis")+"</ALLERGIC_BRONCHITIS>"+
	 * "<HISTORY_OF_ASTHMA>"+(String)
	 * MedInfoProposer.get("HistoryOfAsthma")+"</HISTORY_OF_ASTHMA>"+
	 * "<LUNG_DISORDERS_DETAILS>"+(String)
	 * MedInfoProposer.get("LungDisordersDetails")+"</LUNG_DISORDERS_DETAILS>"+
	 * "<LIVER_RELATED_DISORDER>"+(String)
	 * MedInfoProposer.get("LiverRelatedDisorder")+"</LIVER_RELATED_DISORDER>"+
	 * "<HISTORY_OF_JAUNDICE>"+(String)
	 * MedInfoProposer.get("HistoryOfJaundice")+"</HISTORY_OF_JAUNDICE>"+
	 * "<INDIGESTION_CONSTIPATION>"+(String)
	 * MedInfoProposer.get("IndigestionConstipation")+"</INDIGESTION_CONSTIPATION>"+
	 * "<HISTORY_OF_GALL_BLADDER>"+(String)
	 * MedInfoProposer.get("HistoryOfGallBladder")+"</HISTORY_OF_GALL_BLADDER>"+
	 * "<HISTORY_OF_STONES>"+(String)
	 * MedInfoProposer.get("HistoryOfStones")+"</HISTORY_OF_STONES>"+
	 * "<LIVER_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("LiverOtherDetails")+"</LIVER_OTHER_DETAILS>"+
	 * "<ABNORMAL_GROWTH_OR_STD>"+(String)
	 * MedInfoProposer.get("AbnormalGrowthOrStd")+"</ABNORMAL_GROWTH_OR_STD>"+
	 * "<HISTORY_OF_IRON_DEFICIENCY>"+(String)
	 * MedInfoProposer.get("HistoryOfIronDeficiency")+
	 * "</HISTORY_OF_IRON_DEFICIENCY>"+ "<HISTORY_OF_LIPOMA>"+(String)
	 * MedInfoProposer.get("HistoryOfLipoma")+"</HISTORY_OF_LIPOMA>"+
	 * "<ABNORMAL_GROWTH_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("AbnormalGrowthOtherDetails")+
	 * "</ABNORMAL_GROWTH_OTHER_DETAILS>"+ "<KIDNEY_DISORDER>"+(String)
	 * MedInfoProposer.get("KidneyDisorder")+"</KIDNEY_DISORDER>"+
	 * "<HISTORY_OF_UTI>"+(String)
	 * MedInfoProposer.get("HistoryOfUti")+"</HISTORY_OF_UTI>"+
	 * "<HISTORY_OF_KIDNEY_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfKidneySurgery")+"</HISTORY_OF_KIDNEY_SURGERY>"+
	 * "<HISTORY_OF_STONE>"+(String)
	 * MedInfoProposer.get("HistoryOfStone")+"</HISTORY_OF_STONE>"+
	 * "<KIDNEY_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("KidneyOtherDetails")+"</KIDNEY_OTHER_DETAILS>"+
	 * "<NEUROLOGICAL_PROBLEM>"+(String)
	 * MedInfoProposer.get("NeurologicalProblem")+"</NEUROLOGICAL_PROBLEM>"+
	 * "<NEUROLOGICAL_DETAILS>"+(String)
	 * MedInfoProposer.get("NeurologicalDetails")+"</NEUROLOGICAL_DETAILS>"+
	 * "<MUSCULAR_JOINT_DISORDERS>"+(String)
	 * MedInfoProposer.get("MuscularJointDisorders")+"</MUSCULAR_JOINT_DISORDERS>"+
	 * "<BACK_PAIN_SLIP_DISC>"+(String)
	 * MedInfoProposer.get("BackPainSlipDisc")+"</BACK_PAIN_SLIP_DISC>"+
	 * "<SUGGESTED_PHYSIOTHERAPY>"+(String)
	 * MedInfoProposer.get("SuggestedPhysiotherapy")+"</SUGGESTED_PHYSIOTHERAPY>"+
	 * "<HISTORY_OF_HAIRLINE_FRACTURE>"+(String)
	 * MedInfoProposer.get("HistoryOfHairlineFracture")+
	 * "</HISTORY_OF_HAIRLINE_FRACTURE>"+ "<HISTORY_OF_OSTEOARTHRITIS>"+(String)
	 * MedInfoProposer.get("HistoryOfOsteoarthritis")+
	 * "</HISTORY_OF_OSTEOARTHRITIS>"+ "<HISTORY_OF_ANY_FRACTURE>"+(String)
	 * MedInfoProposer.get("HistoryOfAnyFracture")+"</HISTORY_OF_ANY_FRACTURE>"+
	 * "<MUSCULAR_JOINT_DETAILS>"+(String)
	 * MedInfoProposer.get("MuscularJointDetails")+"</MUSCULAR_JOINT_DETAILS>"+
	 * "<HISTORY_OF_HOSPITALIZATION>"+(String)
	 * MedInfoProposer.get("HistoryOfHospitalization")+
	 * "</HISTORY_OF_HOSPITALIZATION>"+ "<HOSPITALIZATION_FOR_FEVER>"+(String)
	 * MedInfoProposer.get("HospitalizationForFever")+
	 * "</HOSPITALIZATION_FOR_FEVER>"+ "<HOSPITALIZATION_OF_POISONING>"+(String)
	 * MedInfoProposer.get("HospitalizationOfPoisoning")+
	 * "</HOSPITALIZATION_OF_POISONING>"+ "<HOSPITALIZATION_FOR_ACCIDENT>"+(String)
	 * MedInfoProposer.get("HospitalizationForAccident")+
	 * "</HOSPITALIZATION_FOR_ACCIDENT>"+ "<HOSPITALIZED_FOR_CSECTION>"+(String)
	 * MedInfoProposer.get("HospitalizedForCsection")+
	 * "</HOSPITALIZED_FOR_CSECTION>"+ "<HOSPITALIZED_FOR_MALARIA>"+(String)
	 * MedInfoProposer.get("HospitalizedForMalaria")+"</HOSPITALIZED_FOR_MALARIA>"+
	 * "<HISTORY_OF_COLD>"+(String)
	 * MedInfoProposer.get("HistoryOfCold")+"</HISTORY_OF_COLD>"+
	 * "<HOSPITALIZATION_OTHER_DETAILS>"+(String)
	 * MedInfoProposer.get("HospitalizationOtherDetails")+
	 * "</HOSPITALIZATION_OTHER_DETAILS>"+ "<ADVISED_TESTS_XRAY_SURGERY>"+(String)
	 * MedInfoProposer.get("AdvisedTestsXraySurgery")+
	 * "</ADVISED_TESTS_XRAY_SURGERY>"+ "<HISTORY_OF_ACCIDENT_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfAccidentSurgery")+
	 * "</HISTORY_OF_ACCIDENT_SURGERY>"+ "<HISTORY_OF_APPENDIX_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfAppendixSurgery")+
	 * "</HISTORY_OF_APPENDIX_SURGERY>"+ "<HISTORY_OF_PILES_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfPilesSurgery")+"</HISTORY_OF_PILES_SURGERY>"+
	 * "<HISTORY_OF_STONE_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfStoneSurgery")+"</HISTORY_OF_STONE_SURGERY>"+
	 * "<SURGERY_FOR_INSERTION_RODS>"+(String)
	 * MedInfoProposer.get("SurgeryForInsertionRods")+
	 * "</SURGERY_FOR_INSERTION_RODS>"+ "<SIGHT_CORRECTION_LASIK>"+(String)
	 * MedInfoProposer.get("SightCorrectionLasik")+"</SIGHT_CORRECTION_LASIK>"+
	 * "<HISTORY_OF_CATARACT_SURGERY>"+(String)
	 * MedInfoProposer.get("HistoryOfCataractSurgery")+
	 * "</HISTORY_OF_CATARACT_SURGERY>"+ "<SURGERY_FOR_DNS>"+(String)
	 * MedInfoProposer.get("SurgeryForDns")+"</SURGERY_FOR_DNS>"+
	 * "<HISTORY_MRI_FOR_BACK>"+(String)
	 * MedInfoProposer.get("HistoryMriForBack")+"</HISTORY_MRI_FOR_BACK>"+
	 * "<HEALTH_CHECK_UP_NORMAL>"+(String)
	 * MedInfoProposer.get("HealthCheckUpNormal")+"</HEALTH_CHECK_UP_NORMAL>"+
	 * "<BLOOD_INVESTIGATIONS>"+(String)
	 * MedInfoProposer.get("BloodInvestigations")+"</BLOOD_INVESTIGATIONS>"+
	 * "<BLOOD_TEST_USG_DURING_PREGNANCY>"+(String)
	 * MedInfoProposer.get("BloodTestUsgDuringPregnancy")+
	 * "</BLOOD_TEST_USG_DURING_PREGNANCY>"+
	 * "<HISTORY_OF_TEST_BLOOD_DONATION>"+(String)
	 * MedInfoProposer.get("HistoryOfTestBloodDonation")+
	 * "</HISTORY_OF_TEST_BLOOD_DONATION>"+ "<ANY_OTHER_PLEASE_SPECIFY>"+(String)
	 * MedInfoProposer.get("AnyOtherPleaseSpecify")+"</ANY_OTHER_PLEASE_SPECIFY>"+
	 * "<DIAGNOSED_CONGENITAL_ANOMALY>"+(String)
	 * MedInfoProposer.get("DiagnosedCongenitalAnomaly")+
	 * "</DIAGNOSED_CONGENITAL_ANOMALY>"+ "<CONGENITAL_ANOMALY_DETAILS>"+(String)
	 * MedInfoProposer.get("CongenitalAnomalyDetails")+
	 * "</CONGENITAL_ANOMALY_DETAILS>"+ "<HAD_GENETIC_TESTING>"+(String)
	 * MedInfoProposer.get("HadGeneticTesting")+"</HAD_GENETIC_TESTING>"+
	 * "<GENETIC_TESTING_DETAILS>"+(String)
	 * MedInfoProposer.get("GeneticTestingDetails")+"</GENETIC_TESTING_DETAILS>"+
	 * "</Q_MED_INFO_PROP>";
	 * 
	 * //MedicalInformationInsured JSONObject MedInfoInsuredObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("MedicalInformationInsured").
	 * toString());
	 * 
	 * //Adding Data in jsonValidate for Medical Information Insured
	 * jsonValidate.put("MedicalInformationInsured.ManagingDiabetes", (String)
	 * MedInfoInsuredObj.get("ManagingDiabetes"));
	 * jsonValidate.put("MedicalInformationInsured.DiabeticFor", (String)
	 * MedInfoInsuredObj.get("DiabeticFor"));
	 * 
	 * attributesXML = attributesXML +
	 * //Q_MED_INFO_INSUR_SUGGESTED_PHYSIOTHERAPY_label "<Q_MED_INFO_INSUR>"+
	 * "<DIABETES>"+(String) MedInfoInsuredObj.get("Diabetes")+"</DIABETES>"+
	 * "<MANAGING_DIABETES>"+(String)
	 * MedInfoInsuredObj.get("ManagingDiabetes")+"</MANAGING_DIABETES>"+
	 * "<DIABETIC_FOR>"+(String)
	 * MedInfoInsuredObj.get("DiabeticFor")+"</DIABETIC_FOR>"+
	 * "<DIABETES_COMPLICATIONS>"+(String)
	 * MedInfoInsuredObj.get("DiabetesComplications")+"</DIABETES_COMPLICATIONS>"+
	 * "<DIABETES_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("DiabetesOtherDetails")+"</DIABETES_OTHER_DETAILS>"+
	 * "<HYPERTENSION_BP>"+(String)
	 * MedInfoInsuredObj.get("HypertensionBp")+"</HYPERTENSION_BP>"+
	 * "<BP_UNDER_CONTROL>"+(String)
	 * MedInfoInsuredObj.get("BpUnderControl")+"</BP_UNDER_CONTROL>"+
	 * "<CHOLESTEROL_UNDER_CONTROL>"+(String)
	 * MedInfoInsuredObj.get("CholesterolUnderControl")+
	 * "</CHOLESTEROL_UNDER_CONTROL>"+ "<THYROID_UNDER_CONTROL>"+(String)
	 * MedInfoInsuredObj.get("ThyroidUnderControl")+"</THYROID_UNDER_CONTROL>"+
	 * "<BP_CHOLESTEROL_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("BpCholesterolDetails")+"</BP_CHOLESTEROL_DETAILS>"+
	 * "<HEART_DISORDER>"+(String)
	 * MedInfoInsuredObj.get("HeartDisorder")+"</HEART_DISORDER>"+
	 * "<HISTORY_OF_CHEST_PAIN>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfChestPain")+"</HISTORY_OF_CHEST_PAIN>"+
	 * "<CHEST_PAIN_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("ChestPainOtherDetails")+"</CHEST_PAIN_OTHER_DETAILS>"+
	 * "<LUNG_DISORDERS>"+(String)
	 * MedInfoInsuredObj.get("LungDisorders")+"</LUNG_DISORDERS>"+
	 * "<HISTORY_OF_TUBERCULOSIS>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfTuberculosis")+"</HISTORY_OF_TUBERCULOSIS>"+
	 * "<ALLERGIC_BRONCHITIS>"+(String)
	 * MedInfoInsuredObj.get("AllergicBronchitis")+"</ALLERGIC_BRONCHITIS>"+
	 * "<HISTORY_OF_ASTHMA>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfAsthma")+"</HISTORY_OF_ASTHMA>"+
	 * "<LUNG_DISORDERS_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("LungDisordersDetails")+"</LUNG_DISORDERS_DETAILS>"+
	 * "<LIVER_RELATED_DISORDER>"+(String)
	 * MedInfoInsuredObj.get("LiverRelatedDisorder")+"</LIVER_RELATED_DISORDER>"+
	 * "<HISTORY_OF_JAUNDICE>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfJaundice")+"</HISTORY_OF_JAUNDICE>"+
	 * "<INDIGESTION_CONSTIPATION>"+(String)
	 * MedInfoInsuredObj.get("IndigestionConstipation")+
	 * "</INDIGESTION_CONSTIPATION>"+ "<HISTORY_OF_GALL_BLADDER>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfGallBladder")+"</HISTORY_OF_GALL_BLADDER>"+
	 * "<HISTORY_OF_STONES>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfStones")+"</HISTORY_OF_STONES>"+
	 * "<LIVER_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("LiverOtherDetails")+"</LIVER_OTHER_DETAILS>"+
	 * "<ABRMAL_GROWTH_OR_STD>"+(String)
	 * MedInfoInsuredObj.get("AbnormalGrowthOrStd")+"</ABRMAL_GROWTH_OR_STD>"+
	 * "<HISTORY_OF_IRON_DEFICIENCY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfIronDeficiency")+
	 * "</HISTORY_OF_IRON_DEFICIENCY>"+ "<HISTORY_OF_LIPOMA>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfLipoma")+"</HISTORY_OF_LIPOMA>"+
	 * "<ABRMAL_GROWTH_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("AbnormalGrowthOtherDetails")+
	 * "</ABRMAL_GROWTH_OTHER_DETAILS>"+ "<KIDNEY_DISORDER>"+(String)
	 * MedInfoInsuredObj.get("KidneyDisorder")+"</KIDNEY_DISORDER>"+
	 * "<HISTORY_OF_UTI>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfUti")+"</HISTORY_OF_UTI>"+
	 * "<HISTORY_OF_KIDNEY_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfKidneySurgery")+
	 * "</HISTORY_OF_KIDNEY_SURGERY>"+ "<HISTORY_OF_STONE>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfStone")+"</HISTORY_OF_STONE>"+
	 * "<KIDNEY_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("KidneyOtherDetails")+"</KIDNEY_OTHER_DETAILS>"+
	 * "<NEUROLOGICAL_PROBLEM>"+(String)
	 * MedInfoInsuredObj.get("NeurologicalProblem")+"</NEUROLOGICAL_PROBLEM>"+
	 * "<NEUROLOGICAL_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("NeurologicalDetails")+"</NEUROLOGICAL_DETAILS>"+
	 * "<MUSCULAR_JOINT_DISORDERS>"+(String)
	 * MedInfoInsuredObj.get("MuscularJointDisorders")+
	 * "</MUSCULAR_JOINT_DISORDERS>"+ "<BACK_PAIN_SLIP_DISC>"+(String)
	 * MedInfoInsuredObj.get("BackPainSlipDisc")+"</BACK_PAIN_SLIP_DISC>"+
	 * "<SUGGESTED_PHYSIOTHERAPY>"+(String)
	 * MedInfoInsuredObj.get("SuggestedPhysiotherapy")+"</SUGGESTED_PHYSIOTHERAPY>"+
	 * "<HISTORY_OF_HAIRLINE_FRACTURE>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfHairlineFracture")+
	 * "</HISTORY_OF_HAIRLINE_FRACTURE>"+ "<HISTORY_OF_OSTEOARTHRITIS>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfOsteoarthritis")+
	 * "</HISTORY_OF_OSTEOARTHRITIS>"+ "<HISTORY_OF_ANY_FRACTURE>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfAnyFracture")+"</HISTORY_OF_ANY_FRACTURE>"+
	 * "<MUSCULAR_JOINT_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("MuscularJointDetails")+"</MUSCULAR_JOINT_DETAILS>"+
	 * "<HISTORY_OF_HOSPITALIZATION>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfHospitalization")+
	 * "</HISTORY_OF_HOSPITALIZATION>"+ "<HOSPITALIZATION_FOR_FEVER>"+(String)
	 * MedInfoInsuredObj.get("HospitalizationForFever")+
	 * "</HOSPITALIZATION_FOR_FEVER>"+ "<HOSPITALIZATION_OF_POISONING>"+(String)
	 * MedInfoInsuredObj.get("HospitalizationOfPoisoning")+
	 * "</HOSPITALIZATION_OF_POISONING>"+ "<HOSPITALIZATION_FOR_ACCIDENT>"+(String)
	 * MedInfoInsuredObj.get("HospitalizationForAccident")+
	 * "</HOSPITALIZATION_FOR_ACCIDENT>"+ "<HOSPITALIZED_FOR_CSECTION>"+(String)
	 * MedInfoInsuredObj.get("HospitalizedForCsection")+
	 * "</HOSPITALIZED_FOR_CSECTION>"+ "<HOSPITALIZED_FOR_MALARIA>"+(String)
	 * MedInfoInsuredObj.get("HospitalizedForMalaria")+
	 * "</HOSPITALIZED_FOR_MALARIA>"+ "<HISTORY_OF_COLD>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfCold")+"</HISTORY_OF_COLD>"+
	 * "<HOSPITALIZATION_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("HospitalizationOtherDetails")+
	 * "</HOSPITALIZATION_OTHER_DETAILS>"+ "<ADVISED_TESTS_XRAY_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("AdvisedTestsXraySurgery")+
	 * "</ADVISED_TESTS_XRAY_SURGERY>"+ "<ADVISED_S_XRAY_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("AdvisedTestsXraySurgery")+"</ADVISED_S_XRAY_SURGERY>"+
	 * "<HISTORY_OF_ACCIDENT_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfAccidentSurgery")+
	 * "</HISTORY_OF_ACCIDENT_SURGERY>"+ "<HISTORY_OF_APPENDIX_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfAppendixSurgery")+
	 * "</HISTORY_OF_APPENDIX_SURGERY>"+ "<HISTORY_OF_PILES_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfPilesSurgery")+"</HISTORY_OF_PILES_SURGERY>"+
	 * "<HISTORY_OF_STONE_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfStoneSurgery")+"</HISTORY_OF_STONE_SURGERY>"+
	 * "<SURGERY_FOR_INSERTION_RODS>"+(String)
	 * MedInfoInsuredObj.get("SurgeryForInsertionRods")+
	 * "</SURGERY_FOR_INSERTION_RODS>"+ "<SIGHT_CORRECTION_LASIK>"+(String)
	 * MedInfoInsuredObj.get("SightCorrectionLasik")+"</SIGHT_CORRECTION_LASIK>"+
	 * "<HISTORY_OF_CATARACT_SURGERY>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfCataractSurgery")+
	 * "</HISTORY_OF_CATARACT_SURGERY>"+ "<SURGERY_FOR_DNS>"+(String)
	 * MedInfoInsuredObj.get("SurgeryForDns")+"</SURGERY_FOR_DNS>"+
	 * "<HISTORY_MRI_FOR_BACK>"+(String)
	 * MedInfoInsuredObj.get("HistoryMriForBack")+"</HISTORY_MRI_FOR_BACK>"+
	 * "<HEALTH_CHECK_UP_RMAL>"+(String)
	 * MedInfoInsuredObj.get("HealthCheckUpNormal")+"</HEALTH_CHECK_UP_RMAL>"+
	 * "<BLOOD_INVESTIGATIONS>"+(String)
	 * MedInfoInsuredObj.get("BloodInvestigations")+"</BLOOD_INVESTIGATIONS>"+
	 * "<BLOOD__USG_DURING_PREGNANCY>"+(String)
	 * MedInfoInsuredObj.get("BloodTestUsgDuringPregnancy")+
	 * "</BLOOD__USG_DURING_PREGNANCY>"+ "<HISTORY_OF__BLOOD_DONATION>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfTestBloodDonation")+
	 * "</HISTORY_OF__BLOOD_DONATION>"+ "<ANY_OTHER_PLEASE_SPECIFY>"+(String)
	 * MedInfoInsuredObj.get("AnyOtherPleaseSpecify")+"</ANY_OTHER_PLEASE_SPECIFY>"+
	 * "<DIAGSED_CONGENITAL_AMALY>"+(String)
	 * MedInfoInsuredObj.get("DiagnosedCongenitalAnomaly")+
	 * "</DIAGSED_CONGENITAL_AMALY>"+ "<CONGENITAL_AMALY_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("CongenitalAnomalyDetails")+
	 * "</CONGENITAL_AMALY_DETAILS>"+ "<HAD_GENETIC_ING>"+(String)
	 * MedInfoInsuredObj.get("HadGeneticTesting")+"</HAD_GENETIC_ING>"+
	 * "<GENETIC_ING_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("GeneticTestingDetails")+"</GENETIC_ING_DETAILS>"+
	 * "<BLOOD_TEST_USG_DURING_PREGNANCY>"+(String)
	 * MedInfoInsuredObj.get("BloodTestUsgDuringPregnancy")+
	 * "</BLOOD_TEST_USG_DURING_PREGNANCY>"+
	 * "<HISTORY_OF_TEST_BLOOD_DONATION>"+(String)
	 * MedInfoInsuredObj.get("HistoryOfTestBloodDonation")+
	 * "</HISTORY_OF_TEST_BLOOD_DONATION>"+
	 * "<DIAGNOSED_CONGENITAL_ANOMALY>"+(String)
	 * MedInfoInsuredObj.get("DiagnosedCongenitalAnomaly")+
	 * "</DIAGNOSED_CONGENITAL_ANOMALY>"+ "<CONGENITAL_ANOMALY_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("CongenitalAnomalyDetails")+
	 * "</CONGENITAL_ANOMALY_DETAILS>"+ "<HAD_GENETIC_TESTING>"+(String)
	 * MedInfoInsuredObj.get("HadGeneticTesting")+"</HAD_GENETIC_TESTING>"+
	 * "<GENETIC_TESTING_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("GeneticTestingDetails")+"</GENETIC_TESTING_DETAILS>"+
	 * "<ABNORMAL_GROWTH_OR_STD>"+(String)
	 * MedInfoInsuredObj.get("AbnormalGrowthOrStd")+"</ABNORMAL_GROWTH_OR_STD>"+
	 * "<ABNORMAL_GROWTH_OTHER_DETAILS>"+(String)
	 * MedInfoInsuredObj.get("AbnormalGrowthOtherDetails")+
	 * "</ABNORMAL_GROWTH_OTHER_DETAILS>"+ "</Q_MED_INFO_INSUR>";
	 * 
	 * //Height and Weight JSONObject HeightAndWeightObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("HeightandWeight").toString());
	 * attributesXML = attributesXML + "<Q_HEIGHT_AND_WEIGHT>\r\n" +
	 * "<HEIGHT_CM>"+(String) HeightAndWeightObj.get("HeightCM")+"</HEIGHT_CM>\r\n"
	 * + "<WEIGHT_KG>"+(String)
	 * HeightAndWeightObj.get("WeightKG")+"</WEIGHT_KG>\r\n" +
	 * "</Q_HEIGHT_AND_WEIGHT>";
	 * 
	 * //JuvenilleInformation JSONObject JuvenilleInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("JuvenilleInformation").toString()
	 * ); attributesXML = attributesXML + "<Q_JUVENILLE_INFO>\r\n" +
	 * "<PARENT_OCCUPATION>"+(String)
	 * JuvenilleInformationObj.get("ParentOccupation")+"</PARENT_OCCUPATION>\r\n" +
	 * "<PARENT_ANNUAL_INC>"+(String)
	 * JuvenilleInformationObj.get("ParentAnnualIncome")+"</PARENT_ANNUAL_INC>\r\n"
	 * + "<PARENT_TOTAL_INSURANCE>"+(String)
	 * JuvenilleInformationObj.get("ParentTotalInsurance")+
	 * "</PARENT_TOTAL_INSURANCE>\r\n" + "</Q_JUVENILLE_INFO>";
	 * 
	 * //LifeStyleInformation JSONObject LifeStyleInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("LifeStyleInformation").toString()
	 * );
	 * 
	 * //Adding Data in jsonValidate for Life Style Information
	 * jsonValidate.put("LifeStyleInformation.InvolvedProp", (String)
	 * LifeStyleInformationObj.get("InvolvedProp"));
	 * jsonValidate.put("LifeStyleInformation.InvolvedInsur", (String)
	 * LifeStyleInformationObj.get("InvolvedInsur"));
	 * 
	 * attributesXML = attributesXML + "<Q_LIFE_STYLE_INFO>\r\n" +
	 * "<HAZARDOUS_PROP>"+(String)
	 * LifeStyleInformationObj.get("HazardousProp")+"</HAZARDOUS_PROP>\r\n" +
	 * "<HAZARDOUS_INSUR>"+(String)
	 * LifeStyleInformationObj.get("HazardousInsur")+"</HAZARDOUS_INSUR>\r\n" +
	 * "<CONVICTED_PROP>"+(String)
	 * LifeStyleInformationObj.get("ConvictedProp")+"</CONVICTED_PROP>\r\n" +
	 * "<CONVICTED_INSUR>"+(String)
	 * LifeStyleInformationObj.get("ConvictedInsur")+"</CONVICTED_INSUR>\r\n" +
	 * "<INVOLVED_PROP>"+(String)
	 * LifeStyleInformationObj.get("InvolvedProp")+"</INVOLVED_PROP>\r\n" +
	 * "<INVOLVED_INSUR>"+(String)
	 * LifeStyleInformationObj.get("InvolvedInsur")+"</INVOLVED_INSUR>\r\n" +
	 * "<CONVICT_DETAILS_PROP>"+(String)
	 * LifeStyleInformationObj.get("ConvictDetailsProp")+
	 * "</CONVICT_DETAILS_PROP>\r\n" + "<CONVICT_DETAILS_INSUR>"+(String)
	 * LifeStyleInformationObj.get("ConvictDetailsInsur")+
	 * "</CONVICT_DETAILS_INSUR>\r\n" + "</Q_LIFE_STYLE_INFO>";
	 * 
	 * //OtherPolicyInformation JSONObject OtherPolicyInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("OtherPolicyInformation").toString
	 * ()); attributesXML = attributesXML + "<Q_OTHER_POLICY_INFO>\r\n" +
	 * "<INSUR_POLICY_PROP>"+(String)
	 * OtherPolicyInformationObj.get("InsurPolicyProp")+"</INSUR_POLICY_PROP>\r\n" +
	 * "<INSUR_POLICY_INSUR>"+(String)
	 * OtherPolicyInformationObj.get("InsurPolicyInsur")+"</INSUR_POLICY_INSUR>\r\n"
	 * + "<OFFERED_PROP>"+(String)
	 * OtherPolicyInformationObj.get("OfferedProp")+"</OFFERED_PROP>\r\n" +
	 * "<OFFERED_INSUR>"+(String)
	 * OtherPolicyInformationObj.get("OfferedInsur")+"</OFFERED_INSUR>\r\n" +
	 * "<ISSUED_PROP>"+(String)
	 * OtherPolicyInformationObj.get("IssuedProp")+"</ISSUED_PROP>\r\n" +
	 * "<ISSUED_INSUR>"+(String)
	 * OtherPolicyInformationObj.get("IssuedInsur")+"</ISSUED_INSUR>\r\n" +
	 * "<LIFE_TOTAL_SUM_PROP>"+(String)
	 * OtherPolicyInformationObj.get("LifeTotalSumProp")+
	 * "</LIFE_TOTAL_SUM_PROP>\r\n" + "<LIFE_TOTAL_SUM_INSUR>"+(String)
	 * OtherPolicyInformationObj.get("LifeTotalSumInsur")+
	 * "</LIFE_TOTAL_SUM_INSUR>\r\n" + "<TOTAL_SUM_PROP>"+(String)
	 * OtherPolicyInformationObj.get("TotalSumProp")+"</TOTAL_SUM_PROP>\r\n" +
	 * "<TOTAL_SUM_INSUR>"+(String)
	 * OtherPolicyInformationObj.get("TotalSumInsur")+"</TOTAL_SUM_INSUR>\r\n" +
	 * "</Q_OTHER_POLICY_INFO>";
	 * 
	 * //SpouseInformation JSONObject SpouseInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("SpouseInformation").toString());
	 * attributesXML = attributesXML + "<Q_SPOUSE_INFO>\r\n" +
	 * "<SPOUSE_OCCUPATION>"+(String)
	 * SpouseInformationObj.get("SpouseOccupation")+"</SPOUSE_OCCUPATION>\r\n" +
	 * "<SPOUSE_ANNUAL_INC>"+(String)
	 * SpouseInformationObj.get("SpouseAnnualInc")+"</SPOUSE_ANNUAL_INC>\r\n" +
	 * "<TOTAL_INSUR_COVER>"+(String)
	 * SpouseInformationObj.get("TotalInsurCover")+"</TOTAL_INSUR_COVER>\r\n" +
	 * "</Q_SPOUSE_INFO>";
	 * 
	 * //TravelInformation JSONObject TravelInformationObj = (JSONObject)
	 * jsonParser.parse(MedicalPrevPolInfoObj.get("TravelInformation").toString());
	 * attributesXML = attributesXML + "<Q_TRAVEL_INFO>\r\n" +
	 * "<TRAVEL_PROP>"+(String)
	 * TravelInformationObj.get("TravelProp")+"</TRAVEL_PROP>\r\n" +
	 * "<TRAVEL_INSUR>"+(String)
	 * TravelInformationObj.get("TravelInsur")+"</TRAVEL_INSUR>\r\n" +
	 * "</Q_TRAVEL_INFO>";
	 * 
	 * 
	 * //Proposal_No //to be removed later - prakhar attributesXML = attributesXML +
	 * "<PROPOSAL_NUMBER>"+Proposal_No+"</PROPOSAL_NUMBER>";
	 * 
	 * 
	 * try { //String ValidationRequired="NG_ME_DST_DCNNO"+ (char)(21) +"DCNNO"+
	 * (char)(21)+ "'as123'" +(char)(25); String ValidationRequired=""; //
	 * logger.info(ValidationRequired);
	 * logger.info("attributesXML: "+attributesXML);
	 * 
	 * //Calling Proc to validate all the dropdowns String jsonValidateQuery =
	 * "EXEC NG_SP_NB_VALIDATE_JSON '"+jsonValidate.toString()+"'"; // //getting
	 * sessionID // String inputXML =
	 * XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // String outputXML =
	 * callRestAPI_JTS(inputXML); // sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML);
	 * 
	 * String jsonValidateInputXML =
	 * XMLGen.APSelectWithColumnNames(cabinetName,jsonValidateQuery,sessionID);
	 * logger.info("APSelectWithColumnNames_Input_inputXML: "+jsonValidateInputXML);
	 * //String outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333,
	 * 1); String jsonValidateOutputXML = callRestAPI_JTS(jsonValidateInputXML);
	 * logger.info("APSelectWithColumnNames jsonValidateOutputXML: "
	 * +jsonValidateOutputXML); String
	 * jsonValidateResult=jsonValidateOutputXML.substring(jsonValidateOutputXML.
	 * indexOf("SUCCESS")+8, jsonValidateOutputXML.indexOf("</SUCCESS>"));
	 * logger.info("jsonValidateResult: "+jsonValidateResult);
	 * if(!jsonValidateResult.equalsIgnoreCase("SUCCESS")) { String[] arrOfStr =
	 * jsonValidateResult.split(","); ArrayList<String> jsonValidateArrayStr =new
	 * ArrayList<>();
	 * 
	 * for (String a : arrOfStr) jsonValidateArrayStr.add(a);
	 * 
	 * JSONObject jsonValidateObj =new JSONObject(); jsonValidateObj.put("message",
	 * "Please Validate the fields");
	 * jsonValidateObj.put("fields",jsonValidateArrayStr); return
	 * jsonValidateObj.toString(); }
	 * //attributesXML=URLEncoder.encode(attributesXML); String method = "POST";
	 * //ipAddress = "192.168.54.97"; String url =
	 * "http://"+ipAddress+":9090/iBPSRestFulWebServices/ibps/Restful/"+cabinetName+
	 * "/WFUploadWorkItem"; logger.info("url: " +url); HashMap<String, String> hm =
	 * new HashMap<>(); //hm.put("sessionId", sessionID);
	 * //hm.put("attributeXML",attributesXML);
	 * 
	 * String WFUploadWorkItem_XML="";
	 * 
	 * //attaching documents by creating a folder with the name of proposal number
	 * and then moving the documents to WI in case of //success String
	 * isDocPresent="false"; String statusCode="",errMsg=""; try { //String
	 * ProposalNumber = null; String docResult=""; String proposalFolderIndex =
	 * createFolder(Proposal_No,sessionID);
	 * 
	 * if(proposalFolderIndex.indexOf("Error")==-1) { JSONArray DocumentsArray;
	 * DocumentsArray=(JSONArray)json.get("Documents");
	 * 
	 * for (Object j : DocumentsArray) { JSONObject jsonObj=(JSONObject)j;
	 * //attributesXML = attributesXML + String DocumentCategory = (String)
	 * jsonObj.get("DocumentCategory"); String documentData = (String)
	 * jsonObj.get("DocumentDataBase64"); String DocumentName = (String)
	 * jsonObj.get("DocumentName");
	 * 
	 * String createdByAppName = DocumentName.substring(DocumentName.indexOf(".")+1,
	 * DocumentName.length()); String DocumentNameOD = DocumentName.substring(0,
	 * DocumentName.indexOf(".")); //changed by prakhar String docData =
	 * "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ngo=\"http://bdo.ws.jts.omni.newgen.com/NGOAddDocumentService/\"><soapenv:Header/><soapenv:Body>"
	 * + "<ngo:NGOAddDocumentBDO>" + "<cabinetName>"+cabinetName+"</cabinetName>" +
	 * "<documentPath></documentPath>" +
	 * "<folderIndex>"+proposalFolderIndex+"</folderIndex>" //+
	 * "<folderIndex>"+""+"</folderIndex>" +
	 * "<documentName>"+DocumentCategory+"."+createdByAppName+"</documentName>" +
	 * "<userDBId>"+sessionID+"</userDBId>" + "<volumeId>"+volID+"</volumeId>" +
	 * "<creationDateTime></creationDateTime>" + "<versionFlag>Y</versionFlag>" +
	 * "<accessType>S</accessType>" + "<documentType>N</documentType>" +
	 * "<createdByAppName>"+createdByAppName+"</createdByAppName>" +
	 * "<enableLog>Y</enableLog>" + "<comment>"+DocumentNameOD+"</comment>" +
	 * "<author></author>" + "<FTSFlag>Y</FTSFlag>" + "<groupIndex></groupIndex>" +
	 * "<ownerIndex></ownerIndex>" + "<nameLength></nameLength>" +
	 * "<duplicateName></duplicateName>" + "<textAlsoFlag></textAlsoFlag>" +
	 * "<imageData></imageData>" +
	 * "<transactionRequired></transactionRequired><ownerType></ownerType>" +
	 * "<signFlag></signFlag><thumbNailFlag></thumbNailFlag>" +
	 * "<userName></userName>" +
	 * "<encrFlag></encrFlag><passAlgoType></passAlgoType>" +
	 * "<userPassword></userPassword>" + "<document>"+documentData+"</document>" +
	 * "</ngo:NGOAddDocumentBDO></soapenv:Body></soapenv:Envelope>"; docResult =
	 * uploadDoc(docData); // wfuploadXML = wfuploadXML + docResult;
	 * logger.info("docResult"+docResult); // logger.info(result);
	 * 
	 * if(docResult.indexOf("<statusCode>")!=-1) statusCode =
	 * docResult.substring(docResult.indexOf("<statusCode>")+12,docResult.indexOf(
	 * "</statusCode>"));
	 * 
	 * if(!statusCode.equalsIgnoreCase("0")) { errMsg =
	 * docResult.substring(docResult.indexOf("<message>")+9,docResult.indexOf(
	 * "</message>")); wfuploadXML = wfuploadXML +
	 * "<status>"+statusCode+"</status><message>"+errMsg+"</message>"; } else {
	 * wfuploadXML = wfuploadXML + docResult; isDocPresent = "true";
	 * 
	 * //Inserting doc data to table String
	 * documentType="",isIndex="",noOfPages="",documentSize="",createdByApp="",
	 * comment="",createdDateTime="",
	 * proposalNumber="",DocIndex="",parentFolderIndex=""; documentType =
	 * docResult.substring(docResult.indexOf("<documentName>")+14,docResult.indexOf(
	 * "</documentName>")); isIndex =
	 * docResult.substring(docResult.indexOf("<isIndex>")+9,docResult.indexOf(
	 * "</isIndex>")); isIndex = isIndex.substring(0, isIndex.length() - 1);
	 * //removing last # noOfPages =
	 * docResult.substring(docResult.indexOf("<noOfPages>")+11,docResult.indexOf(
	 * "</noOfPages>")); documentSize =
	 * docResult.substring(docResult.indexOf("<documentSize>")+14,docResult.indexOf(
	 * "</documentSize>")); createdByApp =
	 * docResult.substring(docResult.indexOf("<createdByAppName>")+18,docResult.
	 * indexOf("</createdByAppName>")); comment =
	 * docResult.substring(docResult.indexOf("<comment>")+9,docResult.indexOf(
	 * "</comment>")); createdDateTime =
	 * docResult.substring(docResult.indexOf("<createdDateTime>")+17,docResult.
	 * indexOf("</createdDateTime>")); proposalNumber = Proposal_No; DocIndex =
	 * docResult.substring(docResult.indexOf("<documentIndex>")+15,docResult.indexOf
	 * ("</documentIndex>")); parentFolderIndex =
	 * docResult.substring(docResult.indexOf("<parentFolderIndex>")+19,docResult.
	 * indexOf("</parentFolderIndex>"));
	 * 
	 * String query =
	 * "INSERT INTO NG_NB_DOCUMENTS_UPLOADED (DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP,"
	 * +
	 * " COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX, IS_ASSOCIATED)\r\n"
	 * + "VALUES ('"+documentType+"', '"+isIndex+"', '"+noOfPages+"', '"
	 * +documentSize+"', '"+createdByApp+"'," +
	 * " '"+comment+"', '"+createdDateTime+"', '"+proposalNumber+"', '"
	 * +DocIndex+"', '"+parentFolderIndex+"', 'N')"; // //getting sessionID //
	 * inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML);
	 * 
	 * String inputXML =
	 * XMLGen.APSelectWithColumnNames(cabinetName,query,sessionID);
	 * logger.info("APSelectWithColumnNames_Input_inputXML: "+inputXML); //String
	 * outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); String
	 * outputXML = callRestAPI_JTS(inputXML);
	 * logger.info("APSelectWithColumnNames_outputXML: "+outputXML);
	 * 
	 * } } } else return "{\r\n" + "	\"Exception\":\r\n" + "		{\r\n" +
	 * "			\"statusCode\": 1,\r\n" +
	 * "			\"Subject\":\""+proposalFolderIndex+"\"\r\n"+ "		}\r\n" +
	 * "}"; } catch(Exception ex) { ex.printStackTrace(); return "{\\r\\n\" + \r\n"
	 * + "		        			\"	\\\"Exception\\\":\\r\\n\" + \r\n" +
	 * "		        			\"		{\\r\\n\" + \r\n" +
	 * "		        			\"			\\\"statusCode\\\": 1,\\r\\n\" + \r\n"
	 * + "		        			\"			\\\"Subject\\\":\""+ex.toString()+
	 * "\"\\r\\n\"+\r\n" + "		        			\"		}\\r\\n\" + \r\n" +
	 * "		        			\"}"; }
	 * 
	 * if((statusCode.equalsIgnoreCase("0") &&
	 * isDocPresent.equalsIgnoreCase("true")) ||
	 * isDocPresent.equalsIgnoreCase("false") ) {
	 * 
	 * String documetAttribute=""; if(isDocPresent.equalsIgnoreCase("true")) {
	 * documetAttribute = generateDocument(Proposal_No,sessionID); }
	 * 
	 * // sessionID=callRestAPI(urlSessionID, methodsessionID, hm2); //
	 * if(sessionID.indexOf("<SessionId>")==-1) { // String result = sessionID; //
	 * return result; // } // else { // sessionID =
	 * sessionID.substring(sessionID.indexOf("<SessionId>")+11,
	 * sessionID.indexOf("</SessionId>")); // }
	 * 
	 * WFUploadWorkItem_XML =WFUploadWorkItem_XML + "<WFUploadWorkItem>" +
	 * "<Option>WFUploadWorkItem</Option>" +
	 * "<EngineName>"+cabinetName+"</EngineName>" +
	 * "<SessionId>"+sessionID+"</SessionId>" +
	 * "<ProcessDefId>"+processDefId+"</ProcessDefId>" +
	 * "<InitiateFromActivityId>1</InitiateFromActivityId>" +
	 * "<UserDefVarFlag>Y</UserDefVarFlag>" +
	 * "<Attributes>"+attributesXML+"</Attributes>" +
	 * "<Documents>"+documetAttribute+"</Documents>" + "<PSFlag>Y</PSFlag>"
	 * +"<ValidationRequired>NG_NB_PolicyCheck"+(char)21+"PolicyNumber"+(char)21+"'"
	 * +Proposal_No+"'"+(char)25+"</ValidationRequired>" + "</WFUploadWorkItem>";
	 * hm.put("Content-Type", "application/xml");
	 * 
	 * wfuploadXML=callRestAPI(url, method, WFUploadWorkItem_XML, hm);
	 * logger.info("wfuploadXML: "+ wfuploadXML);
	 * 
	 * logger.info("Disconnecting User..."); String ipXML =
	 * XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
	 * logger.info("ipXMLDisconnect_inputXML: "+ipXML); //String outputXML =
	 * WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); String opXML =
	 * callRestAPI_JTS(ipXML); logger.info("ipXMLDisconnect_outputXML: "+opXML);
	 * 
	 * } else { String delResult=""; wfuploadXML = wfuploadXML + "<statusCode>"+
	 * statusCode+"</statusCode><message>Error in uplodaing document! Workitem Creation failed.</message>"
	 * ; //delResult = deleteFolder(Proposal_No); wfuploadXML = wfuploadXML +
	 * delResult; } } catch (Exception ex) {
	 * 
	 * logger.info("Exception"+ex.getMessage()); wfuploadXML
	 * ="<Exception><Message>"+ex.toString()+"</Message></Exception>" ;
	 * //"<Response><MainCode>1</MainCode><Status>Error</Status><Errormsg>"+ex.
	 * getMessage()+"</Errormsg></Response>"; }
	 * 
	 * org.json.JSONObject jsonObj = XML.toJSONObject(wfuploadXML); wfuploadXML =
	 * jsonObj.toString(4); return wfuploadXML; }
	 */

	public static String uploadDoc(String bodyxml) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");
		String inputXML = bodyxml;
		// http://192.168.54.97:9090/OmniDocsWS/services/NGOAddDocumentService/
		// String sSOAPAction="urn:NGOAddDocumentBDO";
		logger.info("input xml doc upload  " + inputXML);
		// ipAddress = "192.168.54.97";
		String wsurl = "http://" + ipAddress + ":"+port+"/OmniDocsWS/services/NGOAddDocumentService/";
		//for testing
		wsurl = "http://127.0.0.1:"+port+"/OmniDocsWS/services/NGOAddDocumentService/";
		logger.info("wsurl  " + wsurl);
		String connectout = SendXMLToWS(inputXML, wsurl, "");

		logger.info("sRes" + connectout);
		return connectout;
	}

	public static String ExecuteAPI_OD(String bodyxml) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");
		String inputXML = bodyxml;
		logger.info("input xml doc upload  " + inputXML);
		// ipAddress = "192.168.54.97";
		String wsurl = "http://" + ipAddress + ":"+port+"/OmniDocsWS/services/NGOExecuteAPIService/";
		String connectout = SendXMLToWS(inputXML, wsurl, "");

		logger.info("sRes" + connectout);
		return connectout;
	}

	public static String SendXMLToWS(String sXml, String urlval, String SOAPAction) {
		logger.info("sXml" + sXml);
		logger.info("urlval" + urlval);
		String strMsg = "";

		try {

			// Create the connection

			logger.info("starting communication...");

			// Log.generateLog("SOAPAction=" + SOAPAction);

			// Log.generateLog("Input XML=" + sXml);

			SOAPConnectionFactory scf = SOAPConnectionFactory.newInstance();

			SOAPConnection conn = scf.createConnection();

			MessageFactory mf = MessageFactory.newInstance();

			SOAPMessage msg = mf.createMessage();

			SOAPPart sp = msg.getSOAPPart();

			MimeHeaders hd = msg.getMimeHeaders();

			hd.addHeader("SOAPAction", SOAPAction);

			InputStream is = new ByteArrayInputStream(sXml.getBytes());
			StreamSource prepMsg = new StreamSource(is);

			logger.info("sXml" + sXml);
			sp.setContent(prepMsg);

			try {

				msg.saveChanges();

				SOAPMessage rp = conn.call(msg, urlval);

				TransformerFactory tff = TransformerFactory.newInstance();

				Transformer tf = tff.newTransformer();

				Source sc = rp.getSOAPPart().getContent();

				StreamResult result = new StreamResult(System.out);

				tf.transform(sc, result);

				ByteArrayOutputStream out = new ByteArrayOutputStream();

				msg.writeTo(out);

				ByteArrayOutputStream out1 = new ByteArrayOutputStream();

				rp.writeTo(out1);

				strMsg = new String(out1.toByteArray());

				strMsg = strMsg.replace("&gt;", ">");

				strMsg = strMsg.replace("&lt;", "<");
				logger.info("strMsg" + strMsg);

				// Log.generateLog("output XML=" + strMsg);

			} catch (Exception e) {

				logger.info("exception 1:" + e.toString());
				StringWriter sw = new StringWriter();
				e.printStackTrace(new PrintWriter(sw));
				String exceptionAsString = sw.toString();
				logger.info("exceptionAsString 1:" + exceptionAsString);
				e.printStackTrace();

			}

			conn.close();

		} catch (Exception e) {

			logger.info("exception 2:" + e.toString());

		}

		return strMsg;

	}

	/*
	 * public String getPolicyInfo(String policyNo) throws FileNotFoundException,
	 * IOException { String query, inputXML, outputXML, response = "",
	 * cabinetName=""; XMLParser xml = new XMLParser(); propertiesFileData = new
	 * Properties(); Properties props = new Properties(); String configPath =
	 * System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\log4j.properties"; String sessionID=""; try {
	 * 
	 * props.load(new FileInputStream(configPath));
	 * PropertyConfigurator.configure(props);
	 * 
	 * configPath = System.getProperty("user.dir") + File.separator +
	 * "CreateWorkitemService\\config.properties"; FileReader reader = new
	 * FileReader(configPath);
	 * 
	 * logger.info("configPath: " + configPath);
	 * 
	 * propertiesFileData = new Properties(); propertiesFileData.load(reader);
	 * 
	 * cabinetName = propertiesFileData.getProperty("cabinetName"); String ipAddress
	 * = propertiesFileData.getProperty("ipAddress"); String username =
	 * propertiesFileData.getProperty("username"); String password =
	 * propertiesFileData.getProperty("password");
	 * logger.info("cabinetName: policyInfo " + cabinetName);
	 * 
	 * query = "EXEC NG_SP_NB_CREATE_JSON '" + policyNo + "'";
	 * 
	 * //getting sessionID // inputXML =
	 * XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // String sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML);
	 * 
	 * sessionID = getSessionID();
	 * 
	 * inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query,sessionID);
	 * logger.info("inputXML: policyInfo " + inputXML); outputXML =
	 * callRestAPI_JTS(inputXML); logger.info("outputXML: policyInfo " + outputXML);
	 * xml.setInputXML(outputXML);
	 * 
	 * response = xml.getValueOf("SUCCESS").trim();
	 * 
	 * if (response.equalsIgnoreCase("SUCCESS")) { query =
	 * "SELECT PolicyAgentCustomerInfo,PersonalInformation,ProductandPaymentInformation,MedicalAndPreviousPolicyinformation FROM NG_NB_JSON_CALLBACK(NOLOCK) WHERE POLICY_NO='"
	 * + policyNo + "'"; //getting sessionID // inputXML =
	 * XMLGen.get_WMConnect_Input(cabinetName,username,password,"N"); //
	 * logger.info("get_WMConnect_Input_inputXML: "+inputXML); // outputXML =
	 * callRestAPI_JTS(inputXML); // sessionID =
	 * outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf(
	 * "</SessionId>")); //
	 * logger.info("get_WMConnect_Input_outputXML: "+outputXML);
	 * 
	 * inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query,sessionID);
	 * logger.info("inputXML: policyInfo " + inputXML); outputXML =
	 * callRestAPI_JTS(inputXML); logger.info("outputXML: policyInfo " + outputXML);
	 * xml.setInputXML(outputXML); response =
	 * xml.getValueOf("PolicyAgentCustomerInfo")+xml.getValueOf(
	 * "PersonalInformation")+xml.getValueOf("ProductandPaymentInformation")+xml.
	 * getValueOf("MedicalAndPreviousPolicyinformation"); }
	 * 
	 * } catch (Exception e) { System.out.println(e); }
	 * 
	 * //disconnecting user logger.info("Disconnecting User..."); String ipXML =
	 * XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
	 * logger.info("ipXMLDisconnect_inputXML: "+ipXML); //String outputXML =
	 * WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1); String opXML =
	 * callRestAPI_JTS(ipXML); logger.info("ipXMLDisconnect_outputXML: "+opXML);
	 * 
	 * return response; }
	 */

	public static String generateDocument(String Proposal_No, String sessionID) throws IOException, Exception {
		Properties propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		System.out.println("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");

		String result = "";
		String documentType = "", isIndex = "", noOfPages = "", documentSize = "", createdByApp = "", comment = "",
				createdDateTime = "", proposalNumber = "", DocIndex = "", parentFolderIndex = "";

		String query = "SELECT DOCUMENT_TYPE, IS_INDEX, NO_OF_PAGES, DOCUMENT_SIZE, CREATED_BY_APP, COMMENT, CREATED_DATE_TIME, PROPOSAL_NUMBER, DOC_INDEX, PARENT_FOLDER_INDEX\r\n"
				+ "FROM NG_NB_DOCUMENTS_UPLOADED(NOLOCK)\r\n" + "WHERE PROPOSAL_NUMBER = '" + Proposal_No
				+ "' AND IS_ASSOCIATED = 'N'";
//		//getting sessionID
//    	String inputXML = XMLGen.get_WMConnect_Input(cabinetName,username,password,"N");
//        //logger.info("get_WMConnect_Input_inputXML: "+inputXML);      
//        String outputXML = WorkitemDao.callRestAPI_JTS(inputXML);
//        String sessionID = outputXML.substring(outputXML.indexOf("<SessionId>")+11,outputXML.indexOf("</SessionId>"));

		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		System.out.println("APSelectWithColumnNames_Input_inputXML: " + inputXML);
		// String outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
		String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
		System.out.println("APSelectWithColumnNames_outputXML: " + outputXML);

		if (outputXML.indexOf("<Record>") != -1) {
			outputXML = outputXML.substring(outputXML.indexOf("<Records>") + 9, outputXML.indexOf("</Records>"));
			System.out.println(outputXML);
			String out1[] = outputXML.split("<Record>");

			int i = 1;
			while (i < out1.length) {
				// documentIndex =
				// (out1[i].substring(out1[i].indexOf("<documentindex>")+15,out1[i].indexOf("</documentindex>")));

				documentType = out1[i].substring(out1[i].indexOf("<DOCUMENT_TYPE>") + 15,
						out1[i].indexOf("</DOCUMENT_TYPE>"));
				isIndex = out1[i].substring(out1[i].indexOf("<IS_INDEX>") + 10, out1[i].indexOf("</IS_INDEX>"));
				noOfPages = out1[i].substring(out1[i].indexOf("<NO_OF_PAGES>") + 13, out1[i].indexOf("</NO_OF_PAGES>"));
				documentSize = out1[i].substring(out1[i].indexOf("<DOCUMENT_SIZE>") + 15,
						out1[i].indexOf("</DOCUMENT_SIZE>"));
				createdByApp = out1[i].substring(out1[i].indexOf("<CREATED_BY_APP>") + 16,
						out1[i].indexOf("</CREATED_BY_APP>"));
				comment = out1[i].substring(out1[i].indexOf("<COMMENT>") + 9, out1[i].indexOf("</COMMENT>"));
				DocIndex = out1[i].substring(out1[i].indexOf("<DOC_INDEX>") + 11, out1[i].indexOf("</DOC_INDEX>"));

				// update associate value
				query = "UPDATE NG_NB_DOCUMENTS_UPLOADED SET IS_ASSOCIATED = 'Y' where DOC_INDEX = '" + DocIndex + "'";

				inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
				// System.out.println("APSelectWithColumnNames_Input_inputXML: "+inputXML);
				// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
				outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
				// System.out.println("APSelectWithColumnNames_outputXML: "+outputXML);

				if (documentType != "" && isIndex != "" && noOfPages != "" && documentSize != "" && createdByApp != ""
						&& comment != "") {
					result = result + documentType + (char) 21 + isIndex + (char) 21 + noOfPages + " " + (char) 21
							+ documentSize + " " + (char) 21 + createdByApp + (char) 21 + comment + (char) 25;
				}
				i++;
			}
		}

		return result;
	}

	public static String getSessionID() throws FileNotFoundException, IOException {
		String sessionID = "", result = "";

		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");
		String method = "POST";
		String url = "http://" + ipAddress + ":"+port+"/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
				+ "/WMConnect/?userName=" + username + "&UserExist=N";

		HashMap<String, String> hm = new HashMap<>();
		hm.put("Password", password);

		sessionID = callRestAPI(url, method, hm);
		if (sessionID.indexOf("<SessionId>") == -1) {
			result = "Invalid Session ID!";
			return result;
		} else {
			sessionID = sessionID.substring(sessionID.indexOf("<SessionId>") + 11, sessionID.indexOf("</SessionId>"));
			result = sessionID;
		}
		return result;
	}

	public String generateSessionID(InputStream incomingData, String password)
			throws FileNotFoundException, IOException, ParseException, JSONException {
		// TODO Auto-generated method stub
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		// String username = propertiesFileData.getProperty("username");
		// String password = propertiesFileData.getProperty("password");
		// String volID = propertiesFileData.getProperty("volID");

		StringBuilder inputJSON = new StringBuilder();
		String result = "";

		BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
		String line = null;
		try {
			while ((line = in.readLine()) != null) {
				inputJSON.append(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("Data Received: " + inputJSON.toString());

		String dataJSON = inputJSON.toString();

		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser.parse(dataJSON);

		String ibpsUserName = (String) json.get("Username");
		String ibpsPassword = password;
		String port = propertiesFileData.getProperty("port");
		String method = "POST";
		String url = "http://" + ipAddress + ":"+port+"/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
				+ "/WMConnect/?userName=" + ibpsUserName + "&UserExist=N";

		HashMap<String, String> hm = new HashMap<>();
		hm.put("Password", ibpsPassword);

		String sessionIDXML = callRestAPI(url, method, hm);

		org.json.JSONObject jsonObj = XML.toJSONObject(sessionIDXML);
		String sessionIDJSON = jsonObj.toString(4);

		return sessionIDJSON;
	}

	public static String AddDocument_MT(String filePath) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String volID = propertiesFileData.getProperty("volID");
		String jtsIP = propertiesFileData.getProperty("mt_ip");
		String jtsPort = propertiesFileData.getProperty("mt_jts");

		JPDBRecoverDocData oRecoverDocData = new JPDBRecoverDocData();
		JPISIsIndex IsIndex = new JPISIsIndex();

		try {
			CPISDocumentTxn.AddDocument_MT(null, jtsIP, (new Short(jtsPort)).shortValue(), cabinetName,
					(new Short(volID)).shortValue(), filePath, oRecoverDocData, "", IsIndex);
		} catch (JPISException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error";
		}
		// String docString =
		// DocumentCategory + (char)21 + IsIndex.m_nDocIndex+ "#"+ IsIndex.m_sVolumeId +
		// (char)21 + "" + (char)21 + IsIndex.m_nDocSize + (char)21 +
		// createdByAppName + (char)21 + DocumentNameOD + (char)25;
		return IsIndex.m_nDocIndex + "#" + IsIndex.m_sVolumeId;
	}

	public static String base64toFile(String base64String, String ProposalNumber, String fileName) {
		// decoding byte array into base64
		byte[] decodedBytes = Base64.getDecoder().decode(base64String);
		// making a directory inside bin/CreateWorkitemService
		new File(System.getProperty("user.dir") + File.separator + "CreateWorkitemService" + File.separator + "tempDocs"
				+ File.separator + ProposalNumber).mkdirs();
		String filePath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService" + File.separator
				+ "tempDocs" + File.separator + ProposalNumber + File.separator + fileName;
		File file = new File(filePath); // new File("E:\\demo_1.pdf");
		try {

			OutputStream os = new FileOutputStream(file);
			os.write(decodedBytes);
			System.out.println("Writing bytes to file...");
			os.close();
		} catch (Exception e) {
			e.printStackTrace();
			return "Error in creating file from encoded string [CommonFunctions.base64toFile()]";
		}
		return filePath;
	}

	/**
	 * Function to create XML String for External Table Variables
	 * 
	 * @param mapping
	 * @param jsonObj
	 * @return
	 */
	protected static String createXMLString(String mapping, JSONObject jsonObj) {
		// TODO Auto-generated method stub
		String attrXML = "";
		String[] mappingArr = mapping.split(",");

		for (int i = 0; i < mappingArr.length; i++) {
			String key, value;
			String[] keyValArr = mappingArr[i].split("~~");
			key = keyValArr[0];
			value = keyValArr[1];

			attrXML = attrXML + "<" + key + ">" + jsonObj.getOrDefault(value, "").toString() + "</" + key + ">";
		}
		return attrXML;
	}

	/**
	 * Function to create XML String for Queue Variables
	 * 
	 * @param mapping
	 * @param jsonObj
	 * @param QVName
	 * @return
	 */
	protected static String createXMLStringQV(String mapping, JSONObject jsonObj, String QVName) {
		String attrXML = "";
		String[] mappingArr = mapping.split(",");
		attrXML = attrXML + "<" + QVName + ">";
		for (int i = 0; i < mappingArr.length; i++) {
			String key, value;
			String[] keyValArr = mappingArr[i].split("~~");
			key = keyValArr[0];
			value = keyValArr[1];

			attrXML = attrXML + "<" + key + ">" + jsonObj.getOrDefault(value, "").toString() + "</" + key + ">";
		}
		attrXML = attrXML + "</" + QVName + ">";

		return attrXML;
	}

	/**
	 * Function to create XML String for Grid Data
	 * 
	 * @param mapping
	 * @param jsonObj
	 * @param QVName
	 * @return
	 */
	protected static String createXMLStringQVGrid(String mapping, JSONArray jsonObj, String QVName) {
		String attrXML = "";
		String[] mappingArr = mapping.split(",");
		int insertionOrderId = 0, hashID = 1;

		for (Object j : jsonObj) {
			attrXML = attrXML + "<" + QVName + ">";
			JSONObject jsonOb = (JSONObject) j;
			attrXML = attrXML + "<InsertionOrderId>" + insertionOrderId + "</InsertionOrderId>" + "<HashId>" + hashID++
					+ "</HashId>";

			for (int i = 0; i < mappingArr.length; i++) {
				String key, value;
				String[] keyValArr = mappingArr[i].split("~~");
				key = keyValArr[0];
				value = keyValArr[1];
				// if((jsonOb.containsKey((key))))
				attrXML = attrXML + "<" + key + ">" + jsonOb.getOrDefault(value, "").toString() + "</" + key + ">";
			}
			attrXML = attrXML + "</" + QVName + ">";

		}

		return attrXML;

	}

}
