package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import org.xml.sax.InputSource;

import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;

public class FetchDocStatus {
    private static Properties propertiesFileData;
    private static Logger logger = Logger.getLogger("CreateWI");

    public String fetchDocStatusService(InputStream incomingData, String sessionId) {
        String Result = "";
        try {
            // Load properties
            propertiesFileData = new Properties();
            Properties props = new Properties();

            String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService" + File.separator + "log4j.properties";
            props.load(new FileInputStream(configPath));
            PropertyConfigurator.configure(props);

            configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService" + File.separator + "config.properties";
            FileReader reader = new FileReader(configPath);
            logger.info("configPath: " + configPath);

            propertiesFileData = new Properties();
            propertiesFileData.load(reader);

            JSONObject erroObj = createErrorJson("400", "Validation");
            String cabinetName = propertiesFileData.getProperty("cabinetName");
            String ipAddress = propertiesFileData.getProperty("ipAddress");
            String username = propertiesFileData.getProperty("username");
            String password = propertiesFileData.getProperty("password");
            String port = propertiesFileData.getProperty("port");
            String query = "";
            StringBuilder inputJSON = new StringBuilder();

            // Read input data
            try (BufferedReader in = new BufferedReader(new InputStreamReader(incomingData))) {
                String line;
                while ((line = in.readLine()) != null) {
                    inputJSON.append(line);
                }
            } catch (Exception e) {
                logger.error("Error Parsing: - ", e);
            }

            logger.info("Data Received: " + inputJSON.toString());

            String wiData = inputJSON.toString();
            wiData = wiData.replaceAll("'", "''''");
            wiData = wiData.replaceAll("&", "&amp;");
            logger.info("widata: " + wiData);

            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(wiData);
            JSONObject PayloadTagsObj = null;
            JSONObject metadatTagsObj = null;
            String proposalNumber = "", INPUT_XML = "", X_Correlation_ID = "", X_App_ID = "";

            // Extract metadata
            if (json.containsKey("metadata")) {
                logger.info("into if for metadata");
                metadatTagsObj = (JSONObject) jsonParser.parse(json.get("metadata").toString());
                X_Correlation_ID = (String) metadatTagsObj.getOrDefault("X-Correlation-ID", "");
                X_App_ID = (String) metadatTagsObj.getOrDefault("X-App-ID", "");
            }

            // Extract payload
            if (json.containsKey("payload")) {
                logger.info("into if for payload");
                PayloadTagsObj = (JSONObject) jsonParser.parse(json.get("payload").toString());
                proposalNumber = (String) PayloadTagsObj.getOrDefault("proposalNumber", "");

                logger.info("proposalNumber: " + proposalNumber);
                logger.info("INPUT_XML: " + INPUT_XML);
                logger.info("OUTPUT: " + wiData);

                query = "EXEC NG_SP_NB_FETCH_DOCUMENTS '" + proposalNumber + "'";
                logger.info("query: " + query);

                String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionId);
                logger.info("inputXML:" + inputXML);
                String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
                logger.info("outputXML:" + outputXML);

                JSONObject resultObj = new JSONObject();
                JSONArray docArray = new JSONArray();
                logger.info("Array of Docs View");

                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                try {
                    logger.info("try lin1");
                    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                    Document doc = dBuilder.parse(new InputSource(new StringReader(outputXML)));
                    logger.info("try lin2");
                    doc.getDocumentElement().normalize();
                    logger.info("Root element :" + doc.getDocumentElement().getNodeName());
                    NodeList nList = doc.getElementsByTagName("Record");
                    logger.info("try line 3" + nList);
                    int Count = 0;

                    for (int temp = 0; temp < nList.getLength(); temp++) {
                        Node nNode = nList.item(temp);
                        logger.info("\nCurrent Element :" + nNode.getNodeName());

                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement = (Element) nNode;
                            String  JSON = "";

                            JSON = eElement.getElementsByTagName("JSON").item(0).getTextContent();

                            logger.info("json: " + JSON);

                            JSONObject docDetails = new JSONObject();
                            docArray.add(Count, JSON);
                            Count++;
                        }
                    }

                    resultObj.put("metadata", metadatTagsObj);
                    JSONObject responsePayload = new JSONObject();
                    responsePayload.put("DocDetails", docArray);
                    resultObj.put("payload", responsePayload);
                    
                } catch (Exception e) {
                    logger.error("incatch", e);
                }

                //resultObj.put("X-Correlation-ID", X_Correlation_ID);
                //resultObj.put("X-App-ID", X_App_ID);
                Result = resultObj.toJSONString();
            }
        } catch (Exception e) {
            logger.error("Exception in fetchDocStatusService", e);
            e.printStackTrace();
        }

        return Result;
    }

    public JSONObject createErrorJson(String msgCode, String msg) {
        JSONObject error = new JSONObject();
        error.put("msgCode", msgCode);
        error.put("msg", msg);
        return error;
    }
}
