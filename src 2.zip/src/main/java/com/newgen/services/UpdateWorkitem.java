package com.newgen.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;

/**
 * 
 * @author prakhar.saxena
 *
 */
public class UpdateWorkitem {	
	public static Properties propertiesFileData;
	static Logger logger = Logger.getLogger(CommonFunctions.class.getName()); 
	
	public String updateWI(InputStream incomingData)
			throws FileNotFoundException, IOException, ParseException, JSONException {
		propertiesFileData = new Properties();
		Properties props = new Properties();

		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);

		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
		FileReader reader = new FileReader(configPath);

		logger.info("configPath: " + configPath);

		propertiesFileData = new Properties();
		propertiesFileData.load(reader);

		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");

		StringBuilder inputJSON = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
			String line = null;
			while ((line = in.readLine()) != null) {
				inputJSON.append(line);
			}
		} catch (Exception e) {
			logger.info("Error Parsing: - ");
		}

		logger.info("Data Received: " + inputJSON.toString());
		
		XMLParser xml = new XMLParser();
		String wiData = inputJSON.toString();
		String sessionID,response,query="EXEC NG_SP_NB_CALLBACK_JSON '"+wiData+"'";
		
//		String inputXML = XMLGen.get_WMConnect_Input(cabinetName, username, password, "N");
//
//		String outputXML = WorkitemDao.callRestAPI_JTS(inputXML);
//		sessionID = outputXML.substring(outputXML.indexOf("<SessionId>") + 11, outputXML.indexOf("</SessionId>"));
		
		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser.parse(wiData);
		String sessionIDJSON = json.get("SessionID").toString();
		
		if(!sessionIDJSON.equalsIgnoreCase("")&&sessionIDJSON!=null) {
			sessionID = sessionIDJSON;
		}
		else 		
			sessionID = CommonFunctions.getSessionID();

		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);

		String outputXML = callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_outputXML: " + outputXML);
		
		xml.setInputXML(outputXML);
		
		response = xml.getValueOf("SUCCESS").trim();
		//disconnecting user
        logger.info("Disconnecting User...");
		 	String ipXML = XMLGen.get_WMDisConnect_Input(cabinetName,sessionID);
        logger.info("ipXMLDisconnect_inputXML: "+ipXML);
        //String outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
        String opXML = callRestAPI_JTS(ipXML);
        logger.info("ipXMLDisconnect_outputXML: "+opXML);     
		return response;
/*
		JSONParser jsonParser = new JSONParser();
		JSONObject json = (JSONObject) jsonParser.parse(wiData);

		String Proposal_No = json.get("ProposalNumber").toString();

		JSONObject WorkitemDataObj = (JSONObject) jsonParser.parse(json.get("WorkitemData").toString());

		// ipAddress = "192.168.54.97";
		String method = "POST";
		String url = "http://" + ipAddress + ":9090/iBPSRestFulWebServices/ibps/Restful/" + cabinetName
				+ "/WMConnect/?userName=" + username + "&UserExist=N";

		HashMap<String, String> hm = new HashMap<>();
		hm.put("Password", password);

		String sessionID = callRestAPI(url, method, hm);
		String result;
		if (sessionID.indexOf("<SessionId>") == -1) {
			result = "Invalid Session ID!";
			return result;
		} else {
			sessionID = sessionID.substring(sessionID.indexOf("<SessionId>") + 11, sessionID.indexOf("</SessionId>"));
		}

		String winame = "", workitemId = "", attributesXML = "";

		String query = "SELECT processinstanceid,WorkItemId FROM WFINSTRUMENTTABLE(nolock) WHERE processinstanceid IN "
				+ "(SELECT wi_name FROM NG_NB_EXT_TABLE(nolock) WHERE proposal_number='" + Proposal_No + "')";

		String inputXML = XMLGen.get_WMConnect_Input(cabinetName, username, password, "N");

		String outputXML = WorkitemDao.callRestAPI_JTS(inputXML);
		sessionID = outputXML.substring(outputXML.indexOf("<SessionId>") + 11, outputXML.indexOf("</SessionId>"));

		inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);

		outputXML = callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

		if (outputXML.indexOf("<processinstanceid>") == -1) {
			result = "No WI found for given Proposal Number!";
			return result;
		} else {
			winame = outputXML.substring(outputXML.indexOf("<processinstanceid>") + 19,
					outputXML.indexOf("</processinstanceid>"));
			workitemId = outputXML.substring(outputXML.indexOf("<WorkItemId>") + 12,
					outputXML.indexOf("</WorkItemId>"));
		}
		logger.info(json.get("WorkitemData").toString());
		attributesXML = "<DOCFLAG>" + WorkitemDataObj.get("DOCFLAG").toString() + "</DOCFLAG>" + "<CC_FLAG>"
				+ WorkitemDataObj.get("CC_FLAG").toString() + "</CC_FLAG>" + "<DISCREPANCY_FLAG>"
				+ WorkitemDataObj.get("DISCREPANCY_FLAG").toString() + "</DISCREPANCY_FLAG>" + "<AUTO_UW_FLAG>"
				+ WorkitemDataObj.get("AUTO_UW_FLAG").toString() + "</AUTO_UW_FLAG>" + "<MED_KICKOUT_FLAG>"
				+ WorkitemDataObj.get("MED_KICKOUT_FLAG").toString() + "</MED_KICKOUT_FLAG>" + "<ADD_INFO_FLAG>"
				+ WorkitemDataObj.get("ADD_INFO_FLAG").toString() + "</ADD_INFO_FLAG>" + "<DECISION>"
				+ WorkitemDataObj.get("DECISION").toString() + "</DECISION>"
		// "<REQ_IN_FLAG>"+WorkitemDataObj.get("REQ_IN_FLAG").toString()+"</REQ_IN_FLAG>"+
		// "<DELETE_CHILD>"+WorkitemDataObj.get("DELETE_CHILD").toString()+"</DELETE_CHILD>"+
		// "<PI_ATTACHED>"+WorkitemDataObj.get("PI_ATTACHED").toString()+"</PI_ATTACHED>"+
		// "<ULIP_CHECK>"+WorkitemDataObj.get("ULIP_CHECK").toString()+"</ULIP_CHECK>"+
		// "<CET_FLAG>"+WorkitemDataObj.get("CET_FLAG").toString()+"</CET_FLAG>"+
		// "<PROPOSER_NAME>"+WorkitemDataObj.get("PROPOSER_NAME").toString()+"</PROPOSER_NAME>"+
		// "<L2BI_NAME>"+WorkitemDataObj.get("L2BI_NAME").toString()+"</L2BI_NAME>"+
		// "<WORK_STATUS>"+WorkitemDataObj.get("WORK_STATUS").toString()+"</WORK_STATUS>"+
		// "<SUB_STATUS>"+WorkitemDataObj.get("SUB_STATUS").toString()+"</SUB_STATUS>"+
		// "<CASE_TYPE>"+WorkitemDataObj.get("CASE_TYPE").toString()+"</CASE_TYPE>"+
		// "<STRAIGHT_PASS_CASE>"+WorkitemDataObj.get("STRAIGHT_PASS_CASE").toString()+"</STRAIGHT_PASS_CASE>"+
		// "<PRIORITY_TYPE>"+WorkitemDataObj.get("PRIORITY_TYPE").toString()+"</PRIORITY_TYPE>"+
		// "<AFYP>"+WorkitemDataObj.get("AFYP").toString()+"</AFYP>"+
		// "<CHANNEL>"+WorkitemDataObj.get("CHANNEL").toString()+"</CHANNEL>"+
		// "<BRANCH_CODE>"+WorkitemDataObj.get("BRANCH_CODE").toString()+"</BRANCH_CODE>"+
		// "<CASE_AGING>"+WorkitemDataObj.get("CASE_AGING").toString()+"</CASE_AGING>"+
		// "<WORKSTEP_AGING>"+WorkitemDataObj.get("WORKSTEP_AGING").toString()+"</WORKSTEP_AGING>"+
		// "<PLAN_NAME>"+WorkitemDataObj.get("PLAN_NAME").toString()+"</PLAN_NAME>"+
		// "<PLAN_TYPE>"+WorkitemDataObj.get("PLAN_TYPE").toString()+"</PLAN_TYPE>"+
		// "<OBJ_OF_INSURANCE>"+WorkitemDataObj.get("OBJ_OF_INSURANCE").toString()+"</OBJ_OF_INSURANCE>"+
		// "<MONEY_CLEARED>"+WorkitemDataObj.get("MONEY_CLEARED").toString()+"</MONEY_CLEARED>"+
		// "<POSV_RESPONSE>"+WorkitemDataObj.get("POSV_RESPONSE").toString()+"</POSV_RESPONSE>"+
		// //"<PROPOSAL_NUMBER>"+WorkitemDataObj.get("PROPOSAL_NUMBER").toString()+"</PROPOSAL_NUMBER>"+
		// "<CANCELLATION_REASON>"+WorkitemDataObj.get("CANCELLATION_REASON").toString()+"</CANCELLATION_REASON>"+
		// "<CANCELLATION_SUB_REASON>"+WorkitemDataObj.get("CANCELLATION_SUB_REASON").toString()+"</CANCELLATION_SUB_REASON>"+
		// "<CANCELLATION_COMMENTS>"+WorkitemDataObj.get("CANCELLATION_COMMENTS").toString()+"</CANCELLATION_COMMENTS>"+
		// "<ACTION>"+WorkitemDataObj.get("ACTION").toString()+"</ACTION>"+
		// "<REVISED_CANCEL_DATE>"+WorkitemDataObj.get("REVISED_CANCEL_DATE").toString()+"</REVISED_CANCEL_DATE>"+
		// "<ROLLBACK_REASON>"+WorkitemDataObj.get("ROLLBACK_REASON").toString()+"</ROLLBACK_REASON>"+
		// "<ROLLBACK_SUB_REASON>"+WorkitemDataObj.get("ROLLBACK_SUB_REASON").toString()+"</ROLLBACK_SUB_REASON>"+
		// "<ROLLBACK_COMMENTS>"+WorkitemDataObj.get("ROLLBACK_COMMENTS").toString()+"</ROLLBACK_COMMENTS>"+
		// "<QC_USER>"+WorkitemDataObj.get("QC_USER").toString()+"</QC_USER>"+
		// "<UW_USER>"+WorkitemDataObj.get("UW_USER").toString()+"</UW_USER>"+
		// "<SOURCING_SYSTEM>"+WorkitemDataObj.get("SOURCING_SYSTEM").toString()+"</SOURCING_SYSTEM>"+
		// "<PRODUCT_TYPE>"+WorkitemDataObj.get("PRODUCT_TYPE").toString()+"</PRODUCT_TYPE>"+
		// "<MONEY_STATUS>"+WorkitemDataObj.get("MONEY_STATUS").toString()+"</MONEY_STATUS>"+
		// "<COLLECTED_AMOUNT>"+WorkitemDataObj.get("COLLECTED_AMOUNT").toString()+"</COLLECTED_AMOUNT>"+
		// "<CLEARED_AMOUNT>"+WorkitemDataObj.get("CLEARED_AMOUNT").toString()+"</CLEARED_AMOUNT>"+
		// "<BOUNCE_AMOUNT>"+WorkitemDataObj.get("BOUNCE_AMOUNT").toString()+"</BOUNCE_AMOUNT>";
		;
		String updateQuery = "update NG_NB_EXT_TABLE set ";

		if (!WorkitemDataObj.get("DOCFLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "DOCFLAG='" + WorkitemDataObj.get("DOCFLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("CC_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CC_FLAG='" + WorkitemDataObj.get("CC_FLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("DISCREPANCY_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "DISCREPANCY_FLAG='" + WorkitemDataObj.get("DISCREPANCY_FLAG").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("AUTO_UW_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "AUTO_UW_FLAG='" + WorkitemDataObj.get("AUTO_UW_FLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("MED_KICKOUT_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "MED_KICKOUT_FLAG='" + WorkitemDataObj.get("MED_KICKOUT_FLAG").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("ADD_INFO_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ADD_INFO_FLAG='" + WorkitemDataObj.get("ADD_INFO_FLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("DECISION").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "DECISION='" + WorkitemDataObj.get("DECISION").toString() + "',";
		}

		if (!WorkitemDataObj.get("REQ_IN_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "REQ_IN_FLAG='" + WorkitemDataObj.get("REQ_IN_FLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("DELETE_CHILD").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "DELETE_CHILD='" + WorkitemDataObj.get("DELETE_CHILD").toString() + "',";
		}
		if (!WorkitemDataObj.get("PI_ATTACHED").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PI_ATTACHED='" + WorkitemDataObj.get("PI_ATTACHED").toString() + "',";
		}
		if (!WorkitemDataObj.get("ULIP_CHECK").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ULIP_CHECK='" + WorkitemDataObj.get("ULIP_CHECK").toString() + "',";
		}
		if (!WorkitemDataObj.get("CET_FLAG").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CET_FLAG='" + WorkitemDataObj.get("CET_FLAG").toString() + "',";
		}
		if (!WorkitemDataObj.get("PROPOSER_NAME").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PROPOSER_NAME='" + WorkitemDataObj.get("PROPOSER_NAME").toString() + "',";
		}
		if (!WorkitemDataObj.get("L2BI_NAME").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "L2BI_NAME='" + WorkitemDataObj.get("L2BI_NAME").toString() + "',";
		}
		if (!WorkitemDataObj.get("WORK_STATUS").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "WORK_STATUS='" + WorkitemDataObj.get("WORK_STATUS").toString() + "',";
		}
		if (!WorkitemDataObj.get("SUB_STATUS").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "SUB_STATUS='" + WorkitemDataObj.get("SUB_STATUS").toString() + "',";
		}
		if (!WorkitemDataObj.get("CASE_TYPE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CASE_TYPE='" + WorkitemDataObj.get("CASE_TYPE").toString() + "',";
		}
		if (!WorkitemDataObj.get("STRAIGHT_PASS_CASE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "STRAIGHT_PASS_CASE='" + WorkitemDataObj.get("STRAIGHT_PASS_CASE").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("PRIORITY_TYPE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PRIORITY_TYPE='" + WorkitemDataObj.get("PRIORITY_TYPE").toString() + "',";
		}
		if (!WorkitemDataObj.get("AFYP").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "AFYP='" + WorkitemDataObj.get("AFYP").toString() + "',";
		}
		if (!WorkitemDataObj.get("CHANNEL").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CHANNEL='" + WorkitemDataObj.get("CHANNEL").toString() + "',";
		}
		if (!WorkitemDataObj.get("BRANCH_CODE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "BRANCH_CODE='" + WorkitemDataObj.get("BRANCH_CODE").toString() + "',";
		}
		if (!WorkitemDataObj.get("CASE_AGING").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CASE_AGING='" + WorkitemDataObj.get("CASE_AGING").toString() + "',";
		}
		if (!WorkitemDataObj.get("WORKSTEP_AGING").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "WORKSTEP_AGING='" + WorkitemDataObj.get("WORKSTEP_AGING").toString() + "',";
		}
		if (!WorkitemDataObj.get("PLAN_NAME").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PLAN_NAME='" + WorkitemDataObj.get("PLAN_NAME").toString() + "',";
		}
		if (!WorkitemDataObj.get("PLAN_TYPE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PLAN_TYPE='" + WorkitemDataObj.get("PLAN_TYPE").toString() + "',";
		}
		if (!WorkitemDataObj.get("OBJ_OF_INSURANCE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "OBJ_OF_INSURANCE='" + WorkitemDataObj.get("OBJ_OF_INSURANCE").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("MONEY_CLEARED").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "MONEY_CLEARED='" + WorkitemDataObj.get("MONEY_CLEARED").toString() + "',";
		}
		if (!WorkitemDataObj.get("POSV_RESPONSE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "POSV_RESPONSE='" + WorkitemDataObj.get("POSV_RESPONSE").toString() + "',";
		}
		if (!WorkitemDataObj.get("CANCELLATION_REASON").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CANCELLATION_REASON='" + WorkitemDataObj.get("CANCELLATION_REASON").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("CANCELLATION_SUB_REASON").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CANCELLATION_SUB_REASON='"
					+ WorkitemDataObj.get("CANCELLATION_SUB_REASON").toString() + "',";
		}
		if (!WorkitemDataObj.get("CANCELLATION_COMMENTS").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CANCELLATION_COMMENTS='"
					+ WorkitemDataObj.get("CANCELLATION_COMMENTS").toString() + "',";
		}
		if (!WorkitemDataObj.get("ACTION").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ACTION='" + WorkitemDataObj.get("ACTION").toString() + "',";
		}
		if (!WorkitemDataObj.get("REVISED_CANCEL_DATE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "REVISED_CANCEL_DATE='" + WorkitemDataObj.get("REVISED_CANCEL_DATE").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("ROLLBACK_REASON").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ROLLBACK_REASON='" + WorkitemDataObj.get("ROLLBACK_REASON").toString() + "',";
		}
		if (!WorkitemDataObj.get("ROLLBACK_SUB_REASON").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ROLLBACK_SUB_REASON='" + WorkitemDataObj.get("ROLLBACK_SUB_REASON").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("ROLLBACK_COMMENTS").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "ROLLBACK_COMMENTS='" + WorkitemDataObj.get("ROLLBACK_COMMENTS").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("QC_USER").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "QC_USER='" + WorkitemDataObj.get("QC_USER").toString() + "',";
		}
		if (!WorkitemDataObj.get("UW_USER").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "UW_USER='" + WorkitemDataObj.get("UW_USER").toString() + "',";
		}
		if (!WorkitemDataObj.get("SOURCING_SYSTEM").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "SOURCING_SYSTEM='" + WorkitemDataObj.get("SOURCING_SYSTEM").toString() + "',";
		}
		if (!WorkitemDataObj.get("PRODUCT_TYPE").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "PRODUCT_TYPE='" + WorkitemDataObj.get("PRODUCT_TYPE").toString() + "',";
		}
		if (!WorkitemDataObj.get("MONEY_STATUS").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "MONEY_STATUS='" + WorkitemDataObj.get("MONEY_STATUS").toString() + "',";
		}
		if (!WorkitemDataObj.get("COLLECTED_AMOUNT").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "COLLECTED_AMOUNT='" + WorkitemDataObj.get("COLLECTED_AMOUNT").toString()
					+ "',";
		}
		if (!WorkitemDataObj.get("CLEARED_AMOUNT").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "CLEARED_AMOUNT='" + WorkitemDataObj.get("CLEARED_AMOUNT").toString() + "',";
		}
		if (!WorkitemDataObj.get("BOUNCE_AMOUNT").toString().equalsIgnoreCase("")) {
			updateQuery = updateQuery + "BOUNCE_AMOUNT='" + WorkitemDataObj.get("BOUNCE_AMOUNT").toString() + "',";
		}

		updateQuery = updateQuery + " where proposal_number='" + Proposal_No + "'";
		updateQuery = updateQuery.replaceAll(", where", " where");
		// getting sessionID
		inputXML = XMLGen.get_WMConnect_Input(cabinetName, username, password, "N");
		// logger.info("get_WMConnect_Input_inputXML: "+inputXML);
		outputXML = WorkitemDao.callRestAPI_JTS(inputXML);
		sessionID = outputXML.substring(outputXML.indexOf("<SessionId>") + 11, outputXML.indexOf("</SessionId>"));

		inputXML = XMLGen.APSelectWithColumnNames(cabinetName, updateQuery, sessionID);
		logger.info("APSelectWithColumnNames_Input_inputXML: " + inputXML);
		// outputXML = WFCallBroker.execute(inputXML, "192.168.54.97", 3333, 1);
		outputXML = callRestAPI_JTS(inputXML);
		logger.info("APSelectWithColumnNames_outputXML: " + outputXML);

		// String bodyXML="";
		// bodyXML = "<WFSetAttributes_Input>\r\n" +
		// "<Option>WFSetAttributes</Option>\r\n" +
		// "<EngineName>"+cabinetName+"</EngineName>\r\n" +
		// "<SessionId>"+sessionID+"</SessionId>\r\n" +
		// "<ProcessInstanceId>"+winame+"</ProcessInstanceId>\r\n" +
		// "<WorkItemId>"+workitemId+"</WorkItemId>\r\n" +
		// "<UserDefVarFlag>Y</UserDefVarFlag>\r\n" +
		// "<Attributes>\r\n" +
		// attributesXML+
		// "</Attributes>\r\n" +
		// "</WFSetAttributes_Input>";

		// outputXML = callRestAPI_JTS(bodyXML);
		// logger.info("APSelectWithColumnNames_outputXML: "+outputXML);

		org.json.JSONObject jsonObj = XML.toJSONObject(outputXML);
		outputXML = jsonObj.toString(4);
*/
		
	}

	//for sessionID
	public String callRestAPI(String url, String method, HashMap<String, String> request) {
        URL urlForGetRequest;
        //String data = "";
        String readLine = null;
        String returnJSON = "", returnVal = null;
        HttpURLConnection conection;
        try {
            urlForGetRequest = new URL(url);
            conection = (HttpURLConnection) urlForGetRequest.openConnection();
            conection.setRequestMethod(method);

            // logger.info(url);
            // logger.info(method);
            for (String i : request.keySet()) {
                conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
            }
            //conection.setRequestProperty("Authorization", "Basic YzBiYThiNmYtZTNiMC00NjU5LTkwNDktNmNjOGVlYzhhYzRiOlhSY3B4ZWxZQVhHNnR3VFlQcmxRUXBhN1RFc1haY2lp"); // set userId its a sample here
            //conection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); // set userId its a sample here

            conection.setDoOutput(true);

            /*if (method.equalsIgnoreCase("POST")) {

                data = "grant_type=openapi_2lo";
                OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
                obj.write(data);
                obj.close();

            }*/
            /*else if(method.equalsIgnoreCase("GET"))
             {
             apiCount++;
             logger.info("API Count " + apiCount);
             }*/

            int responseCode = conection.getResponseCode();
             logger.info(responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(conection.getInputStream()));
                StringBuffer response = new StringBuffer();
                while ((readLine = in.readLine()) != null) {
                    response.append(readLine);
                }
                in.close();

                returnJSON = response.toString();
                // logger.info("JSON String Result " + response.toString());
                returnVal = returnJSON;
            } else {
                
                //Ariba disconnectUser = new Ariba();
                //disconnectUser.disconnectUser();
                returnVal = "ERROR";
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return returnVal;
    }
	
	public static String callRestAPI_JTS(String Body_XML) throws FileNotFoundException, IOException {
		propertiesFileData = new Properties();
		Properties props = new Properties();
		
		String configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\log4j.properties";
		props.load(new FileInputStream(configPath));
		PropertyConfigurator.configure(props);		
		
		configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
        FileReader reader = new FileReader(configPath);
        
         logger.info("configPath: "+configPath);
        
        propertiesFileData = new Properties();
		propertiesFileData.load(reader);		 
		
		String cabinetName = propertiesFileData.getProperty("cabinetName");
		String ipAddress = propertiesFileData.getProperty("ipAddress");
		String username = propertiesFileData.getProperty("username");
		String password = propertiesFileData.getProperty("password");
		String port = propertiesFileData.getProperty("port");

		
		
        URL urlForGetRequest;        
        String readLine = null;
        String returnJSON = "", returnVal = null;
        HttpURLConnection conection;
        
        //ipAddress = "192.168.54.97";
        
        String method = "POST";
        String url = "http://"+ipAddress+":"+port+"/iBPSRestFulWebServices/ibps/Restful/"+cabinetName+"/WFUploadWorkItem";
        HashMap<String, String> request = new HashMap<>();
        request.put("Content-Type", "application/xml");
        
        try {
            urlForGetRequest = new URL(url);
            conection = (HttpURLConnection) urlForGetRequest.openConnection();
            conection.setRequestMethod(method);

            for (String i : request.keySet()) {
                conection.setRequestProperty(i, request.get(i)); // set userId its a sample here
            }
            
            conection.setDoOutput(true);

            if (method.equalsIgnoreCase("POST")) {
                String data = Body_XML;
                OutputStreamWriter obj = new OutputStreamWriter(conection.getOutputStream());
                obj.write(data);
                obj.close();
            }
            
            int responseCode = conection.getResponseCode();
             logger.info(responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(conection.getInputStream()));
                StringBuffer response = new StringBuffer();
                while ((readLine = in.readLine()) != null) {
                    response.append(readLine);
                }
                in.close();

                returnJSON = response.toString();                
                returnVal = returnJSON;
            } else {
                returnVal = "ERROR";
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return returnVal;
    }

	
}
