package com.newgen.services;

import static com.newgen.services.MyMoneyBackFlow.logger;
import static com.newgen.services.MyMoneyBackFlow.propertiesFileData;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.transform.Result;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JsonObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class MyMoneyBackFlow{


    public static Properties propertiesFileData;
    static Logger logger = Logger.getLogger(CommonFunctions.class.getName());

    public String myMoneyBackFlow(InputStream incomingData, String sessionId) throws IOException {
        String Result = "";
        try {

            propertiesFileData = new Properties();
            Properties props = new Properties();

            String configPath = System.getProperty("user.dir") + File.separator
					+ "CreateWorkitemService\\log4j.properties";
            props.load(new FileInputStream(configPath));
            PropertyConfigurator.configure(props);

            configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
            FileReader reader = new FileReader(configPath);

            logger.info("configPath: " + configPath);

            propertiesFileData = new Properties();
            propertiesFileData.load(reader);

            JSONObject erroObj = createErrorJson("400", "Validation");
            String cabinetName = propertiesFileData.getProperty("cabinetName");
            String ipAddress = propertiesFileData.getProperty("ipAddress");
            String username = propertiesFileData.getProperty("username");
            String password = propertiesFileData.getProperty("password");
            String port = propertiesFileData.getProperty("port");
            String query = "";
            StringBuilder inputJSON = new StringBuilder();
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
                String line = null;
                while ((line = in.readLine()) != null) {
                    inputJSON.append(line);
                }
            } catch (Exception e) {
                logger.info("Error Parsing: - ");
            }

            logger.info("Data Received: " + inputJSON.toString());

            String wiData = inputJSON.toString();
            wiData = wiData.replaceAll("'", "''''");
            wiData = wiData.replaceAll("&", "&amp;");
          
            logger.info("widata: " + wiData);
/*
 {
    "metadata": {
        "X-Correlation-ID": "101507887",
        "X-App-ID": "Automation team",
        "proposalNumber": "153581277"
    },
    "payload": {
        "polNo": "153581277",
        "policyInforceDt": "",
        "policyStatusCd": "C",
        "policyStatusDesc": "Complete",
        "modalPremiuminclusiveGST": "2285.04",
        "shortPremium": "N",
        "status": "Enough money",
        "collectedAmount": "2285",
        "clearAmount": "2285",
        "bounceAmount": "",
        "paymentDate": "2024-01-10",
        "ingBatchDate": "29-01-2024"
    },
    "msgInfo": {
        "msgCode": "200",
        "msg": "Success",
        "msgDescription": "Response Generated Successfully"
    }
}
  */
            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(wiData);
            JSONObject PayloadTagsObj =null;
            JSONObject metadatTagsObj =null;
            String PROPOSAL_NO="", INPUT_XML="", MONEYSTATUS="", COLLECTEDAMOUNT="", CLEAREDAMOUNT="", BOUNCEAMT="", paymentDate="";
            String policyInforceDt="", policyStatusCd="", STATUSDESC="", PREMIUMINCLUDEGST="", SHORTPREMIUM="", X_Correlation_ID="";
            String X_App_ID="";
            
            if(json.containsKey("metadata")) {
				metadatTagsObj = (JSONObject) jsonParser.parse(json.get("metadata").toString());
		    
             X_Correlation_ID = (String)metadatTagsObj.getOrDefault("X-Correlation-ID","");
             X_App_ID = (String)metadatTagsObj.getOrDefault("X-App-ID","");
            
            }
            
       // OUTPUT=wiData.toString();
      if (json.containsKey("payload")) {
		PayloadTagsObj = (JSONObject) jsonParser.parse(json.get("payload").toString());
			
		PROPOSAL_NO = (String)PayloadTagsObj.getOrDefault("polNo","");
		MONEYSTATUS = (String)PayloadTagsObj.getOrDefault("status","");
		COLLECTEDAMOUNT = (String)PayloadTagsObj.getOrDefault("collectedAmount","");
		CLEAREDAMOUNT = (String)PayloadTagsObj.getOrDefault("clearAmount","");
		BOUNCEAMT = (String)PayloadTagsObj.getOrDefault("bounceAmount","");
		paymentDate = (String)PayloadTagsObj.getOrDefault("paymentDate","");
		policyInforceDt = (String)PayloadTagsObj.getOrDefault("policyInforceDt","");
		policyStatusCd = (String)PayloadTagsObj.getOrDefault("policyStatusCd","");
		STATUSDESC = (String)PayloadTagsObj.getOrDefault("policyStatusDesc","");
		PREMIUMINCLUDEGST = (String)PayloadTagsObj.getOrDefault("modalPremiuminclusiveGST","");
		SHORTPREMIUM = (String)PayloadTagsObj.getOrDefault("shortPremium","");
	
		try {
			if(!((paymentDate==null)|| (paymentDate.equals("")))){
				   String date="", month="", year="";
			       String[] d=paymentDate.split("-");       
			       
			       year=d[0];
			       month=d[1];
			       date=d[2];
			       
			       paymentDate=date+"/"+month+"/"+year;
			       System.out.println(paymentDate);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		    logger.info("Error in paymentDate" + e);
			e.printStackTrace();
		}
		
		try {
			if(!((policyInforceDt==null)|| (policyInforceDt.equals("")))){
				   String date="", month="", year="";
			       String[] d=policyInforceDt.split("-");       
			       
			       year=d[0];
			       month=d[1];
			       date=d[2];
			       
			       policyInforceDt=month+"/"+date+"/"+year+" 00:00:00";
			       System.out.println(policyInforceDt);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		logger.info("Error in policyInforceDt" + e);
			e.printStackTrace();
			
		}
     
             
		logger.info("PROPOSAL_NO: " + PROPOSAL_NO);
		logger.info("INPUT_XML: " + INPUT_XML);
		logger.info("OUTPUT: " + wiData);
        logger.info("MONEYSTATUS: " + MONEYSTATUS);
        logger.info("COLLECTEDAMOUNT: " + COLLECTEDAMOUNT);
        logger.info("CLEAREDAMOUNT: " + CLEAREDAMOUNT);
        logger.info("BOUNCEAMT: " + BOUNCEAMT);
        logger.info("paymentDate: " + paymentDate);
    	logger.info("policyInforceDt: " + policyInforceDt);
        logger.info("policyStatusCd: " + policyStatusCd);
        logger.info("STATUSDESC: " + STATUSDESC);
        logger.info("PREMIUMINCLUDEGST: " + PREMIUMINCLUDEGST);
        logger.info("SHORTPREMIUM: " + SHORTPREMIUM);
    
        logger.info("sessionID: " + sessionId);
            
            query = "EXEC NG_NB_SP_MYMONEY_UTIL '" + PROPOSAL_NO + "' , '" + INPUT_XML + "' ,'" + wiData + "' ,'"  + MONEYSTATUS + "','" +
            		COLLECTEDAMOUNT+"','"+CLEAREDAMOUNT+"','"+BOUNCEAMT+"','"+paymentDate+"','"+policyInforceDt+"','"+policyStatusCd+"','"+
            		STATUSDESC+"','"+PREMIUMINCLUDEGST+"','"+SHORTPREMIUM+"'";
            logger.info("query: " + query);
            
            String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionId);
            logger.info("inputXML:" + inputXML);
            String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
            logger.info("outputXML:" + outputXML);
			
            String Response = outputXML.substring(outputXML.indexOf("<MainCode>")+10, outputXML.indexOf("</MainCode>"));
			JSONObject resultObj = new JSONObject();
			
			JSONObject metadataObj = new JSONObject();
		    JSONObject msgInfoObj = new JSONObject();
			JSONObject payloadObj = new JSONObject();
			
			if(Response.equals("0")){
				
		        metadataObj.put("X-Correlation-ID", X_Correlation_ID);
		        metadataObj.put("X-App-ID", X_App_ID);
		       
		        msgInfoObj.put("statusCode" ,"00");
		        msgInfoObj.put("Status" ,"Success");
		        msgInfoObj.put("statusDesc" ,"Status Updated Successfully");
		       
		        resultObj.put("metadata", metadataObj);
		        resultObj.put("msgInfo", msgInfoObj);
		        
			Result=resultObj.toJSONString();
			}
			else {
			    metadataObj.put("X-Correlation-ID", X_Correlation_ID);
		        metadataObj.put("X-App-ID", X_App_ID);
		       
		        msgInfoObj.put("statusCode" ,"11");
		        msgInfoObj.put("Status" ,"Failure");
		        msgInfoObj.put("statusDesc" ,"");
		     
		        resultObj.put("metadata", metadataObj);
		        resultObj.put("msgInfo", msgInfoObj);
		        
			Result=resultObj.toJSONString();
			}
           }
        }
	   catch (Exception e) {
            e.printStackTrace();
        }
        return Result;
    }

    public JSONObject createErrorJson(String msgCode, String msg) {
        JSONObject error = new JSONObject();
        error.put("msgCode", msgCode);
        error.put("msg", msg);
        return error;
    }
}