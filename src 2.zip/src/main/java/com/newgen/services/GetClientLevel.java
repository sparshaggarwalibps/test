/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.services;

import static com.newgen.services.GetClientLevel.logger;
import static com.newgen.services.GetClientLevel.propertiesFileData;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.transform.Result;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.XML;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JsonObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author hp-ab032tx
 */
public class GetClientLevel {

    public static Properties propertiesFileData;
    static Logger logger = Logger.getLogger(CommonFunctions.class.getName());

    public String getClientLevel(InputStream incomingData) throws FileNotFoundException, IOException {
        String Result = "";
        try {

            propertiesFileData = new Properties();
            Properties props = new Properties();

            String configPath = System.getProperty("user.dir") + File.separator
					+ "CreateWorkitemService\\log4j.properties";
			props.load(new FileInputStream(configPath));
			PropertyConfigurator.configure(props);

			configPath = System.getProperty("user.dir") + File.separator + "CreateWorkitemService\\config.properties";
			FileReader reader = new FileReader(configPath);

			logger.info("configPath: " + configPath);

			propertiesFileData = new Properties();
			propertiesFileData.load(reader);

			JSONObject erroObj = createErrorJson("400", "Validation");
			String cabinetName = propertiesFileData.getProperty("cabinetName");
			String ipAddress = propertiesFileData.getProperty("ipAddress");
			String username = propertiesFileData.getProperty("username");
			String password = propertiesFileData.getProperty("password");
			String port = propertiesFileData.getProperty("port");
            String query = "";
            StringBuilder inputJSON = new StringBuilder();
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(incomingData));
                String line = null;
                while ((line = in.readLine()) != null) {
                    inputJSON.append(line);
                }
            } catch (Exception e) {
                logger.info("Error Parsing: - ");
            }

            logger.info("Data Received: " + inputJSON.toString());

            String wiData = inputJSON.toString();
            wiData = wiData.replaceAll("'", "''''");
            wiData = wiData.replaceAll("&", "&amp;");
            int Count=0;
            JSONParser jsonParser = new JSONParser();
            JSONObject json = (JSONObject) jsonParser.parse(wiData);
            String BasePlan = json.getOrDefault("BasePlanCode", "").toString();
            String RoleAge = json.getOrDefault("RoleAgeDuration", "").toString();
            String RiderPlanCode = "";
            String RiderDuration = "";
            
            query = "SELECT PLAN_CODE,RATE_CODE,SMOKER_CODE,GENDER,DEATH_BENEFIT_OPTION,MATURITY_EXPIRY_DURATION,EFFECTIVE_DATE,RATE_AGE_DURATION,MAXIMUM_FACE_AMOUNT FROM NG_NB_MS_CLIENT_LEVEL(NOLOCK) WHERE PLAN_CODE='" + BasePlan + "'" + " AND RATE_AGE_DURATION='" + RoleAge + "'";
         
            
            String sessionIDJSON = json.get("SessionID").toString();
			String sessionID = "";
			if (!sessionIDJSON.equalsIgnoreCase("") && sessionIDJSON != null) {
				sessionID = sessionIDJSON;
			} else
				sessionID = CommonFunctions.getSessionID();


            String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
            logger.info("inputXML:" + inputXML);
            String outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
            logger.info("outputXML:" + outputXML);
            String PlanCode, ratecode, smokercode, gender, deathbenefit, maturityexp, effectivedate, rateage, maxfaceamt = "";
            
            XMLParser xmlData = new XMLParser();
            xmlData.setInputXML(outputXML);
            
            
            PlanCode = xmlData.getFirstValueOf("PLAN_CODE");
          
            ratecode = xmlData.getFirstValueOf("RATE_CODE");
            smokercode = xmlData.getFirstValueOf("SMOKER_CODE");
            gender = xmlData.getFirstValueOf("GENDER");
            maturityexp = xmlData.getFirstValueOf(" MATURITY_EXPIRY_DURATION ");
            deathbenefit = xmlData.getFirstValueOf("DEATH_BENEFIT_OPTION");
            effectivedate = xmlData.getFirstValueOf("EFFECTIVE_DATE");
            rateage = xmlData.getFirstValueOf("RATE_AGE_DURATION");
            maxfaceamt = xmlData.getFirstValueOf("MAXIMUM_FACE_AMOUNT");
           
     
         
            JSONObject resultObj = new JSONObject();
           
            
            resultObj.put("BasePlanCode", PlanCode);
            resultObj.put("RateCode", ratecode);
            resultObj.put("SmokerCode", smokercode);
            resultObj.put("Gender", gender);
            resultObj.put("DeathBenefitOption", deathbenefit);
            resultObj.put("MaturityExpiryDuration", maturityexp);
            resultObj.put("EffectiveDate", effectivedate);
            resultObj.put("RateAgeDuration", rateage);
            resultObj.put("MaximumFaceAmount", maxfaceamt);
            
            
            JSONArray riderArray = new JSONArray();
            
            
            
       JSONArray RiderArray = (JSONArray) json.getOrDefault("Rider", "{}");
          String RPlanCode, Rratecode, Rsmokercode, Rgender, Rdeathbenefit, Rmaturityexp, Reffectivedate, Rrateage, Rmaxfaceamt = "";
       for (Object tag : RiderArray) {
           JSONObject jsonObj = (JSONObject) tag;//row
           // attributesXML = attributesXML +
           RiderPlanCode = (String) jsonObj.get("RiderPlanCode");
           RiderDuration = (String) jsonObj.get("RiderPlanDuration");
           query = "SELECT PLAN_CODE,RATE_CODE,SMOKER_CODE,GENDER,DEATH_BENEFIT_OPTION,MATURITY_EXPIRY_DURATION,EFFECTIVE_DATE,RATE_AGE_DURATION,MAXIMUM_FACE_AMOUNT FROM NG_NB_MS_CLIENT_LEVEL(NOLOCK) WHERE PLAN_CODE='" + RiderPlanCode + "'" + "AND RATE_AGE_DURATION='" + RiderDuration + "'";
           inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
           logger.info("inputXML:" + inputXML);
           outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
           logger.info("outputXML:" + outputXML);
           
           XMLParser xmlData1 = new XMLParser();
           xmlData1.setInputXML(outputXML);
           
           
           RPlanCode = xmlData1.getFirstValueOf("PLAN_CODE");
           Rratecode = xmlData1.getFirstValueOf("RATE_CODE");
           Rsmokercode = xmlData1.getFirstValueOf("SMOKER_CODE");
           Rgender = xmlData1.getFirstValueOf("GENDER");
           Rmaturityexp = xmlData1.getFirstValueOf(" MATURITY_EXPIRY_DURATION ");
           Rdeathbenefit = xmlData1.getFirstValueOf("DEATH_BENEFIT_OPTION");
           Reffectivedate = xmlData1.getFirstValueOf("EFFECTIVE_DATE");
           Rrateage = xmlData1.getFirstValueOf("RATE_AGE_DURATION");
           Rmaxfaceamt = xmlData1.getFirstValueOf("MAXIMUM_FACE_AMOUNT");
       
       JSONObject row = new JSONObject();
       row.put("RiderPlanCode", RPlanCode);
       row.put("RateCode", Rratecode);
       row.put("SmokerCode", Rsmokercode);
       row.put("Gender", Rgender);
       row.put("DeathBenefitOption", Rmaturityexp);
       row.put("MaturityExpiryDuration", Rdeathbenefit);
       row.put("EffectiveDate", Reffectivedate);
       row.put("RateAgeDuration", Rrateage);
       row.put("MaximumFaceAmount", Rmaxfaceamt);
       riderArray.add(Count, row);
       Count++;
       
       
        
                  

       }
       
       resultObj.put("Rider", riderArray);

            
            
         
            
          Result=resultObj.toJSONString();
                     
                       
            //response = xml.getValueOf("SUCCESS").trim();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Result;
    }

    public JSONObject createErrorJson(String msgCode, String msg) {
        JSONObject error = new JSONObject();
        error.put("msgCode", msgCode);
        error.put("msg", msg);
        return error;
    }

}
