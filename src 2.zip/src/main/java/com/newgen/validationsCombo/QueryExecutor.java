package com.newgen.validationsCombo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.newgen.omni.jts.cmgr.XMLParser;
import com.newgen.util.CommonFunctions;
import com.newgen.util.XMLGen;

public class QueryExecutor {

	private static String cabinetName;
	private static String sessionID;
	static XMLParser xml = new XMLParser();

	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public MinMaxValues runMinMaxQuery(String query, String source, String minColName, String maxColName,String Interval) {
		MinMaxValues minMaxValues = new MinMaxValues();

		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			minMaxValues.minValue = xml.getValueOf(minColName);
			minMaxValues.maxValue = xml.getValueOf(maxColName);
			minMaxValues.Interval = xml.getValueOf(Interval);
		}
		return minMaxValues;
	}

	public Map<String, String> runCoverageTermQuery(String query, String source) {
		Map<String, String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Plan_Age_Expiry", xml.getValueOf("Plan_Age_Expiry"));
			hm.put("Secondary_Term_CalC_Code", xml.getValueOf("Secondary_Term_CalC_Code"));
			hm.put("Combo_Minimum_Term", xml.getValueOf("Combo_Minimum_Term"));
			hm.put("Combo_Maximum_Term", xml.getValueOf("Combo_Maximum_Term"));
			hm.put("Minimum_Expiry_Age", xml.getValueOf("Minimum_Expiry_Age"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));

		}
		return hm;
	}

	public Map<String, String> getValidKeyValuePair(String query, String source, String colName, String masterTableName,
			String valueCol, String labelCol) {
		Map<String, String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);

			String validValues = xml.getValueOf(colName); // MDM valid values ( , separated)
			if (validValues != null) {
				String[] validValuesArr = validValues.split(",");
				for (int i = 0; i < validValuesArr.length; i++) {
					hm.put(validValuesArr[i].trim(),
							getValueFromMDM(validValuesArr[i].trim(), masterTableName, source, valueCol, labelCol));
				}
			}
		}
		return hm;
	}

	private String getValueFromMDM(String code, String masterTableName, String source, String valueCol,
			String labelCol) {
		String value = "";
		if (source.equalsIgnoreCase("JSON")) {
			String query = "SELECT " + labelCol + " FROM " + masterTableName + " WHERE " + valueCol + "='" + code + "'";
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			value = xml.getValueOf(labelCol);
		}
		return value;
	}

	public Map<String, String> runPPTQuery(String query, String source) {
		Map<String, String> result = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result.put("Secondary_PPT_Cal_Logic_Code", xml.getValueOf("Secondary_PPT_Cal_Logic_Code"));
			result.put("Secondary_Payment_Term", xml.getValueOf("Secondary_Payment_Term"));
			result.put("Calculation_Value", xml.getValueOf("Calculation_Value"));

		}
		return result;
	}

	/*
	 * Will return sub-channel from Channel Code
	 */
	public String getSubChannelDescFromVal(String Channel, String DefenceChannelCase, String source) {
		String channelDesc = "";
		
		if (source.equalsIgnoreCase("JSON")) {
			if(Channel.equals("A") && DefenceChannelCase.equals("Y"))
				channelDesc ="Defence";
			else if(Channel.equals("BY") && DefenceChannelCase.equals("Y"))
				channelDesc ="TeleSale";  //DR12411
			else{
				String query = "SELECT SUB_CHANNEL FROM NG_NB_MS_CHANNEL_MAPPING_CODE_DESC(NOLOCK) WHERE CHANNEL_CODE = '"
						+ Channel + "' AND SUB_CHANNEL!='Defence' AND SUB_CHANNEL!='TeleSale'";
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			channelDesc = xml.getValueOf("SUB_CHANNEL");
			}
		}
		return channelDesc;
	}

	public EffectiveDateResult runEffectiveDateQuery(String query, String source) {
		EffectiveDateResult effectiveDateResult = new EffectiveDateResult();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			effectiveDateResult.planEffectiveDate = xml.getValueOf("Plan_Effective_Date");
			effectiveDateResult.channelEffectiveDate = xml.getValueOf("Channel_Effective_Date");
			effectiveDateResult.planExpiryDate = xml.getValueOf("Plan_Expiry_Date");
			effectiveDateResult.Product_Dating = xml.getValueOf("Product_Dating");
			
		}
		return effectiveDateResult;
	}

	public Map<String, String> runIssueAgeQuery(String query, String source) {
		Map<String,String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Min_Issue_Age", xml.getValueOf("Min_Issue_Age"));
			hm.put("Max_Issue_Age", xml.getValueOf("Max_Issue_Age"));
			hm.put("Minimum_Expiry_Age", xml.getValueOf("Minimum_Expiry_Age"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));
			hm.put("Secondary_Term_CalC_Code", xml.getValueOf("Secondary_Term_CalC_Code"));
		}
		return hm;
	}

	public HashMap<String, String> runRiderQuery(String query, String source) {
		HashMap<String,String> hm = new HashMap<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Riders", xml.getValueOf("Riders"));
			hm.put("Is_Rider_Mandatory", xml.getValueOf("Is_Rider_Mandatory"));
			hm.put("Rider_Expiry_Plan", xml.getValueOf("Rider_Expiry_Plan"));
			hm.put("Rider_Effective_Plan", xml.getValueOf("Rider_Effective_Plan"));
		}
		return hm;
	}
	
	//Rider Queries
	public HashMap<String, String> runRiderCTQuery(String query) {
		HashMap<String,String> hm = new HashMap<>();

			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("Term_Calc_Cd", xml.getValueOf("Term_Calc_Cd"));
			hm.put("Combo_Minimum_Term", xml.getValueOf("Combo_Minimum_Term"));
			hm.put("Combo_Maximum_Term", xml.getValueOf("Combo_Maximum_Term"));
			hm.put("Secondary_Term_CalC_Code", xml.getValueOf("Secondary_Term_CalC_Code"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));
		
		return hm;
	}
	
	public HashMap<String, String> runRiderPPTQuery(String query) {
		HashMap<String,String> hm = new HashMap<>();

			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("PPT_APPLICABLE", xml.getValueOf("PPT_APPLICABLE"));
			hm.put("PPT_Calc_Cd", xml.getValueOf("PPT_Calc_Cd"));
			hm.put("Minimum_PPT", xml.getValueOf("Minimum_PPT"));
			hm.put("Maximum_PPT", xml.getValueOf("Maximum_PPT"));
			hm.put("Secondary_Term_CalC_Code", xml.getValueOf("Secondary_Term_CalC_Code"));
			hm.put("Calculation", xml.getValueOf("Calculation"));
			hm.put("Maximum_Expiry_Age", xml.getValueOf("Maximum_Expiry_Age"));
			
		return hm;
	}
	//Rider Queries End
	
	public ArrayList runDiscountQuery(String query, String source) {
		ArrayList list = new ArrayList();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			String result = xml.getValueOf("Discount");
			if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					list.add(val.trim());
				}
			}
		}
		return list;
	}

	public String runIsVisibleQuery(String query, String source, String colName) {
		String result="";
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result = xml.getValueOf(colName);			
		}
		return result;
	}

	public String runDBQuery(String source, String query, String colName) {
		String result = "";
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			result = xml.getValueOf(colName);
		}
		return result;
	}

	public ArrayList<String> runCoverMultipleQuery(String query, String source) {
		ArrayList<String> Cover_Multiple = new ArrayList<String>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			String result = xml.getValueOf("Cover_Multiple");
			if(!result.equals("")) {
				String[] resultArr = result.split(",");
				for(String val:resultArr) {
					Cover_Multiple.add(val);
				}
			}
		}
		return Cover_Multiple;
	}

	public Map<String, String> runMinMaxCovMulQuery(String query, String source) {
		Map<String, String> hm = new HashMap<>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("MINIMUM_COV_MUL",xml.getValueOf("MINIMUM_COV_MUL"));
			hm.put("MAXIMUM_COV_MUL",xml.getValueOf("MAXIMUM_COV_MUL"));
		}
		
		return hm;
	}

	public Map<String, String> runBenefitRidersQuery(String query, String source) {
		Map<String, String> hm = new HashMap<String, String>();
		
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			hm.put("MINIMUM_COV_MUL",xml.getValueOf("MINIMUM_COV_MUL"));
			hm.put("MAXIMUM_COV_MUL",xml.getValueOf("MAXIMUM_COV_MUL"));
		}
		
		return hm;
	}
	
	private String runQueryJSON(String query) {
		String outputXML="";
		String inputXML = XMLGen.APSelectWithColumnNames(cabinetName, query, sessionID);
		try {
			outputXML = CommonFunctions.callRestAPI_JTS(inputXML);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return outputXML;
		
	}

	public Map<String, String> runFundsQuery(String source, String fundApplicableQuery) {
		Map<String, String> hm = new HashMap<String,String>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(fundApplicableQuery);
			xml.setInputXML(outputXML);
			int noOfRecords = Integer.parseInt(xml.getValueOf("TotalRetrieved"));
			for(int i=0;i<noOfRecords;i++) {
				hm.put(xml.getNextValueOf("Fund_Code"), xml.getNextValueOf("FUND_LABEL"));
			}
		}
		return hm;
	}

	public ArrayList<String> runPPTQuery2(String query, String source) {
		ArrayList<String> list = new ArrayList<>();
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			int noOfRecords = Integer.parseInt(xml.getValueOf("TotalRetrieved"));
			for(int i=0;i<noOfRecords;i++) {
				list.add(xml.getNextValueOf("Premium_Payment_Term").trim());
			}
		}
		return list;
	}

	public boolean validateFundQuery(String query, String source) {
		int count=0;
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			count = Integer.parseInt(xml.getFirstValueOf("TOTAL_COUNT"));
		}
		if(count==0)
			return false;
		else
			return true;
	}
	
	//Rider Part Starts
	public boolean validateInMaster(String query, String source) {
		int count=0;
		if (source.equalsIgnoreCase("JSON")) {
			String outputXML = runQueryJSON(query);
			xml.setInputXML(outputXML);
			count = Integer.parseInt(xml.getFirstValueOf("TOTAL_COUNT"));
		}
		if(count==0)
			return false;
		else
			return true;
	}
	
}

class MinMaxValues {
	String minValue = "";
	String maxValue = "";
	String Interval="0";
}

class EffectiveDateResult{
	String planEffectiveDate="";
	String channelEffectiveDate="";
	String planExpiryDate = "";;
	String Product_Dating="";
	
	public String getPlanEffectiveDate() {
		return planEffectiveDate;
	}
	public String getChannelEffectiveDate() {
		return channelEffectiveDate;
	}
	public String getPlanExpiryDate() {
		return planExpiryDate;
	}
	public String getProduct_Dating() {
		return Product_Dating;
	}
}
